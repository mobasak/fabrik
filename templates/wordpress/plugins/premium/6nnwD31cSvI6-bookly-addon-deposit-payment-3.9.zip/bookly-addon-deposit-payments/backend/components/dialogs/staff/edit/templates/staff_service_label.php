<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div class="col-lg-3 text-center"><?php echo esc_html_x( 'Deposit', 'portion of the payment', 'bookly' ) ?></div>