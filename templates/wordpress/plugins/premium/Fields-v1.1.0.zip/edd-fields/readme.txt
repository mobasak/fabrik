=== Easy Digital Downloads - Fields ===
Contributors: d4mation, joelworsham
Requires at least: 4.5.0
Requires PHP: 5.6.0
Tested up to: 5.8.3
Requires EDD: 2.4.0
EDD tested up to: 2.11.4.1
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily create custom attributes or meta for your Downloads

== Description ==

Easily create custom attributes or meta for your Downloads

== Changelog ==

= 1.1.0 =
- Improves updater code
- Includes WordPress, PHP, and EDD requirements and Tested To values in the readme.txt file
- Updates Plugin URI in the plugin header to match where it is currently located
- Updates our licensing and support module to the latest version

= 1.0.5 =
- Fixed an issue where when creating a new Download a PHP Notice could be shown to the user after selecting a Field Template Group.
- Added a checkbox to the Settings Screen to opt-in to Beta Releases

= 1.0.4 =
- Output the Fields Table on Download Single when using the Themedd Theme properly
- Fixes potential theme issue where Themes may be overzealous with `!important` for the EDD Frontend Submissions integration
- Fixes issue where the integration with the EDD FES Submission Form was not loading
- Ensures that jQuery UI Sortable and jQuery UI Tooltip is loaded on the Settings Page
- Fixes issue where when editing a Download via the EDD FES Vendor Dashboard any values entered into EDD Fields would not load properly.

= 1.0.3 =
- Fixes PHP 7.X incompatibility when modifying Field Template Groups on the Admin Screen

= 1.0.2 =
- Adds a link to the Field Template Group management screen on the Download Edit Screen
- Replaces `<strong>` with `<th>` in the Table Shortcode
- Fixes an incompatibility with EDD Software Licensing

= 1.0.1 =
- Fix: Shortcode Builder in the WYSIWYG Editor did not always load
- Added `edd_fields_get_all_saved_fields()` and `edd_fields_get_chosen_template()` functions to get the saved Fields or chosen Template for a Download.
    - Each function has respective Filters to dynamically inject Fields or alter the chosen Template for Downloads.
        - These are useful if you want to programmatically add additional Fields based on things like Post Meta or Taxonomy Terms.
        - [See our documentation for an example.](https://realbigplugins.com/docs/easy-digital-downloads-fields/#add-fields-programmatically-to-a-download)
- Updates our Licensing and Support Module to the latest version

= 1.0.0 =
- Initial release