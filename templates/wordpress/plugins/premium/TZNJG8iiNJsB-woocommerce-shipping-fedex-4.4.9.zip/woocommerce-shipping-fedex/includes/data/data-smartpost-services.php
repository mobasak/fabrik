<?php
/**
 * FEDEX Smart Post services in array format.
 *
 * @package WC_Shipping_Fedex
 */

return array(
	'SMART_POST',
);
