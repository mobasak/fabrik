<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div id='<?php echo $slug ?>' class="update-nag notice" style="display: block">
    <h3>Bookly Multisite</h3>
    <p><?php printf( __( '<b>Important!</b> One of your sites does not provide a valid and unique purchase code for the %1$s plugin.<br/>Please note that a separate license is required for each domain where %1$s  is used.', 'bookly-multisite' ), $title ) ?></p>
    <a id="<?php echo $slug ?>_hide" href="#"><?php esc_html_e( 'Dismiss', 'bookly-multisite' ) ?></a>
</div>

<script type="text/javascript">
    jQuery('#<?php echo $slug ?>_hide').click(function (e) {
        e.preventDefault();
        jQuery('#<?php echo $slug ?>').hide();
        jQuery.ajax({
            type: 'POST',
            url:  '<?php echo admin_url( 'admin-ajax.php' ) ?>',
            data: {action: 'bookly_multisite_hide_plugin_notice', plugin: '<?php echo $slug ?>'}
        });
    });
</script>