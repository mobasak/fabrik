jQuery(function($) {
    $('.wp-list-table').on('click', '[data-action=license-dialog]', function() {
        BooklyLicenseDialog.showDialog(() => window.location.reload(), $(this).data('blog-id'));
    });
})