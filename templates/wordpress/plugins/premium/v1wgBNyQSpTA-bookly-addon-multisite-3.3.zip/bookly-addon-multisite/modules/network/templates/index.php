<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div id="bookly-tbs" class="wrap">
    <div class="form-row align-items-center mb-3">
        <h4 class="col m-0"><?php esc_html_e( 'Network', 'bookly-multisite' ) ?></h4>
    </div>
    <div class="card">
        <div class="card-body">
            <table class="table wp-list-table w-100 mb-0">
                <thead>
                <tr>
                    <th><?php esc_html_e( 'Site', 'bookly-multisite' ) ?></th>
                    <th>Bookly Pro</th>
                    <th><?php esc_html_e( 'Purchase Code', 'bookly-multisite' ) ?></th>
                    <th><?php esc_html_e( 'Title', 'bookly-multisite' ) ?></th>
                </tr>
                </thead>
                <tbody>
                <?php
                $status_list           = array(
                    'archived' => array( 'site-archived', esc_html__( 'Archived' ) ),
                    'spam'     => array( 'site-spammed', esc_html_x( 'Spam', 'site' ) ),
                    'deleted'  => array( 'site-deleted', esc_html__( 'Deleted' ) ),
                );
                $class                 = '';
                $bookly_purchase_codes = array();
                /** @var \Bookly\Lib\Base\Plugin[] $bookly_plugins * array with add-ons Plugin class name */
                if ( array_key_exists( 'bookly-addon-pro', $bookly_plugins ) ) {
                    $pro                      = $bookly_plugins['bookly-addon-pro'];
                    $pro_active_for_network   = $pro::isNetworkActive();
                    $pro_basename             = $pro::getBasename();
                    $pro_purchase_code_option = $pro::getPurchaseCodeOption();
                } else {
                    $pro_active_for_network   = false;
                    $pro_basename             = 'bookly-addon-pro/main.php';
                    $pro_purchase_code_option = 'bookly_pro_purchase_code';
                }
                ?>

                <?php foreach ( $wp_list_table->items as $blog ) :
                    $class = ( 'alternate' == $class ) ? '' : 'alternate';
                    // WP4.6+ $blog is WP_Site.
                    $blog_id     = ( $blog instanceof WP_Site ) ? $blog->blog_id : $blog['blog_id'];
                    $blog_states = array();
                    foreach ( $status_list as $status => $col ) {
                        if ( get_blog_status( $blog_id, $status ) == 1 ) {
                            $class         = $col[0];
                            $blog_states[] = $col[1];
                        }
                    }
                    $bookly_active = false;
                    $blog_state    = '';
                    $purchase_code = get_blog_option( $blog_id, $pro_purchase_code_option );
                    $sld           = \BooklyMultisite\Lib\Utils\Common::getSLD( get_home_url( $blog_id ) );
                    if ( ! empty( $blog_states ) ) {
                        $state_count = count( $blog_states );
                        $i           = 0;
                        $blog_state  .= ' - ';
                        foreach ( $blog_states as $state ) {
                            ++ $i;
                            ( $i == $state_count ) ? $sep = '' : $sep = ', ';
                            $blog_state .= "<span class='post-state'>$state$sep</span>";
                        }
                    } else {
                        if ( $pro_active_for_network || in_array( $pro_basename, get_blog_option( $blog_id, 'active_plugins', array() ) ) ) {
                            $bookly_active = true;
                        } else {
                            $bookly_active = false;
                        }
                        if ( isset( $bookly_purchase_codes[ $purchase_code ] )
                            && $bookly_purchase_codes[ $purchase_code ]['domain'] != $sld
                            && $bookly_active
                        ) {
                            $purchase_code = '<span class="dashicons dashicons-warning"> <a href="#" data-action="license-dialog" data-blog-id=' . esc_attr( $blog_id ) . '>' . esc_html__( 'Not valid', 'bookly-multisite' ) . '</a>';
                        } elseif ( $purchase_code ) {
                            $bookly_purchase_codes[ $purchase_code ]['domain'] = $sld;
                        } elseif ( empty( $purchase_code ) && $bookly_active ) {
                            $purchase_code = '<span class="dashicons dashicons-warning"></span> <a href="#" data-action="license-dialog" data-blog-id=' . esc_attr( $blog_id ) . '>' . esc_html__( 'Missing', 'bookly-multisite' ) . '</a>';
                        }
                    }
                    $blogname = get_home_url( $blog_id );
                    ?>
                    <tr class="<?php echo $class ?>">
                        <td class='column-blogname blogname'>
                            <a href="<?php echo esc_url( get_home_url( $blog_id ) ) ?>" class="edit"><?php echo $blogname . $blog_state ?></a>
                            <?php
                            $actions = array(
                                'pcode' => '<span><a href="#" data-action="license-dialog" data-blog-id=' . esc_attr( $blog_id ) . '>' . esc_html__( 'Purchase Code', 'bookly-multisite' ) . '</a></span>',
                                'backend' => '<span class="backend"><a href="' . esc_url( get_admin_url( $blog_id ) ) . '">' . esc_html__( 'Dashboard', 'bookly-multisite' ) . '</a></span>',
                                'visit'   => '<span class="view"><a href="' . esc_url( get_home_url( $blog_id ) ) . '" rel="permalink">' . esc_html__( 'Visit', 'bookly-multisite' ) . '</a></span>',
                            );
                            $bookly_active
                                ? printf( '<div class="row-actions">%s | %s | %s</div>', $actions['pcode'], $actions['backend'], $actions['visit'] )
                                : printf( '<div class="row-actions">%s | %s</div>', $actions['backend'], $actions['visit'] );
                            ?>
                        </td>
                        <td><?php echo $bookly_active ? '✓ ' . esc_html__( 'Active', 'bookly-multisite' ) : esc_html__( 'Not active', 'bookly-multisite' ) ?></td>
                        <td><?php echo $purchase_code ?></td>
                        <td><?php echo wp_trim_words( get_blog_option( $blog_id, 'blogdescription' ), 5 ) ?></td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>