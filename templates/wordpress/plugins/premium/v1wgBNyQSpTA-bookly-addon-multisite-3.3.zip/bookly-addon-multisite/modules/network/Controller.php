<?php
namespace BooklyMultisite\Modules\Network;

use BooklyMultisite\Lib;

class Controller
{
    const page_slug = 'bookly-multisite-network';

    public function index()
    {
        wp_enqueue_style( 'bookly-multisite-bootstrap', plugins_url() . '/bookly-addon-multisite/resources/bootstrap/css/bootstrap.min.css' );

        $this->registerBlogAddons();
        if ( method_exists( '\BooklyPro\Backend\Components\License\Components', 'renderLicenseDialog' ) ) {
            wp_enqueue_script( 'bookly-multisite-list', plugins_url() . '/bookly-addon-multisite/modules/network/resources/js/list.js', array( 'jquery' ), false, true );
            \BooklyPro\Backend\Components\License\Components::renderLicenseDialog();
        }

        $this->_index();
    }

    public function _index()
    {
        $wp_list_table = _get_list_table( 'WP_MS_Sites_List_Table' );
        $wp_list_table->prepare_items();

        $this->registerBlogAddons();
        $bookly_plugins = apply_filters( 'bookly_plugins', array() );

        $this->render( 'index', compact( 'bookly_plugins', 'wp_list_table' ) );
    }

    /**
     * Register Add-ons hooks for some blog.
     *
     * @param int|null $blog_id
     */
    private function registerBlogAddons( $blog_id = null )
    {
        $bookly_plugins = apply_filters( 'bookly_plugins', array() );

        $plugins_dir = dirname( dirname( Lib\Plugin::getMainFile() ) ) . '/';
        foreach ( array( 'bookly-responsive-appointment-booking-tool', 'bookly-addon-pro' ) as $slug ) {
            if ( ! array_key_exists( $slug, $bookly_plugins ) ) {
                $loader = $plugins_dir . $slug . '/autoload.php';
                if ( is_readable( $loader ) ) {
                    include_once $loader;
                }
            }
        }
    }

    /**
     * Render a template file.
     *
     * @param $template
     * @param array $variables
     * @param bool $echo
     * @return string
     * @throws \Exception
     */
    protected function render( $template, $variables = array(), $echo = true )
    {
        extract( $variables );

        // Start output buffering.
        ob_start();
        ob_implicit_flush( 0 );

        try {
            include __DIR__ . '/templates/' . $template . '.php';
        } catch ( \Exception $e ) {
            ob_end_clean();
            throw $e;
        }

        if ( $echo ) {
            echo ob_get_clean();
        } else {
            return ob_get_clean();
        }
    }

}