<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div id="bookly-tbs" class="wrap">
    <div class="form-row align-items-center mb-3">
        <h4 class="col m-0"><?php esc_html_e( 'Settings', 'bookly-multisite' ) ?></h4>
    </div>
    <div class="card">
        <form class="card-body" method="post">
            <div style="max-width: 500px">
                <label for="bookly_multisite_purchase_code" class="control-label"><?php esc_html_e( 'Purchase code', 'bookly-multisite' ) ?></label>
                <input type="text" class="form-control" name="bookly_multisite_purchase_code" id="bookly_multisite_purchase_code" value="<?php echo $purchase_code ?>">
                <small class="form-text text-muted"><?php _e( 'Upon providing your purchase code, you’ll gain access to free updates for Bookly. These updates may include functionality improvements and important security fixes. For more information on where to find your purchase code, please see this <a href="https://hub.bookly.pro/go/bookly-code" target="_blank">page</a>.', 'bookly-multisite' ) ?></small>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-success"><?php esc_html_e( 'Save', 'bookly-multisite' ) ?></button>
            </div>
        </form>
    </div>
</div>