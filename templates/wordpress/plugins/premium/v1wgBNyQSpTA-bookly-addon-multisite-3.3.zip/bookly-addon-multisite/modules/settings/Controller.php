<?php
namespace BooklyMultisite\Modules\Settings;

use BooklyMultisite\Lib;

class Controller
{
    const page_slug = 'bookly-multisite-settings';

    public function index()
    {
        wp_enqueue_style( 'bookly-multisite-bootstrap', plugins_url() . '/bookly-addon-multisite/resources/bootstrap/css/bootstrap.min.css' );
        if ( isset ( $_POST['bookly_multisite_purchase_code'] ) ) {
            if ( is_multisite() ) {
                /** @var \WP_Network $current_site */
                global $current_site;

                update_blog_option( $current_site->blog_id, Lib\Plugin::getPurchaseCodeOption(), $_POST['bookly_multisite_purchase_code'] );
            } else {
                update_option( Lib\Plugin::getPurchaseCodeOption(), $_POST['bookly_multisite_purchase_code'] );
            }
        }
        $purchase_code = Lib\Plugin::getPurchaseCode();

        $this->render( 'index', compact( 'purchase_code' ) );
    }

    /**
     * Render a template file.
     *
     * @param $template
     * @param array $variables
     * @param bool $echo
     * @return string
     * @throws \Exception
     */
    protected function render( $template, $variables = array(), $echo = true )
    {
        extract( $variables );

        // Start output buffering.
        ob_start();
        ob_implicit_flush( 0 );

        try {
            include __DIR__ . '/templates/' . $template . '.php';
        } catch ( \Exception $e ) {
            ob_end_clean();
            throw $e;
        }

        if ( $echo ) {
            echo ob_get_clean();
        } else {
            return ob_get_clean();
        }
    }

}