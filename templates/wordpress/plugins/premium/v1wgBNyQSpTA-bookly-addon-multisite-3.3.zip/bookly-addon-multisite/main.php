<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
/*
Plugin Name: Bookly Multisite (Add-on)
Plugin URI: https://www.booking-wp-plugin.com/?utm_source=bookly_admin&utm_medium=plugins_page&utm_campaign=plugins_page
Description: Bookly Multisite add-on enables Bookly to become a Multisite ready plugin. After installation and activation of this add-on you can use Bookly in your Multisite environment.
Version: 3.3
Author: Nota-Info
Author URI: https://www.booking-wp-plugin.com/?utm_source=bookly_admin&utm_medium=plugins_page&utm_campaign=plugins_page
Text Domain: bookly-multisite
Domain Path: /languages
License: Commercial
Network: true
Update URI: https://hub.bookly.pro
*/

include_once __DIR__ . '/autoload.php';

BooklyMultisite\Lib\Plugin::init();