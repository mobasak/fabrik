<?php
namespace BooklyMultisite\Lib;

class Updater
{
    public function update_3_3()
    {
        $new_pc_key = 'bookly_multisite_purchase_code';
        $old_pc_key = 'bookly_multisite_envato_purchase_code';
        $current_pc = get_option( $old_pc_key, 'missing' );
        if ( $current_pc === 'missing' ) {
            add_option( $new_pc_key, '' );
        } else {
            if ( $current_pc ) {
                add_option( $new_pc_key, $current_pc );
            }
            delete_option( $old_pc_key );
        }
    }

    public function update_1_6()
    {
        foreach ( get_users( array( 'role' => 'administrator' ) ) as $admin ) {
            delete_user_meta( $admin->ID, 'bookly_multisite_dismiss_admin_notice' );
        }
        add_option( 'bookly_multisite_grace_start', time() + 2 * WEEK_IN_SECONDS );
        delete_option( 'bookly_multisite_installation_time' );
    }

    public function update_1_1()
    {
        add_option( 'bookly_multisite_loaded', '1' );
        add_option( 'bookly_multisite_installation_time', time() );
        $this->rename_options( array( 'bookly-multisite_envato_purchase_code' => 'bookly_multisite_envato_purchase_code' ) );
    }

    public function rename_options( array $options )
    {
        foreach ( $options as $deprecated_name => $option_name ) {
            add_option( $option_name, get_option( $deprecated_name ) );
            delete_option( $deprecated_name );
        }
    }

    public function run()
    {
        $db_version = get_option( 'bookly_multisite_db_version' );

        if ( Plugin::getVersion() > $db_version && $db_version !== false ) {
            set_time_limit( 0 );

            $db_version_underscored     = 'update_' . str_replace( '.', '_', $db_version );
            $plugin_version_underscored = 'update_' . str_replace( '.', '_', Plugin::getVersion() );

            $updates = array_filter(
                get_class_methods( $this ),
                function ( $method ) { return strstr( $method, 'update_' ); }
            );
            usort( $updates, 'strnatcmp' );

            foreach ( $updates as $method ) {
                if ( strnatcmp( $method, $db_version_underscored ) > 0 && strnatcmp( $method, $plugin_version_underscored ) <= 0 ) {
                    $this->$method();
                }
            }

            update_option( 'bookly_multisite_db_version', Plugin::getVersion() );
        }
    }

}