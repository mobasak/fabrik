<?php
namespace BooklyMultisite\Lib;

class Actions
{
    /* Bookly Multisite */

    /**
     * Activate Bookly plugins when created new blog (site).
     *
     * @param $blog_id
     */
    protected static function createBlog( $blog_id )
    {
        switch_to_blog( $blog_id );
        /** @var \Bookly\Lib\Base\Plugin[] $bookly_plugins */
        $bookly_plugins = apply_filters( 'bookly_plugins', array() );

        // First install Bookly and Bookly Pro because tables
        // in other add-ons can depend on created tables in Bookly
        foreach ( array_merge( array( 'bookly-responsive-appointment-booking-tool', 'bookly-addon-pro' ), array_keys( $bookly_plugins ) ) as $slug ) {
            if ( array_key_exists( $slug, $bookly_plugins ) ) {
                if ( $bookly_plugins[ $slug ]::isNetworkActive() ) {
                    $bookly_plugins[ $slug ]::activate( false );
                }
                unset( $bookly_plugins[ $slug ] );
            }
        }
        restore_current_blog();
    }

    /**
     * Uninstall Bookly plugins when blog deleted.
     *
     * @param $blog_id
     */
    protected static function deleteBlog( $blog_id )
    {
        switch_to_blog( $blog_id );

        $plugins_dir = dirname( dirname( Plugin::getMainFile() ) ) . '/';

        /** @var \Bookly\Lib\Base\Plugin[] $bookly_plugins */
        $bookly_plugins = apply_filters( 'bookly_plugins', array() );
        if ( ! array_key_exists( 'bookly-responsive-appointment-booking-tool', $bookly_plugins ) ) {
            $bookly = $plugins_dir . 'bookly-responsive-appointment-booking-tool/autoload.php';
            if ( is_readable( $bookly ) ) {
                include_once $bookly;
            }
        }

        // Find all Add-ons
        $all_plugins = $bookly_plugins;
        foreach ( glob( $plugins_dir . 'bookly-addon-*', GLOB_ONLYDIR ) as $path ) {
            $slug = wp_basename( $path );
            if ( ! array_key_exists( $slug, $all_plugins ) ) {
                include_once $path . '/autoload.php';

                /** @var \Bookly\Lib\Base\Plugin $plugin_class */
                $plugin_class = '\\' . implode( '', array_map( 'ucfirst', explode( '-', str_replace( '-addon-', '-', basename( $path ) ) ) ) ) . '\Lib\Plugin';
                $all_plugins[ $plugin_class::getSlug() ] = $plugin_class;
            }
        }

        // Uninstall _ALL_ Bookly Add-ons, Pro, Bookly
        if ( class_exists( '\Bookly\Lib\Plugin' ) && class_exists( '\BooklyPro\Lib\Plugin' ) ) {
            $bookly_pro = $all_plugins['bookly-addon-pro'];
            unset( $all_plugins['bookly-addon-multisite'], $all_plugins['bookly-addon-pro'] );
            foreach ( $all_plugins as $plugin ) {
                $plugin::uninstall( false );
            }
            $bookly_pro::uninstall( false );
            \Bookly\Lib\Plugin::uninstall( false );
        }

        restore_current_blog();
    }

    /**
     * WP < 5.1
     *
     * Create blog
     *
     * @param $blog_id
     * @param $user_id
     * @param $domain
     * @param $path
     * @param $site_id
     * @param $meta
     */
    public static function blogNew( $blog_id, $user_id, $domain, $path, $site_id, $meta )
    {
        self::createBlog( $blog_id );
    }

    /**
     * WP >= 5.1
     *
     * Create blog
     *
     * @param \WP_Site $site
     * @param array    $args
     */
    public static function initializeSite( \WP_Site $site, $args )
    {
        self::createBlog( $site->blog_id );
    }

    /**
     * WP >= 5.1
     * Uninstall Bookly plugins when blog deleted.
     *
     * @param \WP_Site $site
     */
    public static function uninitializeSite( \WP_Site $site )
    {
        self::deleteBlog( $site->blog_id );
    }

    /**
     * WP < 5.1
     * Uninstall Bookly plugins when blog deleted.
     *
     * @param $blog_id
     * @param $drop
     */
    public static function blogDelete( $blog_id, $drop )
    {
        self::deleteBlog( $blog_id );
    }

    /**
     * Activate Bookly plugins on network.
     *
     * @param $plugin_slug
     */
    public static function pluginActivate( $plugin_slug )
    {
        $first_blog = get_current_blog_id();
        /** @var \Bookly\Lib\Base\Plugin $plugin_class */
        $plugin_class = $plugin_slug == 'bookly-responsive-appointment-booking-tool'
            ? '\Bookly\Lib\Plugin'
            : '\\' . implode( '', array_map( 'ucfirst', explode( '-', str_replace( '-addon-', '-', $plugin_slug ) ) ) ) . '\Lib\Plugin';

        foreach ( Plugin::blogsId() as $blog_id ) {
            switch_to_blog( $blog_id );
            $plugin_class::activate( false );
        }
        switch_to_blog( $first_blog );
    }

    /**
     * Uninstall Bookly plugins on network.
     *
     * @param $plugin_slug
     */
    public static function pluginUninstall( $plugin_slug )
    {
        $first_blog = get_current_blog_id();
        $boot_class = $plugin_slug == 'bookly-responsive-appointment-booking-tool'
            ? '\Bookly\Lib\Plugin'
            : '\\' . implode( '', array_map( 'ucfirst', explode( '-', str_replace( '-addon-', '-', $plugin_slug ) ) ) ) . '\Lib\Boot';

        foreach ( Plugin::blogsId() as $blog_id ) {
            switch_to_blog( $blog_id );
            $boot_class::uninstall( false );
        }
        switch_to_blog( $first_blog );
    }

    /**
     * Deactivate Bookly plugins on network.
     *
     * @param $plugin_slug
     */
    public static function pluginDeactivate( $plugin_slug )
    {
        /** @var \Bookly\Lib\Base\Plugin[] $bookly_plugins */
        $bookly_plugins = apply_filters( 'bookly_plugins', array() );
        $first_blog = get_current_blog_id();
        foreach ( Plugin::blogsId() as $blog_id ) {
            switch_to_blog( $blog_id );
            $bookly_plugins[ $plugin_slug ]::deactivate( false );
        }
        switch_to_blog( $first_blog );
    }

    /**
     * Init WP Cron for entire network.
     */
    public static function initWpCronForNetwork()
    {
        global $wpdb;

        $blogs = $wpdb->get_col( $wpdb->prepare( 'SELECT `blog_id`
             FROM ' . $wpdb->blogs . ' 
            WHERE GREATEST(`archived`,`spam`,`deleted`) = 0 
              AND blog_id NOT IN(%d,%d)
         ORDER BY `blog_id` DESC', get_current_blog_id(), get_main_site_id() ) );
        set_time_limit( 0 );
        foreach ( $blogs as $blog_id ) {
            wp_remote_get( get_site_url( $blog_id, 'wp-cron.php' ), array(
                'sslverify' => false,
                'timeout' => 1,
            ) );
        }
    }

    /* Add-on Multisite */

    /**
     * Activate Bookly Multisite (Add-on)
     */
    public static function activate()
    {
        if ( is_network_admin() ) {
            $installer = new Installer();
            $installer->install();
        }
    }

    /**
     * Uninstall Bookly Multisite (Add-on)
     */
    public static function uninstall()
    {
        if ( is_network_admin() ) {
            $installer = new Installer();
            $installer->uninstall();
        }
    }

    /**
     * Add Bookly Multisite menu to Network Admin menu.
     *
     * @param string $parent_slug
     */
    public static function menu( $parent_slug = 'bookly-multisite' )
    {
        $dynamic_position = '80.0000001' . mt_rand( 1, 1000 );
        add_menu_page( 'Bookly Multisite', 'Bookly Multisite', 'manage_options', $parent_slug, '', 'dashicons-networking', $dynamic_position );
        add_submenu_page( $parent_slug, __( 'Network',  'bookly-multisite' ), __( 'Network',  'bookly-multisite' ), 'manage_options', \BooklyMultisite\Modules\Network\Controller::page_slug,  array( new \BooklyMultisite\Modules\Network\Controller,  'index' ) );
        add_submenu_page( $parent_slug, __( 'Settings', 'bookly-multisite' ), __( 'Settings', 'bookly-multisite' ), 'manage_options', \BooklyMultisite\Modules\Settings\Controller::page_slug, array( new \BooklyMultisite\Modules\Settings\Controller, 'index' ) );

        global $submenu;
        unset( $submenu[ $parent_slug ][0] );
    }

    public static function renderPluginsNotice()
    {
        global $wpdb;
        $notices = (array) get_user_meta( get_current_user_id(), 'bookly_notices_silent', true );
        $show_notice = array();
        /** @var \Bookly\Lib\Base\Plugin[] $bookly_plugins * array with add-ons Plugin class name */
        $bookly_plugins = apply_filters( 'bookly_plugins', array() );
        unset ( $bookly_plugins['bookly-responsive-appointment-booking-tool'] );
        foreach ( $bookly_plugins as $plugin_slug => $plugin_class ) {
            if ( is_array( $plugin_class ) ) {
                // Deprecated plugin.
                $message = sprintf( __( 'Plugin %s is deprecated, please update', 'bookly-multisite' ), '<strong>' . $plugin_class['title'] . '</strong>' );
                echo '<div class="notice notice-success is-dismissible"><h3>Bookly Multisite (Add-on)</h3><p>' . $message . '</p></div >';
            } else {
                $time = array_key_exists( $plugin_slug, $notices ) ? $notices[ $plugin_slug ] : 0;
                if ( $time < time() ) {
                    $blogs = $wpdb->get_col( 'SELECT blog_id FROM ' . $wpdb->blogs . ' WHERE GREATEST(archived,spam,deleted) = 0' );
                    $domains = array();
                    $purchase_codes = array();
                    foreach ( $blogs as $blog_id ) {
                        if ( $plugin_class::isNetworkActive() || in_array( $plugin_class::getBasename(), get_blog_option( $blog_id, 'active_plugins', array() ) ) ) {
                            $purchase_code = $plugin_class::getPurchaseCode( $blog_id );
                            $sld = Utils\Common::getSLD( get_home_url( $blog_id ) );
                            if ( isset( $purchase_codes[ $purchase_code ] )
                                 && $purchase_codes[ $purchase_code ]['domain'] != $sld
                            ) {
                                // not valid
                                $show_notice[ $plugin_slug ] = true;
                                $notices[ $plugin_slug ] = 0;
                                break;
                            } elseif ( $purchase_code ) {
                                $purchase_codes[ $purchase_code ]['domain'] = $sld;
                                $domains[] = $sld;
                            } elseif ( empty( $purchase_code ) ) {
                                if ( ! in_array( $sld, $domains ) ) {
                                    // missing
                                    $show_notice[ $plugin_slug ] = true;
                                    $notices[ $plugin_slug ]     = 0;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        $bookly_plugins = apply_filters( 'bookly_plugins', array() );
        foreach ( $show_notice as $plugin_slug => $show ) {
            Utils\Common::render( 'plugin_notice', array( 'title' => '<b>' . call_user_func( array( $bookly_plugins[ $plugin_slug ], 'getTitle' ) ) . '</b>', 'slug' => $plugin_slug ) );
        }
        if ( ! empty( $show_notice ) ) {
            update_user_meta( get_current_user_id(), 'bookly_notices_silent', $notices );
        }
    }

    public static function executeHidePluginNotice()
    {
        $notices = (array) get_user_meta( get_current_user_id(), 'bookly_notices_silent', true );
        if ( isset( $_POST['plugin'] ) ) {
            $notices[ $_POST['plugin'] ] = time() + WEEK_IN_SECONDS;
            update_user_meta( get_current_user_id(), 'bookly_notices_silent', $notices );
        }
    }

    public static function registerWpActions( $prefix )
    {
        $reflection = new \ReflectionClass( '\BooklyMultisite\Lib\Actions' );
        foreach ( $reflection->getMethods( \ReflectionMethod::IS_STATIC ) as $method ) {
            if ( preg_match( '/^execute(.*)/', $method->name, $match ) ) {
                add_action(
                    $prefix . strtolower( preg_replace( '/([a-z])([A-Z])/', '$1_$2', $match[1] ) ),
                    array( $method->class, $method->name )
                );
            }
        }
    }

}