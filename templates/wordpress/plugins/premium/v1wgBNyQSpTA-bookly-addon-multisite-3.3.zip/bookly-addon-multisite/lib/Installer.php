<?php
namespace BooklyMultisite\Lib;

class Installer
{
    /**
     * @var array
     */
    protected $options = array();

    public function __construct()
    {
        // Load l10n for fixtures creating.
        load_plugin_textdomain( 'bookly-multisite', false, Plugin::getSlug() . '/languages' );

        $this->options = array(
            'bookly_multisite_loaded' => '0',
            'bookly_multisite_grace_start' => time() + 2 * WEEK_IN_SECONDS,
            // DB version.
            'bookly_multisite_db_version' => Plugin::getVersion(),
            Plugin::getPurchaseCodeOption() => '',
        );
    }

    /**
     * Install.
     */
    public function install()
    {
        // Create tables and load data if it hasn't been loaded yet.
        if ( ! get_option( 'bookly_multisite_loaded' ) ) {
            $this->loadData();
        }
        update_option( 'bookly_multisite_loaded', '1' );
    }

    /**
     * Load data.
     */
    private function loadData()
    {
        // Add options.
        foreach ( $this->options as $name => $value ) {
            add_option( $name, $value );
        }
    }

    /**
     * Remove data.
     */
    private function removeData()
    {
        // Remove options.
        foreach ( $this->options as $name => $value ) {
            delete_option( $name );
        }
        foreach ( get_users( array( 'role' => 'administrator' ) ) as $admin ) {
            delete_user_meta( $admin->ID, 'bookly_notices_silent' );
        }
    }

    /**
     * Uninstall.
     */
    public function uninstall()
    {
        $this->removeData();
        wp_clear_scheduled_hook( 'bookly_multisite_daily_routine' );
    }
}