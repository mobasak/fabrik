<?php
namespace BooklyMultisite\Lib;

class Plugin
{
    /**
     * Option name for purchase code.
     *
     * @staticvar string
     */
    protected static $purchase_code = 'bookly_multisite_purchase_code';

    /**
     * Plugin slug (used in method "slug").
     *
     * @staticvar string
     */
    protected static $slug = 'bookly-addon-multisite';

    /**
     * Class name of installer.
     *
     * @staticvar string
     */
    protected static $installer;

    /**
     * Plugin title.
     *
     * @staticvar string
     */
    protected static $title;

    /**
     * Plugin version (used in method "version").
     *
     * @staticvar string
     */
    protected static $version;

    /**
     * Path to plugin main file (used in method "mainFile").
     *
     * @staticvar string
     */
    protected static $main_file;

    /**
     * Plugin basename (used in method "basename").
     *
     * @staticvar string
     */
    protected static $basename;

    /**
     * Plugin text domain (used in method "textDomain").
     *
     * @staticvar string
     */
    protected static $text_domain;

    private static $blogs_id = array();

    /**
     * Init plugin.
     */
    public static function init()
    {
        if ( is_multisite() ) {
            self::registerHooks();
        }
        self::initUpdateChecker();
    }

    /**
     * Get plugin basename.
     *
     * @return string
     */
    public static function getBasename()
    {
        if ( static::$basename === null ) {
            static::$basename = plugin_basename( static::getMainFile() );
        }

        return static::$basename;
    }

    /**
     * Get plugin purchase code option.
     *
     * @return string
     */
    public static function getPurchaseCodeOption()
    {
        return static::$purchase_code;
    }

    /**
     * Get plugin purchase code.
     *
     * @return string
     */
    public static function getPurchaseCode()
    {
        if ( is_multisite() ) {
            /** @var \WP_Network $current_site */
            global $current_site;

            return get_blog_option( $current_site->blog_id, self::getPurchaseCodeOption() );
        } else {
            return get_option( self::getPurchaseCodeOption() );
        }
    }

    public static function registerHooks()
    {
        /** @var Actions $actions */
        $actions = __NAMESPACE__ . '\Actions';

        add_action( 'plugins_loaded', function () use ( $actions ) {
            // Register hourly routine.
            if ( is_main_site() ) {
                add_action( 'bookly_multisite_hourly_routine', array( $actions, 'initWpCronForNetwork' ), 10, 0 );
                // Schedule hourly routine.
                if ( ! wp_next_scheduled( 'bookly_multisite_hourly_routine' ) ) {
                    wp_schedule_event( current_time( 'timestamp' ), 'hourly', 'bookly_multisite_hourly_routine' );
                }
            }
        } );

        add_action( 'switch_blog', function ( $blog, $prev_blog_id ) {
            if ( method_exists( '\Bookly\Lib\Base\Cache', 'dropCache' ) ) {
                \Bookly\Lib\Base\Cache::dropCache();
            }
        }, 10, 2 );

        if ( is_admin() ) {
            // When uninstall plugin, network admin is only admin.
            add_action( 'bookly_plugin_uninstall',  array( $actions, 'pluginUninstall' ), 10, 1 );

            if ( defined( 'DOING_AJAX' ) && defined( 'BLOG_ID_CURRENT_SITE' ) && BLOG_ID_CURRENT_SITE === get_current_blog_id() ) {
                add_action( 'plugins_loaded', function() {
                    if ( ! has_action( 'wp_ajax_bookly_pro_verify_purchase_code_form' ) ) {
                        $bookly_plugins = apply_filters( 'bookly_plugins', array() );

                        $plugins_dir = dirname( dirname( Plugin::getMainFile() ) ) . '/';
                        foreach ( array( 'bookly-responsive-appointment-booking-tool', 'bookly-addon-pro' ) as $slug ) {
                            if ( ! array_key_exists( $slug, $bookly_plugins ) ) {
                                $loader = $plugins_dir . $slug . '/autoload.php';
                                if ( is_readable( $loader ) ) {
                                    include_once $loader;
                                }
                            }
                        }
                        if ( method_exists( '\BooklyPro\Backend\Components\License\Ajax', 'init' ) ) {
                            \BooklyPro\Backend\Components\License\Ajax::init();
                        }
                    }
                }, 11 );
            }
        }

        if ( is_network_admin() ) {
            global $wp_version;

            $updates = new Updater();
            $updates->run();

            // Add handlers to Bookly actions.
            add_action( 'bookly_plugin_activate',   array( $actions, 'pluginActivate' ), 10, 1 );
            add_action( 'bookly_plugin_deactivate', array( $actions, 'pluginDeactivate' ), 10, 1 );

            // Network hooks
            if ( version_compare( $wp_version, '5.1', '>=' ) ) {
                add_action( 'wp_initialize_site',       array( $actions, 'initializeSite' ), 10, 2 );
                add_action( 'wp_uninitialize_site',     array( $actions, 'uninitializeSite' ), 10, 1 );
            } else {
                add_action( 'wpmu_new_blog',            array( $actions, 'blogNew' ), 10, 6 );
                add_action( 'delete_blog',              array( $actions, 'blogDelete' ), 10, 2 );
            }

            add_action( 'network_admin_menu',       array( $actions, 'menu' ), 10, 0 );
            add_action( 'network_admin_notices',    array( $actions, 'renderPluginsNotice' ), 10, 0 );

            register_activation_hook( self::getMainFile(), array( $actions, 'activate' ) );
            register_uninstall_hook( self::getMainFile(),  array( $actions, 'uninstall' ) );
        }

        // Register ajax actions.
        Actions::registerWpActions( 'wp_ajax_bookly_multisite_' );
    }


    public static function initUpdateChecker()
    {
        if ( self::getPurchaseCode() ) {

            include_once __DIR__ . '/utils/plugin-update-checker.php';

            add_filter( 'puc_manual_check_link-' . static::getSlug(), function () {
                return __( 'Check for updates', 'bookly-multisite' );
            } );

            add_filter( 'puc_manual_check_message-' . static::getSlug(), function ( $message, $status ) {
                switch ( $status ) {
                    case 'no_update':        return __( 'This plugin is up to date.', 'bookly-multisite' );
                    case 'update_available': return __( 'A new version of this plugin is available.', 'bookly-multisite' );
                    default:                 return sprintf( __( 'Unknown update checker status "%s"', 'bookly-multisite' ), htmlentities( $status ) );
                }
            }, 10, 2 );

            $plugin_version = self::getVersion();
            $plugin_slug    = self::getSlug();
            $purchase_code  = self::getPurchaseCodeOption();
            add_filter( 'puc_request_info_query_args-' . self::getSlug(), function( $queryArgs ) use ( $plugin_version, $plugin_slug, $purchase_code ) {

                $queryArgs['site_url']      = site_url();
                $queryArgs['purchase_code'] = get_option( $purchase_code );
                unset ( $queryArgs['checking_for_updates'] );

                return $queryArgs;
            } );

            \PucFactory::buildUpdateChecker(
                strlen( self::getPurchaseCode() ) === 19
                    ? 'https://cloud.bookly.pro/1.2/plugins/bookly-addon-multisite/update'
                    : 'https://hub.bookly.pro/1.2/plugins/bookly-addon-multisite/update',
                self::getMainFile(),
                self::getSlug(),
                24
            );
        } else {
            $plugin_basename = static::getBasename();
            add_filter( 'plugin_row_meta', function ( $links, $plugin ) use ( $plugin_basename )  {
                if ( $plugin == $plugin_basename ) {
                    return array_merge(
                        $links,
                        array(
                            0 => '<span class="dashicons dashicons-info"></span> ' .
                                 sprintf(
                                     __( 'To update - enter the <a href="%s">Purchase code</a>', 'bookly-multisite' ),
                                     Utils\Common::escNetworkAdminUrl( \BooklyMultisite\Modules\Settings\Controller::page_slug )
                                 ),
                        )
                    );
                }
                return $links;
            }, 10, 2 );
        }
    }

    public static function blogsId()
    {
        global $wpdb;

        // WP 5.2.1 when click delete plugin in multisite, WP make XHR request wp-admin/admin-ajax.php and is_network_admin() return false
        // Changed is_network_admin() to is_multisite() for AJAX request
        if ( empty ( self::$blogs_id ) ) {
            if ( ( defined( 'DOING_AJAX' ) && DOING_AJAX && is_multisite() )
                || is_network_admin() ) {
                self::$blogs_id = $wpdb->get_col( 'SELECT `blog_id` FROM ' . $wpdb->blogs . ' ORDER BY `blog_id` DESC' );
            }
        }

        return self::$blogs_id;
    }

    /**
     * Get plugin version.
     *
     * @return mixed
     */
    public static function getVersion()
    {
        if ( self::$version == null ) {
            if ( ! function_exists( 'get_plugin_data' ) ) {
                require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            }
            $plugin_data = get_plugin_data( self::getMainFile(), false, false );
            self::$version     = $plugin_data['Version'];
            self::$title       = $plugin_data['Name'];
            self::$text_domain = $plugin_data['TextDomain'];
        }

        return self::$version;
    }

    /**
     * Get plugin text domain.
     *
     * @return string
     */
    public static function getTextDomain()
    {
        if ( self::$text_domain === null ) {
            if ( ! function_exists( 'get_plugin_data' ) ) {
                require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
            }
            $plugin_data = get_plugin_data( self::getMainFile() );
            self::$version     = $plugin_data['Version'];
            self::$title       = $plugin_data['Name'];
            self::$text_domain = $plugin_data['TextDomain'];
        }

        return static::$text_domain;
    }

    public static function getSlug()
    {
        return self::$slug;
    }

    public static function getMainFile()
    {
        return BOOKLY_MULTISITE_PATH . '/main.php';
    }

}