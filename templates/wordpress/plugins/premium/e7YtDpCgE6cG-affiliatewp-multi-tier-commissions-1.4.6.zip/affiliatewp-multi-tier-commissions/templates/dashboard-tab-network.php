<div id="affwp-affiliate-dashboard-network" class="affwp-tab-content">

	<?php \AffiliateWP\MTC\affiliate_wp_mtc()->frontend->render_network_link(); ?>
	<?php \AffiliateWP\MTC\affiliate_wp_mtc()->frontend->render_network(); ?>

</div>
