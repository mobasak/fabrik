=== Cart Lift - Abandoned Cart Recovery for WooCommerce and EDD ===
Contributors: rextheme, coderexco
Tags: cart abandonment, woocommerce,cart recovery,abandoned carts,edd,woocommerce abandoned cart,abandonment cart email,abandonment recovery,abandoned cart woocommerce,abandoned shopping cart,woocommerce recover abandoned cart,easy digital downloads,lost sales, recover lost sales
Donate link: https://rextheme.com/cart-lift/
Requires at least: 5.0 or higher
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 2.1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cart Lift is an abandoned cart recovery plugin for WooCommerce and EDD stores that lets you implement an automated email recovery campaign to win back abandon cart customers and lost sales.

== Description ==
Are you concerned about the high abandoned rate on your site? Did you waste a lot of time and money trying to stop abandoned carts or to recover them?

With Cart Lift, now you can recover around 20% of your abandoned cart customers without much effort. No more wasted hours and unreasonable expenses on other tools.



💰 Why Cart Lift? 💰
Cart Lift has everything you need to set up and run a successful abandoned cart recovery campaign for your WooCommerce or Easy Digital download based shopping cart.

Using Cart Lift, you can create engaging e-mail campaigns easily, to automatically reach customers who abandoned shopping carts on your site.

You can:

👍 Set strategic intervals to reach prospects for greater results
👍 Use proven e-mail templates with multiple follow-ups
👍 Get exclusive reports to your campaign and recovered sales profit

The plugin is aimed at helping you reach win back abandoned customers and increase revenue.

Plus you can get exclusive features that are easy to use and takes only a few minutes to configure.

⌛Track Abandoned Cart Automatically (GDPR compatible ⌛

The plugin can automatically track the abandoned carts on your site. Every time a person leaves your site with their shopping carts full, the plugin collects the data for that cart and initiates the recovery on your set time intervals.

📧Set Up Your Campaign In A Few Clicks📧
You can set up your recovery campaign really quick. Simply decide on the Subject line and a compelling email copy, and activate the campaign. The plugin will do the rest.

A super easy interface to edit the email copy.*

📩Set Strategic Intervals To Send Emails📩
Set up multiple emails to be sent as a reminder for the cart abandonment. Set the amount of time after which each recovery email will be sent since the cart abandonment.

📊Get Full Analytics On Revenue Recovered📊
The plugin gives you an accurate analytics board where you can know exactly how many abandoned carts you faced, how much were they worth, how many were you able to recover, and how much money did you win back.

⚙️Easy Integrate SMTP⚙️Make sure you're using the targeted keyword enough and Persuasive copy

By default, the plugin uses your website's SMTP (if you have any), or you can easily set up SMTP for the recovery campaign within the plugin. No complications.

>  You will get a **reliable support team** to help you out at all times and detailed [documentation](https://rextheme.com/docs/cart-lift/).


== Fully Compatible ==

The plugin is compatible with any themes and can handle any number of abandoned carts you face through WooCommerce or Easy Digital Downloads.


== Features ==

* Specialized for WooCommerce and EDD
* Full analytics on the recovery campaign
* Auto-track of Abandoned Carts
* Notify Admin When A Cart is Abandoned
* Set Intervals To Send Emails Since Abandonment
* Customize Email through Rich Text Editor
* Apply Coupon/Discount
* Run 2 E-mail Campaigns At Once
* Add External Webhook
* Set Abandoned Cart Expire Date
* Send Test Emails To Check
* Set Up SMTP for any email services
* Full compatible with all themes

== Pro Features: ==

* All Free features
* Run Unlimited E-mail Campaign
* Get Cart Details For Abandoned Customers
* Notify Admin For Every Cart Recovered
* Add specific product/category based Conditional Coupons To Email Campaign(s)
* Track How Many Emails Were Sent

>  If you want to know more about the [Pro version then click here!](https://rextheme.com/cart-lift/)


## Privacy Policy
Cart Lift uses [Appsero](https://appsero.com) SDK to collect some telemetry data upon user's confirmation. This helps us to troubleshoot problems faster & make product improvements.

Appsero SDK **does not gather any data by default.** The SDK only starts gathering basic telemetry data **when a user allows it via the admin notice**. We collect the data to ensure a great user experience for all our users.

Integrating Appsero SDK **DOES NOT IMMEDIATELY** start gathering data, **without confirmation from users in any case.**

Learn more about how [Appsero collects and uses this data](https://appsero.com/privacy-policy/).


== Installation ==
1. Upload the Cart Lift Plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Now a new menu 'Cart Lift' will appear in Dashboard menus.

== Frequently Asked Questions ==
= Can I run more than 2 email campaigns? =
In the Free plugin, you can only run 2 email campaigns at once.

For more campaigns, you have to use the Pro plugin.
= How can I set up the Auto-track of abandoned carts? =
Go to Dashboard > Cart Lift and click on the Settings tab.

There you will find the option to Enable Abandon Cart Tracking.

Enable it and you are all set.
= Will it work if I don't use WooCommerce Or EDD? =
The plugin is specialized for WooCommerce and Easy Digital Downloads. So you have to be using one of the two to be able to use this plugin.

= Can I use MailChimp to send emails? =
You can easily set up the SMTP for any of your email services, including mail chimp, within Cart Lift. Once you integrate it, the emails will be sent through your email provider.

**If your SMTP is already set up for the site, then Cart Lift will use that by default. In that case, integrate SMTP to Cart Lift only when you want to use another email provider.
=  How do I upgrade to pro? =
The Pro plugin is not launched yet. Please stay tuned as it will be launched soon with more useful features.

== Screenshots ==
1. Cart Lift Plugin Dashboard
2. Campaigns
3. Campaign Edit
4. General Settings
5. Email Basic Settings
6. SMTP Set up
7. Abandoned Carts
8. Cart Preview
9. Analytics

== Changelog ==

= 1.1.0 (2020-06-18) =
* Added: Add to cart popup for guest users

= 1.0.0 (2020-06-16) =
* Initial Release

== Upgrade Notice ==
Initial Release