<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://rextheme.com/
 * @since      1.0.0
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/includes
 * @author     RexTheme <info@rextheme.com>
 */
class Cart_Lift_Pro_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
        wp_clear_scheduled_hook( 'cart_lift_license_check' );
		wp_clear_scheduled_hook( 'cart_lift_weekly_report_to_site_admin' );
	}

}
