<?php

if( !function_exists( 'cl_get_user_ip' ) ) {
	/**
	 * Gets current users ip
	 *
	 * @return mixed|string
	 */
	function cl_get_user_ip()
	{
		if( isset( $_SERVER[ 'HTTP_CLIENT_IP' ] ) && $_SERVER[ 'HTTP_CLIENT_IP' ] ) {
			return $_SERVER[ 'HTTP_CLIENT_IP' ];
		}
		else if( isset( $_SERVER[ 'HTTP_X_FORWARDED_FOR' ] ) && $_SERVER[ 'HTTP_X_FORWARDED_FOR' ] ) {
			return $_SERVER[ 'HTTP_X_FORWARDED_FOR' ];
		}
		else if( isset( $_SERVER[ 'HTTP_X_FORWARDED' ] ) && $_SERVER[ 'HTTP_X_FORWARDED' ] ) {
			return $_SERVER[ 'HTTP_X_FORWARDED' ];
		}
		else if( isset( $_SERVER[ 'HTTP_FORWARDED_FOR' ] ) && $_SERVER[ 'HTTP_FORWARDED_FOR' ] ) {
			return $_SERVER[ 'HTTP_FORWARDED_FOR' ];
		}
		else if( isset( $_SERVER[ 'HTTP_FORWARDED' ] ) && $_SERVER[ 'HTTP_FORWARDED' ] ) {
			return $_SERVER[ 'HTTP_FORWARDED' ];
		}
		else if( isset( $_SERVER[ 'REMOTE_ADDR' ] ) && $_SERVER[ 'REMOTE_ADDR' ] ) {
			return $_SERVER[ 'REMOTE_ADDR' ];
		}
		return __( 'UNKNOWN', 'cart-lift' );
	}
	add_filter( 'cl_get_user_ip', 'cl_get_user_ip' );
}

/**
 * Retrieve the user's country based on their IP address.
 *
 * This function determines the active plugin and uses the appropriate geolocation method.
 *
 * @return string The country code of the user, or an empty string if not found.
 */
function cl_get_user_country_from_ip() {
    if (cl_is_wc_active()) {
        return cl_get_country_from_wc_ip();
    } elseif (cl_is_edd_active()) {
        return cl_get_country_from_edd_ip();
    } else {
        return '';
    }
}

/**
 * Retrieve the user's country based on their IP address using Easy Digital Downloads (EDD) geolocation.
 *
 * This function fetches the user's IP address using EDD's `edd_get_ip` function and then uses an external service to determine the country.
 *
 * @return string The country code of the user, or an empty string if not found.
 */
function cl_get_country_from_edd_ip() {
    $ip_address = edd_get_ip();
    if( $ip_address  ){
        $id_details = json_decode( file_get_contents( "http://ipinfo.io/". $ip_address ."/json" ) );
    }
    return $id_details->country ?? '';
}

/**
 * Retrieve the user's country based on their IP address using WooCommerce geolocation.
 *
 * This function fetches the user's IP address using WooCommerce's `WC_Geolocation::get_ip_address` method
 * and then uses WooCommerce's `WC_Geolocation::geolocate_ip` method to determine the country.
 *
 * @return string The country code of the user, or an empty string if not found.
 */
function cl_get_country_from_wc_ip() {
    $ip_address = WC_Geolocation::get_ip_address();
    $country = WC_Geolocation::geolocate_ip($ip_address);
    return !empty($country) ? $country['country'] : '';
}

/**
 * Remove an abandoned cart record from the database.
 *
 * This function deletes a record from the cart table based on the provided user email, session ID, and status.
 *
 * @param string $user_email The email address of the user.
 * @param string $session_id The session ID of the user's cart.
 * @param string $status The status of the cart record to be deleted. Default is 'processing'.
 * @global wpdb $wpdb WordPress database abstraction object.
 */
function cl_pro_remove_abandoned_cart_record( $user_email, $session_id, $status = 'processing' ){
    global $wpdb;
    $cl_cart_table = $wpdb->prefix . CART_LIFT_CART_TABLE;
    $wpdb->delete( $cl_cart_table, array( 'email' => $user_email, 'status' => $status, 'session_id' => $session_id ) );
}