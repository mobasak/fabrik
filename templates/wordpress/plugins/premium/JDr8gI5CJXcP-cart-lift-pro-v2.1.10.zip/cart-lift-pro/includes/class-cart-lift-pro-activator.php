<?php

/**
 * Fired during plugin activation
 *
 * @link       http://rextheme.com/
 * @since      1.0.0
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/includes
 * @author     RexTheme <info@rextheme.com>
 */
class Cart_Lift_Pro_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
        if (! wp_next_scheduled ( 'cart_lift_license_check' )) {
            wp_schedule_event(time(), 'weekly', 'cart_lift_license_check');
        }
		
		if (! wp_next_scheduled ( 'cart_lift_weekly_report_to_site_admin' )) {
            $general_settings        = get_option( 'cl_general_settings' );
            $weekly_report_start_day = isset( $general_settings[ 'weekly_report_start_day' ] ) && !empty ( $general_settings[ 'weekly_report_start_day' ] ) ? $general_settings[ 'weekly_report_start_day' ] : '0';
            if(isset( $general_settings[ 'enable_weekly_report' ] ) && '1' === $general_settings[ 'enable_weekly_report' ] ){
                wp_schedule_event( time(), "* * * * *", 'cart_lift_weekly_report_to_site_admin');
            }

        }

	}

}
