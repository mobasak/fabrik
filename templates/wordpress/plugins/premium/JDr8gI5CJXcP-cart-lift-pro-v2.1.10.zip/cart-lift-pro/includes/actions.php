<?php

if ( ! function_exists( 'cl_trigger_recovered_cart_email_edd' ) ) {
    function cl_trigger_recovered_cart_email_edd($cart_details) {
        $email_data = cl_get_email_settings_data();

        $from_email_name    = $email_data['cl_from_name'];
        $reply_name_preview = $email_data['cl_reply_email'];
        $from_email_preview = $email_data['cl_from_email'];

        $product_table = cl_get_email_product_table( $cart_details->cart_contents, $cart_details->cart_total, $cart_details->provider, false, false );
        $email_body = '';
        $email_body .= cart_lift_email_header('Cart Recovered',false);
        $email_body .= 'Congratulations! This cart is recovered by '. $cart_details->email;
        $email_body .= '<br>';
        $email_body .= $product_table;
        $email_body .= cart_lift_email_footer(false);

        EDD()->emails->send( get_option( 'admin_email' ), 'Cart Recovered', $email_body );
    }
}
add_action( 'cl_trigger_recovered_cart_email_edd', 'cl_trigger_recovered_cart_email_edd' );