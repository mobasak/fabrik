<?php
if ( file_exists( WP_PLUGIN_DIR . '/cart-lift/cart-lift.php' ) ) {
    require_once dirname(__DIR__ ) . '/../cart-lift/admin/class-cart-lift-db.php';
}

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://rextheme.com/
 * @since      1.0.0
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/includes
 * @author     RexTheme <info@rextheme.com>
 */
class Cart_Lift_Pro
{

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Cart_Lift_Pro_Loader $loader Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string $plugin_name The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string $version The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct()
    {
        if ( defined( 'CART_LIFT_PRO_VERSION' ) ) {
            $this->version = CART_LIFT_PRO_VERSION;
        }
        else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'cart-lift-pro';

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();

    }

    /**
     * Load the required dependencies for this plugin.
     *
     * Include the following files that make up the plugin:
     *
     * - Cart_Lift_Pro_Loader. Orchestrates the hooks of the plugin.
     * - Cart_Lift_Pro_i18n. Defines internationalization functionality.
     * - Cart_Lift_Pro_Admin. Defines all hooks for the admin area.
     * - Cart_Lift_Pro_Public. Defines all hooks for the public side of the site.
     *
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies()
    {

        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-cart-lift-pro-loader.php';

        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-cart-lift-pro-i18n.php';


        /**
         * The class responsible for defining all actions that occur in the admin & public area.
         */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'vendor/autoload.php';

        $this->loader = new Cart_Lift_Pro_Loader();

    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * Uses the Cart_Lift_Pro_i18n class in order to set the domain and to register the hook
     * with WordPress.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale()
    {

        $plugin_i18n = new Cart_Lift_Pro_i18n();

        $this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks()
    {

        $plugin_admin   = new Cart_Lift_Pro_Admin( $this->get_plugin_name(), $this->get_version() );
        $plugin_hooks   = new Cart_Lift_Pro_Admin_Hooks();
        $baseOperations = new Cart_Lift_Pro_Rest_api();
        $twilio_sms     = new Cart_Lift_Pro_Twilio_Sms();
        $cl_db_action   = new Cart_Lift_DB();

        $cl_db_version = get_option( 'cl_db_version' );

        if ( $cl_db_version === '1.0' ) {
            $this->loader->add_action( 'plugins_loaded', $cl_db_action, 'cl_update_database' );
        }

        $this->loader->add_action( 'init', $plugin_admin, 'cl_add_action_scheduler' );

        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
        $this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

        $this->loader->add_action( 'cl_pro_sub_menu_items', $plugin_admin, 'cl_pro_sub_menu_items' );
        $this->loader->add_action( 'cl_pro_tabs_render', $plugin_admin, 'cl_pro_tabs_render' );
        $this->loader->add_action( 'cl_after_discount_field', $plugin_hooks, 'cl_after_discount_field', 10, 4 );
        $this->loader->add_action( 'cl_pop_up_email', $plugin_hooks, 'cl_pop_up_email_render' );
        $this->loader->add_action( 'wp_ajax_twilio_sms_submit', $twilio_sms, 'twilio_sms_submit' );
        $this->loader->add_action( 'cl_twilio_sms', $plugin_hooks, 'cl_twilio_sms_render' );

        $this->loader->add_filter( 'cl_campaign_coupon_post_data', $plugin_admin, 'cl_campaign_coupon_post_data' );
        $this->loader->add_filter( 'cl_campaign_meta', $plugin_admin, 'cl_campaign_meta', 10, 2 );


        $this->loader->add_filter( 'woocommerce_email_classes', $plugin_admin, 'cl_wc_admin_email_template' );
        $this->loader->add_filter( 'woocommerce_email_actions', $plugin_admin, 'cl_wc_admin_email_actions' );

        $this->loader->add_action( 'wp_ajax_cl_product_search', $plugin_admin, 'cl_product_search' );
        $this->loader->add_action( 'wp_ajax_cl_category_search', $plugin_admin, 'cl_category_search' );

        if( class_exists( 'ZipArchive' ) ) {
            $this->loader->add_action( 'admin_init', $plugin_admin, 'cl_report_generate' );
        }
        else{
            $this->loader->add_action( 'admin_notices', $plugin_admin, 'cl_zip_class_notice' );
        }

        $this->loader->add_action( 'admin_notices', $plugin_admin, 'cl_pro_activation_notice' );


        $this->loader->add_action( 'admin_init', $plugin_admin, 'edd_init' );
        $this->loader->add_action( 'admin_init', $plugin_admin, 'cl_license_operations' );
        $this->loader->add_action( 'admin_notices', $plugin_admin, 'cl_edd_admin_notices' );
        $this->loader->add_filter( 'is_cl_pro_active', $plugin_admin, 'is_cl_pro_active' );
        $this->loader->add_filter( 'is_cl_premium', $plugin_admin, 'is_cl_premium' );
        $this->loader->add_filter( 'cart_lift_license_check', $plugin_admin, 'cl_license_check_callback' );
        $this->loader->add_action( 'cart_lift_weekly_report_to_site_admin', $plugin_admin, 'cart_lift_weekly_report_to_site_admin' );

        $this->loader->add_action( 'cl_after_email_sent', $twilio_sms, 'twilio_sms_cron', 10 );

        $this->loader->add_filter( 'cl_cart_meta', $plugin_admin, 'add_ip_address' );
        $this->loader->add_action( 'cl_cart_tab_after_email', $plugin_admin, 'cart_tab_add_fields' );

        $this->loader->add_action( 'cl_render_time_logs', $plugin_admin, 'render_cl_time_log_markups' );
        $this->loader->add_action( 'cl_render_cart_contents', $plugin_admin, 'render_cl_cart_content_markups' );
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @return    string    The name of the plugin.
     * @since     1.0.0
     */
    public function get_plugin_name()
    {
        return $this->plugin_name;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @return    string    The version number of the plugin.
     * @since     1.0.0
     */
    public function get_version()
    {
        return $this->version;
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks()
    {

        $plugin_public = new Cart_Lift_Pro_Public( $this->get_plugin_name(), $this->get_version() );

        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
        $this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
        $this->loader->add_action( 'wp_footer', $plugin_public, 'display_email_popup_footer' );

        $this->loader->add_action( 'wp_ajax_nopriv_cl_store_email', $plugin_public, 'cl_store_email' );
        $this->loader->add_action( 'wp_ajax_cl_store_email', $plugin_public, 'cl_store_email' );
        $this->loader->add_action( 'wp_ajax_nopriv_cl_ignore_email_popup', $plugin_public, 'cl_ignore_email_popup' );
        $this->loader->add_action( 'wp_ajax_cl_ignore_email_popup', $plugin_public, 'cl_ignore_email_popup' );
        $this->loader->add_action( 'wp_ajax_nopriv_cl_reinitialize_popup', $plugin_public, 'cl_reinitialize_popup' );
        $this->loader->add_action( 'wp_ajax_cl_reinitialize_popup', $plugin_public, 'cl_reinitialize_popup' );
        $this->loader->add_filter( 'cl_exclude_countries', $plugin_public, 'cl_exclude_countries', 10, 3 );
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run()
    {
        $this->loader->run();
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @return    Cart_Lift_Pro_Loader    Orchestrates the hooks of the plugin.
     * @since     1.0.0
     */
    public function get_loader()
    {
        return $this->loader;
    }

}
