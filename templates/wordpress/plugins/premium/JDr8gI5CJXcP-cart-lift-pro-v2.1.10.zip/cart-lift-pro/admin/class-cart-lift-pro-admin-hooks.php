<?php

class Cart_Lift_Pro_Admin_Hooks {

    public function cl_after_discount_field($coupon_included_products, $coupon_included_products_amount, $coupon_included_categories, $coupon_included_categories_amount) { ?>
        <tr class="cl-coupon-conditional-fields" id="cl-coupon-amount" style="display: none;">
            <th>
                <label for="cl-campaign-coupon-product"><?php esc_html_e( 'If Products', 'cart-lift' ); ?></label>
            </th>
            <td>
                <div class="cl-coupon-conditional-fields-wrapper">
                    <select class="cl-product-search" multiple="multiple" name="cl_campaign_product_ids[]" data-placeholder="<?php esc_attr_e( 'Search for products', 'cart-lift' ); ?>">
                        <?php
                            if($coupon_included_products) {
                                foreach ( $coupon_included_products as $product_id ) {
                                    if( function_exists( 'cl_is_wc_active' ) && cl_is_wc_active() ) {
                                        $product = wc_get_product( $product_id );
                                        if ( is_object( $product ) ) {
                                            $product_name = $product->get_formatted_name();
                                        }
                                    }
                                    if( function_exists( 'cl_is_edd_active' ) && cl_is_edd_active() ) {
                                        $product = new EDD_Download( $product_id );
                                        if ( $product->get_ID() ) {
                                            $product_name = $product->get_name();
                                        }
                                    }
                                    if ( !empty( $product ) && is_object( $product ) ) {
                                        echo '<option value="' . esc_attr( $product_id ) . '"' . selected( true, true, false ) . '>' . wp_kses_post( $product_name ) . '</option>';
                                    }
                                }
                            }
                        ?>
                    </select>
                    <input name="cl_campaign_product_discount_amount" type="number" placeholder="Coupon Amount" value="<?php echo $coupon_included_products_amount; ?>"  />
                </div>
            </td>
        </tr>
        <?php if( function_exists( 'cl_is_wc_active' ) && cl_is_wc_active() ) { ?>
            <tr class="cl-coupon-conditional-fields" id="cl-coupon-amount" style="display: none;">
            <th>
                <label for="cl-campaign-coupon-product"><?php esc_html_e( 'If Product Categories', 'cart-lift' ); ?></label>
            </th>
            <td>
                <div class="cl-coupon-conditional-fields-wrapper">
                    <select class="cl-category-search" multiple="multiple" name="cl_campaign_category_ids[]" data-placeholder="<?php esc_attr_e( 'Search for categories', 'cart-lift' ); ?>">
                        <?php
                            if($coupon_included_categories) {
                                foreach ( $coupon_included_categories as $cat_id ) {
                                    $category = get_term( $cat_id , 'product_cat' );
                                    if ( $category ) {
                                        $category_name = $category->name;
                                        echo '<option value="' . esc_attr( $cat_id ) . '"' . selected( true, true, false ) . '>' . wp_kses_post( $category_name ) . '</option>';
                                    }
                                }
                            }
                        ?>
                    </select>
                    <input name="cl_campaign_category_discount_amount" type="number" placeholder="Coupon Amount" value="<?php echo $coupon_included_categories_amount; ?>"  />
                </div>
            </td>
        </tr>
        <?php } ?>
    <?php }


    public function cl_pop_up_email_render() {

        $default = array(
            'enabler'           => false,
            'enabler_exit'      => false,
            'popup_logo'        => CART_LIFT_PRO_URL . 'admin/images/logo.png',
            'popup_title'       => 'You were not leaving your cart just like that, right?',
            'popup_description' => 'Enter your email below to save your shopping cart for later. And, who knows, maybe we will even send you a sweet discount code.',
            'popup_button_text' => 'Submit',
        );
       
        $data = get_option( 'cl_popup_settings', $default );

        $data_header                   = $data[ 'payloadNew' ][ 'heading' ][ 'font-size' ] ?? '22';
        $header_text_alignment         = $data[ 'payloadNew' ][ 'heading' ][ 'text-align' ] ?? 'center';
        $header_text_font_weight       = $data[ 'payloadNew' ][ 'heading' ][ 'font-weight' ] ?? 'normal';
        $header_text_font_style        = $data[ 'payloadNew' ][ 'heading' ][ 'font-style' ] ?? 'normal';
        $header_text_transform         = $data[ 'payloadNew' ][ 'heading' ][ 'text-transform' ] ?? 'none';
        $header_text_decoration        = $data[ 'payloadNew' ][ 'heading' ][ 'text-decoration' ] ?? 'none';
        $header_text_line_height       = $data[ 'payloadNew' ][ 'heading' ][ 'line-height' ] ?? '1.5';
        $header_text_letter_spacing    = $data[ 'payloadNew' ][ 'heading' ][ 'letter-spacing' ] ?? '0';
        $header_text_word_spacing      = $data[ 'payloadNew' ][ 'heading' ][ 'word-spacing' ] ?? '0';
        $header_text_color             = $data[ 'payloadNew' ][ 'heading' ][ 'color' ] ?? '#000000';
        $content_text_alignment        = $data[ 'payloadNew' ][ 'content' ][ 'text-align' ] ?? 'center';
        $content_text_font_weight      = $data[ 'payloadNew' ][ 'content' ][ 'font-weight' ] ?? '400';
        $content_text_font_style       = $data[ 'payloadNew' ][ 'content' ][ 'font-style' ] ?? 'normal';
        $content_text_transform        = $data[ 'payloadNew' ][ 'content' ][ 'text-transform' ] ?? 'none';
        $content_text_decoration       = $data[ 'payloadNew' ][ 'content' ][ 'text-decoration' ] ?? 'none';
        $content_text_line_height      = $data[ 'payloadNew' ][ 'content' ][ 'line-height' ] ?? '1.5';
        $content_text_letter_spacing   = $data[ 'payloadNew' ][ 'content' ][ 'letter-spacing' ] ?? '0';
        $content_text_word_spacing     = $data[ 'payloadNew' ][ 'content' ][ 'word-spacing' ] ?? '0';
        $content_text_color            = $data[ 'payloadNew' ][ 'content' ][ 'color' ] ?? '#000000';
        $content_text_font_size        = $data[ 'payloadNew' ][ 'content' ][ 'font-size' ] ?? '16';
        $button_text_font_size         = $data[ 'payloadNew' ][ 'button' ][ 'font-size' ] ?? '16';
        $button_text_font_weight       = $data[ 'payloadNew' ][ 'button' ][ 'font-weight' ] ?? '400';
        $button_text_font_style        = $data[ 'payloadNew' ][ 'button' ][ 'font-style' ] ?? 'normal';
        $button_text_transform         = $data[ 'payloadNew' ][ 'button' ][ 'text-transform' ] ?? 'none';
        $button_text_decoration        = $data[ 'payloadNew' ][ 'button' ][ 'text-decoration' ] ?? 'none';
        $button_text_line_height       = $data[ 'payloadNew' ][ 'button' ][ 'line-height' ] ?? '1.5';
        $button_text_letter_spacing    = $data[ 'payloadNew' ][ 'button' ][ 'letter-spacing' ] ?? '0';
        $button_text_word_spacing      = $data[ 'payloadNew' ][ 'button' ][ 'word-spacing' ] ?? '0';
        $button_text_color             = $data[ 'payloadNew' ][ 'button' ][ 'color' ] ?? '#000000';
        $button_text_hover_color       = $data[ 'payloadNew' ][ 'button' ][ 'hover-color' ] ?? '#000000';
        $button_text_border_radius     = $data[ 'payloadNew' ][ 'button' ][ 'border-radius' ] ?? '0';
        $button_text_paddingX          = $data[ 'payloadNew' ][ 'button' ][ 'padding-x' ] ?? '0';
        $button_text_paddingY          = $data[ 'payloadNew' ][ 'button' ][ 'padding-y' ] ?? '0';
        $button_h_offset               = $data[ 'payloadNew' ][ 'button' ][ 'button-shadow-h-offset' ] ?? '0';
        $button_v_offset               = $data[ 'payloadNew' ][ 'button' ][ 'button-shadow-v-offset' ] ?? '0';
        $button_shadow_blur            = $data[ 'payloadNew' ][ 'button' ][ 'button-shadow-blur' ] ?? '0';
        $button_shadow_color           = $data[ 'payloadNew' ][ 'button' ][ 'shadow-color' ] ?? '#000000';
        $button_shadow_spread          = $data[ 'payloadNew' ][ 'button' ][ 'button-shadow-spread' ] ?? '0';
        $container_width               = $data[ 'payloadNew' ][ 'container' ][ 'width' ] ?? '100';
        $button_hover_background_color = $data[ 'payloadNew' ][ 'button' ][ 'hover-background-color' ] ?? '#000000';

        $enabler_checker      = false;
        $enabler_checker_exit = false;

        $enabled      = $data[ 'enabler' ] == '1' ? '1' : '0';
        $enabled_exit = isset( $data[ 'enabler_exit' ] ) && $data[ 'enabler_exit' ] == '1' ? '1' : '0';

        if ( $data[ 'enabler' ] == '1' ) {
            $enabler_status  = 'yes';
            $enabler_checker = true;
        }
        else {
            $enabler_status = 'no';
        }

        if ( isset( $data[ 'enabler_exit' ] ) && $data[ 'enabler_exit' ] == '1' ) {
            $enabler_status_exit  = 'yes';
            $enabler_checker_exit = true;
        }
        else {
            $enabler_status_exit = 'no';
        }

        $props = "enabler='".$enabled."' enable_status=".$enabler_status.
        " enabler_exit='".$enabled_exit."' enable_status=".$enabler_status_exit.
        " enabler_checker='".$enabler_checker."' enabler_checker_exit='".$enabler_checker_exit."' popup_logo='".$data['popup_logo'].
        "' popup_title='".$data['popup_title']."' popup_description='".$data['popup_description'].
        "' popup_button_text='".$data['popup_button_text']."' data_header='".$data_header.
        "' " . "header_text_alignment='".$header_text_alignment."'".
         "header_text_font_weight='".$header_text_font_weight."'". "header_text_font_style='".$header_text_font_style."'". 
         "header_text_transform='".$header_text_transform."'". "header_text_decoration='".$header_text_decoration."'". "header_text_line_height='".$header_text_line_height."'"."header_text_letter_spacing='".$header_text_letter_spacing."'"."header_text_word_spacing='".$header_text_word_spacing."'". "header_text_color='".$header_text_color."'". "content_text_alignment='".$content_text_alignment."'".
        "content_text_font_weight='".$content_text_font_weight."'". "content_text_font_style='".$content_text_font_style."'". "content_text_transform='".$content_text_transform."'". "content_text_decoration='".$content_text_decoration."'". "content_text_line_height='".$content_text_line_height."'"."content_text_letter_spacing='".$content_text_letter_spacing."'"."content_text_word_spacing='".$content_text_word_spacing."'". "content_text_color='".$content_text_color."'". "content_text_font_size='".$content_text_font_size."'". "button_text_font_size='".$button_text_font_size."'". "button_text_font_weight='".$button_text_font_weight."'". "button_text_font_style='".$button_text_font_style."'". "button_text_transform='".$button_text_transform."'". "button_text_decoration='".$button_text_decoration."'". "button_text_line_height='".$button_text_line_height."'"."button_text_letter_spacing='".$button_text_letter_spacing."'"."button_text_word_spacing='".$button_text_word_spacing."'". "button_text_color='".$button_text_color."'". "button_text_hover_color='".$button_text_hover_color."'". "button_text_border_radius='".$button_text_border_radius."'". "button_text_padding_x='".$button_text_paddingX."'". "button_text_padding_y='".$button_text_paddingY."'". "button_hover_background_color='".$button_hover_background_color."'". "button_h_offset='".$button_h_offset."'". "button_v_offset='".$button_v_offset."'". "button_blur_shadow='".$button_shadow_blur."'". "button_shadow_color='".$button_shadow_color."'". "button_shadow_spread='".$button_shadow_spread."'". "container_width='".$container_width."'";
         ;
        ?>

        <div id="vue-app">
            <?php echo "<cl-atc-vue-app $props></cl-atc-vue-app>"; ?>
        </div>
        <?php require_once CART_LIFT_PRO_DIR . '/admin/partials/cart-lift-pro-popup-email.php';
    }

    public function cl_twilio_sms_render() {
        require_once CART_LIFT_PRO_DIR . '/admin/partials/cart-lift-pro-twilio-sms.php';
    }
}