<?php
use kasparsd\MiniSheets\XlsxBuilder;
use Dompdf\Dompdf;
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://rextheme.com/
 * @since      1.0.0
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/admin
 * @author     RexTheme <info@rextheme.com>
 */
class Cart_Lift_Pro_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct( $plugin_name, $version ) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles($hook) {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Cart_Lift_Pro_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Cart_Lift_Pro_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */
        if( ($hook !== 'toplevel_page_cart_lift' ) ){
            return;
        }

        wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cart-lift-pro-admin.css', [], $this->version );
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts($hook) {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Cart_Lift_Pro_Loader as all the hooks are defined
         * in that particular class.
         *
         * The Cart_Lift_Pro_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        if( ($hook !== 'toplevel_page_cart_lift' ) ){
            return;
        }

        if ( ! did_action( 'wp_enqueue_media' ) ) {
            wp_enqueue_media();
        }

        $action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        if($action === 'settings') {
            wp_enqueue_editor();
            wp_enqueue_script( $this->plugin_name.'vue', plugin_dir_url( __FILE__ ) . 'js/vue.min.js', [ 'jquery' ], $this->version, true );
            wp_enqueue_script( $this->plugin_name.'cl-atc', plugin_dir_url( __FILE__ ) . 'js/cart-lift-pro-atc-popup.js', [ 'jquery','wp-editor' ], $this->version, true );
        }

        wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/cart-lift-pro-admin.js', [ 'jquery' ], $this->version, true );
        wp_localize_script($this->plugin_name, 'cl_pro_obj', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'security' => wp_create_nonce('cart-lift-pro')
        ));
    }


    /**
     * Show pro activation notice
     */
    public function cl_pro_activation_notice() {
        $is_premium = get_option('cart_lift_is_premium', 'no');
        if($is_premium === 'no') {
            $msg = __( 'Please %1$sactivate your license%2$s key to enjoy the pro features for %3$s.', 'cart-lift-pro' );
            $msg = sprintf( $msg, '<a href="' . admin_url( 'admin.php?page=cart_lift&action=license">'), '</a>', '<strong>Cart Lift Pro</strong>' );
            echo '<div class="notice notice-error is-dismissible"><p>'.$msg.'</p></div>';
        }
    }


    /**
     * Show error message if 'ZipArchive' not found
     */
    public function cl_zip_class_notice() {
        $is_premium = get_option('cart_lift_is_premium', 'no');
        if($is_premium === 'yes') {
            $link = '<a href="https://anto.online/code/how-to-enable-ziparchive-for-php/" target="_blank">enable</a>';
            $msg = __( "Warning: Class 'ZipArchive' not found. This will restrict you from generating and downloading reports.  Please %s the 'ZipArchive class'.", 'cart-lift-pro' );
            $msg = sprintf( $msg, $link );
            echo '<div class="notice notice-error is-dismissible"><p>'.$msg.'</p></div>';
        }
    }


    /**
     * Check if Cart Lift Pro
     * is activated or not
     *
     * @return bool
     */
    public function is_cl_pro_active() {
        return true;
    }


    /**
     * Check if license for Cart Lift Pro
     * is activated or not
     *
     * @return bool
     */
    public function is_cl_premium() {
        return get_option('cart_lift_is_premium', 'no') === 'yes';
    }


    /**
     * Pro menu items
     *
     */
    public function cl_pro_sub_menu_items() {
        add_submenu_page(
            'cart_lift',
            __('License', 'cart-lift'),
            __('License', 'cart-lift'),
            'manage_options',
            'admin.php?page=cart_lift&action=license'
        );
    }



    public function cl_pro_tabs_render($action) {
        $tab_view = new Cart_Lift_PRO_Tab_View();
        if($action == 'license') {
            $tab_view->print_license_tab_contents();
        }
    }


    /**
     * @param $email_classes
     * @return array
     * @since 1.0.0
     */
    public function cl_wc_admin_email_template($email_classes) {
        require_once CART_LIFT_PRO_DIR.'/includes/wc-email/class-cart-lift-recovered-email-template.php';
        $email_classes['Cart_Lift_Admin_Recovered_Email_Template'] = new Cart_Lift_Admin_Recovered_Email_Template();
        return $email_classes;
    }


    /**
     * @param $actions
     * @return array
     * @since 1.0.0
     */
    public function cl_wc_admin_email_actions($actions) {
        $actions[] = 'cl_trigger_recovered_cart_email';
        return $actions;
    }


    /**
     * @param $email_meta
     * @return mixed
     */
    public function cl_campaign_coupon_post_data($email_meta) {
        $email_meta['cl_campaign_conditional_discount'] = 0;
        $email_meta['cl_campaign_product_ids'] = array();
        $email_meta['cl_campaign_product_discount_amount'] = '';
        $email_meta['cl_campaign_category_ids'] = array();
        $email_meta['cl_campaign_category_discount_amount'] = '';
        $email_meta['cl_campaign_free_shipping'] = 0;
        $email_meta['cl_campaign_individual_use'] = 0;
        $email_meta['cl_campaign_auto_apply'] = 0;
        return $email_meta;
    }


    /**
     * @param $meta
     * @param $post_data
     * @return mixed
     */
    public function cl_campaign_meta($meta, $post_data) {
        $meta['conditional_discount'] = $post_data['cl_campaign_conditional_discount'];
        $meta['coupon_included_products'] = $post_data['cl_campaign_product_ids'];
        $meta['coupon_included_products_amount'] = $post_data['cl_campaign_product_discount_amount'];
        $meta['coupon_included_categories'] = $post_data['cl_campaign_category_ids'];
        $meta['coupon_included_categories_amount'] = $post_data['cl_campaign_category_discount_amount'];
        $meta['free_shipping'] = $post_data['cl_campaign_free_shipping'];
        $meta['individual_use'] = $post_data['cl_campaign_individual_use'];
        $meta['coupon_auto_apply'] = $post_data['cl_campaign_auto_apply'];
        return $meta;
    }


    /**
     * search product
     *
     * @throws Exception
     */
    public function cl_product_search() {
        check_ajax_referer( 'cart-lift-pro', 'security' );
        if ( isset( $_GET['term'] ) ) {
            $term = (string) wp_unslash($_GET['term']);
        }
        if ( empty( $term ) ) {
            wp_die();
        }
        $products        = array();
        if( function_exists( 'cl_is_wc_active' ) && cl_is_wc_active() ) {
            $data_store = WC_Data_Store::load( 'product' );
            $ids        = $data_store->search_products( $term, '', false, false, 10);
            $product_objects = array_filter( array_map( 'wc_get_product', $ids ), 'wc_products_array_filter_readable' );
            foreach ( $product_objects as $product_object ) {
                $formatted_name = $product_object->get_formatted_name();
                $products[ $product_object->get_id() ] = rawurldecode( $formatted_name );
            }
        }

        if( function_exists( 'cl_is_edd_active' ) && cl_is_edd_active() ) {
            $args = array(
                'fields'        => 'ids',
                'post_type'     => 'download',
                'no_found_rows' => true,
                's'             => $term
            );
            $downloads = get_posts( $args );
            foreach ( $downloads as $download_id ) {
                $download = new EDD_Download( $download_id );
                $products[$download_id] = $download->get_name();
            }
        }
        wp_send_json($products);
    }

    /**
     * search product
     *
     * @throws Exception
     */
    public function cl_category_search() {
        check_ajax_referer( 'cart-lift-pro', 'security' );
        if ( isset( $_GET['term'] ) ) {
            $term = (string) wp_unslash($_GET['term']);
        }
        if ( empty( $term ) ) {
            wp_die();
        }
        global $wpdb;
        $sql = "SELECT t.term_id AS id,
                                    t.name    AS term_name
                                    FROM   $wpdb->terms t
                                    LEFT JOIN $wpdb->term_taxonomy tt
                                    ON t.term_id = tt.term_id
                                    WHERE  tt.taxonomy = 'product_cat' AND t.name LIKE %s
                                    ORDER  BY name";

        $terms = $wpdb->get_results($wpdb->prepare($sql, '%' . $wpdb->esc_like($term) . '%'));
        $category = array();
        foreach ($terms as $t) {
            $category[$t->id] = $t->term_name;
        }
        wp_send_json($category);
    }

    /**
     * Generate Report
     */
    public function cl_report_generate() {
        global $wpdb;
        $cl_cart_table = $wpdb->prefix . CART_LIFT_CART_TABLE;

        $master  = array();
        $existing_columns  = array(
            'First Name',
            'Last Name',
            'Email',
            'Phone',
            'Products',
            'Cart Total',
            'Order Status',
            'Unsubscribed',
            'Coupon Code',
        );

        $master[] = $existing_columns;

        $results = $wpdb->get_results("SELECT * from {$cl_cart_table}");

        foreach ($results as $rs_value) {
            $row = array();
            $currency = '';
            if ($rs_value->provider == 'edd') {
                if( function_exists( 'cl_is_edd_active' ) && cl_is_edd_active())  {
                    $currency = edd_get_currency();
                }
            }
            else {
                if( function_exists( 'cl_is_wc_active' ) && cl_is_wc_active())  {
                    $currency = get_woocommerce_currency();
                }
            }
            $email  = $rs_value->email;
            $user = get_user_by('email', $email);
            $user_id = 0;
            if ($user) {
                $user_id = $user->ID;
            }

            $first_name = get_user_meta( $user_id, 'first_name', true );
            if (!$first_name) {
                $first_name = 'Not Found';
            }
            $last_name = get_user_meta( $user_id, 'last_name', true );
            if (!$last_name) {
                $last_name = 'Not Found';
            }
            $products = '';
            if( function_exists( 'cl_get_comma_separated_product_names' ) ) {
                $products = cl_get_comma_separated_product_names( $rs_value->cart_contents, $rs_value->provider );
            }
            $cart_total = $currency . $rs_value->cart_total;
            $status = $rs_value->status;

            if ($rs_value->unsubscribed == '1') {
                $unsubcribed = 'yes';
            }
            else {
                $unsubcribed = 'No';
            }

            if ($rs_value->coupon_code) {
                $coupon_code = $rs_value->coupon_code;
            }
            else {
                $coupon_code = "Not Found";
            }

            $phone = '';
            if( $rs_value->cart_meta ) {
                $cart_meta = maybe_unserialize( $rs_value->cart_meta );
                $phone = !empty( $cart_meta[ 'phone' ] ) ? $cart_meta[ 'phone' ] : '';
            }

            $row[] = $first_name;
            $row[] = $last_name;
            $row[] = $email;
            $row[] = $phone;
            $row[] = $products;
            $row[] = $cart_total;
            $row[] = $status;
            $row[] = $unsubcribed;
            $row[] = $coupon_code;

            $master[] = $row;
        }

        $zipper = new \ZipArchive;
        $filename = CART_LIFT_PRO_DIR . '/report.xlsx';
        $zipper->open( $filename, \ZipArchive::CREATE | \ZipArchive::OVERWRITE );

        $builder = new XlsxBuilder( $zipper );
        $builder->add_rows($master);

        $builder->build();

        $zipper->close();
    }


    public function edd_init() {
        register_setting('cart_lift_license', 'cart_lift_license_key' );
    }


    /**
     * Perform the license operation
     * license activation/deactivation
     *
     */
    public function cl_license_operations() {
        // listen for our activate button to be clicked
        if( isset( $_POST['cart_lift_license_activate'] ) ) {
            // run a quick security check
            if( ! check_admin_referer( 'cart_lift_pro_nonce', 'cart_lift_pro_nonce' ) )
                return; // get out if we didn't click the Activate button
            // retrieve the license from the database
            $license = $_POST['cart_lift_license_key'] != '' ? trim($_POST['cart_lift_license_key']) : trim($_POST['cart_lift_license_key_mask']);

            // data to send in our API request
            $api_params = array(
                'edd_action' => 'activate_license',
                'license'    => $license,
                'item_id'    => CART_LIFT_ITEM_ID, // The ID of the item in EDD
                'url'        => home_url()
            );
            $params = '';
            foreach($api_params as $key=>$value) {
                $params .= $key.'='.$value.'&';
            }
            $params = trim($params, '&');

            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, CART_LIFT_STORE_URL.'?'.$params ); //Url together with parameters
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Return data instead printing directly in Browser
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT , 7); //Timeout after 7 seconds
            curl_setopt($ch, CURLOPT_USERAGENT , "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
            curl_setopt($ch, CURLOPT_HEADER, 0);
            $response = curl_exec($ch);

            if(curl_errno($ch))  {
                $message = __( 'An error occurred, please try again.' );
            }else {
                $license_data = json_decode( $response );
                if ( false === $license_data->success ) {
                    switch( $license_data->error ) {
                        case 'expired' :
                            $message = sprintf(
                                __( 'Your license key expired on %s.' ),
                                date_i18n( get_option( 'date_format' ), strtotime( $license_data->expires, current_time( 'timestamp' ) ) )
                            );
                            break;
                        case 'revoked' :
                            $message = __( 'Your license key has been disabled.' );
                            break;
                        case 'missing' :
                            $message = __( 'Invalid license.' );
                            break;
                        case 'invalid' :
                        case 'site_inactive' :
                            $message = __( 'Your license is not active for this URL.' );
                            break;
                        case 'item_name_mismatch' :
                            $message = sprintf( __( 'This appears to be an invalid license key for %s.' ), 'wpfm-pro' );
                            break;
                        case 'no_activations_left':
                            $message = __( 'Your license key has reached its activation limit.' );
                            break;
                        default :
                            $message = __( 'An error occurred, please try again.' );
                            break;
                    }
                }
            }

            curl_close($ch);

            // Check if anything passed on a message constituting a failure
            if ( ! empty( $message ) ) {
                $base_url = admin_url( 'admin.php?page=cart_lift&action=license' );
                $redirect = add_query_arg( array( 'sl_activation' => 'false', 'message' => urlencode( $message ) ), $base_url );
                wp_redirect( $redirect );
                exit();
            }
            // $license_data->license will be either "valid" or "invalid"
            update_option( 'cart_lift_license_status', $license_data->license );
            update_option('cart_lift_license_key', $license);
            if($license_data->license == 'valid') {
                update_option('cart_lift_is_premium', 'yes');
            }else {
                update_option('cart_lift_is_premium', 'no');
            }
            wp_redirect( admin_url( 'admin.php?page=cart_lift&action=license' ) );
            exit();
        }
        elseif (isset( $_POST['cart_lift_license_deactivate'] ) ) {
            if (!check_admin_referer('cart_lift_pro_nonce', 'cart_lift_pro_nonce'))
                return;

            $license = $_POST['cart_lift_license_key'] != '' ? trim($_POST['cart_lift_license_key']) : trim($_POST['cart_lift_license_key_mask']);

            $api_params = array(
                'edd_action' => 'deactivate_license',
                'license' => $license,
                'item_id' => CART_LIFT_ITEM_ID,
                'url' => home_url()
            );

            $params = '';
            foreach($api_params as $key=>$value) {
                $params .= $key.'='.$value.'&';
            }
            $params = trim($params, '&');

            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, CART_LIFT_STORE_URL.'?'.$params ); //Url together with parameters
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Return data instead printing directly in Browser
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT , 7); //Timeout after 7 seconds
            curl_setopt($ch, CURLOPT_USERAGENT , "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
            curl_setopt($ch, CURLOPT_HEADER, 0);
            $response = curl_exec($ch);

            if(curl_errno($ch))  {
                $message = __( 'An error occurred, please try again.' );
            }else {
                $license_data = json_decode($response);
                if (false === $license_data->success) {
                    switch ($license_data->license) {
                        case 'deactivated':
                            $message = __( 'Your license successfully deactivate.', 'cart-lift-pro' );
                            break;
                        case 'failed':
                            $message = __( 'Your license deactivation failed.', 'cart-lift-pro' );
                            break;

                    }
                }
            }
            curl_close($ch);

            if ( ! empty( $message ) ) {
                $base_url = admin_url( 'admin.php?page=cart_lift&action=license' );
                $redirect = add_query_arg( array( 'sl_activation' => 'false', 'message' => urlencode( $message ) ), $base_url );
                wp_redirect( $redirect );
                exit();
            }
            update_option( 'cart_lift_license_status', '' );
            update_option( 'cart_lift_is_premium', 'no' );
            wp_redirect( admin_url( 'admin.php?page=cart_lift&action=license' ) );
            exit();
        }
    }


    /**
     * License notices
     *
     */
    public function cl_edd_admin_notices() {
        if ( isset( $_GET['sl_activation'] ) && ! empty( $_GET['message'] ) ) {
            switch( $_GET['sl_activation'] ) {
                case 'false':
                    $message = urldecode( $_GET['message'] );
                    ?>
                    <div class="error">
                        <p><?php echo $message; ?></p>
                    </div>
                    <?php
                    break;
                case 'true':
                default:
                    break;
            }
        }
    }


    /**
     * EDD license check
     * This function will check license in every
     * seven days
     *
     */
    public function cl_license_check_callback() {
        $store_url = CART_LIFT_STORE_URL;
        $license = get_option( 'cart_lift_license_key' );
        $api_params = array(
            'edd_action' => 'check_license',
            'license' => $license,
            'item_id' => CART_LIFT_ITEM_ID,
            'url' => home_url()
        );
        $params = '';
        foreach($api_params as $key=>$value) {
            $params .= $key.'='.$value.'&';
        }
        $params = trim($params, '&');
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $store_url.'?'.$params ); //Url together with parameters
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Return data instead printing directly in Browser
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT , 7); //Timeout after 7 seconds
        curl_setopt($ch, CURLOPT_USERAGENT , "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $response = curl_exec($ch);


        if(curl_errno($ch))  {
            curl_close($ch);
            update_option('cl_is_premium', 'no');
            die();
        }
        else{
            $license_data = json_decode( $response );
            if($license) {
                curl_close($ch);
                if( $license_data->license == 'valid' ) {
                    update_option('cl_is_premium', 'yes');
                    die();
                }
                update_option('cl_is_premium', 'no');
                die();
            }
        }
        curl_close($ch);
        update_option('cl_is_premium', 'no');
        die();
    }


    /**
     * Add IP Address to cart meta
     *
     * @param $cart_meta
     * @return mixed
     */
    public function add_ip_address( $cart_meta ) {
        if ( apply_filters( 'is_cl_premium', false ) ) {
            $cart_meta[ 'ip' ] = cl_get_user_ip();
        }
        return $cart_meta;
    }


    /**
     * Adds IP Address and Phone Fields
     * after Email field in Cart Tab
     */
    public function cart_tab_add_fields( $data ) {
        $is_premium = apply_filters( 'is_cl_premium', false );
        ?>
        <?php if ( $is_premium ): ?>
            <li>
                <span class="label"><?php echo __( 'Phone:','cart-lift-pro' ); ?></span>
                <span class="content"><?php echo $data['phone']; ?></span>
            </li>
        <?php endif;?>

        <?php if ( $is_premium ): ?>
            <li>
                <span class="label"><?php echo __( 'IP Address:','cart-lift-pro' ); ?></span>
                <span class="content"><?php echo $data['ip']; ?></span>
            </li>
        <?php endif;?>
        <?php
    }


    /**
     * Renders Time log HTML markups
     */
    public function render_cl_time_log_markups( $data  ) {
        $scheduled_logs = cl_get_scheduled_logs($data['session_id']);
        
        if($scheduled_logs) {
            foreach ($scheduled_logs as $key => $log) { ?>
                <li>
                    <span class="label"><?php echo $log['template_name'] . ' [Email]'; ?></span>
                    <span class="content"><?php echo cl_time_elapsed_string($log['schedule_time']); ?></span>
                </li>
                <?php if( isset( $log['twilio'] ) && $log['twilio'] === 'enabled' ) {?>
                    <li>
                        <span class="label"><?php echo $log['template_name'] . ' [SMS]'; ?></span>
                        <span class="content"><?php echo cl_time_elapsed_string($log['schedule_time'], $log[ 'sms_sent' ]); ?></span>
                    </li>
                <?php }
            }
        }
        else {
            echo '<li class="cl-not-found">'.__('No scheduled Logs found', 'cart-lift').'</li>';
        }
    }


    /**
     * Renders Cart Content HTML markups
     */
    public function render_cl_cart_content_markups( $data  ) {
        foreach ( $data['products'] as $product ) {
            ?>
            <ul class="single-cart-list">
                <li class="image" data-title="<?php _e( 'Product Image :', 'cart-lift' ); ?>">
                    <img src="<?php echo $product['featured_image'] ?>" alt="product image" />
                </li>
                <li class="product-name" data-title="<?php _e( 'Product Name :', 'cart-lift' ); ?>"><?php echo $product['name'] ?></li>
                <li class="price" data-title="<?php _e( 'Price :', 'cart-lift' ); ?>"><?php echo $product['price'] ?></li>
                <li class="quantity" data-title="<?php _e( 'Quantity :', 'cart-lift' ); ?>"><?php echo $product['quantity']; echo $product['quantity'] == 1 ? __( ' Item', 'cart-lift' ): __( ' Items', 'cart-lift' ); ?></li>
            </ul>
            <?php
        }
    }

    /**
     * Generate and send weekly report to site admin.
     * 
     * This function retrieves cart data for the specified week, generates a report,
     * and sends it to site administrators.
     */
    public function cart_lift_weekly_report_to_site_admin()
    {
        $general_settings = get_option( 'cl_general_settings' );
        $weekly_report_start_day = isset($general_settings[ 'weekly_report_start_day']) && !empty($general_settings[ 'weekly_report_start_day']) ? $general_settings[ 'weekly_report_start_day'] : get_option( 'start_of_week' );
        $site_admin_emails = isset($general_settings[ 'weekly_report_email']) && !empty( $general_settings[ 'weekly_report_email']) ? $general_settings[ 'weekly_report_email'] : get_option( 'admin_email' );
        $administrative_emails = array_map('trim', explode(',', $site_admin_emails));
        $weekly_report_email_from = isset($general_settings[ 'weekly_report_email_from']) && !empty($general_settings[ 'weekly_report_email_from']) ? $general_settings[ 'weekly_report_email_from'] : get_option( 'admin_email' );
        $weekly_report_email_body = isset($general_settings[ 'weekly_report_email_body']) && !empty($general_settings[ 'weekly_report_email_body']) ? $general_settings[ 'weekly_report_email_body'] : __('Please find the attached weekly report', 'cart-lift-pro');

        if( isset( $general_settings[ 'enable_weekly_report' ] ) && '1' === $general_settings[ 'enable_weekly_report' ] ) {

            global $wpdb;
            $cl_cart_table = $wpdb->prefix . CART_LIFT_CART_TABLE;

            $master  = array();
            $existing_columns  = array(
                'First Name',
                'Last Name',
                'Email',
                'Phone',
                'Products',
                'Cart Total',
                'Order Status',
                'Unsubscribed',
                'Coupon Code',
            );

            $master[] = $existing_columns;
            $day = strval($weekly_report_start_day);
            $start_date = $this->formatted_day($day, 'last', 'mysql_format');
            $end_date = $this->formatted_day($day, 'next', 'mysql_format');

            $query = $wpdb->prepare(
                "SELECT * FROM {$cl_cart_table} WHERE time BETWEEN %s AND %s",
                $start_date,
                $end_date
            );
            $results = $wpdb->get_results($query);

            foreach ($results as $rs_value) {
                $row = array();
                $currency = '';
                if ($rs_value->provider == 'edd') {
                    if( function_exists( 'cl_is_edd_active' ) && cl_is_edd_active())  {
                        $currency = edd_get_currency();
                    }
                }
                else {
                    if( function_exists( 'cl_is_wc_active' ) && cl_is_wc_active())  {
                        $currency = get_woocommerce_currency();
                    }
                }
                $email  = $rs_value->email;
                $user = get_user_by('email', $email);
                $user_id = 0;
                if ($user) {
                    $user_id = $user->ID;
                }

                $first_name = get_user_meta( $user_id, 'first_name', true );
                if (!$first_name) {
                    $first_name = 'Not Found';
                }
                $last_name = get_user_meta( $user_id, 'last_name', true );
                if (!$last_name) {
                    $last_name = 'Not Found';
                }
                $products = '';
                if( function_exists( 'cl_get_comma_separated_product_names' ) ) {
                    $products = cl_get_comma_separated_product_names( $rs_value->cart_contents, $rs_value->provider );
                }
                $cart_total = $currency .' '.$rs_value->cart_total;
                $status = $rs_value->status;

                if ($rs_value->unsubscribed == '1') {
                    $unsubcribed = 'yes';
                }
                else {
                    $unsubcribed = 'No';
                }

                if ($rs_value->coupon_code) {
                    $coupon_code = $rs_value->coupon_code;
                }
                else {
                    $coupon_code = "Not Found";
                }

                $phone = '';
                if( $rs_value->cart_meta ) {
                    $cart_meta = maybe_unserialize( $rs_value->cart_meta );
                    $phone = !empty( $cart_meta[ 'phone' ] ) ? $cart_meta[ 'phone' ] : '';
                }

                $row[] = $first_name;
                $row[] = $last_name;
                $row[] = $email;
                $row[] = $phone;
                $row[] = $products;
                $row[] = $cart_total;
                $row[] = $status;
                $row[] = $unsubcribed;
                $row[] = $coupon_code;

                $master[] = $row;
            }

            $week_start = $this->formatted_day($day, 'last', 'lower');
            $week_end = $this->formatted_day($day, 'next', 'lower');
            $data_table = $this->cl_generate_html_table($master, $day);

            $html_content = '<html>
                                <head>
                                     <style>
                                        table {
                                            border-collapse: collapse;
                                            width: 100%;
                                        }
                                        th, td {
                                            border: 1px solid black;
                                            padding: 8px;
                                            text-align: left;
                                        }
                                        th {
                                            background-color: #f2f2f2;
                                        }
                                    </style>
                                </head>
                                <body>' . $data_table . '</body>
                            </html>';

            $dompdf = new Dompdf();
            $dompdf->loadHtml($html_content);
            $dompdf->setPaper('A4', 'landscape');
            $dompdf->render();
            $file_name = CART_LIFT_PRO_DIR .'cart-lift-weekly-report-'.$week_start.'-'.$week_end.'.pdf';
            file_put_contents($file_name, $dompdf->output());                         
            $headers[] = 'Content-type: text/html;charset=UTF-8';
            $headers[] = 'MIME-Version: 1.0';
            $headers[] = 'From:' . $weekly_report_email_from;
            $week_start = $this->formatted_day($day, 'last', 'upper');
            $week_end = $this->formatted_day($day, 'next', 'upper');
            $email_subject = 'Cart Lift Weekly Report: '.$week_start.' - '.$week_end;
            foreach($administrative_emails as $email) {
                wp_mail($email, $email_subject, $weekly_report_email_body, $headers, $file_name);
            }
            if(file_exists($file_name)){
                unlink($file_name);
            }
        }
    }

    /**
     * Generates HTML table for weekly report.
     *
     * This function generates an HTML table for a weekly report, displaying data
     * from the given $master array. The report spans from the start of the week
     * to the end of the week based on the given $day.
     *
     * @param array $master  The array containing the data to be displayed in the table.
     * @param string $day    The day within the week for which the report is generated.
     * @return string        HTML code for the generated table.
     */
    public function cl_generate_html_table( $master, $day){
        $week_start = $this->formatted_day($day, 'last', 'full');
        $week_end = $this->formatted_day($day, 'next', 'full');

        $html = '<div>';
        $html .= '<h2 style="text-align: center;">Weekly Report from '.$week_start.' to '.$week_end.' </h2>';
        $html .= '<table border="1">';
        $html .= '<tr>';
        foreach ($master[0] as $key => $value) {
            $html .= '<th>' . $value . '</th>';
        }
        $html .= '</tr>';
        unset($master[0]);
        $master = array_values($master);
        foreach ($master as $row) {
         $html .= '<tr>';
            foreach ($row as $cell) {
                $width = ' style="width: 11%;"';
                $html .= '<td'.$width.'>' . $cell . '</td>';
            }
            $html .= '</tr>';
        }
    
        $html .= '</table>';
        $html .= '</div>';
        return $html;
    }

    /**
     * Formats the day based on the given prefix and case.
     *
     * This function formats the day based on the given prefix and case. The prefix
     * determines whether the day is "last" or "next". The case determines whether
     * the formatted day should be in lowercase or uppercase.
     *
     * @param int $day          The day of the week (0 for Sunday, 1 for Monday, etc.).
     * @param string $prefix    The prefix to indicate "last" or "next" day.
     * @param string $lower     The case of the formatted day ('lower' for lowercase, otherwise uppercase).
     * @return string           Formatted day according to the provided prefix and case.
     */
    public function formatted_day($day, $prefix, $lower){
        $formatted_string = $prefix.' ';
        if('0' === $day){
            $formatted_string .= 'sunday';
        } else if('1' === $day){
            $formatted_string .= 'monday';
        } else if('2' === $day){
            $formatted_string .= 'tuesday';
        } else if('3' === $day){
            $formatted_string .= 'wednesday';
        } else if('4' === $day){
            $formatted_string .= 'thursday';
        } else if('5' === $day){
            $formatted_string .= 'friday';
        } else if('6' === $day){
            $formatted_string .= 'saturday';
        }

        if( 'lower' === $lower ){
            return strtolower(date('Md', strtotime($formatted_string)));
        } else if('upper' === $lower ){
            return date('M d', strtotime($formatted_string));
        } else if( 'full' === $lower ){
          return date('F d', strtotime($formatted_string));
        } else if( 'mysql_format' === $lower ){
            if( 'last' === $prefix ){
                $formatted_string = date('Y-m-d 00:00:00', strtotime($formatted_string));
            } else if( 'next' === $prefix ){
                $formatted_string = date('Y-m-d 23:59:59', strtotime($formatted_string));
            }
            return $formatted_string;
        }
    }

    /**
     * Adds action scheduler for weekly report.
     *
     * This function adds an action scheduler for the weekly report to be sent to the site admin.
     * It checks if the action is not already scheduled, then retrieves the general settings
     * to determine the start day for the weekly report. If the weekly report is enabled,
     * it schedules the action to run every .
     */
    public function cl_add_action_scheduler() {
        if ( function_exists( 'as_has_scheduled_action' ) && !as_has_scheduled_action( 'cart_lift_weekly_report_to_site_admin' ) ) {
            $general_settings        = get_option( 'cl_general_settings' );
            $weekly_report_start_day = !empty( $general_settings[ 'weekly_report_start_day' ] ) ? $general_settings[ 'weekly_report_start_day' ] : get_option( 'start_of_week' );
            wp_clear_scheduled_hook( 'cart_lift_weekly_report_to_site_admin' );
            if ( isset( $general_settings[ 'enable_weekly_report' ] ) && '1' === $general_settings[ 'enable_weekly_report' ] && function_exists( 'as_schedule_cron_action' ) ) {
                as_schedule_cron_action( time(), "0 0 * * $weekly_report_start_day", 'cart_lift_weekly_report_to_site_admin' );
            }
        }
    }
}