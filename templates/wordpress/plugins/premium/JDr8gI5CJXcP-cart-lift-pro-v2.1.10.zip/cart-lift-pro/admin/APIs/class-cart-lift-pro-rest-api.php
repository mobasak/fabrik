<?php

/**
 * REST_API Handler
 */
class Cart_Lift_Pro_Rest_api
{

	/**
	 * Instance of this class.
	 *
	 * @since    0.8.1
	 *
	 * @var      object
	 */
	protected static $instance = null;


	/**
	 * Namespace of of this endpoints.
	 *
	 * @since    0.8.1
	 *
	 * @var      object
	 */
	public $namespace = '';


	/**
	 * The slug or namespace used for this plugin.
	 *
	 * This property stores the unique identifier for the plugin, which is often used
	 * in various contexts such as API endpoints, options names, or text domains.
	 *
	 * @since    2.1.7
	 *
	 * @var      string
	 */
	public $plugin_slug = '';


	/**
	 * Initialize the plugin by setting localization and loading public scripts
	 * and styles.
	 *
	 * @since     0.8.1
	 */
	public function __construct()
	{
		$version           = '1';
		$this->plugin_slug = 'cartlift';
		$this->namespace   = $this->plugin_slug . '/v' . $version;
		$this->do_hooks();
	}


	/**
	 * Set up WordPress hooks and filters
	 *
	 * @return void
	 */
	public function do_hooks()
	{
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Return an instance of this class.
	 *
	 * @return    object    A single instance of this class.
	 * @since     0.8.1
	 *
	 */
	public static function get_instance()
	{
		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
			self::$instance->do_hooks();
		}

		return self::$instance;
	}


	/**
	 * Register the routes for the objects of the controller.
	 */
	public function register_routes()
	{
		register_rest_route(
			$this->namespace, '/userVerify', array(
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'cl_user_verify' ),
				'permission_callback' => array( $this, 'w2cloud_permissions_check' ),
			),
		) );
	}

	public function cl_user_verify( $request )
	{
		$username = $request->get_param( 'username' );
		$password = $request->get_param( 'password' );
		$response = wp_authenticate( $username, $password );
		if ( $response->data ) {
			return true;
		}
		return false;
	}

	/**
	 * Check if a given request has access to update a setting
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 * @return WP_Error|bool
	 */
	public function w2cloud_permissions_check( $request )
	{
		// return true;
		return current_user_can( 'manage_options' );
	}
}
