<?php

/**
 * Class Cart_Lift_PRO_Tab_View
 */


class Cart_Lift_PRO_Tab_View extends Cart_Lift_Tab_View {

    public function print_license_tab_contents() {
        require_once CART_LIFT_PRO_DIR . '/admin/partials/cart-lift-pro-license-page.php';
    }


    public function save_license() {

    }
}
