<?php
require_once CART_LIFT_PRO_DIR . '/vendor/autoload.php';

use Twilio\Rest\Client;

class Cart_Lift_Pro_Twilio_Sms
{
    /**
     * Implements twilio sms
     *
     * @param $data
     * @return false|\Twilio\Rest\Api\V2010\Account\MessageInstance
     */
	public static function cl_send_twilio_sms( $data )
	{
		// Twilio sending sms starts
		$twilio_settings  = cl_get_twilio_settings_data();
		$campaign_enabler = $data->twilio_sms;
        $is_sms_sent = false;

		if ( apply_filters( 'is_cl_premium', false ) && $data->status === 'abandoned' && cl_is_twilio_enabled() && $campaign_enabler === 'enabled' ) {
			$cart_meta     = unserialize( $data->cart_meta );
			$cl_user_phone = $cart_meta['phone'] ?? '';

            if ( $cl_user_phone && $cl_user_phone !== '' ) {

				$cart_contents = unserialize( $data->cart_contents );
				$product_names = '';
				$first_product = true;
				foreach ( $cart_contents as $content ) {

					if ( $data->provider === 'wc' && cl_is_wc_active() ) {
						$product_names .= !$first_product ? ', ' : '';
						$product_names .= wc_get_product( $content[ 'id' ] )->get_name();
					}
					else if ( $data->provider === 'edd' && cl_is_edd_active() ) {
						$product_names .= !$first_product ? ', ' : '';
						$product       = new EDD_Download( $content[ 'id' ] );
						$product_names .= $product->get_name();
					}
					
					$first_product = false;
				}

				$coupon_code                     = isset( $_SESSION[ 'cl_current_coupon' ] ) ? $_SESSION[ 'cl_current_coupon' ] : '';
				$_SESSION[ 'cl_current_coupon' ] = '';
				$email_meta                      = unserialize( $data->email_meta );

				$token_data = array(
					'cl_session_id'     => $data->session_id,
					'coupon_code'       => $email_meta[ 'coupon' ] ? $coupon_code : null,
					'coupon_auto_apply' => isset( $email_meta[ 'coupon_auto_apply' ] ) ? 'yes' : 'no',
					'email'             => $data->email,
					'first_name'        => isset( $cart_meta[ 'first_name' ] ) ? $cart_meta[ 'first_name' ] : '',
					'last_name'         => isset( $cart_meta[ 'last_name' ] ) ? $cart_meta[ 'last_name' ] : '',
					'phone'             => isset( $cart_meta[ 'phone' ] ) ? $cart_meta[ 'phone' ] : '',
					'country'           => isset( $cart_meta[ 'country' ] ) ? $cart_meta[ 'country' ] : '',
					'address'           => isset( $cart_meta[ 'address' ] ) ? $cart_meta[ 'address' ] : '',
					'city'              => isset( $cart_meta[ 'city' ] ) ? $cart_meta[ 'city' ] : '',
					'postcode'          => isset( $cart_meta[ 'postcode' ] ) ? $cart_meta[ 'postcode' ] : '',
					'provider'          => $data->provider,
				);

				$checkout_url = cl_get_checkout_page_url( $token_data, $data->provider );

				$checkout_url = file_get_contents('http://tinyurl.com/api-create.php?url='.$checkout_url);

				$twilio_account_sid   = $twilio_settings[ 'twilio_account_sid' ];
				$twilio_auth_token    = $twilio_settings[ 'twilio_auth_token' ];
				$twilio_mobile_number = $twilio_settings[ 'twilio_mobile_number' ];

				$twilio_sms_body = $data->twilio_sms_body;

				$coupon   = $coupon_code !== '' ? $coupon_code : '';
				$sms_body = '';

				$first_name = isset( $cart_meta[ 'first_name' ] ) ? $cart_meta[ 'first_name' ] : '';
				$last_name  = isset( $cart_meta[ 'last_name' ] ) ? $cart_meta[ 'last_name' ] : '';

				$twilio_sms_body = str_replace( '{{site.url}}', home_url(), $twilio_sms_body );
				$twilio_sms_body = str_replace( '{{site.title}}', get_bloginfo(), $twilio_sms_body );
				$twilio_sms_body = str_replace( '{{customer.firstname}}', $first_name, $twilio_sms_body );
				$twilio_sms_body = str_replace( '{{customer.lastname}}', $last_name, $twilio_sms_body );
				$twilio_sms_body = str_replace( '{{customer.fullname}}', $first_name . ' ' . $last_name, $twilio_sms_body );
				$twilio_sms_body = str_replace( '{{cart.product.names}}', $product_names, $twilio_sms_body );
				$twilio_sms_body = str_replace( '{{cart.coupon_code}}', $coupon, $twilio_sms_body );
				$twilio_sms_body = str_replace( '{{cart.checkout_url}}', $checkout_url, $twilio_sms_body );

				$sms_body = $twilio_sms_body;

				// Your Account SID and Auth Token from twilio.com/console
				$account_sid = $twilio_account_sid;
				$auth_token  = $twilio_auth_token;
				// In production, these should be environment variables. E.g.:
				// $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

				// A Twilio number you own with SMS capabilities
				$twilio_number = $twilio_mobile_number;

				try {
					$client        = new Client( $account_sid, $auth_token );
					$phone_number  = $client->lookups->v1->phoneNumbers( $cl_user_phone )->fetch( [ "countryCode" => $token_data[ 'country' ] ] );
					$cl_user_phone = $phone_number->phoneNumber;

                    $is_sms_sent = $client->messages->create(
					// Where to send a text message (your cell phone?)
                        $cl_user_phone,
						array(
							'from' => $twilio_number,
							'body' => $sms_body
						)
					);
				}
				catch ( Exception $e ) {
                    print_r( $e->getMessage(), 1 );
                }
			}
		}
        return $is_sms_sent;
		// Twilio sending sms ends
	}

	/**
	 * @desc submitting  twilio sms required data to send sms
	 * @param $payload
	 * @return array
	 */
    public static function twilio_sms_submit()
    {
        $twilio_nonce = isset( $_POST[ 'nonce' ] ) ? $_POST[ 'nonce' ] : '';

        if( wp_verify_nonce( $twilio_nonce, 'cart-lift-pro' ) ) {
            $enabler    = isset( $_POST[ 'enabler' ] ) ? $_POST[ 'enabler' ] : 0;
            $sid        = isset( $_POST[ 'twilio_account_sid' ] ) ? $_POST[ 'twilio_account_sid' ] : '';
            $token      = isset( $_POST[ 'twilio_auth_token' ] ) ? $_POST[ 'twilio_auth_token' ] : '';
            $mobile     = isset( $_POST[ 'twilio_mobile_number' ] ) ? $_POST[ 'twilio_mobile_number' ] : '';

            if ( ($enabler && $sid != '' && $token != '' && $mobile != '') || !$enabler ) {
                if ( !$enabler ) {
                    $twilio_settings = array(
                        'enabler'              => $_POST[ 'enabler' ],
                        'twilio_account_sid'   => $sid,
                        'twilio_auth_token'    => $token,
                        'twilio_mobile_number' => $mobile
                    );

                    update_option( 'cl_twilio_settings', $twilio_settings );

                    $response = array(
                        'status'  => true,
                        'message' => __('Successfully Saved', 'cart-lift-pro'),
                    );

                    wp_send_json( $response );
                }
                else {
                    $curl = curl_init();
                    curl_setopt_array(
                        $curl, array(
                        CURLOPT_URL            => 'https://accounts.twilio.com/v1/Credentials/PublicKeys',
                        CURLOPT_USERPWD        => $sid . ':' . $token,
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING       => '',
                        CURLOPT_MAXREDIRS      => 10,
                        CURLOPT_TIMEOUT        => 0,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST  => 'GET'

                    ) );

                    $curl_response = curl_exec( $curl );
                    curl_close( $curl );
                    $curl_response = json_decode( $curl_response );

                    if ( !property_exists( $curl_response, 'status' ) ) {
                        $twilio_settings = array(
                            'enabler'              => $_POST[ 'enabler' ],
                            'twilio_account_sid'   => $sid,
                            'twilio_auth_token'    => $token,
                            'twilio_mobile_number' => $mobile
                        );

                        update_option( 'cl_twilio_settings', $twilio_settings );

                        $response = array(
                            'status'  => true,
                            'message' => __('Successfully Saved', 'cart-lift-pro'),
                        );

                        wp_send_json( $response );
                    }
                    else if ( $curl_response->message ) {
                        $message = 'Error Saving Data';

                        if ( $curl_response->message === 'Authenticate' ) {
                            $message = 'Invalid Auth Token';
                        }
                        else {
                            $message = 'Invalid Account SID';
                        }
                        $response = array(
                            'status'  => false,
                            'message' => $message,
                        );

                        wp_send_json( $response );
                    }
                }
            }
            else {
                $message = 'Can Not Save Blank Field(s)';

                $response = array(
                    'status'  => false,
                    'message' => $message,
                );

                wp_send_json( $response );
            }
        }
        else{
            $response = array(
                'status'  => false,
                'message' => 'Error Saving Data',
            );

            wp_send_json( $response );
        }
    }


    public static function twilio_sms_cron()
    {
        global $wpdb;
        $cl_cart_table             = $wpdb->prefix . CART_LIFT_CART_TABLE;
        $cl_email_table            = $wpdb->prefix . CART_LIFT_EMAIL_TEMPLATE_TABLE;
        $cl_campaign_history_table = $wpdb->prefix . CART_LIFT_CAMPAIGN_HISTORY_TABLE;
        $current_time              = current_time( CART_LIFT_DATETIME_FORMAT );

        $scheduled_sms_query = "SELECT h.id, h.campaign_id, h.session_id, e.twilio_sms, e.twilio_sms_body, c.email, e.email_meta, c.status, c.cart_contents, c.cart_total, c.cart_meta, c.provider, c.time, c.id as cart_id from $cl_campaign_history_table as h
            INNER JOIN $cl_email_table as e ON h.campaign_id = e.id
            INNER JOIN $cl_cart_table as c ON h.session_id = c.session_id
            WHERE h.sms_sent = 0 AND c.unsubscribed = 0 AND h.schedule_time <= %s AND c.status = %s AND c.schedular_status = %s";

        $schedule_sms = array();

        try {
            $schedule_sms = $wpdb->get_results( $wpdb->prepare( $scheduled_sms_query, $current_time, 'abandoned', 'active' ) );
        }
        catch ( Exception $e ) {}

        try {
            foreach ( $schedule_sms as $schedule ) {
                $process_sms = apply_filters( 'cl_before_process_sms', true, $schedule );

                if( $process_sms ) {
                    $sms_data    = cl_get_scheduled_log_data( $schedule );
                    $track_purchased_product_status = cl_get_general_settings_data( 'disable_purchased_products_campaign' );

                    if ( $track_purchased_product_status ) {
                        $orders = cl_get_orders_by_email( $sms_data->email, $sms_data->provider, $sms_data->time );
                        $is_product_ordered = cl_check_if_product_is_ordered( $orders, $sms_data->cart_contents, $sms_data->provider );
                    }
                    else {
                        $is_product_ordered = false;
                    }

                    if ( $is_product_ordered ) {
                        $wpdb->update(
                            $cl_campaign_history_table,
                            array(
                                'sms_sent' => -1,
                            ),
                            array(
                                'id' => $schedule->id
                            )
                        );
                        $wpdb->update(
                            $cl_cart_table,
                            array(
                                'status' => 'discard',
                            ),
                            array(
                                'session_id' => $sms_data->session_id
                            )
                        );
                    }
                    else {
                        $is_sms_sent = self::cl_send_twilio_sms( $sms_data );

                        if ( $is_sms_sent ) {
                            $wpdb->update(
                                $cl_campaign_history_table,
                                array(
                                    'sms_sent' => 1,
                                ),
                                array(
                                    'id' => $schedule->id
                                )
                            );
                            $wpdb->update(
                                $cl_cart_table,
                                array(
                                    'last_sent_sms' => $schedule->campaign_id,
                                ),
                                array(
                                    'session_id' => $sms_data->session_id
                                )
                            );
                        }
                    }
                }
            }
        }
        catch ( Exception $e ) {}
    }
}