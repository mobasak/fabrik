<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://rextheme.com/
 * @since      1.0.0
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/admin/partials
 */

if ( apply_filters( 'is_cl_premium', false ) ) {
    $twilio_settings = get_option( 'cl_twilio_settings' );
    $enabler         = isset( $twilio_settings[ 'enabler' ] ) ? (int)$twilio_settings[ 'enabler' ] : 0;

    $twilio_account_sid   = isset( $twilio_settings[ 'twilio_account_sid' ] ) ? $twilio_settings[ 'twilio_account_sid' ] : '';
    $twilio_auth_token    = isset( $twilio_settings[ 'twilio_auth_token' ] ) ? $twilio_settings[ 'twilio_auth_token' ] : '';
    $twilio_mobile_number = isset( $twilio_settings[ 'twilio_mobile_number' ] ) ? $twilio_settings[ 'twilio_mobile_number' ] : '';
}
?>
<div class="twilio-sms-settings-wrapper">
    <form id="twilio-sms-settings">
        <div class="cl-atc-popup-settings">
            <div class="cl-form-group-wrapper">
                <div class="cl-form-group">
                    <span class="title"><?php _e( 'Enable Twilio SMS Notification:', 'cart-lift-pro' ); ?></span>
                    <span class="cl-switcher">
                        <input class="cl-toggle" type="checkbox" id="twilio_sms" name="twilio_sms"
                               <?php
                               if ( apply_filters( 'is_cl_premium', false ) ) {
                                   if ( $enabler === 1 ) {
                                       echo 'checked';
                                   }
                               }
                               ?>
                        />
                        <label for="twilio_sms"></label>
                    </span>
                    
                    <div class="tooltip">
                        <span class="icon">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 19" width="18" height="19">
                                <defs>
                                    <clipPath clipPathUnits="userSpaceOnUse" id="cp1">
                                        <path d="M-941 -385L379 -385L379 866L-941 866Z"></path>
                                    </clipPath>
                                </defs>
                                <style>
                                    tspan {
                                        white-space: pre
                                    }

                                    .shp0 {
                                        fill: #6e42d3
                                    }
                                </style>
                                <g id="Final Create New Abandoned Cart Campaign " clip-path="url(#cp1)">
                                    <g id="name">
                                        <g id="question">
                                            <path id="Shape" fill-rule="evenodd" class="shp0" d="M18 10C18 14.97 13.97 19 9 19C4.03 19 0 14.97 0 10C0 5.03 4.03 1 9 1C13.97 1 18 5.03 18 10ZM16.8 10C16.8 5.7 13.3 2.2 9 2.2C4.7 2.2 1.2 5.7 1.2 10C1.2 14.3 4.7 17.8 9 17.8C13.3 17.8 16.8 14.3 16.8 10Z"></path>
                                            <path id="Path" class="shp0" d="M8.71 11.69C8.25 11.69 7.87 12.07 7.87 12.53C7.87 12.98 8.24 13.37 8.71 13.37C9.19 13.37 9.56 12.98 9.56 12.53C9.56 12.07 9.18 11.69 8.71 11.69Z"></path>
                                            <path id="Path" class="shp0" d="M8.64 6.06C7.35 6.06 6.75 6.85 6.75 7.38C6.75 7.77 7.07 7.94 7.33 7.94C7.84 7.94 7.63 7.19 8.61 7.19C9.09 7.19 9.48 7.4 9.48 7.86C9.48 8.39 8.94 8.69 8.62 8.97C8.34 9.21 7.98 9.62 7.98 10.47C7.98 10.98 8.11 11.12 8.51 11.12C8.98 11.12 9.07 10.91 9.07 10.72C9.07 10.21 9.08 9.91 9.61 9.49C9.87 9.28 10.69 8.61 10.69 7.69C10.69 6.76 9.87 6.06 8.64 6.06Z"></path>
                                        </g>
                                    </g>
                                </g>
                            </svg>
                        </span>
                        <p><?php _e( 'This will enable twilio sms notification.', 'cart-lift-pro' ); ?></p>
                    </div>
                </div>

                <div id="twilio_sms_setting_fields" style="display: none">
                    <div class="cl-form-group">
                        <span class="title"><?php _e( 'Account SID:', 'cart-lift-pro' ); ?></span>
                        <input v-model="title" class="modal_title" type="text" placeholder="<?php _e('Account SID', 'cart-lift-pro' )?>" id="twilio_account_sid" name="twilio_account_sid" value="<?php echo $twilio_account_sid?>"/>

                        <div class="tooltip">
                            <span class="icon">
                                <a href="https://www.twilio.com/console" target="_blank">
                                    <img src="<?php echo CART_LIFT_PRO_URL. 'admin/images/question-icon.png' ?>" alt="icon">
                                </a>
                            </span>
                            <p><?php _e( 'Click to get your Account SID.', 'cart-lift-pro' ); ?></p>
                        </div>
                    </div>

                    <div class="cl-form-group">
                        <span class="title"><?php _e( 'Auth Token:', 'cart-lift-pro' ); ?></span>
                        <input class="button-text" type="password" placeholder="<?php _e('Authentication Token', 'cart-lift-pro' )?>" id="twilio_auth_token" name="twilio_auth_token"  v-model="button_text" value="<?php echo $twilio_auth_token?>">

                        <div class="tooltip">
                            <span class="icon">
                                <a href="https://www.twilio.com/console" target="_blank">
                                    <img src="<?php echo CART_LIFT_PRO_URL. 'admin/images/question-icon.png' ?>" alt="icon">
                                </a>
                            </span>
                            <p><?php _e( 'Click to get your Auth Token.', 'cart-lift-pro' ); ?></p>
                        </div>

                    </div>

                    <div class="cl-form-group">
                        <span class="title"><?php _e( 'Mobile Number:', 'cart-lift-pro' ); ?></span>
                        <input class="button-text" type="text" placeholder="+1234567890" id="twilio_mobile_number" name="twilio_mobile_number"  v-model="button_text"  value="<?php echo $twilio_mobile_number?>">

                        <div class="tooltip">
                            <span class="icon">
                                <a href="https://www.twilio.com/console" target="_blank">
                                    <img src="<?php echo CART_LIFT_PRO_URL. 'admin/images/question-icon.png' ?>" alt="icon">
                                </a>
                            </span>
                            <p><?php _e( 'Click to get your Mobile Number.', 'cart-lift-pro' ); ?></p>
                        </div>
                    </div>

                    <div class="btn-area">
                        <button id="twilio_sms" class="cl-btn"><?php _e( 'Save Settings', 'cart-lift-pro' ); ?></button>
                        <p id="twilio_sms_notice" class="cl-notice" style="display:none;"></p>
                    </div>

                </div>

            </div>
        </div>
    </form>
</div>