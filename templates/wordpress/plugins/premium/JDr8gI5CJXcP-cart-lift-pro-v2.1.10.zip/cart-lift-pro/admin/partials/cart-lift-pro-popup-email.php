<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://rextheme.com/
 * @since      1.0.0
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/admin/partials
 */

$pop_up_options   = get_option('cl_popup_settings');
$no_thanks_button = isset($pop_up_options['no_thanks_btn']) ? $pop_up_options['no_thanks_btn'] : 'on';
$checked          = $no_thanks_button === 'on' ? 'checked' : '';
?>

<template id="cl-atc-vue-app">

    <div class="popup-settings-wrapper-area">
        <div class="popup-settings-wrapper">

            <form id="email-popup-settings">

                <div class="cl-atc-popup-settings">
                    <div class="cl-form-group-wrapper">
                        <div class="cl-form-group">
                            <span class="title"><?php echo __('Enable Cart Lift Popup:', 'cart-lift-pro'); ?></span>
                            <span class="cl-switcher">
                                <input class="cl-toggle" type="checkbox" id="email_popup" name="email_popup" data-status="status" true-value="1" false-value="0" :value="enabled" data-value="enabled" v-model="enabled" @change="check($event)" />
                                <label for="email_popup"></label>
                            </span>
                            <div class="tooltip">
                                <span class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 19" width="18" height="19">
                                        <defs>
                                            <clipPath clipPathUnits="userSpaceOnUse" id="cp1">
                                                <path d="M-941 -385L379 -385L379 866L-941 866Z"></path>
                                            </clipPath>
                                        </defs>
                                        <style>
                                            tspan {
                                                white-space: pre
                                            }

                                            .shp0 {
                                                fill: #6e42d3
                                            }
                                        </style>
                                        <g id="Final Create New Abandoned Cart Campaign " clip-path="url(#cp1)">
                                            <g id="name">
                                                <g id="question">
                                                    <path id="Shape" fill-rule="evenodd" class="shp0" d="M18 10C18 14.97 13.97 19 9 19C4.03 19 0 14.97 0 10C0 5.03 4.03 1 9 1C13.97 1 18 5.03 18 10ZM16.8 10C16.8 5.7 13.3 2.2 9 2.2C4.7 2.2 1.2 5.7 1.2 10C1.2 14.3 4.7 17.8 9 17.8C13.3 17.8 16.8 14.3 16.8 10Z"></path>
                                                    <path id="Path" class="shp0" d="M8.71 11.69C8.25 11.69 7.87 12.07 7.87 12.53C7.87 12.98 8.24 13.37 8.71 13.37C9.19 13.37 9.56 12.98 9.56 12.53C9.56 12.07 9.18 11.69 8.71 11.69Z"></path>
                                                    <path id="Path" class="shp0" d="M8.64 6.06C7.35 6.06 6.75 6.85 6.75 7.38C6.75 7.77 7.07 7.94 7.33 7.94C7.84 7.94 7.63 7.19 8.61 7.19C9.09 7.19 9.48 7.4 9.48 7.86C9.48 8.39 8.94 8.69 8.62 8.97C8.34 9.21 7.98 9.62 7.98 10.47C7.98 10.98 8.11 11.12 8.51 11.12C8.98 11.12 9.07 10.91 9.07 10.72C9.07 10.21 9.08 9.91 9.61 9.49C9.87 9.28 10.69 8.61 10.69 7.69C10.69 6.76 9.87 6.06 8.64 6.06Z"></path>
                                                </g>
                                            </g>
                                        </g>
                                    </svg>
                                </span>
                                <p><?php echo __('This will initiate a pop-up and prompt guest users to provide email addresses when they add product to cart.', 'cart-lift-pro'); ?></p>
                            </div>
                        </div>

                        <div class="cl-form-group">
                            <span class="title"><?php echo __('Enable Cart Lift Popup Exit:', 'cart-lift-pro'); ?></span>
                            <span class="cl-switcher">
                                <input class="cl-toggle" type="checkbox" id="email_popup_exit" name="email_popup_exit" data-status="status" true-value="1" false-value="0" :value="enabled_exit" data-value="enabled_exit" v-model="enabled_exit" @change="check_exit($event)" />
                                <label for="email_popup_exit"></label>
                            </span>
                            <div class="tooltip">
                                <span class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 19" width="18" height="19">
                                        <defs>
                                            <clipPath clipPathUnits="userSpaceOnUse" id="cp1">
                                                <path d="M-941 -385L379 -385L379 866L-941 866Z"></path>
                                            </clipPath>
                                        </defs>
                                        <style>
                                            tspan {
                                                white-space: pre
                                            }

                                            .shp0 {
                                                fill: #6e42d3
                                            }
                                        </style>
                                        <g id="Final Create New Abandoned Cart Campaign " clip-path="url(#cp1)">
                                            <g id="name">
                                                <g id="question">
                                                    <path id="Shape" fill-rule="evenodd" class="shp0" d="M18 10C18 14.97 13.97 19 9 19C4.03 19 0 14.97 0 10C0 5.03 4.03 1 9 1C13.97 1 18 5.03 18 10ZM16.8 10C16.8 5.7 13.3 2.2 9 2.2C4.7 2.2 1.2 5.7 1.2 10C1.2 14.3 4.7 17.8 9 17.8C13.3 17.8 16.8 14.3 16.8 10Z"></path>
                                                    <path id="Path" class="shp0" d="M8.71 11.69C8.25 11.69 7.87 12.07 7.87 12.53C7.87 12.98 8.24 13.37 8.71 13.37C9.19 13.37 9.56 12.98 9.56 12.53C9.56 12.07 9.18 11.69 8.71 11.69Z"></path>
                                                    <path id="Path" class="shp0" d="M8.64 6.06C7.35 6.06 6.75 6.85 6.75 7.38C6.75 7.77 7.07 7.94 7.33 7.94C7.84 7.94 7.63 7.19 8.61 7.19C9.09 7.19 9.48 7.4 9.48 7.86C9.48 8.39 8.94 8.69 8.62 8.97C8.34 9.21 7.98 9.62 7.98 10.47C7.98 10.98 8.11 11.12 8.51 11.12C8.98 11.12 9.07 10.91 9.07 10.72C9.07 10.21 9.08 9.91 9.61 9.49C9.87 9.28 10.69 8.61 10.69 7.69C10.69 6.76 9.87 6.06 8.64 6.06Z"></path>
                                                </g>
                                            </g>
                                        </g>
                                    </svg>
                                </span>
                                <p><?php echo __('This will initiate a pop-up and prompt guest users to provide email addresses when move cursor over the taskbar.', 'cart-lift-pro'); ?></p>
                            </div>
                        </div>

                        <div class="cl-form-group">
                            <span class="title"><?php echo __('Include "No Thanks" Button:', 'cart-lift-pro'); ?></span>
                            <span class="cl-switcher">
                                <input class="cl-toggle" type="checkbox" id="no_thanks_btn" name="no_thanks_btn" <?php echo $checked ?> />
                                <label for="no_thanks_btn"></label>
                            </span>
                            <div class="tooltip">
                                <span class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 19" width="18" height="19">
                                        <defs>
                                            <clipPath clipPathUnits="userSpaceOnUse" id="cp1">
                                                <path d="M-941 -385L379 -385L379 866L-941 866Z"></path>
                                            </clipPath>
                                        </defs>
                                        <style>
                                            tspan {
                                                white-space: pre
                                            }

                                            .shp0 {
                                                fill: #6e42d3
                                            }
                                        </style>
                                        <g id="Final Create New Abandoned Cart Campaign " clip-path="url(#cp1)">
                                            <g id="name">
                                                <g id="question">
                                                    <path id="Shape" fill-rule="evenodd" class="shp0" d="M18 10C18 14.97 13.97 19 9 19C4.03 19 0 14.97 0 10C0 5.03 4.03 1 9 1C13.97 1 18 5.03 18 10ZM16.8 10C16.8 5.7 13.3 2.2 9 2.2C4.7 2.2 1.2 5.7 1.2 10C1.2 14.3 4.7 17.8 9 17.8C13.3 17.8 16.8 14.3 16.8 10Z"></path>
                                                    <path id="Path" class="shp0" d="M8.71 11.69C8.25 11.69 7.87 12.07 7.87 12.53C7.87 12.98 8.24 13.37 8.71 13.37C9.19 13.37 9.56 12.98 9.56 12.53C9.56 12.07 9.18 11.69 8.71 11.69Z"></path>
                                                    <path id="Path" class="shp0" d="M8.64 6.06C7.35 6.06 6.75 6.85 6.75 7.38C6.75 7.77 7.07 7.94 7.33 7.94C7.84 7.94 7.63 7.19 8.61 7.19C9.09 7.19 9.48 7.4 9.48 7.86C9.48 8.39 8.94 8.69 8.62 8.97C8.34 9.21 7.98 9.62 7.98 10.47C7.98 10.98 8.11 11.12 8.51 11.12C8.98 11.12 9.07 10.91 9.07 10.72C9.07 10.21 9.08 9.91 9.61 9.49C9.87 9.28 10.69 8.61 10.69 7.69C10.69 6.76 9.87 6.06 8.64 6.06Z"></path>
                                                </g>
                                            </g>
                                        </g>
                                    </svg>
                                </span>
                                <p><?php echo __('This will include a "No Thanks" button in the pop-up option.', 'cart-lift-pro'); ?></p>
                            </div>
                        </div>

                        <div class="cl-form-group logo-upload">
                            <span class="title"><?php echo __('Logo:', 'cart-lift-pro'); ?></span>
                            <div class="upload-area">
                                <input type="hidden" name="popup_logo_src" id="popup_logo_src" class="" v-model="logo" />
                                <input type="hidden" name="attachment_id" class="popup_logo_id" id="popup_logo_id" v-model="logo_id" />

                                <div class="upload-preview">
                                    <div class="cl-upload-icon">
                                        <img v-if="logo" :src="logo" id="popup_logo_preview" alt="popup-logo" style="display:block" />
                                        <span class="remove-icon action-icon" title="<?php _e('Remove Logo', 'cart-lift-pro'); ?>" id="remove_popup_logo" @click="remove">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="23" viewBox="0 0 22 23" fill="none">
                                                <circle cx="11" cy="11.8846" r="10.5" fill="white" stroke="#F0ECFA"/>
                                                <path d="M14.4375 8.44711L7.5625 15.3221" stroke="#EF7E32" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M7.5625 8.44711L14.4375 15.3221" stroke="#EF7E32" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                        </span>
                                    </div>
                                
                                    

                                    <button type="button" class="upload-btn action-icon" id="upload_popup_logo" title="<?php _e('Upload Logo', 'cart-lift-pro'); ?>" @click="upload">
                                        <?php echo __('Upload Logo', 'cart-lift-pro'); ?>
                                    </button>
                                </div>

                            </div>
                        </div>


                        <div class="cl-popup-tab-area">
                            <nav class="tab-menu" aria-label="Tab navigation">
                                <ul role="tablist">
                                    <li role="presentation">
                                        <a href="#" class="cl-popup-tab-a active-a" data-id="tab1" role="tab" aria-controls="tab1" aria-selected="true" tabindex="0"><?php echo __('Title', 'cart-lift-pro'); ?></a>
                                    </li>
                                    <li role="presentation">
                                        <a href="#" class="cl-popup-tab-a" data-id="tab2" role="tab" aria-controls="tab2" aria-selected="false" tabindex="-1"><?php echo __('Description', 'cart-lift-pro'); ?></a>
                                    </li>
                                    <li role="presentation">
                                        <a href="#" class="cl-popup-tab-a" data-id="tab3" role="tab" aria-controls="tab3" aria-selected="false" tabindex="-1"><?php echo __('Button', 'cart-lift-pro'); ?></a>
                                    </li>
                                    <li role="presentation">
                                        <a href="#" class="cl-popup-tab-a" data-id="tab4" role="tab" aria-controls="tab4" aria-selected="false" tabindex="-1"><?php echo __('Popup', 'cart-lift-pro'); ?></a>
                                    </li>
                                </ul>
                            </nav><!--end of tab-menu-->

                            <section class="tab tab-active" data-id="tab1" role="tabpanel" id="tab1" aria-labelledby="tab1">
                                <div class="cl-popup-content-area">
                                    <!-- popup title -->
                                    <div class="cl-form-group">
                                        <span class="title"><?php echo __('Popup Title:', 'cart-lift-pro'); ?></span>
                                        <input v-model="title" class="modal_title" type="text" id="modal_title" name="modal_title" />
                                    </div>
                                    <!--popup title typography accordion start -->
                                    <div class="cl-form-group">
                                        <span class="title"><?php echo __('Typography: ', 'cart-lift-pro'); ?></span>
                                        
                                        <div class="cl-accordion">
                                            <div class="cl-accordion-item">
                                                <div class="cl-accordion-title"><?php echo __('Please Select','cart-lift-pro'); ?>
                                                    <span class="cl-accordion-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24">
                                                            <path fill="currentColor" d="M12 15.25a.74.74 0 0 1-.53-.22l-5-5A.75.75 0 0 1 7.53 9L12 13.44L16.47 9a.75.75 0 0 1 1.06 1l-5 5a.74.74 0 0 1-.53.25" />
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="cl-accordion-content">
                                                    <div class="cl-accordion-content-wrapper">
                                                        <!-- popup title alignment -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Text Alignment:', 'cart-lift-pro'); ?></span>
                                                            <select v-model="titleAlignment" class="cl-modal-title-alignment-input" id="modal_title_alignment" name="modal_title_alignment" value='<?php echo isset($pop_up_options['payloadNew']['heading']['text-align']) ? $pop_up_options['payloadNew']['heading']['text-align'] : 'center'; ?>'>
                                                                <option value="left"><?php echo __('Left', 'cart-lift-pro') ?></option>
                                                                <option value="right"><?php echo __('Right', 'cart-lift-pro')?></option>
                                                                <option value="center"><?php echo __('Center', 'cart-lift-pro')?></option>
                                                                <option value="justify"><?php echo __('Justify', 'cart-lift-pro')?></option>
                                                            </select>
                                                        </div>
                                                        <!-- modal title font size -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Font Size (px): ', 'cart-lift-pro'); ?></span>
                                                            <input v-model="titleFontSize" class="cl-modal-title-fontSize-input" type="number" min="0" id="modal_title_fontSize" name="modal_title_fontSize" value='<?php echo isset($pop_up_options['payloadNew']['heading']['font-size']) ? $pop_up_options['payloadNew']['heading']['font-size'] : '22'; ?>' />
                                                        </div>
                                                        <!-- modal title font weight -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Font Weight: ', 'cart-lift-pro'); ?></span>
                                                            <select v-model="titleFontWeight" class="cl-modal-title-fontWeight-input" id="modal_title_fontWeight" name="modal_title_fontWeight" value='<?php echo isset($pop_up_options['payloadNew']['heading']['font-weight']) ? $pop_up_options['payloadNew']['heading']['font-weight'] : 'normal'; ?>'>
                                                                <option value=100><?php echo __('100', 'cart-lift-pro') ?></option>
                                                                <option value=200><?php echo __('200', 'cart-lift-pro') ?></option>
                                                                <option value=300><?php echo __('300', 'cart-lift-pro') ?></option>
                                                                <option value=400><?php echo __('400', 'cart-lift-pro') ?></option>
                                                                <option value=500><?php echo __('500', 'cart-lift-pro') ?></option>
                                                                <option value=600><?php echo __('600', 'cart-lift-pro') ?></option>
                                                                <option value=700><?php echo __('700', 'cart-lift-pro') ?></option>
                                                                <option value=800><?php echo __('800', 'cart-lift-pro') ?></option>
                                                                <option value=900><?php echo __('900', 'cart-lift-pro') ?></option>
                                                                <option value="normal"><?php echo __('Normal', 'cart-lift-pro') ?></option>
                                                                <option value="bold"><?php echo __('Bold', 'cart-lift-pro') ?></option>
                                                                <option value="bolder"><?php echo __('Bolder', 'cart-lift-pro') ?></option>
                                                                <option value="lighter"><?php echo __('Lighter', 'cart-lift-pro') ?></option>
                                                                <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                                <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>
                                                        <!-- modal title font style -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Font Style:', 'cart-lift-pro'); ?></span>
                                                            <select v-model="titleFontStyle" class="cl-modal-title-fontStyle-input" id="modal_title_fontStyle" name="modal_title_fontStyle" value='<?php echo isset($pop_up_options['payloadNew']['heading']['font-style']) ? $pop_up_options['payloadNew']['heading']['font-style'] : 'normal'; ?>'>
                                                                <option value="normal"><?php echo __('Normal', 'cart-lift-pro') ?></option>
                                                                <option value="italic"><?php echo __('Italic', 'cart-lift-pro') ?></option>
                                                                <option value="oblique"><?php echo __('Oblique', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>
                                                        <!-- modal title text transform -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Text Transform:', 'cart-lift-pro'); ?></span>
                                                            <select v-model="titleTransformation" class="cl-modal-title-transformation-input" id="modal_title_transformation" name="modal_title_transformation" value='<?php echo isset($pop_up_options['payloadNew']['heading']['text-transform']) ? $pop_up_options['payloadNew']['heading']['text-transform'] : 'none'; ?>'>
                                                                <option value="none"><?php echo __('None', 'cart-lift-pro') ?></option>
                                                                <option value="capitalize"><?php echo __('Capitalize', 'cart-lift-pro') ?></option>
                                                                <option value="uppercase"><?php echo __('Uppercase', 'cart-lift-pro') ?></option>
                                                                <option value="lowercase"><?php echo __('Lowercase', 'cart-lift-pro') ?></option>
                                                                <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                                <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>
                                                        <!-- modal title text decoration -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Text Decoration:', 'cart-lift-pro'); ?></span>
                                                            <select v-model="titleDecoration" class="cl-modal-title-decoration-input" id="modal_title_decoration" name="modal_title_decoration" value='<?php echo isset($pop_up_options['payloadNew']['heading']['text-decoration']) ? $pop_up_options['payloadNew']['heading']['text-decoration'] : 'none'; ?>'>
                                                                <option value="none"><?php echo __('None', 'cart-lift-pro') ?></option>
                                                                <option value="underline"><?php echo __('Underline', 'cart-lift-pro') ?></option>
                                                                <option value="overline"><?php echo __('Overline', 'cart-lift-pro') ?></option>
                                                                <option value="line-through"><?php echo __('Line Through', 'cart-lift-pro') ?></option>
                                                                <option value="underline overline"><?php echo __('Underline Overline', 'cart-lift-pro') ?></option>
                                                                <option value="underline line-through"><?php echo __('Underline Line Through', 'cart-lift-pro') ?></option>
                                                                <option value="overline line-through"><?php echo __('Overline Line Through', 'cart-lift-pro') ?></option>
                                                                <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                                <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>
                                                        <!-- modal title line height -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Line height (em): ', 'cart-lift-pro'); ?></span>
                                                            <input v-model="titleLineHeight" class="cl-modal-title-lineHeight-input" type="number" step=".1" id="modal_title_lineHeight" name="modal_title_lineHeight" value='<?php echo isset($pop_up_options['payloadNew']['heading']['line-height']) ? $pop_up_options['payloadNew']['heading']['line-height'] : '1.5'; ?>' />
                                                        </div>
                                                        <!-- modal title letter spacing -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Letter Spacing (px): ', 'cart-lift-pro'); ?></span>
                                                            <input v-model="titleLetterSpacing" class="cl-modal-title-letterSpacing-input" type="number" step=".1" id="modal_title_letterSpacing" name="modal_title_letterSpacing" value='<?php echo isset($pop_up_options['payloadNew']['heading']['letter-spacing']) ? $pop_up_options['payloadNew']['heading']['letter-spacing'] : '0'; ?>' />
                                                        </div>
                                                        <!-- modal title word spacing -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Word Spacing (px): ', 'cart-lift-pro'); ?></span>
                                                            <input v-model="titleWordSpacing" class="cl-modal-title-wordSpacing-input" type="number" step=".1" id="modal_title_wordSpacing" name="modal_title_wordSpacing" value='<?php echo isset($pop_up_options['payloadNew']['heading']['word-spacing']) ? $pop_up_options['payloadNew']['heading']['word-spacing'] : '0'; ?>' />
                                                        </div>
                                                        <!-- modal title color -->
                                                        <div class="cl-item">
                                                            <?php
                                                            $title_color = isset($pop_up_options['payloadNew']['heading']['color']) && $pop_up_options['payloadNew']['heading']['color'] !== '' ? $pop_up_options['payloadNew']['heading']['color'] : '#333'
                                                            ?>
                                                            <span class="cl-item-color-palate"><?php echo __('Text Color:', 'cart-lift-pro'); ?></span>
                                                            <input class="cl-wp-title-color-picker" type="text" value="<?php echo $title_color; ?>" id="modal_title_color" name="modal_title_color">
                                                        </div>
                                                        <!-- modal title color end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section><!--end of tab one-->

                            <section class="tab" data-id="tab2" role="tabpanel" id="tab2" aria-labelledby="tab2" hidden>
                                <!-- popup description start -->
                                <div class="cl-popup-content-area">
                                    <div class="cl-form-group">
                                        <span class="title"><?php echo __('Popup Description:', 'cart-lift-pro'); ?></span>
                                        <textarea role="1" class="cl-modal-description" id="modal_description" type="text" name="cl-modal-description" v-model="description">{{ description }}</textarea>
                                    </div>

                                    <!--popup description typography accordion start -->
                                    <div class="cl-form-group">
                                        <span class="title"><?php echo __('Typography:','cart-lift-pro'); ?></span>
                                        <div class="cl-accordion">
                                            <div class="cl-accordion-item">
                                                <div class="cl-accordion-title"><?php echo __('Please Select','cart-lift-pro'); ?>
                                                    <span class="cl-accordion-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24">
                                                            <path fill="currentColor" d="M12 15.25a.74.74 0 0 1-.53-.22l-5-5A.75.75 0 0 1 7.53 9L12 13.44L16.47 9a.75.75 0 0 1 1.06 1l-5 5a.74.74 0 0 1-.53.25" />
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="cl-accordion-content">
                                                    <div class="cl-accordion-content-wrapper">
                                                        <!-- popup description alignment -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Text Alignment:', 'cart-lift-pro'); ?></span>
                                                            <select v-model="descriptionAlignment" class="cl-modal-description-alignment-input" id="modal_description_alignment" name="modal_description_alignment" value='<?php echo isset($pop_up_options['payloadNew']['content']['text-align']) ? $pop_up_options['payloadNew']['content']['text-align'] : 'center'; ?>'>
                                                                <option value="left"><?php echo __('Left', 'cart-lift-pro') ?></option>
                                                                <option value="right"><?php echo __('Right', 'cart-lift-pro') ?></option>
                                                                <option value="center"><?php echo __('Center', 'cart-lift-pro') ?></option>
                                                                <option value="justify"><?php echo __('Justify', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>
                                                        <!-- modal title font size -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Font Size (px): ', 'cart-lift-pro'); ?></span>
                                                            <input v-model="descriptionFontSize" class="cl-modal-description-fontSize-input" type="number" min="0" id="modal_description_fontSize" name="modal_description_fontSize" value='<?php echo isset($pop_up_options['payloadNew']['content']['font-size']) ? $pop_up_options['payloadNew']['content']['font-size'] : '16'; ?>' />
                                                        </div>
                                                        <!-- modal description font weight -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Font Weight: ', 'cart-lift-pro'); ?></span>
                                                            <select v-model="descriptionFontWeight" class="cl-modal-description-fontWeight-input" id="modal_description_fontWeight" name="modal_description_fontWeight" value='<?php echo isset($pop_up_options['payloadNew']['content']['font-weight']) ? $pop_up_options['payloadNew']['content']['font-weight'] : '400'; ?>'>
                                                                <option value=100><?php echo __('100', 'cart-lift-pro') ?></option>
                                                                <option value=200><?php echo __('200', 'cart-lift-pro') ?></option>
                                                                <option value=300><?php echo __('300', 'cart-lift-pro') ?></option>
                                                                <option value=400><?php echo __('400', 'cart-lift-pro') ?></option>
                                                                <option value=500><?php echo __('500', 'cart-lift-pro') ?></option>
                                                                <option value=600><?php echo __('600', 'cart-lift-pro') ?></option>
                                                                <option value=700><?php echo __('700', 'cart-lift-pro') ?></option>
                                                                <option value=800><?php echo __('800', 'cart-lift-pro') ?></option>
                                                                <option value=900><?php echo __('900', 'cart-lift-pro') ?></option>
                                                                <option value="normal"><?php echo __('Normal', 'cart-lift-pro') ?></option>
                                                                <option value="bold"><?php echo __('Bold', 'cart-lift-pro') ?></option>
                                                                <option value="bolder"><?php echo __('Bolder', 'cart-lift-pro') ?></option>
                                                                <option value="lighter"><?php echo __('Lighter', 'cart-lift-pro') ?></option>
                                                                <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                                <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>
                                                        <!-- modal description font style -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Font Style:', 'cart-lift-pro'); ?></span>
                                                            <select v-model="descriptionFontStyle" class="cl-modal-description-fontStyle-input" id="modal_description_fontStyle" name="modal_description_fontStyle" value='<?php echo isset($pop_up_options['payloadNew']['content']['font-style']) ? $pop_up_options['payloadNew']['content']['font-style'] : 'normal'; ?>'>
                                                                <option value="normal"><?php echo __('Normal', 'cart-lift-pro') ?></option>
                                                                <option value="italic"><?php echo __('Italic', 'cart-lift-pro') ?></option>
                                                                <option value="oblique"><?php echo __('Oblique', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>

                                                        <!-- modal description text transform -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Text Transform:', 'cart-lift-pro'); ?></span>
                                                            <select v-model="descriptionTransformation" class="cl-modal-description-transformation-input" id="modal_description_transformation" name="modal_description_transformation" value='<?php echo isset($pop_up_options['payloadNew']['content']['text-transform']) ? $pop_up_options['payloadNew']['content']['text-transform'] : 'none'; ?>'>
                                                                <option value="none"><?php echo __('None', 'cart-lift-pro') ?></option>
                                                                <option value="capitalize"><?php echo __('Capitalize', 'cart-lift-pro') ?></option>
                                                                <option value="uppercase"><?php echo __('Uppercase', 'cart-lift-pro') ?></option>
                                                                <option value="lowercase"><?php echo __('Lowercase', 'cart-lift-pro') ?></option>
                                                                <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                                <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>

                                                        <!-- modal description text decoration -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Text Decoration:', 'cart-lift-pro'); ?></span>
                                                            <select v-model="descriptionDecoration" class="cl-modal-description-decoration-input" id="modal_description_decoration" name="modal_description_decoration" value='<?php echo isset($pop_up_options['payloadNew']['content']['text-decoration']) ? $pop_up_options['payloadNew']['content']['text-decoration'] : 'none'; ?>'>
                                                                <option value="none"><?php echo __('None', 'cart-lift-pro') ?></option>
                                                                <option value="underline"><?php echo __('Underline', 'cart-lift-pro') ?></option>
                                                                <option value="overline"><?php echo __('Overline', 'cart-lift-pro') ?></option>
                                                                <option value="line-through"><?php echo __('Line Through', 'cart-lift-pro') ?></option>
                                                                <option value="underline overline"><?php echo __('Underline Overline', 'cart-lift-pro') ?></option>
                                                                <option value="underline line-through"><?php echo __('Underline Line Through', 'cart-lift-pro') ?></option>
                                                                <option value="overline line-through"><?php echo __('Overline Line Through', 'cart-lift-pro') ?></option>
                                                                <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                                <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                            </select>
                                                        </div>

                                                        <!-- modal description line height -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Line height (em): ', 'cart-lift-pro'); ?></span>
                                                            <input v-model="descriptionLineHeight" class="cl-modal-description-lineHeight-input" type="number" step=".1" id="modal_description_lineHeight" name="modal_description_lineHeight" value='<?php echo isset($pop_up_options['payloadNew']['content']['line-height']) ? $pop_up_options['payloadNew']['content']['line-height'] : '1.4'; ?>' />
                                                        </div>

                                                        <!-- modal description letter spacing -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Letter Spacing (px): ', 'cart-lift-pro'); ?></span>
                                                            <input v-model="descriptionLetterSpacing" class="cl-modal-description-letterSpacing-input" type="number" step=".1" id="modal_description_letterSpacing" name="modal_description_letterSpacing" value='<?php echo isset($pop_up_options['payloadNew']['content']['letter-spacing']) ? $pop_up_options['payloadNew']['content']['letter-spacing'] : '0'; ?>' />
                                                        </div>

                                                        <!-- modal description word spacing -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Word Spacing (px): ', 'cart-lift-pro'); ?></span>
                                                            <input v-model="descriptionWordSpacing" class="cl-modal-description-wordSpacing-input" type="number" step=".1" id="modal_description_wordSpacing" name="modal_description_wordSpacing" value='<?php echo isset($pop_up_options['payloadNew']['content']['word-spacing']) ? $pop_up_options['payloadNew']['content']['word-spacing'] : '0'; ?>' />
                                                        </div>
                                                        <!-- modal description color -->
                                                        <div class="cl-item">
                                                            <?php
                                                            $color = isset($pop_up_options['modal_description_color']) && $pop_up_options['modal_description_color'] !== '' ? $pop_up_options['modal_description_color'] : '#333'
                                                            ?>
                                                            <span class="cl-item-color-palate"><?php echo __('Text Color:', 'cart-lift-pro'); ?></span>
                                                            <input class="cl-wp-description-color-picker" type="text" value="<?php echo $color; ?>" id="modal_description_color" name="modal_description_color">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--popup description typography accordion end -->
                                </div>

                            </section><!--end of tab two-->

                            <section class="tab" data-id="tab3" role="tabpanel" id="tab3" aria-labelledby="tab3" hidden>
                                <div class="cl-popup-content-area">
                                    <!-- popup button text -->
                                    <div class="cl-form-group">
                                        <span class="title"><?php echo __('Button Text:', 'cart-lift-pro'); ?></span>
                                        <input class="button-text" type="text" id="modal_button_text" name="button-text" v-model="button_text">
                                    </div>
                                    <!-- button style start -->
                                    <div class="cl-form-group">
                                        <span class="title"><?php echo __('Button Style: ', 'cart-lift-pro'); ?></span>
                                        <div class="cl-accordion">
                                            <div class="cl-accordion-item">
                                                <div class="cl-accordion-title"><?php echo __('Please Select','cart-lift-pro'); ?>
                                                    <span class="cl-accordion-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24">
                                                            <path fill="currentColor" d="M12 15.25a.74.74 0 0 1-.53-.22l-5-5A.75.75 0 0 1 7.53 9L12 13.44L16.47 9a.75.75 0 0 1 1.06 1l-5 5a.74.74 0 0 1-.53.25" />
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="cl-accordion-content">
                                                    <div class="cl-accordion-child">
                                                        <!-- button typography -->
                                                        <div class="cl-accordion-item">
                                                            <div class="cl-accordion-title"><?php echo __('Typography','cart-lift-pro'); ?>
                                                                <span class="cl-accordion-icon">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24">
                                                                        <path fill="currentColor" d="M12 15.25a.74.74 0 0 1-.53-.22l-5-5A.75.75 0 0 1 7.53 9L12 13.44L16.47 9a.75.75 0 0 1 1.06 1l-5 5a.74.74 0 0 1-.53.25" />
                                                                    </svg>
                                                                </span>
                                                            </div>
                                                            <div class="cl-accordion-content">
                                                                <div class="cl-accordion-content-wrapper">
                                                                    <!-- modal button font size -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Font Size (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonFontSize" class="cl-modal-button-fontSize-input" type="number" min="0" id="modal_button_fontSize" name="modal_button_fontSize" value='<?php echo isset($pop_up_options['payloadNew']['button']['font-size']) ? $pop_up_options['payloadNew']['button']['font-size'] : '16'; ?>' />
                                                                    </div>
                                                                    <!-- modal button font weight -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Font Weight: ', 'cart-lift-pro'); ?></span>
                                                                        <select v-model="buttonFontWeight" class="cl-modal-button-fontWeight-input" id="modal_button_fontWeight" name="modal_button_fontWeight" value='<?php echo isset($pop_up_options['payloadNew']['button']['font-weight']) ? $pop_up_options['payloadNew']['button']['font-weight'] : '400'; ?>'>
                                                                            <option value=100><?php echo __('100', 'cart-lift-pro') ?></option>
                                                                            <option value=200><?php echo __('200', 'cart-lift-pro') ?></option>
                                                                            <option value=300><?php echo __('300', 'cart-lift-pro') ?></option>
                                                                            <option value=400><?php echo __('400', 'cart-lift-pro') ?></option>
                                                                            <option value=500><?php echo __('500', 'cart-lift-pro') ?></option>
                                                                            <option value=600><?php echo __('600', 'cart-lift-pro') ?></option>
                                                                            <option value=700><?php echo __('700', 'cart-lift-pro') ?></option>
                                                                            <option value=800><?php echo __('800', 'cart-lift-pro') ?></option>
                                                                            <option value=900><?php echo __('900', 'cart-lift-pro') ?></option>
                                                                            <option value="normal"><?php echo __('Normal', 'cart-lift-pro') ?></option>
                                                                            <option value="bold"><?php echo __('Bold', 'cart-lift-pro') ?></option>
                                                                            <option value="bolder"><?php echo __('Bolder', 'cart-lift-pro') ?></option>
                                                                            <option value="lighter"><?php echo __('Lighter', 'cart-lift-pro') ?></option>
                                                                            <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                                            <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                                        </select>
                                                                    </div>
                                                                    <!-- modal button font style -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Font Style:', 'cart-lift-pro'); ?></span>
                                                                        <select v-model="buttonFontStyle" class="cl-modal-button-fontStyle-input" id="modal_button_fontStyle" name="modal_button_fontStyle" value='<?php echo isset($pop_up_options['payloadNew']['button']['font-style']) ? $pop_up_options['payloadNew']['button']['font-style'] : 'normal'; ?>'>
                                                                            <option value="normal"><?php echo __('Normal', 'cart-lift-pro') ?></option>
                                                                            <option value="italic"><?php echo __('Italic', 'cart-lift-pro') ?></option>
                                                                            <option value="oblique"><?php echo __('Oblique', 'cart-lift-pro') ?></option>
                                                                        </select>
                                                                    </div>
                                                                    <!-- modal button text transform -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Text Transform:', 'cart-lift-pro'); ?></span>
                                                                        <select v-model="buttonTextTransformation" class="cl-modal-button-transformation-input" id="modal_button_transformation" name="modal_button_transformation" value='<?php echo isset($pop_up_options['payloadNew']['button']['text-transform']) ? $pop_up_options['payloadNew']['button']['text-transform'] : 'none'; ?>'>
                                                                            <option value="none"><?php echo __('None', 'cart-lift-pro') ?></option>
                                                                            <option value="capitalize"><?php echo __('Capitalize', 'cart-lift-pro') ?></option>
                                                                            <option value="uppercase"><?php echo __('Uppercase', 'cart-lift-pro') ?></option>
                                                                            <option value="lowercase"><?php echo __('Lowercase', 'cart-lift-pro') ?></option>
                                                                            <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                                            <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                                        </select>
                                                                    </div>
                                                                    <!-- modal button text decoration -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Text Decoration:', 'cart-lift-pro'); ?></span>
                                                                        <select v-model="buttonTextDecoration" class="cl-modal-button-decoration-input" id="modal_button_decoration" name="modal_button_decoration" value='<?php echo isset($pop_up_options['payloadNew']['button']['text-decoration']) ? $pop_up_options['payloadNew']['button']['text-decoration'] : 'none'; ?>'>
                                                                            <option value="none"><?php echo __('None', 'cart-lift-pro') ?></option>
                                                                            <option value="underline"><?php echo __('Underline', 'cart-lift-pro') ?></option>
                                                                            <option value="overline"><?php echo __('Overline', 'cart-lift-pro') ?></option>
                                                                            <option value="line-through"><?php echo __('Line Through', 'cart-lift-pro') ?></option>
                                                                            <option value="underline overline"><?php echo __('Underline Overline', 'cart-lift-pro') ?></option>
                                                                            <option value="underline line-through"><?php echo __('Underline Line Through', 'cart-lift-pro') ?></option>
                                                                            <option value="overline line-through"><?php echo __('Overline Line Through', 'cart-lift-pro') ?></option>
                                                                            <option value="inherit"><?php echo __('Inherit', 'cart-lift-pro') ?></option>
                                                                            <option value="initial"><?php echo __('Initial', 'cart-lift-pro') ?></option>
                                                                        </select>
                                                                    </div>
                                                                    <!-- modal button line height -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Line height (em): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonTextLineHeight" class="cl-modal-button-lineHeight-input" type="number" step=".1" id="modal_button_lineHeight" name="modal_button_lineHeight" value='<?php echo isset($pop_up_options['payloadNew']['button']['line-height']) ? $pop_up_options['payloadNew']['button']['line-height'] : '0'; ?>' />
                                                                    </div>
                                                                    <!-- modal button letter spacing -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Letter Spacing (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonLetterSpacing" class="cl-modal-button-letterSpacing-input" type="number" step=".1" id="modal_button_letterSpacing" name="modal_button_letterSpacing" value='<?php echo isset($pop_up_options['payloadNew']['button']['letter-spacing']) ? $pop_up_options['payloadNew']['button']['letter-spacing'] : '0'; ?>' />
                                                                    </div>
                                                                    <!-- modal button word spacing -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Word Spacing (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonWordSpacing" class="cl-modal-button-wordSpacing-input" type="number" step=".1" id="modal_button_wordSpacing" name="modal_button_wordSpacing" value='<?php echo isset($pop_up_options['payloadNew']['button']['word-spacing']) ? $pop_up_options['payloadNew']['button']['word-spacing'] : '0'; ?>' />
                                                                    </div>
                                                                    <!-- modal button text color -->
                                                                    <div class="cl-item">
                                                                        <?php
                                                                        $color = isset($pop_up_options['payloadNew']['button']['color']) && $pop_up_options['payloadNew']['button']['color'] !== '' ? $pop_up_options['payloadNew']['button']['color'] : '#fff'
                                                                        ?>
                                                                        <span class="cl-item-color-palate"><?php echo __('Text Color:', 'cart-lift-pro'); ?></span>
                                                                        <input class="cl-wp-button-text-color-picker" type="text" value="<?php echo $color; ?>" id="modal_button_text_color" name="modal_button_text_color">
                                                                    </div>
                                                                    <!-- modal button hover text color -->
                                                                    <div class="cl-item">
                                                                        <?php
                                                                        $hover_text_color = isset($pop_up_options['payloadNew']['button']['hover-text-color']) && $pop_up_options['payloadNew']['button']['hover-text-color'] !== '' ? $pop_up_options['payloadNew']['button']['hover-text-color'] : '#000'
                                                                        ?>
                                                                        <span class="cl-item-color-palate"><?php echo __('Hover Text Color:', 'cart-lift-pro'); ?></span>
                                                                        <input class="cl-wp-button-hover-text-color-picker" type="text" value="<?php echo $hover_text_color; ?>" id="modal_button_hover_text_color" name="modal_button_hover_text_color">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- button border type -->
                                                        <div class="cl-accordion-item">
                                                            <div class="cl-accordion-title"><?php echo __('Border Type','cart-lift-pro'); ?>
                                                                <span class="cl-accordion-icon">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24">
                                                                        <path fill="currentColor" d="M12 15.25a.74.74 0 0 1-.53-.22l-5-5A.75.75 0 0 1 7.53 9L12 13.44L16.47 9a.75.75 0 0 1 1.06 1l-5 5a.74.74 0 0 1-.53.25" />
                                                                    </svg>
                                                                </span>
                                                            </div>
                                                            <div class="cl-accordion-content">
                                                                <div class="cl-accordion-content-wrapper">
                                                                    <!-- modal button border radius -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Border Radius (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonBorderRadius" class="cl-modal-button-borderRadius-input" type="number" min="0" id="modal_button_borderRadius" name="modal_button_borderRadius" value='<?php echo isset($pop_up_options['payloadNew']['button']['border-radius']) ? $pop_up_options['payloadNew']['button']['border-radius'] : '10'; ?>' />
                                                                    </div>
                                                                    <!-- modal button padding-X -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Padding-X (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonPaddingX" class="cl-modal-button-paddingX-input" type="number" min="0" id="modal_button_paddingX" name="modal_button_paddingX" name="modal_button_borderRadius" value='<?php echo isset($pop_up_options['payloadNew']['button']['padding-x']) ? $pop_up_options['payloadNew']['button']['padding-x'] : '30'; ?>' />
                                                                    </div>
                                                                    <!-- modal button padding-Y -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Padding-Y (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonPaddingY" class="cl-modal-button-paddingY-input" type="number" min="0" id="modal_button_paddingY" name="modal_button_paddingY" value='<?php echo isset($pop_up_options['payloadNew']['button']['padding-y']) ? $pop_up_options['payloadNew']['button']['padding-y'] : '10'; ?>' />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- button box shadow -->
                                                        <div class="cl-accordion-item">
                                                            <div class="cl-accordion-title"><?php echo __('Box Shadow','cart-lift-pro'); ?>
                                                                <span class="cl-accordion-icon">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24">
                                                                        <path fill="currentColor" d="M12 15.25a.74.74 0 0 1-.53-.22l-5-5A.75.75 0 0 1 7.53 9L12 13.44L16.47 9a.75.75 0 0 1 1.06 1l-5 5a.74.74 0 0 1-.53.25" />
                                                                    </svg>
                                                                </span>
                                                            </div>
                                                            <div class="cl-accordion-content">
                                                                <div class="cl-accordion-content-wrapper">
                                                                    <!-- modal button shadow h-offset -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('H-Offset (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonShadowHOffset" class="cl-modal-button-shadowHOffset-input" type="number" step=".1" id="modal_button_shadowHOffset" name="modal_button_shadowHOffset" value='<?php echo isset($pop_up_options['payloadNew']['button']['button-shadow-h-offset']) ? $pop_up_options['payloadNew']['button']['button-shadow-h-offset'] : '1'; ?>' />
                                                                    </div>
                                                                    <!-- modal button shadow v-offset -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('V-Offset (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonShadowVOffset" class="cl-modal-button-shadowVOffset-input" type="number" step=".1" id="modal_button_shadowVOffset" name="modal_button_shadowVOffset" value='<?php echo isset($pop_up_options['payloadNew']['button']['button-shadow-v-offset']) ? $pop_up_options['payloadNew']['button']['button-shadow-v-offset'] : '1'; ?>' />
                                                                    </div>
                                                                    <!-- modal button shadow blur -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Blur (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonShadowBlur" class="cl-modal-button-shadowBlur-input" type="number" step=".1" id="modal_button_shadowBlur" name="modal_button_shadowBlur" value='<?php echo isset($pop_up_options['payloadNew']['button']['button-shadow-blur']) ? $pop_up_options['payloadNew']['button']['button-shadow-blur'] : '20'; ?>' />
                                                                    </div>
                                                                    <!-- modal button shadow spread -->
                                                                    <div class="cl-item">
                                                                        <span><?php echo __('Spread (px): ', 'cart-lift-pro'); ?></span>
                                                                        <input v-model="buttonShadowSpread" class="cl-modal-button-shadowSpread-input" type="number" step=".1" id="modal_button_shadowSpread" name="modal_button_shadowSpread" value='<?php echo isset($pop_up_options['payloadNew']['button']['button-shadow-spread']) ? $pop_up_options['payloadNew']['button']['button-shadow-spread'] : '5'; ?>' />
                                                                    </div>
                                                                    <!-- modal button shadow color -->
                                                                    <div class="cl-item">
                                                                        <div>
                                                                            <?php
                                                                            $color = isset($pop_up_options['payloadNew']['button']['shadow-color']) && $pop_up_options['payloadNew']['button']['shadow-color'] !== '' ? $pop_up_options['payloadNew']['button']['shadow-color'] : '#dd3333'
                                                                            ?>
                                                                            <span class="cl-item-color-palate"><?php echo __('Color:', 'cart-lift-pro'); ?></span>
                                                                            <input class="cl-wp-button-shadow-color-picker" type="text" value="<?php echo $color; ?>" id="modal_button_shadow_color" name="modal_button_shadow_color">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- button background color -->
                                                        <div class="cl-accordion-item">
                                                            <div class="cl-accordion-title"><?php echo __('Background Color', 'cart-lift-pro'); ?>
                                                                <span class="cl-accordion-icon">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24">
                                                                        <path fill="currentColor" d="M12 15.25a.74.74 0 0 1-.53-.22l-5-5A.75.75 0 0 1 7.53 9L12 13.44L16.47 9a.75.75 0 0 1 1.06 1l-5 5a.74.74 0 0 1-.53.25" />
                                                                    </svg>
                                                                </span>
                                                            </div>
                                                            <div class="cl-accordion-content">
                                                                <div class="cl-accordion-content-wrapper">
                                                                    <!-- modal button color -->
                                                                    <div class="cl-item">
                                                                        <?php
                                                                        $color = isset($pop_up_options['modal_submit_btn_color']) && $pop_up_options['modal_submit_btn_color'] !== '' ? $pop_up_options['modal_submit_btn_color'] : '#1e73be'
                                                                        ?>
                                                                        <span class="cl-item-color-palate"><?php echo __('Color:', 'cart-lift-pro'); ?></span>
                                                                        <input class="cl-wp-color-picker" type="text" value="<?php echo $color; ?>" id="modal_button_color" name="button_color">
                                                                    </div>

                                                                    <!-- modal button hover color -->
                                                                    <div class="cl-item">
                                                                        <?php
                                                                        $button_hover_color = isset($pop_up_options['payloadNew']['button']['hover-color']) && $pop_up_options['payloadNew']['button']['hover-color']  !== '' ? $pop_up_options['payloadNew']['button']['hover-color']  : '#000'
                                                                        ?>
                                                                        <span class="cl-item-color-palate"><?php echo __('Hover Color:', 'cart-lift-pro'); ?></span>
                                                                        <input class="cl-wp-button-hover-color-picker" type="text" value="<?php echo $button_hover_color; ?>" id="modal_button_hover_color" name="modal_button_hover_color">
                                                                    </div>
                                                                    <!-- modal button hover color end -->
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- button style end -->
                                </div>
                            </section><!--end of tab three-->

                            <section class="tab" data-id="tab4" role="tabpanel" id="tab4" aria-labelledby="tab4" hidden>
                                <div class="cl-popup-content-area">
                                    <!--popup width and color accordion start -->
                                    <div class="cl-form-group">
                                        <span class="title"><?php echo __('Popup Style: ', 'cart-lift-pro'); ?></span>
                                        <div class="cl-accordion">
                                            <div class="cl-accordion-item">
                                                <div class="cl-accordion-title">
                                                     <?php echo __('Please Select','cart-lift-pro'); ?>
                                                    <span class="cl-accordion-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24">
                                                            <path fill="currentColor" d="M12 15.25a.74.74 0 0 1-.53-.22l-5-5A.75.75 0 0 1 7.53 9L12 13.44L16.47 9a.75.75 0 0 1 1.06 1l-5 5a.74.74 0 0 1-.53.25" />
                                                        </svg>
                                                    </span>
                                                </div>
                                                <div class="cl-accordion-content">
                                                    <div class="cl-accordion-content-wrapper">
                                                        <!-- popup width -->
                                                        <div class="cl-item">
                                                            <span><?php echo __('Width (%):', 'cart-lift-pro'); ?></span>
                                                            <input v-model="modalWidth" class="cl-modal-width-input" type="number" id="modal_width" name="modal_width" />
                                                        </div>

                                                        <!-- modal background color -->
                                                        <div class="cl-item">
                                                            <?php
                                                            $container_background_color = isset($pop_up_options['payloadNew']['container']['background-color']) && $pop_up_options['payloadNew']['container']['background-color'] !== '' ? $pop_up_options['payloadNew']['container']['background-color'] : '#F6F6F8'
                                                            ?>
                                                            <span class="cl-item-color-palate"><?php echo __('Background Color:', 'cart-lift-pro'); ?></span>
                                                            <input class="cl-wp-bg-color-picker" type="text" value="<?php echo $container_background_color; ?>" id="modal_background_color" name="button_color">
                                                        </div>
                                                        <!-- modal background color end -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--popup description typography accordion end -->
                                </div>
                            </section><!--end of tab three-->

                        </div><!--end of container-->

                    </div>
                </div>

                <div class="btn-area">
                    <button id="email-popup" class="cl-btn"><?php echo __('Save Change', 'cart-lift-pro'); ?></button>
                    <p id="email-popup-notice" class="cl-notice" style="display:none;"></p>
                </div>

            </form>

            <div class="cl-atc-popup-preview">
                <div class="cl-add2cart-modal" id="cart-lift">
                    <?php
                    $container_style = '';
                    $container_pixel_add = ['width'];
                    if (isset($pop_up_options['payloadNew']['container'])) {
                        foreach ($pop_up_options['payloadNew']['container'] as $key => $value) {
                            $suffix_pixel = in_array($key, $container_pixel_add) ? '%' : '';
                            $container_style .= "$key: $value" . $suffix_pixel . "; ";
                        }
                    }
                    ?>
                    <div class="modal-wrapper" id="cl_popup_modal" style="<?php echo $container_style; ?>">
                        <div class="modal-body">
                            <div class="popup-logo">
                                <img v-if="logo" :src="logo">
                            </div>
                            <?php
                            $heading_title_style = '';
                            $pixel_add = ['font-size', 'letter-spacing', 'word-spacing'];
                            $line_height = ['line-height'];
                            if (isset($pop_up_options['payloadNew']['heading'])) {
                                foreach ($pop_up_options['payloadNew']['heading'] as $key => $value) {
                                    $suffix_pixel = in_array($key, $pixel_add) ? 'px' : '';
                                    $suffix_em = in_array($key, $line_height) ? 'em' : '';
                                    $heading_title_style .= "$key: $value" . $suffix_pixel . $suffix_em . ";";
                                }
                            }
                            ?>
                            <h4 id="cl_popup_title" style="<?php echo $heading_title_style ?>">{{ title }}</h4>

                            <?php
                            $content_style = '';
                            $content_pixel_add = ['font-size', 'letter-spacing', 'word-spacing'];
                            $content_line_height = ['line-height'];
                            if (isset($pop_up_options['payloadNew']['content'])) {
                                foreach ($pop_up_options['payloadNew']['content'] as $key => $value) {
                                    $suffix_pixel = in_array($key, $content_pixel_add) ? 'px' : '';
                                    $suffix_em = in_array($key, $content_line_height) ? 'em' : '';
                                    $content_style .= "$key: $value" . $suffix_pixel . $suffix_em . ";";
                                }
                            }
                            ?>

                            <p id="cl_popup_description" style="<?php echo $content_style ?>">{{ description }}</p>
                            <div class="cl-popup-email-invalid-notice" style="display:none; color:red; text-align: center; font-size: small;padding-bottom: 2px;">
                                <?php echo __('The email is invalid.', 'cart-lift-pro'); ?>
                            </div>
                            <input type="email" name="email" value="" placeholder="<?php _e('Enter your email', 'cart-lift-pro'); ?>" id="cl-popup-email">
                            <?php
                            $button_style = '';
                            $button_pixel_add = ['font-size', 'letter-spacing', 'word-spacing', 'border-radius', 'padding-x', 'padding-y', 'h-offset', 'v-offset', 'blur', 'spread'];
                            $button_line_height = ['line-height'];
                            if (isset($pop_up_options['payloadNew']['button'])) {
                                foreach ($pop_up_options['payloadNew']['button'] as $key => $value) {
                                    $suffix_pixel = in_array($key, $button_pixel_add) ? 'px' : '';
                                    $suffix_em = in_array($key, $button_line_height) ? 'em' : '';
                                    $button_style .= "$key: $value" . $suffix_pixel . $suffix_em . ";";
                                }
                            }
                            ?>
                            <button class="cl-btn" id="cl_popup_submit_btn" style="<?php echo $button_style; ?>" onmouseover="this.style.backgroundColor='<?php echo $pop_up_options['payloadNew']['button']['hover-color'] ?? ''; ?>'; this.style.color='<?php echo $pop_up_options['payloadNew']['button']['hover-text-color'] ?? ''; ?>'; " onmouseout="this.style.backgroundColor='<?php echo $pop_up_options['modal_submit_btn_color'] ?? ''; ?>'; this.style.color='<?php echo $pop_up_options['payloadNew']['button']['color'] ?? ''; ?>';">{{ button_text }}</button>
                            <div class="cl-popup-thank-you-notice" style="display:none; color:#ee8134; font-size: small;padding-bottom: 10px;">
                                <?php echo __('Thank you. Happy shopping.', 'cart-lift-pro'); ?>
                            </div>
                            <?php
                            $style = '';
                            if ($no_thanks_button === 'off') {
                                $style = 'style="display: none;"';
                            }
                            ?>
                            <a href="#" class="cl-alert-cancel" id="cl-ignore-email-form" <?php echo $style ?>><?php echo __('No Thanks!', 'cart-lift-pro'); ?></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

</template>