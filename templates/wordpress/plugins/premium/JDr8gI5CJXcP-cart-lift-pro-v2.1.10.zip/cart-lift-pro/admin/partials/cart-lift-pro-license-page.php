<?php
$license = get_option( 'cart_lift_license_key' );
$status  = get_option( 'cart_lift_license_status' );

$start = 5;
$length = mb_strlen( $license ) - $start - 5;

$mask_string = preg_replace( '/\S/', '*', $license );
$mask_string = mb_substr( $mask_string, $start, $length );
$license_mask = substr_replace( $license, $mask_string, $start, $length );


?>

<div class="wrap">
    <form method="post" action="options.php">
        <div class="cl-license-wrapper">
            <div class="cl-license-filed">
                <div class="field-area">
                    <div class="promo-text-area">
                        <div class="single-area">
                            <span class="icon">
                                <svg width="14px" height="18px" viewBox="0 0 14 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
                                        <g id="Report--Copy" transform="translate(-1012.000000, -30.000000)" stroke="#6e41d3" stroke-width="1.5">
                                            <g id="Group-6" transform="translate(279.000000, 31.000000)">
                                                <g id="1-copy-6" transform="translate(535.000000, 0.000000)">
                                                    <g id="Group-9" transform="translate(199.000000, 0.000000)">
                                                        <polyline id="Stroke-1" points="9 6 12 3 9 0"></polyline>
                                                        <path d="M0,9 L0,5.4725824 C0,4.10699022 1.04467307,3 2.3333903,3 L12,3" id="Stroke-3"></path>
                                                        <polyline id="Stroke-5" points="3 10 0 13.0002224 3 16"></polyline>
                                                        <path d="M12,7 L12,10.5274176 C12,11.8930098 10.9553269,13 9.66701986,13 L0,13" id="Stroke-7"></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
                            </span>
                            <h4><?php echo __('Stay Updated', 'cart-lift-pro'); ?></h4>
                            <p><?php echo __('Update the plugin right from your WordPress Dashboard.', 'cart-lift-pro'); ?></p>
                        </div>
                        <div class="single-area">
                            <span class="icon">
                                <svg width="18px" height="17px" viewBox="0 0 18 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
                                        <g id="Report--Copy" transform="translate(-972.000000, -31.000000)" stroke="#6e41d3" stroke-width="1.5">
                                            <g id="Group-6" transform="translate(279.000000, 31.000000)">
                                                <g id="1-copy-6" transform="translate(535.000000, 0.000000)">
                                                    <polygon id="Stroke-1" points="167 13.1256696 171.635405 15.688 170.75 10.2610156 174.5 6.41730801 169.317703 5.62566961 167 0.688 164.682297 5.62566961 159.5 6.41730801 163.25 10.2610156 162.364595 15.688"></polygon>
                                                </g>
                                            </g>
                                        </g>
                                    </g>
                                </svg>
                            </span>
                            <h4><?php echo __('Premium Support', 'cart-lift-pro'); ?></h4>
                            <p><?php echo __('Supported by professional and courteous staff.', 'cart-lift-pro'); ?></p>
                        </div>
                    </div>
                    <!-- /promo-text-area -->

                    <div class="input-field-area">
                        <div class="input-field">
                            <input id="cart_lift_license_key" name="cart_lift_license_key_mask" type="text" class="regular-text" value="<?php esc_attr_e( $license_mask ); ?>" placeholder="<?php _e('Enter your license key', 'cart-lift-pro'); ?>" />
                            <input id="cart_lift_license_key" name="cart_lift_license_key" type="hidden" value="<?php esc_attr_e( $license ); ?>"/>
                        </div>
                        <div class="btn-area">
                            <?php if( $status !== false && $status == 'valid' ) { ?>
                                <?php wp_nonce_field( 'cart_lift_pro_nonce', 'cart_lift_pro_nonce' ); ?>
                                <input type="submit" class="cl-btn" name="cart_lift_license_deactivate" value="<?php _e('Deactivate License', 'cart-lift-pro'); ?>" required/>
                            <?php } else {
                                wp_nonce_field( 'cart_lift_pro_nonce', 'cart_lift_pro_nonce' ); ?>
                                <input type="submit" class="cl-btn" name="cart_lift_license_activate" value="<?php _e('Activate License', 'cart-lift-pro'); ?>"/>
                            <?php } ?>
                        </div>
                    </div>
                </div>

                <div class="logo-area">
                    <div class="cl-logo">
                        <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 346.44 440.97"><defs><style>.cls-1{fill:#6e42d3;}.cls-2{fill:#6645ce;}</style></defs><path class="cls-1" d="M313.33,79.74l-22.55-4a4.77,4.77,0,0,1-.16.89c-1.43,6.68-7.35,11.08-13.23,9.82s-9.48-7.7-8-14.38a.83.83,0,0,1,0-.15l-61.49-11a11.79,11.79,0,0,1-.24,1.64c-1.33,6.21-7.07,10.24-12.83,9s-9.35-7.27-8-13.47c.07-.31.14-.61.23-.9l-26.77-4.76a8.09,8.09,0,0,0-9.08,5.37l-18.27,53.79c28.67,20.6,89.85,53.4,157.25,21.23,0,0-56,68.09-164.28-.51l-22.76,67a9.92,9.92,0,0,0,7.65,13l190.68,34A9.91,9.91,0,0,0,313.07,237l1.49-32L297,202.38a7.57,7.57,0,0,1,1.09-15.07,7.16,7.16,0,0,1,1.13.08l16,2.42.71-15.23-2.7-.44a7.57,7.57,0,0,1,1.12-15,7.16,7.16,0,0,1,1.13.08l1.15.17.71-15.31-2.94-.44a7.57,7.57,0,0,1,1.13-15,7.11,7.11,0,0,1,1.12.08l1.4.21,1.9-40.79A8.1,8.1,0,0,0,313.33,79.74Zm-97.56,23.4c-.63,11-8.22,19.46-16.94,19s-15.29-9.81-14.66-20.79,8.23-19.46,17-19,15.24,9.79,14.6,20.79Zm58.66,11.11c-1.59,10.87-9.89,18.67-18.54,17.41s-14.37-11.11-12.78-22S253,91,261.64,92.25,276,103.35,274.43,114.25Z" transform="translate(0.01 0)"/><path class="cls-1" d="M268.84,112.47c-.62,6.19-5.72,10.75-11.39,10.18s-9.75-6-9.13-12.24S254,99.66,259.7,100.23a9.48,9.48,0,0,1,4.59,1.73,3.83,3.83,0,0,0,2,6.8,3.74,3.74,0,0,0,2.23-.46A12.27,12.27,0,0,1,268.84,112.47Z" transform="translate(0.01 0)"/><path class="cls-1" d="M210.07,102.73c-.62,6.2-5.71,10.76-11.38,10.19s-9.76-6.05-9.14-12.24,5.72-10.76,11.38-10.19a9.62,9.62,0,0,1,4.61,1.73,3.83,3.83,0,0,0,4.23,6.36A12.15,12.15,0,0,1,210.07,102.73Z" transform="translate(0.01 0)"/><path class="cls-1" d="M195.93,66.47h0c2.18.39,4.22-.52,4.68-2.09,1.68-5.62,6.3-18.54,15.46-27.82C237.88,14.47,275.44,14,274,77c0,1.91,1.84,3.7,4.38,4.15h0c3,.53,5.62-1,5.7-3.19.34-10.12-.44-36.43-16.16-53.32-19.79-21.28-45.24-5-45.24-5s-21.39,12.85-30.36,42.76C191.82,64.14,193.47,66,195.93,66.47Z" transform="translate(0.01 0)"/><path class="cls-1" d="M291.84,171l25.81,3.89a7.57,7.57,0,0,1,6.36,8.61h0a7.57,7.57,0,0,1-8.61,6.36L289.59,186a7.57,7.57,0,0,1-6.36-8.61h0A7.57,7.57,0,0,1,291.84,171Z" transform="translate(0.01 0)"/><path class="cls-1" d="M298.6,202.67l25.81,3.89a7.57,7.57,0,0,1,6.36,8.61h0a7.57,7.57,0,0,1-8.61,6.36l-25.81-3.89A7.57,7.57,0,0,1,290,209h0A7.57,7.57,0,0,1,298.6,202.67Z" transform="translate(0.01 0)"/><path class="cls-1" d="M315.36,143.86l16.51,2.49a7.57,7.57,0,0,1,6.36,8.61h0a7.57,7.57,0,0,1-8.61,6.36l-16.55-2.49a7.57,7.57,0,0,1-6.36-8.61h0a7.57,7.57,0,0,1,8.61-6.37Z" transform="translate(0.01 0)"/><path class="cls-1" d="M337.89,177.34h0a7.57,7.57,0,0,1,6.36,8.61h0a7.57,7.57,0,0,1-8.61,6.36h0a7.57,7.57,0,0,1-6.36-8.61h0A7.57,7.57,0,0,1,337.89,177.34Z" transform="translate(0.01 0)"/><path class="cls-1" d="M299.24,265.51,95.14,227.14a12.59,12.59,0,0,1-10.31-11.58L96.3,24A12.69,12.69,0,0,0,86.07,11.48L15.93.26A11.3,11.3,0,0,0,2.24,10.49h0A14.49,14.49,0,0,0,13.57,25.68l58,8.8L60.07,226.14A25.4,25.4,0,0,0,79.7,249.25a11.62,11.62,0,0,0,4.22,1.67l210.37,39.47a12.93,12.93,0,0,0,15-9.54,12.69,12.69,0,0,0-9.49-15.23h0Z" transform="translate(0.01 0)"/><circle class="cls-1" cx="117.81" cy="293.37" r="20.07" transform="translate(-185.24 383.37) rotate(-84.66)"/><circle class="cls-1" cx="235.07" cy="314.19" r="20.07" transform="translate(-99.62 519) rotate(-84.66)"/><path class="cls-1" d="M59.42,73.28,20.67,67.72c-6.63-1-11.34-6.34-10.51-12h0C11,50.08,17,46.29,23.67,47.26l36.74,5.39Z" transform="translate(0.01 0)"/><path class="cls-1" d="M57.07,113.81l-29.25-4.17c-5-.73-8.39-5.91-7.56-11.55h0c.83-5.64,5.56-9.63,10.56-8.89l27.73,4.07Z" transform="translate(0.01 0)"/><path class="cls-2" d="M55.64,417.29q-.8,11-8.13,17.34T28.17,441Q15,441,7.52,432.12T0,407.86v-4.17a40.9,40.9,0,0,1,3.47-17.34,26,26,0,0,1,9.91-11.51,27.77,27.77,0,0,1,15-4q11.81,0,19,6.33t8.34,17.77H41.67q-.52-6.61-3.68-9.59t-9.63-3q-7,0-10.52,5T14.25,403v5.16q0,11.06,3.35,16.17t10.57,5.11q6.51,0,9.73-3t3.68-9.21Z" transform="translate(0.01 0)"/><path class="cls-2" d="M93.38,440A15,15,0,0,1,92,435.47,16.39,16.39,0,0,1,79.22,441a18,18,0,0,1-12.35-4.31A13.87,13.87,0,0,1,62,425.77q0-8.06,6-12.37T85.22,409h6.23v-2.91a8.36,8.36,0,0,0-1.8-5.62q-1.8-2.11-5.7-2.11A8.07,8.07,0,0,0,78.59,400a5.57,5.57,0,0,0-1.95,4.5H63.07a13.61,13.61,0,0,1,2.72-8.16,18,18,0,0,1,7.69-5.88,28,28,0,0,1,11.16-2.13q9.38,0,14.88,4.71t5.55,13.26v22q0,7.22,2,10.92v.8Zm-11.2-9.42a11.67,11.67,0,0,0,5.53-1.34,8.77,8.77,0,0,0,3.75-3.59v-8.72H86.39q-10.17,0-10.83,7v.8a5.42,5.42,0,0,0,1.78,4.17,6.92,6.92,0,0,0,4.83,1.68Z" transform="translate(0.01 0)"/><path class="cls-2" d="M144,402a36.8,36.8,0,0,0-4.87-.37q-7.69,0-10.08,5.2V440H115.45V389.3h12.8l.38,6q4.08-7,11.3-7a14.19,14.19,0,0,1,4.22.61Z" transform="translate(0.01 0)"/><path class="cls-2" d="M169.07,376.83V389.3h8.67v9.94h-8.67v25.31a6,6,0,0,0,1.08,4q1.08,1.22,4.13,1.22a21.6,21.6,0,0,0,4-.33v10.27a27.89,27.89,0,0,1-8.2,1.22q-14.25,0-14.53-14.39v-27.3h-7.48V389.3h7.41V376.83Z" transform="translate(0.01 0)"/><path class="cls-2" d="M224.07,428.72H254V440h-43.9V371.77h14Z" transform="translate(0.01 0)"/><path class="cls-2" d="M261.07,376.18a6.67,6.67,0,0,1,2-5,8.79,8.79,0,0,1,11.09,0,7.16,7.16,0,0,1,0,10.08,8.69,8.69,0,0,1-11,0A6.65,6.65,0,0,1,261.07,376.18ZM275.44,440h-13.6V389.3h13.59Z" transform="translate(0.01 0)"/><path class="cls-2" d="M290.3,440V399.24h-7.55V389.3h7.55V385q0-8.53,4.9-13.24T308.91,367a31.67,31.67,0,0,1,6.89.94l-.14,10.5a17.27,17.27,0,0,0-4.12-.42q-7.64,0-7.64,7.17v4.08H314v9.94H303.89V440Z" transform="translate(0.01 0)"/><path class="cls-2" d="M337.22,376.83V389.3h8.67v9.94h-8.67v25.31a6,6,0,0,0,1.08,4q1.08,1.22,4.13,1.22a21.6,21.6,0,0,0,4-.33v10.27a27.89,27.89,0,0,1-8.2,1.22q-14.25,0-14.53-14.39v-27.3h-7.43V389.3h7.41V376.83Z" transform="translate(0.01 0)"/></svg>
                    </div>
                    <a href="https://rextheme.com/your-account/#purchase" target="_blank" class="cl-btn manage-license"><?php echo __('manage license', 'cart-lift-pro'); ?></a>
                </div>
            </div>

            <?php settings_fields('cart_lift_license'); ?>

            <!--            --><?php //submit_button(); ?>
        </div>
    </form>

    <div class="cl-doc-row">
        <div class="single-col">
            <span class="icon">
                <svg width="15px" height="18px" viewBox="0 0 15 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
                        <g id="Report--Copy" transform="translate(-1012.000000, -30.000000)" stroke="#6E41D3" stroke-width="1.5">
                            <g id="Group-6" transform="translate(279.000000, 31.000000)">
                                <g id="1-copy-6" transform="translate(535.000000, 0.000000)">
                                    <g id="Group-11" transform="translate(199.000000, 0.000000)">
                                        <polygon id="Stroke-1" points="8.10769503 0 13 4.54311111 13 16 0 16 0 0"></polygon>
                                        <polyline id="Stroke-3" points="8 0 8 5 13 5"></polyline>
                                        <path d="M2,12 L10,12" id="Stroke-5"></path>
                                        <path d="M2,8 L10,8" id="Stroke-7"></path>
                                        <path d="M3,4 L5,4" id="Stroke-9"></path>
                                    </g>
                                </g>
                            </g>
                        </g>
                    </g>
                </svg>
            </span>
            <h4 class="title"><?php echo __('Documentation', 'cart-lift-pro'); ?></h4>
            <p><?php echo __('Get started by spending some time with the documentation and win back abandoned customers with automated recovery campaign with Cart Lift.', 'cart-lift-pro'); ?></p>
            <a href="https://rextheme.com/docs-category/cart-lift/" class="cl-btn" target="_blank"><?php echo __('Documentation', 'cart-lift-pro'); ?></a>
        </div>

        <div class="single-col">
            <span class="icon">
                <svg width="20px" height="18px" viewBox="0 0 20 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
                        <g id="Report--Copy" transform="translate(-979.000000, -30.000000)" stroke="#6E41D3" stroke-width="1.5">
                            <g id="Group-6" transform="translate(279.000000, 30.000000)">
                                <g id="1-copy-6" transform="translate(535.000000, 0.000000)">
                                    <g id="Group-9" transform="translate(166.000000, 0.500000)">
                                        <path d="M3.768,0.5 L2,0.5 C0.8955,0.5 0,1.43683798 0,2.59232379 L0,11.2330979 C0,12.3885838 0.8955,13.3254217 2,13.3254217 L5.1365,13.3254217 C5.667,13.3254217 6.1755,13.5456388 6.5505,13.9379495 L9,16.5 L11.4485,13.9379495 C11.8235,13.5456388 12.3325,13.3254217 12.8625,13.3254217 L16,13.3254217 C17.1045,13.3254217 18,12.3885838 18,11.2330979 L18,2.59232379 C18,1.43683798 17.1045,0.5 16,0.5 L6.2095,0.5" id="Stroke-1"></path>
                                        <g id="Group-4" transform="translate(5.000000, 7.000000)">
                                            <path d="M8.9355,0.5 C8.9355,0.75 8.7405,0.954 8.4995,0.954 C8.2595,0.954 8.0645,0.75 8.0645,0.5 C8.0645,0.25 8.2595,0.046 8.4995,0.046 C8.7405,0.046 8.9355,0.25 8.9355,0.5 Z" id="Stroke-3"></path>
                                            <path d="M0.935,0.5 C0.935,0.75 0.741,0.954 0.5,0.954 C0.259,0.954 0.065,0.75 0.065,0.5 C0.065,0.25 0.259,0.046 0.5,0.046 C0.741,0.046 0.935,0.25 0.935,0.5 Z" id="Stroke-5"></path>
                                            <path d="M4.935,0.5 C4.935,0.75 4.741,0.954 4.5,0.954 C4.26,0.954 4.065,0.75 4.065,0.5 C4.065,0.25 4.26,0.046 4.5,0.046 C4.741,0.046 4.935,0.25 4.935,0.5 Z" id="Stroke-7"></path>
                                        </g>
                                    </g>
                                </g>
                            </g>
                        </g>
                    </g>
                </svg>                 
            </span>
            <h4 class="title"><?php echo __('Support', 'cart-lift-pro'); ?></h4>
            <p><?php echo __('Can’t find solution with our documentation? Just post a ticket. Our professional team is here to solve your problems.', 'cart-lift-pro'); ?></p>
            <a href="https://rextheme.com/your-account/?active_tab=support" target="_blank" class="cl-btn"><?php echo __('Post A Ticket', 'cart-lift-pro'); ?></a>
        </div>

        <div class="single-col">
            <span class="icon">
                <svg width="20px" height="19px" viewBox="0 0 20 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
                        <g id="Report--Copy" transform="translate(-1041.000000, -29.000000)" stroke="#6E41D3" stroke-width="1.5">
                            <g id="Group-6" transform="translate(279.000000, 30.000000)">
                                <g id="1-copy-6" transform="translate(535.000000, 0.000000)">
                                    <path d="M236.985196,3.42441231 C234.47921,-1.16158153 228.754244,0.0378401827 228.072248,4.2433029 C227.328252,8.83239469 232.480722,13.7426403 236.985196,16.4941333 C241.489669,13.7426403 246.804638,8.85356399 245.898143,4.2433029 C245.077148,0.0646890545 239.491181,-1.16158153 236.985196,3.42441231" id="Stroke-1"></path>
                                </g>
                            </g>
                        </g>
                    </g>
                </svg>                   
            </span>
            <h4 class="title"><?php echo __('Show Your Love', 'cart-lift-pro'); ?></h4>
            <p><?php echo __('We love to have you in Cart Lift family. Take your 2 minutes to review  and speed the love to encourage us to keep it going.', 'cart-lift-pro'); ?></p>
            <a href="<?php echo sanitize_url( 'https://wordpress.org/support/plugin/cart-lift/reviews/?filter=5#new-post' )?>" class="cl-btn"  target="_blank"><?php echo __('Leave a Review', 'cart-lift-pro'); ?></a>
        </div>
    </div>
</div>
