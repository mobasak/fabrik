( function ( $ ) {
  ("use strict");
  /**
   * All of the code for your admin-facing JavaScript source
   * should reside in this file.
   *
   * Note: It has been assumed you will write jQuery code here, so the
   * $ function reference has been prepared for usage within the scope
   * of this function.
   *
   * This enables you to define handlers, for when the DOM is ready:
   *
   * $(function() {
   *
   * });
   *
   * When the window is loaded:
   *
   * $( window ).load(function() {
   *
   * });
   *
   * ...and/or other possibilities.
   *
   * Ideally, it is not considered best practise to attach more than a
   * single DOM-ready or window-load handler for a particular page.
   * Although scripts in the WordPress core, Plugins and Themes may be
   * practising this, we should strive to set a better example in our own work.
   */

  const EmailTemplateProActions = {
    init: function () {
      this.initProductSearch();
      this.initCategorySearch();
      $(document).on("change", "#cl-free-shipping", this.toggleCouponOption);
      $(document).on("change", "#cl-individual-use", this.toggleCouponOption);
      $(document).on("change", "#cl-auto-apply", this.toggleCouponOption);
    },

    initProductSearch: function () {
      $(".cl-product-search").select2({
        minimumInputLength: 3,
        allowClear: true,
        ajax: {
          url: cl_pro_obj.ajaxurl,
          dataType: "json",
          delay: 250,
          data: function (params) {
            return {
              term: params.term,
              action: "cl_product_search",
              security: cl_pro_obj.security,
            };
          },
          processResults: function (data) {
            var terms = [];
            if (data) {
              $.each(data, function (id, text) {
                terms.push({ id: id, text: text });
              });
            }
            return {
              results: terms,
            };
          },
          cache: true,
        },
      });
    },

    initCategorySearch: function () {
      $(".cl-category-search").select2({
        minimumInputLength: 3,
        allowClear: true,
        ajax: {
          url: cl_pro_obj.ajaxurl,
          dataType: "json",
          delay: 250,
          data: function (params) {
            return {
              term: params.term,
              action: "cl_category_search",
              security: cl_pro_obj.security,
            };
          },
          processResults: function (data) {
            var terms = [];
            if (data) {
              $.each(data, function (id, text) {
                terms.push({ id: id, text: text });
              });
            }
            return {
              results: terms,
            };
          },
          cache: true,
        },
      });
    },

    toggleCouponOption: function () {
      let $_this = $(this),
        id = $_this.attr("id"),
        value = $_this.val();
      if (value == "1") {
        $_this.attr("data-status", "off");
        $_this.val(0);
      } else {
        $_this.attr("data-status", "on");
        $_this.val(1);
      }
    },
  };

  const EmailPopupSettings = {
    init: function () {
      $(document).on(
        "submit",
        "#email-popup-settings",
        this.email_popup_submit
      );
    },

    email_popup_submit: function (e) {
      e.preventDefault();
      $("#cl-loader").fadeIn();
      $("#email-popup-notice").hide().removeClass("cl-success cl-error");

      var enabler = $("#email_popup").val();
      var enabler_exit = $("#email_popup_exit").val();
      var popup_logo = $("#popup_logo_src").val();
      var no_thanks_btn = $("#no_thanks_btn").is(":checked") ? "on" : "off";
      var modal_title = $("#modal_title").val();
      var modal_description = $("#modal_description").val();
      var modal_button_text = $("#modal_button_text").val();
      var modal_submit_btn_color = $("#modal_button_color").val();

      var modal_width = $("#modal_width").val();
      var titleAlignment = $("#modal_title_alignment").val();
      var titleFontSize = $("#modal_title_fontSize").val();
      var titleFontWeight = $("#modal_title_fontWeight").val();
      var titleFontStyle = $("#modal_title_fontStyle").val();
      var titleTransformation = $("#modal_title_transformation").val();
      var titleDecoration = $("#modal_title_decoration").val();
      var titleLineHeight = $("#modal_title_lineHeight").val();
      var titleLetterSpacing = $("#modal_title_letterSpacing").val();
      var titleWordSpacing = $("#modal_title_wordSpacing").val();

      var descriptionAlignment = $("#modal_description_alignment").val();
      var descriptionFontSize = $("#modal_description_fontSize").val();
      var descriptionFontWeight = $("#modal_description_fontWeight").val();
      var descriptionFontStyle = $("#modal_description_fontStyle").val();
      var descriptionTransformation = $(
        "#modal_description_transformation"
      ).val();
      var descriptionDecoration = $("#modal_description_decoration").val();
      var descriptionLineHeight = $("#modal_description_lineHeight").val();
      var descriptionLetterSpacing = $(
        "#modal_description_letterSpacing"
      ).val();
      var descriptionWordSpacing = $("#modal_description_wordSpacing").val();

      var buttonFontSize = $("#modal_button_fontSize").val();
      var buttonFontWeight = $("#modal_button_fontWeight").val();
      var buttonFontStyle = $("#modal_button_fontStyle").val();
      var buttonTextTransformation = $("#modal_button_transformation").val();
      var buttonTextDecoration = $("#modal_button_decoration").val();
      var buttonTextLineHeight = $("#modal_button_lineHeight").val();
      var buttonLetterSpacing = $("#modal_button_letterSpacing").val();
      var buttonWordSpacing = $("#modal_button_wordSpacing").val();
      var buttonBorderRadius = $("#modal_button_borderRadius").val();
      var buttonPaddingX = $("#modal_button_paddingX").val();
      var buttonPaddingY = $("#modal_button_paddingY").val();
      var buttonShadowHOffset = $("#modal_button_shadowHOffset").val();
      var buttonShadowVOffset = $("#modal_button_shadowVOffset").val();
      var buttonShadowBlur = $("#modal_button_shadowBlur").val();
      var buttonShadowSpread = $("#modal_button_shadowSpread").val();

      var modalBackgroundColor = $("#modal_background_color").val();
      var modalTitleColor = $("#modal_title_color").val();
      var modalDescriptionColor = $("#modal_description_color").val();
      var modalButtonTextColor = $("#modal_button_text_color").val();
      var modalButtonHoveTextColor = $("#modal_button_hover_text_color").val();
      var modalButtonHoverColor = $("#modal_button_hover_color").val();
      var modalButtonShadowColor = $("#modal_button_shadow_color").val();

      let payloadNew = {
        container: {
          "background-color": modalBackgroundColor,
          width: modal_width,
        },
        heading: {
          color: modalTitleColor,
          "text-align": titleAlignment,
          "font-size": titleFontSize,
          "font-weight": titleFontWeight,
          "font-style": titleFontStyle,
          "text-transform": titleTransformation,
          "text-decoration": titleDecoration,
          "line-height": titleLineHeight,
          "letter-spacing": titleLetterSpacing,
          "word-spacing": titleWordSpacing,
        },
        content: {
          color: modalDescriptionColor,
          "text-align": descriptionAlignment,
          "font-size": descriptionFontSize,
          "font-weight": descriptionFontWeight,
          "font-style": descriptionFontStyle,
          "text-transform": descriptionTransformation,
          "text-decoration": descriptionDecoration,
          "line-height": descriptionLineHeight,
          "letter-spacing": descriptionLetterSpacing,
          "word-spacing": descriptionWordSpacing,
        },
        button: {
          color: modalButtonTextColor,
          "hover-color": modalButtonHoverColor,
          "hover-text-color": modalButtonHoveTextColor,
          "font-size": buttonFontSize,
          "font-weight": buttonFontWeight,
          "font-style": buttonFontStyle,
          "text-transform": buttonTextTransformation,
          "text-decoration": buttonTextDecoration,
          "line-height": buttonTextLineHeight,
          "letter-spacing": buttonLetterSpacing,
          "word-spacing": buttonWordSpacing,
          "border-radius": buttonBorderRadius,
          "padding-x": buttonPaddingX,
          "padding-y": buttonPaddingY,
          "button-shadow-h-offset": buttonShadowHOffset,
          "button-shadow-v-offset": buttonShadowVOffset,
          "button-shadow-blur": buttonShadowBlur,
          "button-shadow-spread": buttonShadowSpread,
          "shadow-color": modalButtonShadowColor,
          "box-shadow": `${buttonShadowHOffset}px ${buttonShadowVOffset}px ${buttonShadowBlur}px ${buttonShadowSpread}px ${modalButtonShadowColor}`,
          padding: `${buttonPaddingY}px ${buttonPaddingX}px`,
        },
      };
      let payload = {
        enabler: enabler,
        enabler_exit: enabler_exit,
        popup_logo: popup_logo,
        no_thanks_btn: no_thanks_btn,
        popup_title: modal_title,
        popup_description: modal_description,
        popup_button_text: modal_button_text,
        modal_submit_btn_color: modal_submit_btn_color,
        payloadNew,
      };
      wpAjaxHelperRequest("email-popup-submit", payload)
        .success(function (response) {
          $("#cl-loader").fadeOut();
          $("#email-popup-notice").show().addClass("cl-success");
          $("#email-popup-notice").text(response.message);
          setTimeout(function () {
            $("#email-popup-notice").fadeOut().removeClass("cl-success");
          }, 3000);
        })
        .error(function (response) {
          $("#cl-loader").fadeOut();
          $("#email-popup-notice").show().addClass("cl-error");
          $("#email-popup-notice").text("Error Occured");
          setTimeout(function () {
            $("#email-popup-notice").fadeOut().removeClass("cl-error");
          }, 3000);
        });
    },
  };

  const TwilioSmsSettings = {
    init: function () {
      $(document).on("submit", "#twilio-sms-settings", this.twilio_sms_submit);
    },

    twilio_sms_submit: function (e) {
      e.preventDefault();

      $("#cl-loader").fadeIn();
      $("#twilio_sms_notice").hide().removeClass("cl-success cl-error");

      var enabler = $("#twilio_sms").is(":checked") === true ? 1 : 0;
      var twilio_account_sid = $("#twilio_account_sid").val();
      var twilio_auth_token = $("#twilio_auth_token").val();
      var twilio_mobile_number = $("#twilio_mobile_number").val();
      var ajaxurl = cl_pro_obj.ajaxurl;
      var ajaxnonce = cl_pro_obj.security;

      jQuery.ajax({
        type: "POST",
        url: ajaxurl,
        data: {
          action: "twilio_sms_submit",
          nonce: ajaxnonce,
          enabler: enabler,
          twilio_account_sid: twilio_account_sid,
          twilio_auth_token: twilio_auth_token,
          twilio_mobile_number: twilio_mobile_number,
        },

        success: function (response) {
          $("#cl-loader").fadeOut();
          if (response.status) {
            $("#twilio_sms_notice").show().addClass("cl-success");
            $("#twilio_sms_notice").text(response.message);
            setTimeout(function () {
              $("#twilio_sms_notice").fadeOut().removeClass("cl-success");
            }, 3000);
          } else {
            $("#twilio_sms_notice").show().addClass("cl-error");
            $("#twilio_sms_notice").text(response.message);

            setTimeout(function () {
              $("#twilio_sms_notice").fadeOut().removeClass("cl-error");
            }, 3000);
          }
        },
        error: function (response) {
          $("#cl-loader").fadeOut();
          $("#twilio_sms_notice").show().addClass("cl-error");
          $("#twilio_sms_notice").text(response.message);

          setTimeout(function () {
            $("#twilio_sms_notice").fadeOut().removeClass("cl-error");
          }, 3000);
        },
      });
    },
  };

  $(document).on("change", "#twilio_sms", function (e) {
    e.preventDefault();
    $("#twilio_sms").is(":checked") === true
      ? $("#twilio_sms_setting_fields").show()
      : $("#twilio_sms_setting_fields").hide();
  });

  $(document).on("change", "#no_thanks_btn", function (e) {
    e.preventDefault();
    $("#no_thanks_btn").is(":checked")
      ? $("#cl-ignore-email-form").show()
      : $("#cl-ignore-email-form").hide();
  });


  $(document).ready(function(){ 

    $('.cl-popup-tab-a').click(function(e){  
      e.preventDefault();
      $(".tab").removeClass('tab-active');
      $(".tab[data-id='"+$(this).attr('data-id')+"']").addClass("tab-active");
      $(".cl-popup-tab-a").removeClass('active-a');
      $(this).parent().find(".cl-popup-tab-a").addClass('active-a');
     });

  });

  // --------accordion--------
  document.addEventListener("DOMContentLoaded", function () {
    const accordionItems = document.querySelectorAll(".cl-accordion-item");

    accordionItems.forEach((item) => {
      const title = item.querySelector(".cl-accordion-title");
      const icon = item.querySelector(".cl-accordion-icon svg");

      title.addEventListener("click", () => {
        item.classList.toggle("active");
        const content = item.querySelector(".cl-accordion-content");
        content.style.display =
          content.style.display === "block" ? "none" : "block";
        icon.classList.toggle("cl-rotate-icon");
      });
    });
  });

  $(document).ready(function () {
    EmailTemplateProActions.init();
    EmailPopupSettings.init();

    $("#twilio_sms").is(":checked") === true
      ? $("#twilio_sms_setting_fields").show()
      : $("#twilio_sms_setting_fields").hide();

    TwilioSmsSettings.init();

    EmailPopupColorPicker();

    SelectEmailPopupSubmitButtonColor();

    ChangeModalBackgroundColor();

    ChangeModalTitleColor();

    ChangeModalDescriptionColor();

    ChangeModalButtonTextColor();

    ChangeModalButtonHoverTextColor();

    ChangeModalButtonHoverColor();

    ChangeModalWidth();

    ChangeModalTitleAlignment();

    ChangeModalTitleFontSize();

    ChangeModalTitleFontWeight();

    ChangeModalTitleFontStyle();

    ChangeModalTitleTransformation();

    ChangeModalTitleDecoration();

    ChangeModalTitleLineHeight();

    ChangeModalTitleLetterSpacing();

    ChangeModalTitleWordSpacing();

    ChangeModalDescriptionAlignment();

    ChangeModalDescriptionFontSize();

    ChangeModalDescriptionFontWeight();

    ChangeModalDescriptionFontStyle();

    ChangeModalDescriptionTransformation();

    ChangeModalDescriptionDecoration();

    ChangeModalDescriptionLineHeight();

    ChangeModalDescriptionLetterSpacing();

    ChangeModalDescriptionWordSpacing();

    ChangeModalButtonFontSize();

    ChangeModalButtonFontWeight();

    ChangeModalButtonFontStyle();

    ChangeModalButtonTransformation();

    ChangeModalButtonDecoration();

    ChangeModalButtonLineHeight();

    ChangeModalButtonLetterSpacing();

    ChangeModalButtonWordSpacing();

    ChangeModalButtonBorderRadius();

    ChangeModalButtonPaddingX();

    ChangeModalButtonPaddingY();

    changeModalButtonShadow(
      ".cl-modal-button-shadowHOffset-input",
      ".cl-modal-button-shadowVOffset-input",
      ".cl-modal-button-shadowBlur-input",
      ".cl-modal-button-shadowSpread-input",
      ".cl-wp-button-shadow-color-picker"
    );
  });

  function EmailPopupColorPicker() {
    $(".cl-wp-color-picker").wpColorPicker({
      change: function (event, ui) {
        var selected_color = ui.color.toString();
        $("#cl_popup_submit_btn").css("background-color", selected_color);
      },
    });
  }

  // change modal button color
  function SelectEmailPopupSubmitButtonColor() {
    var selected_color = $("#modal_button_color").val();
    $("#cl_popup_submit_btn").css("background-color", selected_color);
  }

  // change modal bg color
  function ChangeModalBackgroundColor() {
    $(".cl-wp-bg-color-picker").wpColorPicker({
      change: function (event, ui) {
        var selected_color = ui.color.toString();
        $("#cl_popup_modal").css("background-color", selected_color);
      },
    });
  }
  // change modal title color
  function ChangeModalTitleColor() {
    $(".cl-wp-title-color-picker").wpColorPicker({
      change: function (event, ui) {
        var selected_color = ui.color.toString();
        $("#cl_popup_title").css("color", selected_color);
      },
    });
  }
  // change modal description color
  function ChangeModalDescriptionColor() {
    $(".cl-wp-description-color-picker").wpColorPicker({
      change: function (event, ui) {
        var selected_color = ui.color.toString();
        $("#cl_popup_description").css("color", selected_color);
      },
    });
  }
  // change modal button text color
  function ChangeModalButtonTextColor() {
    $(".cl-wp-button-text-color-picker").wpColorPicker({
      change: function (event, ui) {
        var selected_color = ui.color.toString();
        $("#cl_popup_submit_btn").css("color", selected_color);
      },
    });
  }

  // change modal button hover text color
  function ChangeModalButtonHoverTextColor() {
    $(".cl-wp-button-hover-text-color-picker").wpColorPicker({
      change: function (event, ui) {
        var hover_color = ui.color.toString();
        $("#cl_popup_submit_btn").data("hover-text-color", hover_color);
      },
    });

    $("#cl_popup_submit_btn")
      .on("mouseover", function () {
        $(this).css("color", $(this).data("hover-text-color"));
      })
      .on("mouseout", function () {
        // Restore the original color when mouseout
        var original_color = $("#modal_button_text_color").val();
        $(this).css("color", original_color);
      });
  }

  // change modal button hover color
  function ChangeModalButtonHoverColor() {
    $(".cl-wp-button-hover-color-picker").wpColorPicker({
      change: function (event, ui) {
        var hover_color = ui.color.toString();
        $("#cl_popup_submit_btn").data("hover-color", hover_color);
      },
    });

    $("#cl_popup_submit_btn")
      .on("mouseover", function () {
        $(this).css("background-color", $(this).data("hover-color"));
      })
      .on("mouseout", function () {
        // Restore the original color when mouseout
        var original_color = $("#modal_button_color").val();
        $(this).css("background-color", original_color);
      });
  }

  // change modal width
  function ChangeModalWidth() {
    $(".cl-modal-width-input").on("input", function () {
      var widthPercentage = $(this).val();
      var numericValue = parseFloat(widthPercentage);

      if (numericValue > 100) {
        $("#cl_popup_modal").css("width", "100%");
      } else {
        $("#cl_popup_modal").css("width", widthPercentage + "%");
      }
    });
  }
  // change modal title alignment
  function ChangeModalTitleAlignment() {
    $(".cl-modal-title-alignment-input").on("input", function () {
      var titleAlignment = $(this).val();
      $("#cl_popup_title").css("text-align", titleAlignment);
    });
  }
  // change modal title font size
  function ChangeModalTitleFontSize() {
    $(".cl-modal-title-fontSize-input").on("input", function () {
      var fontSize = $(this).val();
      if (!isNaN(fontSize) && fontSize >= 0) {
        $("#cl_popup_title").css("font-size", fontSize + "px");
      } else {
        console.error("Please enter a valid font size.");
      }
    });
  }
  // change modal title font weight
  function ChangeModalTitleFontWeight() {
    $(".cl-modal-title-fontWeight-input").on("input", function () {
      var fontWeight = $(this).val();
      $("#cl_popup_title").css("font-weight", fontWeight);
    });
  }
  // change modal title font style
  function ChangeModalTitleFontStyle() {
    $(".cl-modal-title-fontStyle-input").on("input", function () {
      var fontStyle = $(this).val();
      $("#cl_popup_title").css("font-style", fontStyle);
    });
  }
  // modal title text transformation
  function ChangeModalTitleTransformation() {
    $(".cl-modal-title-transformation-input").on("input", function () {
      var textTransform = $(this).val();
      $("#cl_popup_title").css("text-transform", textTransform);
    });
  }
  // modal title text decoration
  function ChangeModalTitleDecoration() {
    $(".cl-modal-title-decoration-input").on("input", function () {
      var textDecoration = $(this).val();
      $("#cl_popup_title").css("text-decoration", textDecoration);
    });
  }
  // change modal title line height
  function ChangeModalTitleLineHeight() {
    $(".cl-modal-title-lineHeight-input").on("input", function () {
      var lineHeight = $(this).val();
      if (!isNaN(lineHeight) && lineHeight !== "") {
        $("#cl_popup_title").css("line-height", lineHeight + "em");
      } else {
        console.error("Please enter a valid line height.");
      }
    });
  }

  // change modal title letter spacing
  function ChangeModalTitleLetterSpacing() {
    $(".cl-modal-title-letterSpacing-input").on("input", function () {
      var letterSpacing = $(this).val();
      $("#cl_popup_title").css("letter-spacing", letterSpacing + "px");
    });
  }
  // change modal title word spacing
  function ChangeModalTitleWordSpacing() {
    $(".cl-modal-title-wordSpacing-input").on("input", function () {
      var wordSpacing = $(this).val();
      $("#cl_popup_title").css("word-spacing", wordSpacing + "px");
    });
  }

  // change modal description alignment----------------
  function ChangeModalDescriptionAlignment() {
    $(".cl-modal-description-alignment-input").on("input", function () {
      var descriptionAlignment = $(this).val();
      $("#cl_popup_description").css("text-align", descriptionAlignment);
    });
  }

  // change modal description font size
  function ChangeModalDescriptionFontSize() {
    $(".cl-modal-description-fontSize-input").on("input", function () {
      var fontSize = $(this).val();
      if (!isNaN(fontSize) && fontSize >= 0) {
        $("#cl_popup_description").css("font-size", fontSize + "px");
      } else {
        console.error("Please enter a valid font size.");
      }
    });
  }

  // change modal description font weight
  function ChangeModalDescriptionFontWeight() {
    $(".cl-modal-description-fontWeight-input").on("input", function () {
      var fontWeight = $(this).val();
      $("#cl_popup_description").css("font-weight", fontWeight);
    });
  }

  // change modal description font style
  function ChangeModalDescriptionFontStyle() {
    $(".cl-modal-description-fontStyle-input").on("input", function () {
      var fontStyle = $(this).val();
      $("#cl_popup_description").css("font-style", fontStyle);
    });
  }

  // modal description text transformation
  function ChangeModalDescriptionTransformation() {
    $(".cl-modal-description-transformation-input").on("input", function () {
      var textTransform = $(this).val();
      $("#cl_popup_description").css("text-transform", textTransform);
    });
  }

  // modal description text decoration
  function ChangeModalDescriptionDecoration() {
    $(".cl-modal-description-decoration-input").on("input", function () {
      var textDecoration = $(this).val();
      $("#cl_popup_description").css("text-decoration", textDecoration);
    });
  }
  // change modal description line height
  function ChangeModalDescriptionLineHeight() {
    $(".cl-modal-description-lineHeight-input").on("input", function () {
      var lineHeight = $(this).val();
      if (!isNaN(lineHeight) && lineHeight !== "") {
        $("#cl_popup_description").css("line-height", lineHeight + "em");
      } else {
        console.error("Please enter a valid line height.");
      }
    });
  }

  // change modal description letter spacing
  function ChangeModalDescriptionLetterSpacing() {
    $(".cl-modal-description-letterSpacing-input").on("input", function () {
      var letterSpacing = $(this).val();
      $("#cl_popup_description").css("letter-spacing", letterSpacing + "px");
    });
  }

  // change modal description word spacing
  function ChangeModalDescriptionWordSpacing() {
    $(".cl-modal-description-wordSpacing-input").on("input", function () {
      var wordSpacing = $(this).val();
      $("#cl_popup_description").css("word-spacing", wordSpacing + "px");
    });
  }

  // change modal button font size
  function ChangeModalButtonFontSize() {
    $(".cl-modal-button-fontSize-input").on("input", function () {
      var fontSize = $(this).val();
      if (!isNaN(fontSize) && fontSize >= 0) {
        $("#cl_popup_submit_btn").css("font-size", fontSize + "px");
      } else {
        console.error("Please enter a valid font size.");
      }
    });
  }

  // change modal button font weight
  function ChangeModalButtonFontWeight() {
    $(".cl-modal-button-fontWeight-input").on("input", function () {
      var fontWeight = $(this).val();
      $("#cl_popup_submit_btn").css("font-weight", fontWeight);
    });
  }

  // change modal button font style
  function ChangeModalButtonFontStyle() {
    $(".cl-modal-button-fontStyle-input").on("input", function () {
      var fontStyle = $(this).val();
      $("#cl_popup_submit_btn").css("font-style", fontStyle);
    });
  }

  // modal button text transformation
  function ChangeModalButtonTransformation() {
    $(".cl-modal-button-transformation-input").on("input", function () {
      var textTransform = $(this).val();
      $("#cl_popup_submit_btn").css("text-transform", textTransform);
    });
  }

  // modal button text decoration
  function ChangeModalButtonDecoration() {
    $(".cl-modal-button-decoration-input").on("input", function () {
      var textDecoration = $(this).val();
      $("#cl_popup_submit_btn").css("text-decoration", textDecoration);
    });
  }

  // change modal button line height
  function ChangeModalButtonLineHeight() {
    $(".cl-modal-button-lineHeight-input").on("input", function () {
      var lineHeight = $(this).val();
      if (!isNaN(lineHeight) && lineHeight !== "") {
        $("#cl_popup_submit_btn").css("line-height", lineHeight + "em");
      } else {
        console.error("Please enter a valid line height.");
      }
    });
  }

  // change modal button letter spacing
  function ChangeModalButtonLetterSpacing() {
    $(".cl-modal-button-letterSpacing-input").on("input", function () {
      var letterSpacing = $(this).val();
      $("#cl_popup_submit_btn").css("letter-spacing", letterSpacing + "px");
    });
  }

  // change modal button word spacing
  function ChangeModalButtonWordSpacing() {
    $(".cl-modal-button-wordSpacing-input").on("input", function () {
      var wordSpacing = $(this).val();
      $("#cl_popup_submit_btn").css("word-spacing", wordSpacing + "px");
    });
  }

  // button border radius
  function ChangeModalButtonBorderRadius() {
    $(".cl-modal-button-borderRadius-input").on("input", function () {
      var borderRadius = $(this).val();
      if (!isNaN(borderRadius) && borderRadius >= 0) {
        $("#cl_popup_submit_btn").css("border-radius", borderRadius + "px");
      } else {
        console.error("Please enter a valid font size.");
      }
    });
  }
  // button padding x
  function ChangeModalButtonPaddingX() {
    $(".cl-modal-button-paddingX-input").on("input", function () {
      var paddingX = $(this).val();
      if (!isNaN(paddingX) && paddingX >= 0) {
        $("#cl_popup_submit_btn").css({
          "padding-left": paddingX + "px",
          "padding-right": paddingX + "px",
        });
      } else {
        console.error("Please enter a valid font size.");
      }
    });
  }
  // button padding Y
  function ChangeModalButtonPaddingY() {
    $(".cl-modal-button-paddingY-input").on("input", function () {
      var paddingY = $(this).val();
      if (!isNaN(paddingY) && paddingY >= 0) {
        $("#cl_popup_submit_btn").css({
          "padding-top": paddingY + "px",
          "padding-bottom": paddingY + "px",
        });
      } else {
        console.error("Please enter a valid font size.");
      }
    });
  }

  // button box shadow
  function changeModalButtonShadow(
    hOffsetSelector,
    vOffsetSelector,
    blurSelector,
    spreadSelector,
    colorSelector
  ) {
    function updateShadow(hOffset, vOffset, blur, spread, color) {
      if (
        hOffset !== null &&
        vOffset !== null &&
        blur !== null &&
        spread !== null &&
        color !== null
      ) {
        $("#cl_popup_submit_btn").css(
          "box-shadow",
          `${hOffset}px ${vOffset}px ${blur}px ${spread}px ${color}`
        );
      } else {
        console.error("Please enter valid shadow values.");
      }
    }

    $(colorSelector).wpColorPicker({
      change: function (event, ui) {
        var shadow_color = ui.color.toString();
        var hOffset = $(hOffsetSelector).val();
        var vOffset = $(vOffsetSelector).val();
        var blur = $(blurSelector).val();
        var spread = $(spreadSelector).val();
        updateShadow(hOffset, vOffset, blur, spread, shadow_color);
      },
    });

    $(
      hOffsetSelector +
        ", " +
        vOffsetSelector +
        ", " +
        blurSelector +
        ", " +
        spreadSelector
    ).on("input", function () {
      var hOffset = $(hOffsetSelector).val();
      var vOffset = $(vOffsetSelector).val();
      var blur = $(blurSelector).val();
      var spread = $(spreadSelector).val();
      var color = $(colorSelector).wpColorPicker("color").toString();
      updateShadow(hOffset, vOffset, blur, spread, color);
    });
  }



} )( jQuery );






