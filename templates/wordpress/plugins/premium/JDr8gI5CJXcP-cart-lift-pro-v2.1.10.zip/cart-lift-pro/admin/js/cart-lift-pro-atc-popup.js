var Form = Vue.component('cl-atc-vue-app', {
    template: '#cl-atc-vue-app',
    parent: App,
    props: [
        'enabler','enabler_exit', 'popup_logo', 'popup_title', 'popup_description', 'popup_button_text', 
        'enable_status', 'enable_status', 'exitIntendPopupEnabled','data_header', 'header_text_alignment',
        'header_text_font_weight', 'header_text_font_style', 'header_text_transform', 'header_text_decoration',
        'header_text_line_height', 'header_text_letter_spacing', 'header_text_word_spacing', 'content_text_alignment',
        'content_text_font_weight', 'content_text_font_style', 'content_text_transform', 'content_text_decoration',
        'content_text_line_height', 'content_text_letter_spacing', 'content_text_word_spacing', 'content_text_font_size',
        'content_text_color', 'button_text_font_size', 'button_text_font_weight', 'button_text_font_style', 'button_text_transform',
        'button_text_decoration', 'button_text_line_height', 'button_text_letter_spacing', 'button_text_word_spacing', 'button_text_border_radius', 'button_text_shadow_h_offset', 'button_text_shadow_v_offset', 'button_text_shadow_blur',
        'button_text_shadow_spread', 'button_text_color', 'button_text_background_color', 'button_text_hover_color','button_hover_background_color',
        'button_h_offset', 'button_v_offset', 'button_blur', 'button_text_shadow_color', 'button_text_hover_shadow_color','button_shadow_spread', 'button_text_paddingX', 'button_text_paddingY', 'button_text_padding_x', 'button_text_padding_y', 'button_blur_shadow', 'container_width'
    ],
    data: function(){
        return {
            enabled: this.enabler,
            enabled_exit: this.enabler_exit,
            logo: this.popup_logo,
            logo_id: '',
            title: this.popup_title,
            description: this.popup_description,
            button_text: this.popup_button_text,
            status: this.enable_status,
            checked: this.enable_status,
            titleAlignment: this.header_text_alignment,
            titleFontSize: this.data_header,
            titleFontWeight: this.header_text_font_weight,
            titleFontStyle: this.header_text_font_style,
            titleTransformation: this.header_text_transform,
            titleDecoration: this.header_text_decoration,
            titleLineHeight: this.header_text_line_height,
            titleLetterSpacing: this.header_text_letter_spacing,
            titleWordSpacing: this.header_text_word_spacing,
            descriptionAlignment: this.content_text_alignment,
            descriptionFontSize: this.content_text_font_size,
            descriptionFontWeight: this.content_text_font_weight,
            descriptionFontStyle: this.content_text_font_style,
            descriptionTransformation: this.content_text_transform,
            descriptionDecoration: this.content_text_decoration,
            descriptionLineHeight: this.content_text_line_height,
            descriptionLetterSpacing: this.content_text_letter_spacing,
            descriptionWordSpacing: this.content_text_word_spacing,
            buttonFontSize: this.button_text_font_size,
            buttonFontWeight: this.button_text_font_weight,
            buttonFontStyle: this.button_text_font_style,
            buttonTextTransformation: this.button_text_transform,
            buttonTextDecoration: this.button_text_decoration,
            buttonTextLineHeight: this.button_text_line_height,
            buttonLetterSpacing: this.button_text_letter_spacing,
            buttonWordSpacing: this.button_text_word_spacing,
            buttonBorderRadius: this.button_text_border_radius,
            buttonPaddingX: this.button_text_padding_x,
            buttonPaddingY: this.button_text_padding_y,
            buttonShadowHOffset: this.button_h_offset,
            buttonShadowVOffset: this.button_v_offset,
            buttonShadowBlur: this.button_blur_shadow,
            buttonShadowSpread: this.button_shadow_spread,
            modalWidth: this.container_width,                         
        }
    },
    methods: {
        check: function(e) {
            if(e.target.checked) {
                this.enabled = 1;
            }else {
                this.enabled = 0;
            }
        },
        check_exit: function(e) {
            if(e.target.checked) {
                this.enabled_exit = 1;
            }else {
                this.enabled_exit = 0;
            }
        },

        exitIntendCheck: function(e) {

            if(e.target.checked) {
                this.exitIntendPopupEnabled = 1;
            }else {
                this.exitIntendPopupEnabled = 0;
            }
        },
    
        upload: function (e) {
            // this.logo = 'http://dev.cartlift.com/wp-content/uploads/2020/04/beanie-with-logo-1.jpg';
            if (this.window === undefined) {
                this.window = wp.media({
                    title: 'Insert Logo',
                    library: {type: 'image'},
                    multiple: false,
                    button: {text: 'Insert Logo'}
                });
                var self = this;
                this.window.on('select', function() {
                    var response = self.window.state().get('selection').first().toJSON();
                    self.logo = response.url;
                    self.logo_id = response.id;
                });
            }

            this.window.open();
            return false;
        },

        remove: function () {
            this.logo = '';
            this.logo_id = '';
        }
    },

    
});


// create a root instance
var App = new Vue({
    el: '#vue-app',
    
});

