<?php
$default = array(
    'enabler' => '0',
    'enabler_exit' => '0',
    'popup_logo' => CART_LIFT_PRO_URL . 'admin/images/logo.png',
    'no_thanks_btn' => 'on',
    'popup_title' => 'You were not leaving your cart just like that, right?',
    'popup_description' => 'Enter your email below to save your shopping cart for later. And, who knows, maybe we will even send you a sweet discount code.',
    'popup_button_text' => 'Submit',

);
$data = get_option('cl_popup_settings', $default);

$id = 'cl-email-popup-form';
if (function_exists('cl_is_wc_active') && cl_is_wc_active()) {
    if (is_product()) {
        $id = 'cl-email-popup-form-wc-single';
    }
}

$provider = 'wc';
if (function_exists('cl_is_wc_active') && cl_is_wc_active()) {
    if (is_woocommerce()) {
        $provider = 'wc';
    } else {
        $provider = 'edd';
    }
} else {
    $provider = 'edd';
}

$add_no_thanks = isset($data['no_thanks_btn']) ? $data['no_thanks_btn'] : 'on';
?>


<div class="cl-add2cart-modal" id="cart-lift-email-popup">
    <?php
    $container_style = '';
    $container_pixel_add = ['width'];
    if (isset($data['payloadNew']['container'])) {
        foreach ($data['payloadNew']['container'] as $key => $value) {
            $suffix_pixel = in_array($key, $container_pixel_add) ? '%' : '';
            $container_style .= "$key: $value" . $suffix_pixel . ";";
        }
    }

    ?>
    <div class="modal-wrapper" style="<?php echo  esc_attr($container_style); ?>">
        <div class="modal-body">
            <?php if ($data['popup_logo']) { ?>
                <div class="plugin-logo">
                    <img src="<?php echo $data['popup_logo']; ?>">
                </div>
            <?php } ?>

            <?php
            $heading_title_style = '';
            $pixel_add = ['font-size', 'letter-spacing', 'word-spacing'];
            $line_height = ['line-height'];
            if (isset($data['payloadNew']['heading'])) {
                foreach ($data['payloadNew']['heading'] as $key => $value) {
                    $suffix_pixel = in_array($key, $pixel_add) ? 'px' : '';
                    $suffix_em = in_array($key, $line_height) ? 'em' : '';
                    $heading_title_style .= "$key: $value" . $suffix_pixel . $suffix_em . ";";
                }
            }
            ?>

            <h4 style="<?php echo esc_attr($heading_title_style); ?>"><?php echo $data['popup_title']; ?></h4>

            <?php
            $content_style = '';
            $content_pixel_add = ['font-size', 'letter-spacing', 'word-spacing'];
            $content_line_height = ['line-height'];
            if (isset($data['payloadNew']['content'])) {
                foreach ($data['payloadNew']['content'] as $key => $value) {
                    $suffix_pixel = in_array($key, $content_pixel_add) ? 'px' : '';
                    $suffix_em = in_array($key, $content_line_height) ? 'em' : '';
                    $content_style .= "$key: $value" . $suffix_pixel . $suffix_em . ";";
                }
            }
            ?>

            <p style="<?php echo esc_attr($content_style); ?>"><?php echo $data['popup_description']; ?></p>
            <form id="<?php echo $id; ?>">
                <div class="cl-popup-email-invalid-notice" style="display:none; color:red; text-align: center; font-size: small;padding-bottom: 2px;">
                    <?php echo __('The email is invalid.', 'cart-lift-pro'); ?>
                </div>
                <input type="email" name="email" value="" placeholder="<?php _e('Enter your email', 'cart-lift-pro'); ?>" id="cl-popup-email">
                <?php
                $general_settings = function_exists('cl_get_general_settings') ? cl_get_general_settings() : [];
                if (isset($general_settings['enable_gdpr']) && $general_settings['enable_gdpr']) {
                    $gdpr_msg = isset($general_settings['gdpr_text']) ? $general_settings['gdpr_text'] : '';
                    echo "<span id='cl_gdpr_message'><span>" . $gdpr_msg . "</span></span>";
                }
                ?>
                <?php
                $button_style = '';
                $button_pixel_add = ['font-size', 'letter-spacing', 'word-spacing', 'border-radius', 'padding-x', 'padding-y', 'h-offset', 'v-offset', 'blur', 'spread'];
                $button_line_height = ['line-height'];
                if (isset($data['payloadNew']['button'])) {
                    foreach ($data['payloadNew']['button'] as $key => $value) {
                        $suffix_pixel = in_array($key, $button_pixel_add) ? 'px' : '';
                        $suffix_em = in_array($key, $button_line_height) ? 'em' : '';
                        $button_style .= "$key: $value" . $suffix_pixel . $suffix_em . "; ";
                    }
                }
                $modal_button_submit_color = $data['modal_submit_btn_color'] ?? '#ee8134';
                $button_style  .= 'background-color: ' . $modal_button_submit_color . "; ";
                ?>
                <button id="cl-atc-button" class="cl-btn" data-provider="<?php echo $provider ?? ''; ?>" style="<?php echo $button_style; ?>" onmouseover="this.style.backgroundColor='<?php echo $data['payloadNew']['button']['hover-color'] ?? ''; ?>'; this.style.color='<?php echo $data['payloadNew']['button']['hover-text-color'] ?? ''; ?>'; " onmouseout="this.style.backgroundColor='<?php echo $modal_button_submit_color; ?>'; this.style.color='<?php echo $data['payloadNew']['button']['color'] ?? ''; ?>';"><?php echo $data['popup_button_text'] ?? ''; ?></button>
            </form>
            <div class="cl-popup-thank-you-notice" style="display:none; color:#ee8134; font-size: small;padding-bottom: 10px;">
                <?php echo __('Thank you. Happy shopping.', 'cart-lift-pro'); ?>
            </div>
            <?php if ($add_no_thanks === 'on') : ?>
                <a href="#" class="cl-alert-cancel" id="cl-ignore-email-form"><?php _e('No Thanks!', 'cart-lift-pro'); ?></a>
            <?php endif; ?>
        </div>
    </div>
</div>