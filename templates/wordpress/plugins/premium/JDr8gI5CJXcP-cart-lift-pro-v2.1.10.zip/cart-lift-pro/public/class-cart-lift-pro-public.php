<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://rextheme.com/
 * @since      1.0.0
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Cart_Lift_Pro
 * @subpackage Cart_Lift_Pro/public
 * @author     RexTheme <info@rextheme.com>
 */
class Cart_Lift_Pro_Public {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of the plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct( $plugin_name, $version ) {

        $this->plugin_name = $plugin_name;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Cart_Lift_Pro_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Cart_Lift_Pro_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cart-lift-pro-public.css', array(), $this->version, 'all' );


    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Cart_Lift_Pro_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Cart_Lift_Pro_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/cart-lift-pro-public.js', array( 'jquery' ), $this->version, false );

        if ( $this->is_popup_enabled() || $this->is_entent_popup_enabled() ) {
            $is_wc_cart_empty = true;
            $is_edd_cart_empty = true;
            if ( function_exists( 'cl_is_wc_active' ) && cl_is_wc_active() ) {
                $is_wc_cart_empty = WC()->cart->is_empty();
            }
            if ( function_exists( 'cl_is_edd_active' ) && cl_is_edd_active() ) {
                $is_edd_cart_empty = EDD()->cart->is_empty();
            }
            $data                    = [
                'ajaxurl'                => admin_url( 'admin-ajax.php' ),
                'security'               => wp_create_nonce( 'cart-lift-pro-frontend' ),
                'is_cart_empty'          => $is_wc_cart_empty && $is_edd_cart_empty,
                'ignore_popup'           => $_COOKIE[ 'cart_lift_ignore_email_popup' ] ?? 0,
                'is_show_entent_popup'   => $this->is_show_intent_popup(),
                'is_ignore_intent_popup' => $_COOKIE[ 'cart_lift_intent_popup' ] ?? 0,
                'is_wc_active'           => function_exists( 'cl_is_wc_active' ) && cl_is_wc_active(),
                'is_edd_active'          => function_exists( 'cl_is_edd_active' ) && cl_is_edd_active() ,
                'is_user_not_logged_in'  => !is_user_logged_in()
            ];
            $data[ 'cart_is_empty' ] = $is_wc_cart_empty && $is_edd_cart_empty;
            wp_enqueue_script( $this->plugin_name . 'email_popup', plugin_dir_url( __FILE__ ) . 'js/cart-lift-pro-email-popup.js', array( 'jquery' ), $this->version, false );
            wp_enqueue_script( $this->plugin_name . 'cookie', plugin_dir_url( __FILE__ ) . 'js/js.cookie.min.js', array( 'jquery' ), $this->version, false );
            wp_localize_script( $this->plugin_name . 'email_popup', 'cl_pop_up', $data );
        }
    }

    /**
     * Checks if the intent popup is enabled based on popup settings.
     *
     * This function retrieves popup settings from the WordPress options table and
     * determines if the exit intent popup should be enabled. The popup is considered
     * enabled if the 'enabler_exit' option is set to '1'.
     *
     * @return bool True if the exit intent popup is enabled, false otherwise.
     */
    public function is_entent_popup_enabled() {
        $pop_up_options = get_option( 'cl_popup_settings' );
        return isset( $pop_up_options[ 'enabler_exit' ] ) && '1' === $pop_up_options[ 'enabler_exit' ];
    }

    /**
     * Determines if the intent popup should be shown based on the current page.
     *
     * This function checks if the current page is the cart page, the Easy Digital Downloads
     * (EDD) checkout page, or the WooCommerce checkout page. Additionally, it ensures that
     * the current endpoint is not 'order-received' if the WooCommerce endpoint function exists.
     *
     * @return bool True if the intent popup should be shown, false otherwise.
     */
    public function is_show_intent_popup() {
        return (
                ( function_exists( 'is_cart' ) && is_cart() )
                || ( function_exists( 'edd_is_checkout' ) && edd_is_checkout() )
                || ( function_exists( 'is_checkout' ) && is_checkout() )
            )
            && ( !function_exists( 'is_wc_endpoint_url' ) || !is_wc_endpoint_url( 'order-received' ) );

    }

    /**
     * Displays the email popup footer if certain conditions are met.
     *
     * This function checks whether the popup is enabled or an exit intent is detected.
     * It determines whether the cart is empty and identifies the current session ID
     * based on the active e-commerce plugin (WooCommerce or Easy Digital Downloads).
     * If the necessary conditions are met, it renders and displays the email popup.
     *
     * @global wpdb $wpdb WordPress database abstraction object.
     *
     * @return void
     */
    public function display_email_popup_footer() {

        if($this->is_enabler_exit() && $this->is_show_intent_popup()){
            $this->cl_render_and_display_email_popup();
        }

        if($this->is_popup_enabled() && !$this->is_show_intent_popup() ){
            $this->cl_render_and_display_email_popup();
        }
    }

    /**
     * Render the email popup HTML.
     *
     * This function captures the output of the email popup template and returns it as a string.
     * It uses output buffering to capture the content generated by the template file located
     * in the 'cart-lift-pro' directory.
     *
     * @return string The rendered HTML of the email popup.
     */
    public function render_email_popup() {
        ob_start();
        require_once CART_LIFT_PRO_DIR . '/public/templates/cart-lift-pro-email-popup.php';
        return ob_get_clean();
    }

    /**
     * Check if the popup is enabled for non-logged-in users.
     *
     * This function determines if the popup should be shown to non-logged-in users.
     * It first checks if the user is logged in. If not, it retrieves the popup settings
     * from the WordPress options table and returns the value of the 'enabler' option.
     *
     * @return bool True if the popup is enabled, false otherwise.
     */
    function is_popup_enabled(){
        if(is_user_logged_in()) {
            return false;
        }
        $popup_options = get_option('cl_popup_settings', array(
            'enabler' => false,
            'header_text' => 'You were not leaving your cart just like that, right?',
            'helper_text' => 'Enter your email below to save your shopping cart for later. And, who knows, maybe we will even send you a sweet discount code  .',
        ));
        return $popup_options['enabler'];
    }

    /**
     * Check if the exit popup is enabled for non-logged-in users.
     *
     * This function determines if the exit popup should be shown to non-logged-in users.
     * It first checks if the user is logged in. If not, it retrieves the popup settings
     * from the WordPress options table and returns the value of the 'enabler_exit' option.
     *
     * @return bool True if the exit popup is enabled, false otherwise.
     */
    function is_enabler_exit(){
        if(is_user_logged_in()) {
            return false;
        }
        $popup_options = get_option('cl_popup_settings', array(
            'enabler_exit' => false,
            'header_text' => 'You were not leaving your cart just like that, right?',
            'helper_text' => 'Enter your email below to save your shopping cart for later. And, who knows, maybe we will even send you a sweet discount code  .',
        ));
        return $popup_options['enabler_exit'];
    }

    /**
     * Store the user's email address associated with the current session.
     *
     * This function processes an AJAX request to store the user's email address. It checks the AJAX nonce for security,
     * determines the session ID based on the provider (WooCommerce or Easy Digital Downloads), and updates the database
     * with the email address. It also sets cookies to ignore the email popup and store the email address.
     *
     * @global wpdb $wpdb WordPress database abstraction object.
     *
     * @return void
     */
    public function cl_store_email() {
        check_ajax_referer( 'cart-lift-pro-frontend', 'security' );

        $provider = sanitize_text_field($_POST['provider']);

        if($provider === 'wc' && cl_is_wc_active() ) {
            $session_id = WC()->session->get('cl_wc_session_id');
        }

        if ($provider === 'edd' && cl_is_edd_active() ) {
            $session_id = EDD()->session->get('cl_edd_session_id');
        }

        $email = sanitize_email($_POST['email']);
        global $wpdb;
        $cl_cart_table = $wpdb->prefix . CART_LIFT_CART_TABLE;

        $wpdb->update(
            $cl_cart_table,
            array('email' => $email),
            array('session_id' => $session_id)
        );

        setcookie( 'cart_lift_ignore_email_popup', '1', time()+3600, '/' );
        setcookie( 'cart_lift_user_email', $email , time()+3600, '/' );
        if(isset($_POST['intent_popup']) && sanitize_text_field( $_POST['intent_popup'] ) === '1'){
            setcookie( 'cart_lift_intent_popup', '1' , time()+604800, '/' );
        }
        wp_send_json_success();
    }

    /**
     * Handle the email popup ignore action.
     *
     * This function sets cookies to ignore the email popup and, optionally, the intent popup.
     * It checks the AJAX nonce for security, sets the cookies, and returns a JSON success response.
     *
     * @return void
     */
    public function cl_ignore_email_popup() {
        check_ajax_referer( 'cart-lift-pro-frontend', 'security' );
        setcookie( 'cart_lift_ignore_email_popup', '1', time()+3600, '/' );
        if(isset($_POST['intent_popup']) && sanitize_text_field( $_POST['intent_popup'] ) === '1'){
            setcookie( 'cart_lift_intent_popup', '1' , time()+604800, '/' );
        }
        wp_send_json_success();
    }


    /**
     * Reinitialize the popup based on the cart status.
     *
     * This function checks if the WooCommerce or Easy Digital Downloads cart is empty and returns the status.
     * It sends a JSON response with the cart empty status.
     *
     * @return void
     */
    public function cl_reinitialize_popup() {
        $is_cart_empty = true;

        if( function_exists( 'cl_is_wc_active' ) && cl_is_wc_active() ) {
            $is_cart_empty = WC()->cart->is_empty();
        }
        if ( function_exists( 'cl_is_edd_active' ) && cl_is_edd_active() ) {
            $is_cart_empty = EDD()->cart->is_empty();
        }
        wp_send_json_success(
            array(
                'is_cart_empty' => $is_cart_empty ? 1 : 0
            )
        );
    }

    /**
     * Excludes countries from the abandoned cart process.
     *
     * This function checks if the user's country is in the list of excluded countries.
     * If the country is found in the excluded list, it removes the abandoned cart record
     * for the given email and session ID.
     *
     * @param string $email The email address of the user.
     * @param string $session_id The session ID of the user's cart.
     * @param array $excluded_countries An array of country codes to be excluded.
     * @return bool Returns true if the country is excluded and the cart record is removed, false otherwise.
     */
    public function cl_exclude_countries($email, $session_id, $excluded_countries){
        $country = cl_get_user_country_from_ip( );
        if( !empty( $country ) && in_array( $country , $excluded_countries, true) ){
            cl_pro_remove_abandoned_cart_record( $email, $session_id );
            return true;
        }
        return false;
    }

    /**
     * Render and display the email popup.
     *
     * This function captures the output of the email popup template and echoes it.
     * It is used to display the email popup on the public-facing side of the site.
     *
     * @since 3.1.17
     * @return void
     */
    public function cl_render_and_display_email_popup(){
        $output = $this->render_email_popup();
        echo $output;
    }




    

}