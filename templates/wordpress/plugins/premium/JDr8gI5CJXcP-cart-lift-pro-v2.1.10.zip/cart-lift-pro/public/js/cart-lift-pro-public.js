(function( $ ) {

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	$(document).on('mouseleave', function (e) {
		let is_cart_empty = window?.cl_pop_up?.is_cart_empty;
		let is_wc_empty = true;
		let is_edd_empty = true;
		if(window?.cl_pop_up?.is_wc_active){
			if($(".woocommerce-cart-form").length == 1 || $(".checkout.woocommerce-checkout").length == 1 ){
				is_wc_empty = false;
			}
		}

		if(window?.cl_pop_up?.is_edd_active){
			if( 1 === $( '#edd_checkout_cart_form' ).length ){
				is_edd_empty = false;
			}
		}

		if(is_cart_empty || ( !is_wc_empty && !is_edd_empty ) ){
			return;
		}
		let is_show_entent_popup = window?.cl_pop_up?.is_show_entent_popup;
		let is_ignore_intent_popup = '1' !== window?.cl_pop_up?.is_ignore_intent_popup;
		let is_user_not_logged_in = window?.cl_pop_up?.is_user_not_logged_in;
		if (e.clientY <= 0 && is_show_entent_popup && is_ignore_intent_popup && is_user_not_logged_in ) {
			$("#cart-lift-email-popup").addClass("show");
			$('#cl-email-popup-form').append('<input type="hidden" id="intent_popup" name="intent_popup" value="1">');
		}
	});
})( jQuery );
