<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://rextheme.com/
 * @since             1.0.0
 * @package           Cart_Lift_Pro
 *
 * @wordpress-plugin
 * Plugin Name:       Cart Lift Pro
 * Plugin URI:        http://rextheme.com/cart-lift
 * Description:       Enhance your abandoned cart recovery campaign with more exclusive features and increase conversion.
 * Version:           2.1.10
 * Author:            RexTheme
 * Author URI:        http://rextheme.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       cart-lift-pro
 * Domain Path:       /languages
 *
 * WP Requirement & Test
 * Requires at least: 5.0
 * Tested up to: 6.6
 * Requires PHP: 7.4
 *
 * WC Requirement & Test
 * WC requires at least: 3.8.0
 * WC tested up to: 8.8.2
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define('CART_LIFT_PRO_VERSION', '2.1.10' );

define('CART_LIFT_ITEM_ID', 33844 );
define('CART_LIFT_STORE_URL', sanitize_url( 'https://rextheme.com/' ) );

define('CART_LIFT_PRO_FILE', __FILE__ );
define('CART_LIFT_PRO_BASE', plugin_basename( CART_LIFT_PRO_FILE ) );
define('CART_LIFT_PRO_DIR', plugin_dir_path(CART_LIFT_PRO_FILE));
define('CART_LIFT_PRO_URL', plugin_dir_url(CART_LIFT_PRO_FILE));

define('CART_LIFT_PRO_DEV_MODE', false);

if ( !defined( 'CART_LIFT_DATETIME_FORMAT' ) ) {
    define( 'CART_LIFT_DATETIME_FORMAT', 'Y-m-d H:i:s' );
}
if ( !defined( 'CART_LIFT_CART_TABLE' ) ) {
    define('CART_LIFT_CART_TABLE', 'cl_abandon_cart');
}
if ( !defined( 'CART_LIFT_EMAIL_TEMPLATE_TABLE' ) ) {
    define('CART_LIFT_EMAIL_TEMPLATE_TABLE', 'cl_email_templates');
}
if ( !defined( 'CART_LIFT_CAMPAIGN_HISTORY_TABLE' ) ) {
    define('CART_LIFT_CAMPAIGN_HISTORY_TABLE', 'cl_campaign_history');
}

require plugin_dir_path( __FILE__ ) . 'includes/actions.php';
require plugin_dir_path( __FILE__ ) . 'includes/helper.php';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-cart-lift-pro-activator.php
 */
function activate_cart_lift_pro() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-cart-lift-pro-activator.php';
	Cart_Lift_Pro_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-cart-lift-pro-deactivator.php
 */
function deactivate_cart_lift_pro() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-cart-lift-pro-deactivator.php';
	Cart_Lift_Pro_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_cart_lift_pro' );
register_deactivation_hook( __FILE__, 'deactivate_cart_lift_pro' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-cart-lift-pro.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */

if ( ! function_exists( 'is_plugin_active' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
function run_cart_lift_pro() {
    if ( file_exists( WP_PLUGIN_DIR . '/cart-lift/cart-lift.php' )  && ( is_plugin_active('woocommerce/woocommerce.php') || is_plugin_active('easy-digital-downloads/easy-digital-downloads.php') || is_plugin_active('easy-digital-downloads-pro/easy-digital-downloads.php')) ) {
        $plugin = new Cart_Lift_Pro();
        $plugin->run();
        new Cart_Lift_Pro_Dependency( 'cart-lift/cart-lift.php', __FILE__, '3.1.17', 'cart-lift-pro' );
    }
    else {
        add_action( 'admin_notices', 'cl_check_free_availability' );
        add_action( 'admin_init', 'cartlift_pro_self_deactivation' );
    }
}


function cartlift_pro_self_deactivation() {
    deactivate_plugins( plugin_basename( __FILE__ ) );
}

function cl_check_free_availability() {
    $message = 'Please install and activate Cart Lift free version first.';
    printf( '<div class="error notice is-dismissible"><p class="extension-message">%s</p></div>', $message );
}
run_cart_lift_pro();



if( !class_exists( 'Cart_Lift_Pro_EDD_Updater' ) ) {
    include( dirname( __FILE__ ) . '/includes/class-cart-lift-pro-edd-updater.php' );
}

$license_key = trim( get_option( 'cart_lift_license_key' ) );
if($license_key) {
    $edd_updater = new Cart_Lift_Pro_EDD_Updater( CART_LIFT_STORE_URL, __FILE__, array(
        'version' 	    => CART_LIFT_PRO_VERSION,
        'license' 	    => $license_key,
        'item_id'       => CART_LIFT_ITEM_ID,
        'author' 	    => 'RexTheme',
        'url'           => home_url(),
        'beta'          => false
    ) );
}

/**
 * Declare plugin's compatibility with WooCommerce HPOS
 *
 * @return void
 * @since 2.1.3
 */
function cl_pro_wc_hpos_compatibility() {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__ );
	}
}
add_action( 'before_woocommerce_init', 'cl_pro_wc_hpos_compatibility' );