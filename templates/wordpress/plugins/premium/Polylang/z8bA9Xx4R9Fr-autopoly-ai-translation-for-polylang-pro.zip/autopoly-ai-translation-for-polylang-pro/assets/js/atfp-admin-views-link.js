jQuery(document).ready(function(){
    const atfpSubsubsubList = jQuery('.atfp_subsubsub');
    const atfpBulkTranslateBtn = jQuery('.atfpp-bulk-translate-btn');

    if(atfpSubsubsubList.length){
        const $defaultSubsubsub = jQuery('ul.subsubsub:not(.atfp_subsubsub_list)');

        if($defaultSubsubsub.length){
            $defaultSubsubsub.after(atfpSubsubsubList);
            atfpSubsubsubList.show();
        }
    }

    const appendButton=(btn)=>{
        if(!btn.length || btn.length < 0){
            return;
        }

        const $defaultFilter = jQuery('.actions:not(.bulkactions)');
        const $bulkAction=jQuery('.actions.bulkactions');

        if($defaultFilter.length){
            $defaultFilter.each(function(){
                const clone=btn.clone(true);
                jQuery(this).append(clone);
                clone.show();
            });

            btn.remove();
        }else if($bulkAction.length){
            $bulkAction.each(function(){
                const clone=btn.clone(true);
                jQuery(this).after(clone);
                clone.show();
            });
        }
    }

    appendButton(atfpBulkTranslateBtn);
});
