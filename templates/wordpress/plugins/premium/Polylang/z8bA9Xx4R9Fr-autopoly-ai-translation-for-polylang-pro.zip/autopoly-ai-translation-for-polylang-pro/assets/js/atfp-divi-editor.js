jQuery(window).on('et_fb_init_app_after', async function() {

    let translateCompleted=false;
    let modalOpen=false;

    if(!window.atfpDiviTranslateData || !window.atfpDiviTranslateData.postId){
        return;
    }

    const atfpDiviGlobalObject=window.atfpDiviTranslateData;

    const __=(text, domain)=>{
        if(window.wp && window.wp.i18n){
            return window.wp.i18n.__(text, domain);
        }
        return text;
    }

    const sprintf=(...args)=>{
        if(window.wp && window.wp.i18n){
            const text = args[0];
            const placeholders = args.slice(1);
            return window.wp.i18n.sprintf(text, placeholders);
        }
        return args[0];
    }

    /**
     * Creates a message popup based on the post type and target language.
     * @returns {HTMLElement} The created message popup element.
     */
    const createMessagePopup = () => {
        const postType = atfpDiviGlobalObject.postType;
        const targetLangName = atfpDiviGlobalObject.targetLangObject['name'];
        const magincWandUrl=atfpDiviGlobalObject.atfpUrl + 'assets/images/magic-wand.svg';
    
        const messagePopup = document.createElement('div');
        messagePopup.id = 'atfp-modal-open-warning-wrapper';
        messagePopup.innerHTML = `
            <div class="modal-container" style="display: flex">
        <div class="modal-content">
            <div class="modal-header">
                <div class="atfp-modal-header-left">
                    <img src="${magincWandUrl}" style="width: 20px; height: 20px; margin-right: 5px; filter: brightness(0) invert(0);" alt="${__("AI", "autopoly-ai-translation-for-polylang")}">
                    <h3>${__("AI Translation", "autopoly-ai-translation-for-polylang")}</h3>
                </div>
                <span class="atfp-modal-close dashicons dashicons-no-alt" data-value="no"></span>
            </div>
            <div class="atfp-modal-body">
            <div class="atfp-main-section">
                <p>${sprintf(__("Would you like to duplicate your original %s content and have it automatically translated into %s?", 'autopoly-ai-translation-for-polylang-pro'), postType, targetLangName)}</p>
                <button type="button" class="atfp-translate-button button" data-value="yes" id="atfp-translate-button" data-value="yes">
                    <img src="${magincWandUrl}" style="width: 20px; height: 20px; margin-right: 5px; filter: brightness(0) invert(1);" alt="AI">
                    Translate Now
                </button>
            </div>
            </div>
            <div class="modal-footer-notice">
            <span class="dashicons dashicons-warning"></span>
            <p><em>${__("Note: close this popup if you do not want AI translation.", "autopoly-ai-translation-for-polylang")}</em></p>
            </div>
        </div>
        </div>`;
        return messagePopup;
    };

    /**
     * Inserts the message popup into the DOM.
     */
    const insertMessagePopup = () => {
        const messagePopup = createMessagePopup();
        document.body.appendChild(messagePopup);

        const firstRenderBtns = document.querySelectorAll('#atfp-modal-open-warning-wrapper .atfp-translate-button,#atfp-modal-open-warning-wrapper .atfp-modal-close');
        
        firstRenderBtns.forEach(ele => {
            if (ele) {
                ele.addEventListener('click', openModalOnLoadHandler);
            }
        })
    };

    const openModalOnLoadHandler = (e) => {
        e.preventDefault();
        const btnElement = e.target;
        const visibility = btnElement.dataset.value;

        if(atfpDiviGlobalObject.popupHiddenNonce && atfpDiviGlobalObject.popupHiddenNonce !== ''){
            updateInitialTranslationPopupHidden();
        }

        if (visibility === 'yes') {
            sendPostMessageToChild();
        }

        btnElement.closest('#atfp-modal-open-warning-wrapper').remove();
    }

    const updateInitialTranslationPopupHidden = () => {
        fetch(atfpDiviGlobalObject.ajaxUrl, {
            method: 'POST',
            headers: {
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept': 'application/json',
            },
            body: new URLSearchParams({
                action: 'atfp_hide_initial_translation_popup',
                post_id: atfpDiviGlobalObject.postId,
                hide_popup_nonce: atfpDiviGlobalObject.popupHiddenNonce
            })
        }).then(response => response.json()).then(data => {
            if(!data.success){
                console.warn(data.data);
            }
        }).catch(error => {
            console.error(error.message);
        });
    }

    const sendPostMessageToChild = () => {

        if(translateCompleted) return;
        if(modalOpen) return;

        modalOpen=true;

        const iframe = document.querySelector('iframe#et-vb-app-frame');

        if (!iframe || !iframe.contentWindow) {
            console.warn('Divi iframe not found');
            return;
        }

        const overLayWrp=document.createElement('div');
        document.body.classList.add('atfp-divi-modal-open');
        overLayWrp.id = 'atfp-divi-overlay';
        document.querySelector('#et-vb-app-frame-wrapper').prepend(overLayWrp);
    
        iframe.contentWindow.postMessage(
            { action: 'ATFP_DIVI_OPEN_SETTING_MODAL', postId: atfpDiviGlobalObject.postId },
            window.location.origin
        );
    };

    await new Promise(resolve => setTimeout(resolve, 300));

    const sideBarWrp=document.querySelector('.et-vb-page-bar-right-side-save-button');

    if(sideBarWrp){
        const reTranslateStatus=atfpDiviGlobalObject.re_translate_page && atfpDiviGlobalObject.re_translate_page === "1";
        const transaltebtn=document.createElement('button');
        transaltebtn.classList.add('button', 'atfp-divi-translate-btn');
        const translateText=reTranslateStatus ? __('Re-Translate', 'autopoly-ai-translation-for-polylang-pro') : __('Translate', 'autopoly-ai-translation-for-polylang-pro');
        transaltebtn.textContent = translateText;
        transaltebtn.addEventListener('click', sendPostMessageToChild);
        
        if(!reTranslateStatus && (!atfpDiviGlobalObject.hideInitialTranslationPopup || '1' !== atfpDiviGlobalObject.hideInitialTranslationPopup) ){
            insertMessagePopup();
        }
        
        sideBarWrp.prepend(transaltebtn);
    }
    
    window.addEventListener('message', (event) => {
        if (event.data.action === 'ATFP_DIVI_TRANSLATION_COMPLETE') {
            translateCompleted=true;
            modalClose();

            const transaltebtn=document.querySelector('.atfp-divi-translate-btn');
            if(transaltebtn){
                transaltebtn.disabled = true;
                transaltebtn.title = __("Translation Completed", 'autopoly-ai-translation-for-polylang-pro');
                transaltebtn.textContent = __("Already Translated", 'autopoly-ai-translation-for-polylang-pro');
            }
        }

        if(event.data.action === 'ATFP_UPDATE_MODAL_VISIBILITY'){
            modalClose();
        }
        
        if(event.data.action === 'ATFP_DIVI_ADD_MODULE_MODAL_HIDE'){
            toggleAddModuleModalVisibility(true);

            setTimeout(() => {
                toggleAddModuleModalVisibility(false);
            }, 5000);
        }

        if(event.data.action === 'ATFP_DIVI_ADD_MODULE_MODAL_SHOW'){
            toggleAddModuleModalVisibility(false);
        }
    });

    const modalClose=()=>{
        modalOpen=false;
        document.body.classList.remove('atfp-divi-modal-open');
        
        const overLayWrp=document.querySelector('#atfp-divi-overlay');
        if(overLayWrp){
            overLayWrp.remove();
        }
    }

    const toggleAddModuleModalVisibility = (visibility) => {
        document.body.classList.toggle('atfp-divi-add-module-modal-hidden', visibility);
    }
});

