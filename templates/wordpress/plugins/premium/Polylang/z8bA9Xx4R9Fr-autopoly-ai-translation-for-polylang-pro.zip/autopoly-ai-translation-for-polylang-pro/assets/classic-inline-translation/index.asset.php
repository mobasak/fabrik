<?php return array('dependencies' => array('react', 'react-dom', 'wp-i18n'), 'version' => '3aba280d86d09cf46a55');
