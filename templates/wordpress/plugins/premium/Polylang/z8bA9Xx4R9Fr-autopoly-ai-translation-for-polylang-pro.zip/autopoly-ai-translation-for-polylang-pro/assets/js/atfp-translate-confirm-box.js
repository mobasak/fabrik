const { __, sprintf } = wp.i18n;

const atfpElementorConfirmBox = {
    init: function () {
        this.pageTitleEvent = false;
        if (window.atfpTranslateConfirmBoxData && window.atfpTranslateConfirmBoxData.translationEditorType === 'Elementor') {
            this.createElementorConfirmBox();
        } else if (window.atfpTranslateConfirmBoxData && window.atfpTranslateConfirmBoxData.translationEditorType === 'Divi') {
            this.createDiviConfirmBox();
        }
    },

    createElementorConfirmBox: function () {
        const confirmBox = jQuery(`<div class="atfp-translate-confirm-box modal-container" style="display:flex">
            <div class="modal-content">
            <div class="modal-header">
                    <div class="atfp-modal-header-left">
                        <img src="${window.atfpTranslateConfirmBoxData.maginc_wand_url}" style="width: 20px; height: 20px; margin-right: 5px; filter: brightness(0) invert(0);" alt="${__("AI")}">
                        <h3>${__("AI Translation", "autopoly-ai-translation-for-polylang-pro")}</h3>
                    </div>
                    <span class="atfp-modal-close dashicons dashicons-no-alt"></span>
            </div>
            <div class="atfp-modal-body">
                <div class="atfp-main-section">
                    <p>${__("Use AI to translate this page inside Elementor while keeping the same layout and design.", "autopoly-ai-translation-for-polylang-pro")}</p>
                    <button type="button" class="atfp-translate-button button" data-value="yes" id="atfp-translate-button">
                        <img src="${window.atfpTranslateConfirmBoxData.maginc_wand_url}" style="width: 20px; height: 20px; margin-right: 5px; filter: brightness(0) invert(1);" alt="${__("AI")}">
                        ${__("Translate Now", "autopoly-ai-translation-for-polylang-pro")}
                    </button>
                </div>
            </div>
            <div class="modal-footer-notice">
            <span class="dashicons dashicons-warning"></span>
            <p><em>${__("Note: close this popup if you do not want AI translation.", "autopoly-ai-translation-for-polylang-pro")}</em></p>
            </div>
            </div>
        </div>
        `);

        confirmBox.appendTo(jQuery('body'));

        confirmBox.find('button.atfp-translate-button').on('click', (e)=>{this.elementorConfirmTranslation(e)});
        confirmBox.find('span.atfp-modal-close').on('click', (e)=>{e.preventDefault();this.closeConfirmBox();});
    },

    createDiviConfirmBox: function () {
        const confirmBox = jQuery(`<div class="atfp-translate-confirm-box modal-container" style="display:flex">
            <div class="modal-content">
            <div class="modal-header">
                    <div class="atfp-modal-header-left">
                        <img src="${window.atfpTranslateConfirmBoxData.maginc_wand_url}" style="width: 20px; height: 20px; margin-right: 5px; filter: brightness(0) invert(0);" alt="${__("AI")}">
                        <h3>${__("AI Translation", "autopoly-ai-translation-for-polylang-pro")}</h3>
                    </div>
                    <span class="atfp-modal-close dashicons dashicons-no-alt"></span>
            </div>
            <div class="atfp-modal-body">
                <div class="atfp-main-section">
                    <p>${__("Use AI to translate this page inside Divi while keeping the same layout and design.", "autopoly-ai-translation-for-polylang-pro")}</p>
                    <button type="button" class="atfp-translate-button button" data-value="yes" id="atfp-translate-button">
                        <img src="${window.atfpTranslateConfirmBoxData.maginc_wand_url}" style="width: 20px; height: 20px; margin-right: 5px; filter: brightness(0) invert(1);" alt="${__("AI")}">
                        ${__("Translate Now", "autopoly-ai-translation-for-polylang-pro")}
                    </button>
                </div>
            </div>
            <div class="modal-footer-notice">
            <span class="dashicons dashicons-warning"></span>
            <p><em>${__("Note: close this popup if you do not want AI translation.", "autopoly-ai-translation-for-polylang-pro")}</em></p>
            </div>
            </div>
        </div>
        `);
        confirmBox.appendTo(jQuery('body'));

        confirmBox.find('button.atfp-translate-button').on('click', (e)=>{this.diviConfirmTranslation(e)});
        confirmBox.find('span.atfp-modal-close').on('click', (e)=>{e.preventDefault();this.closeConfirmBox();});
    },

    closeConfirmBox: function () {
        const confirmBox = jQuery('.atfp-translate-confirm-box.modal-container');
        confirmBox.remove();
    },

    diviConfirmTranslation: async function (e) {
        e.preventDefault();

        if (e.currentTarget && (e.currentTarget.disabled || e.currentTarget.classList.contains('loading'))) {
            return;
        }

        const defaultEditor = window.atfpTranslateConfirmBoxData.editorType;

        let diviButton = null;

        if (defaultEditor === 'gutenberg') {
            diviButton = document.getElementById('et-switch-to-divi');

            if (!diviButton) {
                const diviButtonTwo = document.querySelector('button.editor-post-switch-to-divi');

                if (diviButtonTwo) {
                    diviButtonTwo.click();

                    let startRedirection = false;

                    setInterval(() => {

                        if (startRedirection) {
                            return;
                        }

                        diviButton = document.getElementById('et-switch-to-divi');

                        if (diviButton) {
                            this.loadingText(e.currentTarget);
                            diviButton.click();
                            return;
                        }
                    }, 500);

                    window.addEventListener('beforeunload', function () {
                        startRedirection = true;
                    });

                    return;
                }
            }
        } else if (defaultEditor === 'classic') {
            diviButton = document.getElementById('et_pb_use_the_builder');
        }

        if (diviButton) {
            this.loadingText(e.currentTarget);
            diviButton.click();
        }
    },

    loadingText: function (ele) {
        if (!ele) {
            return;
        }

        ele.disabled = true;

        ele.classList.add('loading');

        const loadinText = __("Loading", 'autopoly-ai-translation-for-polylang-pro');
        ele.innerHTML = `${loadinText}<span class="dot" style="--i: 0"></span><span class="dot" style="--i: 1"></span><span class ="dot" style="--i: 2"></span>`;
    },

    elementorConfirmTranslation: function (e) {
        this.setPageTitle();
        e.preventDefault();
        const postId = window.atfpTranslateConfirmBoxData.postId;
        const targetLangSlug = window.atfpTranslateConfirmBoxData.targetLangSlug;

        if (postId && targetLangSlug) {
            let oldData = localStorage.getItem('atfpElementorConfirmBox');
            let data = { [postId + '_' + targetLangSlug]: true };

            if (oldData && 'string' === typeof oldData && '' !== oldData) {
                oldData = JSON.parse(oldData);
                data = { ...oldData, ...data };
            }

            localStorage.setItem('atfpElementorConfirmBox', JSON.stringify(data));

            const translateButton=document.querySelector('button.atfp-translate-button');

            if(translateButton){
                this.loadingText(translateButton);
            }

            const elementorButton = document.getElementById('elementor-editor-button');
            const elementorEditModeButton = document.getElementById('elementor-edit-mode-button');

            if (elementorEditModeButton) {
                elementorEditModeButton.click();
            } else if (elementorButton) {
                elementorButton.click();
            }
        }
    },

    setPageTitle: function () {

        if (window.atfpTranslateConfirmBoxData.editorType !== 'classic') {
            return;
        }

        if (this.pageTitleEvent) {
            return;
        }

        this.pageTitleEvent = true;

        const elementorButtons = document.querySelectorAll('#elementor-editor-button, #elementor-edit-mode-button');

        elementorButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();

                if (window.wp && window.elementorAdmin && window.elementorAdmin.getDefaultElements) {
                    const defaultElements = window.elementorAdmin.getDefaultElements();

                    if (defaultElements) {
                        $goToEditLink = defaultElements.$goToEditLink;

                        if ($goToEditLink) {
                            var $wpTitle = jQuery('#title');

                            if (!$wpTitle.val()) {
                                $wpTitle.val('Elementor #' + jQuery('#post_ID').val());
                            }

                            if (wp.autosave) {
                                wp.autosave.server.triggerSave();
                            }

                            jQuery(document).on('heartbeat-tick.autosave', function () {
                                window.elementorCommon.elements.$window.off('beforeunload.edit-post');
                                location.href = $goToEditLink.attr('href');
                            });
                        }
                    }
                }
            });
        });
    }

};

jQuery(document).ready(function ($) {
    atfpElementorConfirmBox.init();
});