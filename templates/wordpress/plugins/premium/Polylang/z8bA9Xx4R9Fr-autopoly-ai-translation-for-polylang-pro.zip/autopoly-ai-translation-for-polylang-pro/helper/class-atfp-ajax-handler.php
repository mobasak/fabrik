<?php
/**
 * ATFPP Ajax Handler
 *
 * @package ATFPP
 */

/**
 * Do not access the page directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ATFPP\AI_Translate\Services\API\Enums\AI_Capability;
use ATFPP\AI_Translate\Services\API\Helpers;

/**
 * Handle ATFPP ajax requests
 */
if ( ! class_exists( 'ATFPP_Ajax_Handler' ) ) {
	class ATFPP_Ajax_Handler {
		/**
		 * Member Variable
		 *
		 * @var instance
		 */
		private static $instance;
		/**
		 * Stores custom block data for processing and retrieval.
		 *
		 * This static array holds the data related to custom blocks that are
		 * used within the plugin. It can be utilized to manage and manipulate
		 * the custom block information as needed during AJAX requests.
		 *
		 * @var array
		 */
		private $custom_block_data_array = array();

		/**
		 * Gets an instance of our plugin.
		 *
		 * @param object $settings_obj timeline settings.
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 *
		 * @param object $settings_obj Plugin settings.
		 */
		public function __construct() {
			if ( is_admin() ) {
				add_action( 'wp_ajax_atfp_fetch_post_content', array( $this, 'fetch_post_content' ) );
				add_action('wp_ajax_atfp_fetch_post_meta_fields', array($this, 'fetch_post_meta_fields'));
				add_action('wp_ajax_atfp_update_post_meta_fields', array($this, 'update_post_meta_fields'));
				add_action( 'wp_ajax_atfp_block_parsing_rules', array( $this, 'block_parsing_rules' ) );
				add_action( 'wp_ajax_atfp_get_custom_blocks_content', array( $this, 'get_custom_blocks_content' ) );
				add_action( 'wp_ajax_atfp_update_custom_blocks_content', array( $this, 'update_custom_blocks_content' ) );
				add_action('wp_ajax_atfp_update_translate_data', array($this, 'atfp_update_translate_data'));
				add_action( 'wp_ajax_atfp_update_elementor_data', array( $this, 'update_elementor_data' ) );
				add_action('wp_ajax_atfp_update_divi_data', array($this, 'update_divi_data'));
				add_action('wp_ajax_atfp_update_post_custom_fields', array($this, 'update_post_custom_fields_content'));
				add_action('wp_ajax_atfp_update_term_custom_fields', array($this, 'update_term_custom_fields_content'));
				add_action('wp_ajax_atfp_hide_initial_translation_popup', array($this, 'hide_initial_translation_popup'));
				add_action('wp_ajax_atfpp_update_enabled_providers', array($this, 'update_enabled_providers'));
			}
		}

		public function hide_initial_translation_popup() {
			$post_id = isset( $_POST['post_id']) ? absint(sanitize_text_field(wp_unslash($_POST['post_id']))) : false;

			if ( ! check_ajax_referer( 'atfp_hide_initial_translation_popup_'.absint($post_id), 'hide_popup_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}			

			if(!isset($post_id) || false === $post_id){
				wp_send_json_error( __( 'Invalid Post ID.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			if(!current_user_can('edit_post', $post_id)){
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}
			
			update_post_meta( $post_id, '_atfpp_initial_translation_popup_hidden', 'true');
			wp_send_json_success();
			exit;
		}

		/**
		 * Update enabled/disabled providers
		 *
		 * Handles the update enabled/disabled providers AJAX request.
		 */
		public function update_enabled_providers() {
            if ( ! check_ajax_referer( 'atfpp_update_enabled_providers', 'update_providers_key', false ) ) {
                wp_send_json_error( __( 'Invalid security token sent.', 'automatic-translations-for-polylang' ) );
                wp_die( '0', 400 );
                exit();
            }

			$enabled_providers = isset($_POST['enabled_providers']) ? sanitize_text_field(wp_unslash($_POST['enabled_providers'])) : '';
			if(json_last_error() !== JSON_ERROR_NONE){
				wp_send_json_error( __( 'Invalid JSON.', 'automatic-translations-for-polylang' ) );
				wp_die( '0', 400 );
				exit();
			}
			$enabled_providers = json_decode($enabled_providers, true);
			if(!is_array($enabled_providers)){
				wp_send_json_error( __( 'Invalid enabled providers.', 'automatic-translations-for-polylang' ) );
				wp_die( '0', 400 );
				exit();
			}
			
			$valid_providers = array('chrome-built-in-ai', 'yandex-translate', 'google-translate', 'openai', 'deepl', 'gemini');

			$updated_providers = array();

			foreach($enabled_providers as $provider_key => $status){
				if(in_array($provider_key, $valid_providers) && $status === true){
					$updated_providers[] = sanitize_text_field($provider_key);
				}
			}

			update_option('atfp_enabled_providers', $updated_providers);
			wp_send_json_success( array( 'providers' => $updated_providers, 'message' => __( 'Enabled providers updated successfully.', 'automatic-translations-for-polylang' ) ) );
			exit;
        }

		/**
		 * Block Parsing Rules
		 *
		 * Handles the block parsing rules AJAX request.
		 */
		public function block_parsing_rules() {
			if ( ! check_ajax_referer( 'atfp_translate_nonce', 'atfp_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			if(!current_user_can('edit_posts')){
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}

			$block_parse_rules = ATFPP_Helper::get_instance()->get_block_parse_rules();

			$data = array(
				'blockRules' => json_encode( $block_parse_rules ),
			);

			return wp_send_json_success( $data );
			exit;
		}

		/**
		 * Fetches post meta fields via AJAX request.
		 */
		public function fetch_post_meta_fields() {
			if ( ! check_ajax_referer( 'atfp_fetch_post_meta_fields', 'atfp_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			$post_id = isset( $_POST['postId']) ? absint(sanitize_text_field(wp_unslash($_POST['postId']))) : false;

			if(!isset($post_id) || false === $post_id){
				wp_send_json_error( __( 'Invalid Post ID.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			if(!current_user_can('edit_post', $post_id)){
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}

			$post_meta_sync = true;

            if (!isset(PLL()->options['sync']) || (isset(PLL()->options['sync']) && !in_array('post_meta', PLL()->options['sync']))) {
                $post_meta_sync = false;
            }

			if($post_meta_sync){
				wp_send_json_success( __( 'Post meta sync is enabled. Please disable post meta sync in Polylang settings.', 'autopoly-ai-translation-for-polylang-pro' ) );
			}


			$filtered_meta_fields=array();
			$allowed_meta_fields=ATFPP_Helper::get_allowed_custom_fields();

			if(isset($_POST['re_translate_page']) && 'true' === $_POST['re_translate_page']){
				$current_post_id=isset($_POST['current_post_id']) ? absint(sanitize_text_field(wp_unslash($_POST['current_post_id']))) : false;

				if(!isset($current_post_id) || false === $current_post_id){
					wp_send_json_error( __( 'Invalid Current Post ID.', 'autopoly-ai-translation-for-polylang-pro' ) );
					wp_die( '0', 400 );
				}
					
				$filtered_meta_fields=ATFP_Re_Translation::get_updated_post_metas((int) $current_post_id, (int) $post_id);
			}else{
				$post_meta_fields=get_post_meta($post_id);
	
				$existed_meta_fields=array_intersect(array_keys($post_meta_fields), array_keys($allowed_meta_fields));
	
				foreach($existed_meta_fields as $key){
					if(isset($post_meta_fields[$key]) && !empty($post_meta_fields[$key]) && isset($allowed_meta_fields[$key]['status']) && true === $allowed_meta_fields[$key]['status']){
						$value=$allowed_meta_fields[$key]['type'] && is_array($post_meta_fields[$key]) ? maybe_unserialize($post_meta_fields[$key][0]) : maybe_unserialize($post_meta_fields[$key]);
						$filtered_meta_fields[$key]=$value;
					}
				}
			}

			$data=array(
				'metaFields' => $filtered_meta_fields,
			);

			if($filtered_meta_fields && is_array($filtered_meta_fields) && count($filtered_meta_fields) > 0){
				$data['allowedMetaFields'] = $allowed_meta_fields;
			}else{
				unset($data['metaFields']);
				$data['message'] = __( 'No Meta Fields to update.', 'autopoly-ai-translation-for-polylang-pro' );
			}

			return wp_send_json_success( $data );

			exit;
		}

		public function update_post_meta_fields() {
			if ( ! check_ajax_referer( 'atfp_update_post_meta_fields', 'post_meta_fields_key', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}
			
			$post_id = isset( $_POST['post_id']) ? absint(sanitize_text_field(wp_unslash($_POST['post_id']))) : false;

			if(!isset($post_id) || false === $post_id){
				wp_send_json_error( __( 'Invalid Post ID.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			if(!current_user_can('edit_post', $post_id)){
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}

			// no need to sanitize here because we are using sanitize according to data type where have using this data.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$meta_fields = isset( $_POST['meta_fields']) ? json_decode(wp_unslash($_POST['meta_fields']), true) : false;
			
			if(!$meta_fields || !is_array($meta_fields) || count($meta_fields) < 1){
				wp_send_json_success( __( 'No Meta Fields to update.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 200 );
			}

			$this->update_post_custom_fields($meta_fields, $post_id);

			wp_send_json_success( __( 'Meta Fields updated successfully.', 'autopoly-ai-translation-for-polylang-pro' ) );
			exit;
		}

		/**\
		 * Fetches post content via AJAX request.
		 */
		public function fetch_post_content() {
			if ( ! check_ajax_referer( 'atfp_translate_nonce', 'atfp_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			$post_id = absint(isset( $_POST['postId'] ) ? absint(sanitize_text_field(wp_unslash($_POST['postId']))) : false);
			
			if(!current_user_can('edit_post', $post_id)){
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}

			if ( false !== $post_id ) {
				$post_data = get_post( absint($post_id) );
                $locale = isset($_POST['local']) ? sanitize_text_field(wp_unslash($_POST['local'])) : 'en';
                $current_locale = isset($_POST['current_local']) ? sanitize_text_field(wp_unslash($_POST['current_local'])) : 'en';
				$slug_translation_option = get_option('atfp_slug_translation_option','title_translate');
				$re_translate_page=isset($_POST['re_translate_page']) && 'true' === $_POST['re_translate_page'] ? true : false;

				$content = $post_data->post_content;
				$content = ATFPP_Helper::replace_links_with_translations($content, $locale, $current_locale);

				$data    = array(
					'title' => $post_data->post_title,
					'excerpt' => $post_data->post_excerpt,
					'content' => $content,
				);

				if(!$re_translate_page){
					if($slug_translation_option === 'slug_translate' || $slug_translation_option === 'slug_keep'){
						$data['slug_name']=urldecode(get_post_field('post_name', $post_id));
					}
				}


				return wp_send_json_success( $data );
			} else {
				wp_send_json_error( __( 'Invalid Post ID.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			exit;
		}

		public function get_custom_blocks_content() {
			if ( ! check_ajax_referer( 'atfp_block_update_nonce', 'atfp_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			if(!current_user_can('edit_posts')){
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}

			$custom_content = get_option( 'atfp_custom_block_data', false ) ? get_option( 'atfp_custom_block_data', false ) : false;

			if ( $custom_content && is_string( $custom_content ) && ! empty( trim( $custom_content ) ) ) {
				return wp_send_json_success( array( 'block_data' => $custom_content ) );
			} else {
				return wp_send_json_success( array( 'message' => __( 'No custom blocks found.', 'autopoly-ai-translation-for-polylang-pro' ) ) );
			}
			exit();
		}

		public function update_custom_blocks_content() {
			if ( ! check_ajax_referer( 'atfp_block_update_nonce', 'atfp_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			if(!current_user_can('edit_posts')){
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}

			// no need to sanitize here because we are using sanitize according to data type where have using this data.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$json = isset($_POST['save_block_data']) ? wp_unslash($_POST['save_block_data']) : false;
			$updated_blocks_data = json_decode($json, true);
			if(json_last_error() !== JSON_ERROR_NONE){ 
				wp_send_json_error( __( 'Invalid JSON', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			if ( $updated_blocks_data ) {
				$block_parse_rules = ATFPP_Helper::get_instance()->get_block_parse_rules();

				if ( isset( $block_parse_rules['AtfpBlockParseRules'] ) ) {
					$previous_translate_data = get_option( 'atfp_custom_block_translation', false );
					if ( $previous_translate_data && ! empty( $previous_translate_data ) ) {
						$this->custom_block_data_array = $previous_translate_data;
					}

					foreach ( $updated_blocks_data as $key => $block_data ) {
						$this->verify_block_data( array( $key ), $block_data, $block_parse_rules['AtfpBlockParseRules'][ $key ] );
					}

					if ( count( $this->custom_block_data_array ) > 0 ) {
						update_option( 'atfp_custom_block_translation', $this->custom_block_data_array );
					}

					delete_option( 'atfp_custom_block_data' );

				}
			}

			return wp_send_json_success( array( 'message' => __( 'Automatic Translation for Polylang: Custom Blocks data updated successfully', 'autopoly-ai-translation-for-polylang-pro' ) ) );
		}

		private function verify_block_data( $id_keys, $value, $block_rules ) {
			$block_rules = is_object( $block_rules ) ? json_decode( json_encode( $block_rules ) ) : $block_rules;

			if ( ! isset( $block_rules ) ) {
				return $this->create_nested_attribute( $value,$id_keys );
			}
			if ( is_object( $value ) && isset( $block_rules ) ) {
				foreach ( $value as $key => $item ) {
					if ( isset( $block_rules[ $key ] ) && is_object( $item ) ) {
						$this->verify_block_data( array_merge( $id_keys, array( $key ) ), $item, $block_rules[ $key ], false );
						continue;
					} elseif ( ! isset( $block_rules[ $key ] ) && true === $item ) {
						$this->create_nested_attribute(  true,array_merge( $id_keys, array( $key ) ) );
						continue;
					} elseif ( ! isset( $block_rules[ $key ] ) && is_object( $item ) ) {
						$this->create_nested_attribute(  $item,array_merge( $id_keys, array( $key ) ) );
						continue;
					}
				}
			}
		}

		private function create_nested_attribute( $value,$id_keys = array() ) {
			$value = is_object( $value ) ? json_decode( json_encode( $value ), true ) : $value;

			$current_array = &$this->custom_block_data_array;

			foreach ( $id_keys as $index => $id ) {
				$index_id=gettype($id) === 'integer' ? intval($id) : sanitize_text_field($id);

				if ( ! isset( $current_array[ $id ] ) ) {
					$current_array[ $index_id ] = array();
				}

				$current_array = &$current_array[ $index_id ];
			}

			$current_array = $this->sanitize_block_data($value);
		}

		private function sanitize_block_data($data){
			 // Handle arrays.
			 if ( is_array( $data ) ) {
				foreach ( $data as $key => $value ) {
					$data[ sanitize_text_field($key) ] = $this->sanitize_block_data( $value );
				}
				return $data;
			}
		
			// Handle objects.
			if ( is_object( $data ) ) {
				foreach ( $data as $key => $value ) {
					$key = sanitize_text_field($key);
					$data->$key = $this->sanitize_block_data( $value );
				}
				return $data;
			}
		
			// Handle scalar values.
			if ( is_string( $data ) ) {
				return sanitize_text_field( wp_unslash( $data ) );
			}
		
			if ( is_int( $data ) ) {
				return absint( $data );
			}
		
			if ( is_float( $data ) ) {
				return floatval( $data );
			}
		
			if ( is_bool( $data ) ) {
				return (bool) $data;
			}
		
			// Null or unknown type.
			return $data;
		}

		public function atfp_update_translate_data() {
			if ( ! check_ajax_referer( 'atfp_translate_nonce', 'atfp_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			$post_id = isset($_POST['post_id']) ? absint(sanitize_text_field(wp_unslash($_POST['post_id']))) : 0;
			$editor_type = isset($_POST['editorType']) ? sanitize_text_field(wp_unslash($_POST['editorType'])) : '';
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Data is sanitized where we are using it.
			$extra_data=isset($_POST['extraData']) ? json_decode(wp_unslash($_POST['extraData']), true) : [];
			$bulk_translate=isset($_POST['bulk_translate']) && 'true' === $_POST['bulk_translate'] ? true : false;

			if($editor_type !== 'elementor' && !$bulk_translate){
				update_post_meta($post_id, '_atfpp_translation_publish_status', 'true');
			};

			// Require capability based on context
			if ( $post_id > 0 ) {
				if ( ! current_user_can('edit_post', $post_id) && $editor_type !== 'taxonomy' ) {
					wp_send_json_error( __( 'Unauthorized to edit post', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
					wp_die( '0', 403 );
				}
				
				if($editor_type === 'taxonomy'){
					if ( ! current_user_can('edit_posts') ) {
						wp_send_json_error( __( 'Unauthorized to edit terms', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
						wp_die( '0', 403 );
					}
				}
			} else {
				if ( ! current_user_can('edit_posts') ) {
					wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
					wp_die( '0', 403 );
				}
			}

			$provider = isset($_POST['provider']) ? sanitize_text_field(wp_unslash($_POST['provider'])) : '';
			$total_string_count = isset($_POST['totalStringCount']) ? absint($_POST['totalStringCount']) : 0;
			$total_word_count = isset($_POST['totalWordCount']) ? absint($_POST['totalWordCount']) : 0;
			$total_char_count = isset($_POST['totalCharacterCount']) ? absint($_POST['totalCharacterCount']) : 0;
			$date = isset($_POST['date']) ? gmdate('Y-m-d H:i:s', strtotime(sanitize_text_field(wp_unslash($_POST['date'])))) : '';
			$source_string_count = isset($_POST['sourceStringCount']) ? absint($_POST['sourceStringCount']) : 0;
			$source_word_count = isset($_POST['sourceWordCount']) ? absint($_POST['sourceWordCount']) : 0;
			$source_char_count = isset($_POST['sourceCharacterCount']) ? absint($_POST['sourceCharacterCount']) : 0;
			$source_lang = isset($_POST['sourceLang']) ? sanitize_text_field(wp_unslash($_POST['sourceLang'])) : '';
			$target_lang = isset($_POST['targetLang']) ? sanitize_text_field(wp_unslash($_POST['targetLang'])) : '';
			$time_taken = isset($_POST['timeTaken']) ? absint(wp_unslash($_POST['timeTaken'])) : 0;

			if (class_exists('Atfpp_Dashboard')) {
				$translation_data = array(
					'post_id' => $post_id,
					'service_provider' => $provider,
					'source_language' => $source_lang,
					'target_language' => $target_lang,
					'time_taken' => $time_taken,
					'string_count' => $total_string_count,
					'word_count' => $total_word_count,
					'character_count' => $total_char_count,
					'source_string_count' => $source_string_count,
					'source_word_count' => $source_word_count,
					'source_character_count' => $source_char_count,
					'editor_type' => $editor_type,
					'date_time' => $date,
					'version_type' => 'pro'
				);

				if(!empty($extra_data) && is_array($extra_data) && count($extra_data) > 0){
					foreach($extra_data as $key => $value){
						if(!isset($translation_data[$key]) && !empty($value) && !empty($key)){
							$translation_data[sanitize_text_field($key)] = sanitize_text_field($value);
						}
					}
				}

				Atfpp_Dashboard::store_options(
					'atfp',
					'post_id', 
					'update',
					$translation_data
				);

				wp_send_json_success(array(
					'message' => __('Translation data updated successfully', 'autopoly-ai-translation-for-polylang-pro')
				));
			} else {
				wp_send_json_error(array(
					'message' => __('Atfpp_Dashboard class not found', 'autopoly-ai-translation-for-polylang-pro') 
				));
			}
			exit;
		}

		public function update_divi_data() {
			if ( ! check_ajax_referer( 'atfp_divi_data_nonce', 'atfp_divi_data_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			$post_id = isset($_POST['post_id']) ? absint(sanitize_text_field(wp_unslash($_POST['post_id']))) : 0;
			if ( ! $post_id || ! current_user_can('edit_post', $post_id) ) {
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}
			
			$status = isset($_POST['status']) ? sanitize_text_field(wp_unslash($_POST['status'])) : '';

			if ( $status !== 'completed' ) {
				wp_send_json_error( __( 'Invalid status', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				wp_die( '0', 400 );
			}

			$parent_post_id=isset($_POST['parent_post_id']) ? absint(wp_unslash($_POST['parent_post_id'])) : 0;

			if(!$parent_post_id){
				return wp_send_json_error( __( 'Parent post ID is required.', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				wp_die( '0', 400 );
			}

			$slug_translation_option = get_option('atfp_slug_translation_option','title_translate');
			$current_slug=get_post_field('post_name', $post_id);
			$new_post_name=false;

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Data is sanitized where we are using it.
			$new_meta_fields=isset($_POST['meta_fields']) ? json_decode(wp_unslash($_POST['meta_fields']), true) : false;

			if('' === $current_slug){
				if(isset($_POST['post_name']) && '' !== $_POST['post_name'] && $slug_translation_option === 'slug_translate'){
					$new_post_name=sanitize_title(wp_unslash($_POST['post_name']));
				}else if($slug_translation_option === 'slug_keep'){
					$new_post_name=sanitize_text_field(get_post_field('post_name', $parent_post_id));
				}
			}

			$this->update_post_custom_fields($new_meta_fields, $post_id);

			if($new_post_name && '' !== $new_post_name){
				wp_update_post(array(
					'ID' => $post_id,
					'post_name' => $new_post_name
				));
			}

			wp_send_json_success( 'Divi translation completed.' );
			exit;
		}

		/**
         * Handle AJAX request to update Elementor data.
         */
        public function update_elementor_data() {
			if ( ! check_ajax_referer( 'atfp_translate_nonce', 'atfp_nonce', false ) ) {
				wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			$post_id = isset($_POST['post_id']) ? absint(sanitize_text_field(wp_unslash($_POST['post_id']))) : 0;

			if ( ! $post_id || ! current_user_can('edit_post', $post_id) ) {
				wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
				wp_die( '0', 403 );
			}
			
			// Optional hardening: enforce valid JSON if not using Elementor Document API
			if ( isset($_POST['elementor_data']) && is_string($_POST['elementor_data']) ) {
				// No need to sanitize this data because we are using it for json_decode only to check valid json data.
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash
				$decoded = json_decode( wp_unslash( $_POST['elementor_data'] ), true );
				if ( json_last_error() !== JSON_ERROR_NONE ) {
					wp_send_json_error( __( 'Invalid data.', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
					wp_die( '0', 400 );
				}
			}
			
			$parent_post_id=isset($_POST['parent_post_id']) ? absint(wp_unslash($_POST['parent_post_id'])) : 0;

			if(!$parent_post_id){
				return wp_send_json_error( __( 'Parent post ID is required.', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				wp_die( '0', 400 );
			}

			$slug_translation_option = get_option('atfp_slug_translation_option','title_translate');
			$current_slug=get_post_field('post_name', $post_id);
			$new_post_name=false;
			
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Data is sanitized where we are using it.
			$new_meta_fields=isset($_POST['meta_fields']) ? json_decode(wp_unslash($_POST['meta_fields']), true) : false;
			
            $elementor_data = isset($_POST['elementor_data']) ? sanitize_text_field(wp_unslash($_POST['elementor_data'])) : '';

			if('' === $current_slug){
				if(isset($_POST['post_name']) && '' !== $_POST['post_name'] && $slug_translation_option === 'slug_translate'){
					$new_post_name=sanitize_title(wp_unslash($_POST['post_name']));
				}else if($slug_translation_option === 'slug_keep'){
					$new_post_name=sanitize_text_field(get_post_field('post_name', $parent_post_id));
				}
			}

			if(!defined('DOING_ATFPP_ELEMENTOR_PAGE_TRANSLATION')){
				// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- ATFPP is our plugin prefix
				define('DOING_ATFPP_ELEMENTOR_PAGE_TRANSLATION', true);
			}

			delete_post_meta($post_id, '_atfpp_elementor_page_publish_status');

			// Check if the current post has Elementor data
			if($elementor_data && '' !== $elementor_data){
				if(class_exists('Elementor\Plugin')){
					$plugin=\Elementor\Plugin::$instance;
					$document=$plugin->documents->get($post_id);

					// no need to sanitize elementor data internally sanitized and prevent page content formatting break issue.
					// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
					$elementor_data=json_decode(wp_unslash($_POST['elementor_data']), true);
					
					if (json_last_error() !== JSON_ERROR_NONE) {
						wp_send_json_error( __( 'Invalid Elementor data.', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
						wp_die( '0', 400 );
					}

					$document->save( [
						'elements' => $elementor_data,
					] );

					$plugin->files_manager->clear_cache();

					$this->update_post_custom_fields($new_meta_fields, $post_id);

					update_post_meta($post_id, '_atfp_elementor_translated', 'true');
				}
			}

			if($new_post_name && '' !== $new_post_name){
				wp_update_post(array(
					'ID' => $post_id,
					'post_name' => $new_post_name
				));
			}

			if(isset($_POST['re_translate_page']) && 'true' === $_POST['re_translate_page']){
				ATFP_Re_Translation::delete_re_translation_data((int) $post_id);
			}
				
            wp_send_json_success( 'Elementor data updated.' );
			exit;
        }

		private function update_post_custom_fields($fields, $post_id){
			$post_meta_sync = true;

            if (!isset(PLL()->options['sync']) || (isset(PLL()->options['sync']) && !in_array('post_meta', PLL()->options['sync']))) {
                $post_meta_sync = false;
            }

			if($post_meta_sync){
				return;
			}

			$allowed_meta_fields=ATFPP_Helper::get_allowed_custom_fields();

			if($fields && is_array($fields) && count($fields) > 0){
				$valid_meta_fields=array_intersect(array_keys($fields), array_keys($allowed_meta_fields));
				if(count($valid_meta_fields) > 0){
					foreach($valid_meta_fields as $key){
						if(isset($allowed_meta_fields[$key]) && $allowed_meta_fields[$key]['status']){
							$value=is_array($fields[$key]) ? $this->sanitize_array_value($fields[$key], array()) : sanitize_text_field($fields[$key]);

							update_post_meta(absint($post_id), sanitize_text_field($key), $value);
						}
					}
				}
			}
		}

		private function sanitize_array_value($value, $arr){
			foreach($value as $key => $item){
				$arr[sanitize_text_field($key)]=is_array($item) ? $this->sanitize_array_value($item, array()) : sanitize_text_field($item);
			}

			return $arr;
		}

		public function update_post_custom_fields_content() {
			$this->update_custom_fields_content('post');
		}

		public function update_term_custom_fields_content() {
			$this->update_custom_fields_content('term');
		}

		private function update_custom_fields_content($type='post') {
			$type=sanitize_text_field($type);
			$key='atfp_update_'.$type.'_custom_fields';
			$option_key=$type === 'post' ? 'atfp_allowed_custom_fields' : 'atfp_term_allowed_custom_fields';

            if ( ! check_ajax_referer( $key, 'atfp_nonce', false ) ) {
                wp_send_json_error( __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ) );
                wp_die( '0', 400 );
            }

            if(!current_user_can('edit_posts')){
                wp_send_json_error( __( 'Unauthorized', 'autopoly-ai-translation-for-polylang-pro' ), 403 );
                wp_die( '0', 403 );
            }
            
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Data is sanitized in the next line
            $json = isset($_POST['save_custom_fields_data']) ? wp_unslash($_POST['save_custom_fields_data']) : false;
            $updated_custom_fields_data = json_decode($json, true);

			$updated_custom_fields_data=array_map('sanitize_text_field', $updated_custom_fields_data);
			$existing_fields=get_option(sanitize_text_field($option_key), false);

			if(json_last_error() !== JSON_ERROR_NONE){ 
                wp_send_json_error( __( 'Invalid JSON', 'autopoly-ai-translation-for-polylang-pro' ) );
                wp_die( '0', 400 );
            }
			
			$allowed_fields=ATFPP_Helper::get_custom_fields_data($type);

			if(!$allowed_fields || !is_array($allowed_fields)){
				wp_send_json_error( __( 'Invalid allowed fields', 'autopoly-ai-translation-for-polylang-pro' ) );
				wp_die( '0', 400 );
			}

			$allowed_fields_values=array_keys($allowed_fields);

			$valid_fields=array_intersect($updated_custom_fields_data, $allowed_fields_values);
			
			$sanitize_fields=array();
			$old_fields=array();

			foreach($valid_fields as $field){
				if(!isset($existing_fields[$field]) || $existing_fields[$field]['status'] !== true || $existing_fields[$field]['type'] !== $allowed_fields[$field]['type']){
					$sanitize_fields[sanitize_text_field($field)]=['status'=>true, 'type'=>sanitize_text_field($allowed_fields[$field]['type'])];
				}else{
					$old_fields[$field]=$existing_fields[$field];
				}
			}

			$unset_fields=array_diff(array_keys($existing_fields), $updated_custom_fields_data );

			foreach($unset_fields as $field){
				if(isset($existing_fields[$field]) && $existing_fields[$field]['status'] === true){
					$sanitize_fields[$field]=$existing_fields[$field];
					$sanitize_fields[$field]['status']=false;
				}
			}

			if(count($sanitize_fields) < 1){
				wp_send_json_success(array( 'message' => __( 'No changes detected. All selected custom fields are already up to date.', 'autopoly-ai-translation-for-polylang-pro' ) ));
				exit;
			}

			update_option(sanitize_text_field($option_key), array_merge($old_fields, $sanitize_fields));

			$save_settings=get_option(sanitize_text_field($option_key), false);

			if ( ! $save_settings || ! is_array( $save_settings ) || count( $save_settings ) < 1 ) {
				wp_send_json_success( array( 'message' => __( 'No custom fields selected. Autopoly cannot translate any fields.', 'autopoly-ai-translation-for-polylang-pro' ) ) );
				exit;
			}

            wp_send_json_success( array(
                'message' => __( 'Custom fields translation settings have been updated successfully. Your selected fields will now be translated automatically.', 'autopoly-ai-translation-for-polylang-pro' ),
                'updated_fields' => $sanitize_fields
            ) );

			exit;
        }
	}
}
