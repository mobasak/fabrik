<?php

/**
 * ATFPP Ajax Handler
 *
 * @package ATFPP
 */

/**
 * Do not access the page directly
 */
if (! defined('ABSPATH')) {
	exit;
}

/**
 * ATFPP Helper
 */
if (! class_exists('ATFPP_Helper')) {
	class ATFPP_Helper
	{
		/**
		 * Member Variable
		 *
		 * @var instance
		 */
		private static $instance;

		/**
		 * Stores custom block data for processing and retrieval.
		 *
		 * This static array holds the data related to custom blocks that are
		 * used within the plugin. It can be utilized to manage and manipulate
		 * the custom block information as needed during AJAX requests.
		 *
		 * @var array
		 */
		private $custom_block_data_array = array();

		/**
		 * Gets an instance of our plugin.
		 *
		 * @param object $settings_obj timeline settings.
		 */
		public static function get_instance()
		{
			if (null === self::$instance) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		public static function get_custom_block_post_id()
		{
			$first_post_id = null;

			$query = new WP_Query(
				array(
					'post_type'      => 'atfp_add_blocks',
					'posts_per_page' => 1,
					'orderby'        => 'date',
					'order'          => 'ASC',
				)
			);

			$existing_post = $query->posts ? $query->posts[0] : null;

			if (! $existing_post) {
				$post_title    = esc_html__('Add More Gutenberg Blocks', 'autopoly-ai-translation-for-polylang-pro');
				$first_post_id = wp_insert_post(
					array(
						'post_title'   => $post_title,
						'post_content' => '',
						'post_status'  => 'publish',
						'post_type'    => 'atfp_add_blocks',
					)
				);
			} elseif ($query->have_posts()) {
				$query->the_post();
				$first_post_id = get_the_ID();
			}

			return $first_post_id;
		}

		public function get_block_parse_rules()
		{
			$response = wp_remote_get( esc_url_raw( ATFPP_URL . 'includes/translation-rules/block-rules.json' ), array(
				'timeout' => 15,
			) );

			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				global $wp_filesystem;

				// Initialize the WordPress filesystem
				if ( ! function_exists( 'WP_Filesystem' ) ) {
					require_once ABSPATH . 'wp-admin/includes/file.php';
				}

				WP_Filesystem();

				$local_path = ATFPP_DIR_PATH . 'includes/translation-rules/block-rules.json';
				if($wp_filesystem->exists($local_path) && $wp_filesystem->is_readable( $local_path )){
					$block_rules = $wp_filesystem->get_contents( $local_path );
				}else{
					$block_rules = array();
				}
			} else {
				$block_rules = wp_remote_retrieve_body( $response );
			}

			if(empty($block_rules)){
				return array();
			}

			$block_translation_rules = json_decode($block_rules, true);

			$this->custom_block_data_array = isset($block_translation_rules['AtfpBlockParseRules']) ? $block_translation_rules['AtfpBlockParseRules'] : null;

			$custom_block_translation = get_option('atfp_custom_block_translation', false);

			if (! empty($custom_block_translation) && is_array($custom_block_translation)) {
				foreach ($custom_block_translation as $key => $block_data) {
					$block_rules = isset($block_translation_rules['AtfpBlockParseRules'][$key]) ? $block_translation_rules['AtfpBlockParseRules'][$key] : null;
					$this->filter_custom_block_rules(array($key), $block_data, $block_rules);
				}
			}

			$block_translation_rules['AtfpBlockParseRules'] = $this->custom_block_data_array ? $this->custom_block_data_array : array();

			return $block_translation_rules;
		}

		private function filter_custom_block_rules(array $id_keys, $value, $block_rules, $attr_key = false)
		{
			$block_rules = is_object($block_rules) ? json_decode(json_encode($block_rules)) : $block_rules;

			if (! isset($block_rules)) {
				return $this->merge_nested_attribute($id_keys, $value);
			}
			if (is_object($value) && isset($block_rules)) {
				foreach ($value as $key => $item) {
					if (isset($block_rules[$key]) && is_object($item)) {
						$this->filter_custom_block_rules(array_merge($id_keys, array($key)), $item, $block_rules[$key], false);
						continue;
					} elseif (! isset($block_rules[$key]) && true === $item) {
						$this->merge_nested_attribute(array_merge($id_keys, array($key)), true);
						continue;
					} elseif (! isset($block_rules[$key]) && is_object($item)) {
						$this->merge_nested_attribute(array_merge($id_keys, array($key)), $item);
						continue;
					}
				}
			}
		}

		private function merge_nested_attribute(array $id_keys, $value)
		{
			$value = is_object($value) ? json_decode(json_encode($value), true) : $value;

			$current_array = &$this->custom_block_data_array;

			foreach ($id_keys as $index => $id) {
				if (! isset($current_array[$id])) {
					$current_array[$id] = array();
				}
				$current_array = &$current_array[$id];
			}

			$current_array = $value;
		}

		public static function replace_links_with_translations($content, $locale, $current_locale)
		{
			// Get all URLs in the content that start with the current home page URL (current domain), regardless of attribute or tag
			$home_url = preg_quote(get_home_url(), '/');
			$pattern = '/(' . $home_url . '[^\s"\'<>]*)/i';
			$terms_data=self::get_terms_data();

			if (preg_match_all($pattern, $content, $matches)) {
				$image_urls=self::get_image_ids_by_urls($matches[1], $locale);

				$content = preg_replace_callback($pattern, function ($match) use ($image_urls, $locale, $current_locale, $terms_data) {
		
					$href = $match[1];
		
					if (preg_match('/<img[^>]+(src|srcset)=[\'"][^\'"]*' . preg_quote($href, '/') . '[\'"][^>]*>/i', $match[0])) {
						return $href;
					}
		
					if (isset($image_urls[$href]) && !empty($image_urls[$href])) {
						return $image_urls[$href];
					}
		
					$postID = url_to_postid($href);
					if ($postID > 0) {
						$translatedPost = pll_get_post($postID, $locale);
						if ($translatedPost) {
							$link = get_permalink($translatedPost);
							if ($link) {
								return esc_url(urldecode_deep($link));
							}
						}
					}

					$path = trim(str_replace(pll_home_url($current_locale), '', $href), '/');
					$category_slug = end(array_filter(explode('/', $path)));
		
					$taxonomy_name = self::extract_taxonomy_name($path, $terms_data);
					$taxonomy_name = $taxonomy_name ? $taxonomy_name : 'category';
		
					$category = get_term_by('slug', $category_slug, $taxonomy_name);
		
					if (!$category) {
						// Remove the language prefix if using Polylang
						$languages = pll_languages_list(); // e.g., ['en', 'fr']
						$segments = explode('/', $path);
						if (in_array($segments[0], $languages)) {
							$lang_code = $segments[0];
							$category_id = Pll()->model->term_exists_by_slug($category_slug, $lang_code, $taxonomy_name);

							if ($category_id) {
								$category = get_term($category_id, $taxonomy_name);
							}
						}
					}
		
					if ($category) {
						$term_id = pll_get_term($category->term_id, $locale);
						if ($term_id > 0) {
							$link = get_category_link($term_id);
							return esc_url($link);

						}
					}
					return $href;
		
				}, $content);
			}

			return $content;
		}

		private static function extract_taxonomy_name($path, $terms_data){
			// Remove the language prefix if using Polylang
			$languages = pll_languages_list(); // e.g., ['en', 'fr']
			$segments = explode('/', $path);
			if (in_array($segments[0], $languages)) {
				array_shift($segments); // remove 'en', 'fr', etc.
			}
			
			if (empty($segments)) {
				return null;
			}

			// First segment after language is usually the taxonomy slug
			$possible_tax = $segments[0];

			if (taxonomy_exists($possible_tax) || (isset($terms_data[$possible_tax]) && taxonomy_exists($terms_data[$possible_tax]))) {
		   		return isset($terms_data[$possible_tax]) ? $terms_data[$possible_tax] : $possible_tax;
			}

			return false;
		}

		private static function get_terms_data(){
			$taxonomies=get_taxonomies([],'objects');

			$taxonomies_data=array();
			foreach($taxonomies as $key=>$taxonomy){
				if(isset($taxonomy->rewrite['slug'])){
					$taxonomies_data[$taxonomy->rewrite['slug']]=$key;
				}else{
					$taxonomies_data[$key]=$key;
				}
			}

			return $taxonomies_data;
		}

		private static function get_image_ids_by_urls( $image_urls = [] , $locale='en') {
			global $wpdb;
		
			// Convert single URL string to array
			if ( is_string( $image_urls ) ) {
				$image_urls = [ $image_urls ];
			}
		
			if ( empty( $image_urls ) || ! is_array( $image_urls ) ) {
				return [];
			}
		
			$upload_dir = wp_upload_dir();
			$base_url   = $upload_dir['baseurl'];
			$results    = [];
		
			$cleaned_paths_map = []; // [cleaned_path] => [original_urls]
		
			foreach ( $image_urls as $url ) {
				if ( strpos( $url, $base_url ) === false ) {
					$results[ $url ] = false;
					continue;
				}
		
				// Relative path
				$relative_path = str_replace( $base_url . '/', '', $url );
		
				// Strip size suffix if present
				$cleaned_path = preg_replace( '/-\d+x\d+(?=\.(jpg|jpeg|png|gif|webp)$)/i', '', $relative_path );
		
				// Map cleaned path to original URL(s)
				if ( ! isset( $cleaned_paths_map[ $cleaned_path ] ) ) {
					$cleaned_paths_map[ $cleaned_path ] = [];
				}
		
				$cleaned_paths_map[ $cleaned_path ][] = $url;
			}

			$like_parts = [];
			$args       = [];

			// Build the OR'ed LIKEs and gather args
			foreach ( array_keys( $cleaned_paths_map ) as $path ) {
				$like_parts[] = 'guid LIKE %s';
				// Always escape for LIKE, then add wildcards yourself
				$args[] = '%' . $wpdb->esc_like( $path ) . '%';
			}

			// Nothing to search? bail early.
			if ( empty( $like_parts ) ) {
				return $results;
			}

			// Compose the SQL with placeholders only
			$sql = "
				SELECT ID, guid
				FROM {$wpdb->posts}
				WHERE post_type = %s
				AND (" . implode( ' OR ', $like_parts ) . ")
			";

			// First arg is for post_type, then all the LIKE args
			array_unshift( $args, 'attachment' );

			// Run the query
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $sql is already sanitized and sql esc_like it's safe.
			$found = $wpdb->get_results( $wpdb->prepare( $sql, $args ) );

		
			// Map found GUIDs to IDs
			$guid_to_id = [];
			foreach ( $found as $row ) {
				
				$guid_to_id[ $row->guid ] = esc_url($row->guid);
				$translated_post=pll_get_post(intval($row->ID), $locale);

				if($translated_post){
					$image_url=wp_get_attachment_url(intval($translated_post));

					if($image_url && !empty($image_url)){
						$guid_to_id[$row->guid]=esc_url($image_url);
					}
				}
			}
		
			// Match original URLs to found IDs
			foreach ( $image_urls as $original_url ) {
				$found_id = false;
		
				if(isset($guid_to_id[$original_url])){
					$results[$original_url]=$guid_to_id[$original_url];
					continue;
				}

				// Exact match first
				if ( isset( $guid_to_id[ $original_url ] ) ) {
					$found_id = $guid_to_id[ $original_url ];
				} else {
					// Fallback to cleaned path match
					$relative_path = str_replace( $base_url . '/', '', $original_url );
					$cleaned_path  = preg_replace('/-\d+x\d+(?=\.(jpg|jpeg|png|gif|webp)$)/i', '', $relative_path );

					preg_match('/-\d+x\d+(?=\.(jpg|jpeg|png|gif|webp)$)/i', $original_url, $matches);
					$suffix = isset($matches[0]) ? $matches[0] : '';

					foreach ( $guid_to_id as $guid => $url ) {
						if ( strpos( $guid, $cleaned_path ) !== false ) {
							if (!empty($suffix)) {
								// Insert $suffix before the file extension in $url
								$found_id = preg_replace('/(\.[a-zA-Z0-9]+)$/', $suffix . '$1', $url);
							} else {
								$found_id = $url;
							}
							break;
						}
					}
				}
		
				$results[ $original_url ] = esc_url($found_id);
			}
			
		
			return $results;
		}

		public static function translation_data_migration(){
			$already_migrated = get_option('atfp_translation_string_migration', false);

			if(!$already_migrated){
				
				$old_data=get_option('cpt_dashboard_data', array());

				$updated=array();

				if(isset($old_data['atfp']) && count($old_data['atfp']) > 0){
					foreach($old_data['atfp'] as $data){
						$updated_data=$data;
						if(isset($data['string_count'])){
							$updated_data['word_count']=$data['string_count'];
							$updated_data['string_count']=$data['string_count'] / 30;
						}

						if(isset($data['source_string_count'])){
							$updated_data['source_word_count']=$data['source_string_count'];
							$updated_data['source_string_count']=$data['source_string_count'] / 30;
						}

						$updated[]=$updated_data;
					}

					if(count($updated) > 0){
						$old_data['atfp']=$updated;

						update_option('cpt_dashboard_data', $old_data);
					}
				}

				update_option('atfp_translation_string_migration', true);
			}
		}

		public static function get_custom_fields_data($type='post'){
			$results=array();
			$type=sanitize_text_field($type);
			$option_key=$type === 'post' ? 'atfp_allowed_custom_fields' : 'atfp_term_allowed_custom_fields';

			if('term' === $type){
				$results=self::get_term_custom_fields_query();
			}else{
				$results=self::get_post_custom_fields_query();
			}

			$data=array();

			if($results && is_array($results)){
				$excluded_fields=self::get_excluded_custom_fields_keys();
				$allowed_fields=self::get_allowed_custom_fields($type);

				foreach($results as $result){
					if(in_array($result['meta_key'], $excluded_fields)){
						continue;
					}

					$serialized_value=maybe_unserialize($result['meta_value']);
					$value_type=json_decode($result['meta_value'], true) ? 'array' : (is_array($serialized_value) ? 'array' : 'string');
					
					$type=isset($allowed_fields[$result['meta_key']]) && true === $allowed_fields[$result['meta_key']]['status'] ? $allowed_fields[$result['meta_key']]['type'] : $value_type;
					
					$status=isset($allowed_fields[$result['meta_key']]) && true === $allowed_fields[$result['meta_key']]['status'] ? 'Supported' : 'Unsupported';

					$data[sanitize_text_field($result['meta_key'])]=['type'=>$type, 'status'=>$status];
				}
			}

			$default_allowed_fields=self::get_default_allowed_fields();

			$default_key_diff=array_diff(array_keys($default_allowed_fields), array_keys($data));

			foreach($default_key_diff as $key){
				$status='Supported';
				$saved_allowed_fields=get_option(sanitize_text_field($option_key), false);
				$status=isset($saved_allowed_fields[$key]) && true === $saved_allowed_fields[$key]['status'] ? 'Supported' : 'Unsupported';

				$data[$key]=['type'=>$default_allowed_fields[$key]['type'], 'status'=>$status];
			}

			$data=apply_filters('atfp/'.sanitize_text_field($type).'/custom_fields/all_fields', $data);

			return $data;
		}

		private static function get_post_custom_fields_query(){
			global $wpdb;

           	// Escape LIKE pattern for hidden keys (_%)
			$like_pattern = $wpdb->esc_like('_') . '%';

			$fetch_keys = array('_product_attributes');

			$required_keys = apply_filters(
				'atfp/post/custom_fields/required_keys',
				$fetch_keys
			);

			// Sanitize
			$required_keys = array_map('sanitize_key', (array) $required_keys);
			$required_keys = array_filter($required_keys);

			// Build placeholders
			$placeholders = '';
			$prepare_args = array($like_pattern);

			if (!empty($required_keys)) {

				$placeholders = implode(',', array_fill(0, count($required_keys), '%s'));

				$prepare_args = array_merge($prepare_args, $required_keys);
			}

			// Final SQL
			$sql = "
				SELECT DISTINCT pm.meta_key, pm.meta_value, 'post' AS meta_type
				FROM {$wpdb->postmeta} pm
				WHERE (
					pm.meta_key NOT LIKE %s
					" . (!empty($placeholders) ? " OR pm.meta_key IN ($placeholders)" : "") . "
				)
				AND pm.meta_value <> ''
				AND pm.meta_value NOT IN ('0','1')
				AND pm.meta_value NOT REGEXP '^[0-9]+$'
				AND pm.meta_value NOT REGEXP '^[0-9]+\\.[0-9]+$'
				AND pm.meta_value NOT REGEXP '^(https?:\/\/|www\.)'
				ORDER BY pm.meta_key ASC
			";

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql is a prepared statement with valid placeholders we need latest results from the database.
			$sql = $wpdb->prepare($sql, $prepare_args);

            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $query is a prepared statement with validplaceholders we need latest results from the database.
            $results = $wpdb->get_results($sql, ARRAY_A);

			return $results;
		}

		private static function get_term_custom_fields_query(){
			global $wpdb;

            // Escape LIKE pattern for system meta (_%)
			$like_pattern = $wpdb->esc_like('_') . '%';

			// SQL with DISTINCT + filtering
			$sql = $wpdb->prepare(
				"
				SELECT DISTINCT pm.meta_key, pm.meta_value, 'term' AS meta_type
				FROM {$wpdb->termmeta} pm
				WHERE pm.meta_key NOT LIKE %s
				AND pm.meta_value <> ''                         -- skip empty
				AND pm.meta_value NOT IN ('0','1')              -- skip boolean
				AND pm.meta_value NOT REGEXP '^[0-9]+$'         -- skip integer
				AND pm.meta_value NOT REGEXP '^[0-9]+\\.[0-9]+$' -- skip decimal
				AND pm.meta_value NOT REGEXP '^(https?:\/\/|www\.)[A-Za-z0-9\.\-]+.*$' -- skip URLs
				ORDER BY pm.meta_key ASC
				",
				$like_pattern
			);

            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- $query is a prepared statement with validplaceholders we need latest results from the database.
            $results = $wpdb->get_results($sql, ARRAY_A);

			return $results;
		}

		private static function get_excluded_custom_fields_keys(){
			$excluded_fields= array(
                '_edit_last',
                '_edit_lock',
                '_wp_page_template',
                '_wp_attachment_metadata',
                '_icl_translator_note',
                '_alp_processed',
                '_pingme',
                '_encloseme',
                '_icl_lang_duplicate_of',
                'atfpp_parent_post_language',
                'atfp_parent_post_language_slug',
                'atfpp_parent_post_language_slug',
                'twae_exists',
                'twae_post_migration',
                'twae_style_migration',
                '_thumbnail_id',
            );

            return apply_filters('atfp/custom_fields/excluded_keys', $excluded_fields);
		}

		public static function get_allowed_custom_fields($type='post'){
			$allowed_custom_fields=array();
			$type=sanitize_text_field($type);

			if('term' === $type){
				$allowed_custom_fields=self::get_term_allowed_custom_fields();
			}else{
				$allowed_custom_fields=self::get_post_allowed_custom_fields();
			}

			$allowed_custom_fields=apply_filters('atfp/'.$type.'/custom_fields/allowed_fields', $allowed_custom_fields);
		
			return $allowed_custom_fields;
		}

		private static function get_post_allowed_custom_fields(){			
			$allowed_fields=get_option('atfp_allowed_custom_fields', array());

			if($allowed_fields && is_array($allowed_fields) && count($allowed_fields) > 0){
				return $allowed_fields;
			}

			if(!$allowed_fields || !is_array($allowed_fields)){
				$default_allowed_fields=self::get_default_allowed_fields();

				foreach($default_allowed_fields as $key => $value){
					$allowed_fields[$key]=['status'=>true, 'type'=>'string'];
				}

				update_option('atfp_allowed_custom_fields', $allowed_fields);
			}

			ksort($allowed_fields);
			
			return $allowed_fields;
		}

		private static function get_term_allowed_custom_fields(){
			$allowed_fields=get_option('atfp_term_allowed_custom_fields', array());

			if($allowed_fields && is_array($allowed_fields) && count($allowed_fields) > 0){
				return $allowed_fields;
			}

			if(!$allowed_fields || !is_array($allowed_fields)){
				$default_allowed_fields=self::get_default_allowed_fields();

				foreach($default_allowed_fields as $key => $value){
					$allowed_fields[$key]=['status'=>true, 'type'=>'string'];
				}

				update_option('atfp_term_allowed_custom_fields', $allowed_fields);
			}

			ksort($allowed_fields);
			
			return $allowed_fields;
		}

		private static function get_default_allowed_fields($type='post'){
			$found=false;

			$response = wp_remote_get( esc_url_raw( ATFPP_URL . 'includes/translation-rules/default-allow-metafields.json' ), array(
				'timeout' => 15,
			) );

			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				global $wp_filesystem;

				// Initialize the WordPress filesystem
				if ( ! function_exists( 'WP_Filesystem' ) ) {
					require_once ABSPATH . 'wp-admin/includes/file.php';
				}

				WP_Filesystem();

				$local_path = ATFPP_DIR_PATH . 'includes/translation-rules/default-allow-metafields.json';
				if($wp_filesystem->exists($local_path) && $wp_filesystem->is_readable( $local_path )){
					$found=true;
					$default_allowed_fields = $wp_filesystem->get_contents( $local_path );
				}
			}else{
				$found=true;
				$default_allowed_fields = wp_remote_retrieve_body( $response );
			}

			if(!$found){
				return array();
			}

			$default_allowed_fields=json_decode($default_allowed_fields, true);
			
			if(is_array($default_allowed_fields) && count($default_allowed_fields) > 0){
				$allowed_keys=array_keys($default_allowed_fields);
				$allowed_keys=array_map('sanitize_text_field', $allowed_keys);
				
				global $wpdb;

				$table_name=$type === 'post' ? $wpdb->postmeta : $wpdb->termmeta;
				$placeholders = implode(',', array_fill(0, count($default_allowed_fields), '%s'));
				$table_name=esc_sql($table_name);

				// $placeholders is a placeholder for the allowed keys & already esc_sql used for $table_name.
				// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$query=$wpdb->prepare("SELECT ct.meta_key from {$table_name} ct Where ct.meta_key IN ($placeholders)", ...array_map('esc_sql', $allowed_keys));

				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery -- $query is a prepared statement with valid placeholders we need latest results from the database.
				$results=$wpdb->get_results($query, ARRAY_A);

				$not_existing_keys=array_diff($allowed_keys, array_column($results, 'meta_key'));

				foreach($not_existing_keys as $key){
					unset($default_allowed_fields[$key]);
				}
			}

			return $default_allowed_fields;
		}

		public static function bulk_translation_render($current_screen){
			global $polylang;
        
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- No need to verify nonce here.
			if(!$polylang || !property_exists($polylang, 'model') || (isset($current_screen->action) && $current_screen->action === 'add') || (isset($_GET['post']) && isset($_GET['action']) && $_GET['action'] === 'edit')){
				return false;
			}

			$translated_post_types = $polylang->model->get_translated_post_types();
			$translated_taxonomies = $polylang->model->get_translated_taxonomies();
	
			$translated_post_types = array_values($translated_post_types);
			$translated_taxonomies = array_values($translated_taxonomies);
				
			$translated_post_types=array_filter($translated_post_types, function($post_type){
				return is_string($post_type);
			});
	
			$translated_taxonomies=array_filter($translated_taxonomies, function($taxonomy){
				return is_string($taxonomy);
			});
	
			$valid_post_type=(isset($current_screen->post_type) && !empty($current_screen->post_type)) && in_array($current_screen->post_type, $translated_post_types) && $current_screen->post_type !== 'attachment' ? $current_screen->post_type : false;
			$valid_taxonomy=(isset($current_screen->taxonomy) && !empty($current_screen->taxonomy)) && in_array($current_screen->taxonomy, $translated_taxonomies) ? $current_screen->taxonomy : false;

			if(isset($current_screen->is_block_editor) && true === $current_screen->is_block_editor){
				return false;
			}
	
			if((!$valid_post_type && !$valid_taxonomy) || ((!$valid_post_type || empty($valid_post_type)) && !isset($valid_taxonomy)) || (isset($current_screen->taxonomy) && !empty($current_screen->taxonomy) && !$valid_taxonomy)){
				return false;
			}

			return true;
		}

		public static function deepl_base_url($api_key){
			$key_free=str_ends_with($api_key, ':fx');
			return $key_free ? 'https://api-free.deepl.com' : 'https://api.deepl.com';
		}

		public static function compare_divi_version($version='5'){
			if(!function_exists('et_get_theme_version')){
				return false;
			}

			$divi_version=et_get_theme_version();
			return version_compare($divi_version, $version, '>=');
		}

		public static function is_atfp_new_post(){
			$atfp_new_post=(isset( $_GET['from_post'], $_GET['new_lang'], $_GET['_wpnonce'] ) && isset($_GET['_wpnonce']) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'new-post-translation' ));
			
			return $atfp_new_post;
		}

		public static function is_wp_ai_client_exist(){
			return function_exists('wp_ai_client_prompt') && class_exists('WordPress\AiClient\AiClient');
		}

		public static function get_providers_key($providers=array(), $mask_api_key=true) {
			$api_key = array();
	
			if(empty($providers)) {
				$providers = array();
			}
	
			$allowed_providers = array( 'openai', 'google', 'deepl' );
	
			$providers = array_intersect( $providers, $allowed_providers );
	
			if(self::is_wp_ai_client_exist() && function_exists('_wp_register_default_connector_settings')){
				foreach ($providers as $provider) {
					$ai_client_option_name='connectors_ai_'.$provider.'_api_key';
	
					remove_filter( "option_{$ai_client_option_name}", '_wp_connectors_mask_api_key' );

					$client_api_key=get_option($ai_client_option_name, '');
	
					add_filter( "option_{$ai_client_option_name}", '_wp_connectors_mask_api_key' );
	
					if(!empty($client_api_key) && is_string($client_api_key)) {
						$api_key[$provider] = self::mask_api_key($client_api_key, $mask_api_key);
					}
				}
			}else{
				foreach ($providers as $provider) {
					$value = get_option('Atfpp_Ai_Translate_'.$provider.'_api_key', '');
					
					if(!empty($value) && is_string($value)) {
						$api_key[$provider] = self::mask_api_key($value, $mask_api_key);
					}
				}
			}
	
			return $api_key;
		}

		private static function mask_api_key($api_key, $mask_api_key){
			if(true !== $mask_api_key){
				return $api_key;
			}

			$api_key_length = strlen($api_key);
			if ($api_key_length <= 8 || true !== $mask_api_key) {
				return $api_key;
			}
			$start = substr($api_key, 0, 5);
			$end = substr($api_key, -5);
			$mask = str_repeat('*', $api_key_length - 8);
			return $start . $mask . $end;

		}

		public static function delete_initial_translation_data(int $post_id){
			delete_post_meta($post_id, '_atfpp_translate_status');
			delete_post_meta($post_id, '_atfp_parent_post_language_slug');
			delete_post_meta($post_id, '_atfpp_parent_post_id');
			delete_post_meta($post_id, '_atfpp_translation_publish_status');
			delete_post_meta($post_id, '_atfp_elementor_translated');
			delete_post_meta($post_id, '_atfpp_elementor_page_publish_status');
			delete_post_meta($post_id, '_atfpp_initial_translation_popup_hidden');
		}

		public static function get_polylang_default_language(){
			if(function_exists('pll_default_language')){
				return pll_default_language();
			}
			return '';
		}

		public static function get_polylang_supported_languages(){
			if(function_exists('PLL') && property_exists(PLL(), 'model')){
				$atfp_polylang_languages = PLL()->model->get_languages_list();
				$atfp_polylang_languages_object = array();
				foreach ($atfp_polylang_languages as $lang) {
					$atfp_polylang_languages_object[$lang->slug] = array('name' => $lang->name);
				}

				return $atfp_polylang_languages_object;
			}
			return array();
		}

		public static function get_active_providers(){
			$active_providers = get_option('atfp_enabled_providers', array('chrome-built-in-ai', 'yandex-translate', 'google-translate', 'openai', 'deepl', 'gemini'));
	
			$valid_providers = array('chrome-built-in-ai', 'yandex-translate', 'google-translate', 'openai', 'deepl', 'gemini');
	
			$active_providers = array_filter($active_providers, function($provider_name) use ($valid_providers) {
				return in_array($provider_name, $valid_providers);
			});
	
			return array_values($active_providers);
		}
	}
}
