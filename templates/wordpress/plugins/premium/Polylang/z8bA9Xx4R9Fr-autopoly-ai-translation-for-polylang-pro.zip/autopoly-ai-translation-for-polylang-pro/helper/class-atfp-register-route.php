<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ATFPP\AI_Translate\Services\API\Enums\AI_Capability;
use ATFPP\AI_Translate\Services\API\Helpers;
use ET\Builder\Migration\Utils\MigrationUtils;

if ( ! class_exists( 'ATFP_Register_Route' ) ) :
	/**
	 * ATFP_Register_Route
	 *
	 * @package ATFPP\AI_Translate\Services\API\Helpers
	 */
	class ATFP_Register_Route {
		/**
		 * The base name of the route.
		 *
		 * @var string
		 */
		private $base_name;

		/**
		 * Constructor
		 *
		 * @param string $base_name The base name of the route.
		 */
		public function __construct( $base_name ) {
			$this->base_name = $base_name;
			add_action( 'rest_api_init', array( $this, 'register_routes' ) );
		}

		/**
		 * Register the routes
		 */
		public function register_routes() {
			register_rest_route(
				$this->base_name,
				'/(?P<slug>[\w-]+)/translate-text',
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'ai_translation' ),
					'permission_callback' => array( $this, 'permission_only_admins' ),
					'args'                => array(
						'slug'            => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_key',
						),
						'atfp_nonce'      => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
							'validate_callback' => array( $this, 'validate_atfp_ai_translate_nonce' ),
						),
						'strings'         => array(
							'type'     => 'string',
							'required' => true,
						),
						'target_language' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				)
			);

			register_rest_route(
				$this->base_name,
				'/(?P<slug>[\w-]+)/pending-posts-ids',
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'get_pending_posts_ids' ),
					'permission_callback' => array( $this, 'permission_only_admins' ),
					'args'                => array(
						'privateKey' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
							'validate_callback' => array( $this, 'validate_pending_posts_ids_request' ),
						),
						'ids' => array(
							'type'     => 'string',
							'required' => true,
						),
						'lang' => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				)
			);

			register_rest_route(
				$this->base_name,
				'/(?P<slug>[\w-]+)/bulk-translate-entries',
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'bulk_translate_entries' ),
					'permission_callback' => array( $this, 'permission_only_admins' ),
					'args'                => array(
						'ids'        => array(
							'type'     => 'string',
							'required' => true,
						),
						'lang'       => array(
							'type'     => 'string',
							'required' => true,
						),
						'privateKey' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
							'validate_callback' => array( $this, 'validate_atfpp_bulk_nonce' ),
						),
					),
				)
			);

			register_rest_route(
				$this->base_name,
				'/(?P<slug>[\w-]+)/bulk-translate-taxonomy-entries',
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'bulk_translate_taxonomy_entries' ),
					'permission_callback' => array( $this, 'permission_only_admins' ),
					'args'                => array(
						'taxonomy'   => array(
							'type'     => 'string',
							'required' => true,
						),
						'lang'       => array(
							'type'     => 'string',
							'required' => true,
						),
						'privateKey' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
							'validate_callback' => array( $this, 'validate_atfpp_bulk_nonce' ),
						),
						'ids'        => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				)
			);

			register_rest_route(
				$this->base_name,
				'/(?P<post_id>[\w-]+)/create-translate-post',
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'create_translate_post' ),
					'permission_callback' => array( $this, 'permission_only_admins' ),
					'args'                => array(
						'privateKey'      => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
							'validate_callback' => array( $this, 'validate_atfpp_create_post_nonce' ),
						),
						'post_id'         => array(
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
						'target_language' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'editor_type'     => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'source_language' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'post_title'      => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'post_content'    => array(
							'type'     => 'string',
							'required' => false,
						),
					),
				)
			);

			register_rest_route(
				$this->base_name,
				'/(?P<term_id>[\w-]+)/create-translate-taxonomy',
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'create_translate_taxonomy' ),
					'permission_callback' => array( $this, 'permission_only_admins' ),
					'args'                => array(
						'term_id'              => array(
							'required'          => true,
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						),
						'privateKey'           => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
							'validate_callback' => array( $this, 'validate_atfpp_create_term_nonce' ),
						),
						'target_language'      => array(
							'required'          => true,
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'source_language'      => array(
							'required'          => true,
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'taxonomy'             => array(
							'required'          => true,
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'taxonomy_name'        => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'taxonomy_slug'        => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'taxonomy_description' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'wp_kses_post',
						),
					),
				)
			);
		}

		public function permission_only_admins( $request ) {
			$nonce = $request->get_header( 'X-WP-Nonce' );

			if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
				return new WP_Error( 'rest_forbidden', __( 'Invalid nonce.', 'autopoly-ai-translation-for-polylang-pro' ), array( 'status' => 403 ) );
			}

			if ( ! is_user_logged_in() ) {
				return new \WP_Error( 'rest_forbidden', __( 'You are not authorized to perform this action.', 'autopoly-ai-translation-for-polylang-pro' ), array( 'status' => 401 ) );
			}
			if ( ! current_user_can( 'edit_posts' ) ) {
				return new \WP_Error( 'rest_forbidden', __( 'You are not authorized to perform this action.', 'autopoly-ai-translation-for-polylang-pro' ), array( 'status' => 403 ) );
			}
			return true;
		}

		public function validate_atfp_ai_translate_nonce( $value, $request, $param ) {
			return wp_verify_nonce( $value, 'atfp_ai_translate_nonce' ) ? true : new \WP_Error( 'rest_invalid_param', __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ), array( 'status' => 403 ) );
		}

		public function validate_atfpp_bulk_nonce( $value, $request, $param ) {
			return wp_verify_nonce( $value, 'atfpp_bulk_translate_entries_nonce' ) ? true : new \WP_Error( 'rest_invalid_param', __( 'You are not authorized to perform this action.', 'autopoly-ai-translation-for-polylang-pro' ), array( 'status' => 403 ) );
		}

		public function validate_atfpp_create_post_nonce( $value, $request, $param ) {
			return wp_verify_nonce( $value, 'atfpp_create_translate_post_nonce' ) ? true : new \WP_Error( 'rest_invalid_param', __( 'You are not authorized to perform this action.', 'autopoly-ai-translation-for-polylang-pro' ), array( 'status' => 403 ) );
		}

		public function validate_atfpp_create_term_nonce( $value, $request, $param ) {
			return wp_verify_nonce( $value, 'atfpp_create_translate_taxonomy_nonce' ) ? true : new \WP_Error( 'rest_invalid_param', __( 'You are not authorized to perform this action.', 'autopoly-ai-translation-for-polylang-pro' ), array( 'status' => 403 ) );
		}

		public function validate_pending_posts_ids_request( $value, $request, $param ) {
			return wp_verify_nonce( $value, 'atfpp_pending_posts_ids_nonce' ) ? true : new \WP_Error( 'rest_invalid_param', __( 'Invalid security token sent.', 'autopoly-ai-translation-for-polylang-pro' ), array( 'status' => 403 ) );
		}

		/**
		 * AI Translation
		 *
		 * @param WP_REST_Request $params The request parameters.
		 * @return WP_REST_Response The response.
		 */
		public function ai_translation( $params ) {
			// Check if the user is logged in and has the necessary capabilities
			if ( ! is_user_logged_in() ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}
			if ( ! current_user_can( 'edit_posts' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			// Get the parameters from the request
			$params = $params->get_params();

			// Get the service slug
			$service_slug = $params['slug'];

			$pro_providers=array(
				'google'=>'gemini',
				'openai'=>'openai',
				'deepl'=>'deepl'
			);

			if(!in_array($service_slug, array_keys($pro_providers))){
				wp_send_json_error( 'You are not selected the valid provider.' );
			}

			$active_providers = ATFPP_Helper::get_active_providers();
			$atfpp_is_wp_ai_client_exist = ATFPP_Helper::is_wp_ai_client_exist();

			if(!in_array($pro_providers[$service_slug], $active_providers)){
				wp_send_json_error( 'Selected provider is not active.' );
			}

			// Verify the nonce
			if ( ! wp_verify_nonce( $params['atfp_nonce'], 'atfp_ai_translate_nonce' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			// Check if the user has the necessary capabilities
			if ( wp_get_current_user()->has_cap( 'edit_posts' ) ) {
				$providers_key=ATFPP_Helper::get_providers_key(['openai', 'google', 'deepl']);
				if(isset($providers_key[$params['slug']]) && !empty($providers_key[$params['slug']])){

					// Get the selected model
					$selected_model = '';
					if ( $params['slug'] === 'google' ) {
						$selected_model = get_option( 'atfpp_selected_google_model', '' );
					} elseif ( $params['slug'] === 'openai' ) {
						$selected_model = get_option( 'atfpp_selected_openai_model', '' );
					}

					$default_models=array(
						'openai' => 'gpt-4o-mini',
						'google' => 'gemini-2.5-flash',
					);

					if(empty($selected_model) && isset($default_models[$params['slug']])){
						$selected_model = $default_models[$params['slug']];
					}

					// Get the strings
					$strings = $params['strings'];

					// Convert strings to array if it's a JSON string
					$string_array = is_string( $strings ) ? json_decode( $strings, true ) : $strings;

					if ( strpos( $strings, '&lt;' ) !== false && strpos( $strings, '&gt;' ) !== false ) {
						$strings = html_entity_decode( $strings );
					}

					// Get the target language
					$target_language = $params['target_language'];

					// Use the source language from params
					$source_language = $params['source_language'];

					$glossary_data         = get_option( 'atfpp_glossary_data', array() );
					$glossary_instructions = '';
					$matched_terms         = array();
					$has_glossary_terms    = false;

					if ( ! empty( $glossary_data ) && is_array( $glossary_data ) ) {
						// First, check if any strings contain glossary terms
						foreach ( $string_array as $string ) {
							foreach ( $glossary_data as $entry ) {
								if (
									is_array( $entry ) &&
									! empty( $entry['original_term'] ) &&
									$entry['original_language_code'] === $source_language &&
									stripos( $string, $entry['original_term'] ) !== false
								) {
									$has_glossary_terms = true;
									break 2; // Break both loops if we find a match
								}
							}
						}

						// Only process glossary terms if we found matches
						if ( $has_glossary_terms ) {
							// If strings parameter exists, decode it and check each string
							$strings_to_check = array();
							if ( isset( $params['strings'] ) ) {
								$decoded_strings = json_decode( $params['strings'], true );
								if ( is_array( $decoded_strings ) ) {
									$strings_to_check = array_values( $decoded_strings );
								}
							}

							foreach ( $glossary_data as $entry ) {
								// Skip invalid entries early
								if (
									! is_array( $entry ) ||
									empty( $entry['original_language_code'] ) ||
									empty( $entry['original_term'] ) ||
									empty( $entry['translations'] ) ||
									$entry['original_language_code'] !== $source_language
								) {
									continue;
								}

								// Use array_column for faster lookup if translations is an array of arrays
								$translations_by_code = array();
								foreach ( $entry['translations'] as $translation ) {
									if (
										is_array( $translation ) &&
										! empty( $translation['target_language_code'] ) &&
										! empty( $translation['translated_term'] )
									) {
										$translations_by_code[ $translation['target_language_code'] ] = $translation['translated_term'];
									}
								}

								// Check if the term exists in any of the strings
								$term_found = false;
								if ( ! empty( $strings_to_check ) ) {
									foreach ( $strings_to_check as $string ) {
										if ( stripos( $string, $entry['original_term'] ) !== false ) {
											$term_found = true;
											break;
										}
									}
								} else {
									// If no strings parameter, treat as found (original behavior)
									$term_found = true;
								}

								if ( $term_found && isset( $translations_by_code[ $target_language ] ) ) {
									$matched_terms[] = array(
										'term'        => $entry['original_term'],
										'translation' => $translations_by_code[ $target_language ],
										'description' => $entry['description'] ?? '',
									);
								}
							}
						}
					}

					// Build glossary instructions string only if we found matches
					if ( $has_glossary_terms && ! empty( $matched_terms ) ) {
						$glossary_instructions = "Please use the following glossary terms in your translation:\n";

						foreach ( $matched_terms as $term ) {
							$src_term    = isset( $term['term'] ) ? (string) $term['term'] : '';
							$translation = isset( $term['translation'] ) ? (string) $term['translation'] : '';
							$description = isset( $term['description'] ) ? (string) $term['description'] : '';

							$glossary_instructions .= "- \"{$src_term}\" → \"{$translation}\"";

							if ( $description !== '' ) {
								$glossary_instructions .= " — Note: {$description}";
							}

							$glossary_instructions .= "\n";
						}
					} else {
						$glossary_instructions = '';
					}

					// Get the custom prompt
					$custom_prompt = get_option( 'atfp_context_aware', '' );

					$ai_request_timeout = get_option( 'atfp_ai_request_timeout', 120 );

					// Only return the translation in the format of a JSON object with the keys being numeric values (matching the source keys), and the values being the translated strings
					$content = sprintf(
						'You are a professional translator.

						Source Language: %s  
						Target Language: %s  
					
						Instruction 1: Translate visible text content semantically from %s into %s language. Provide a proper meaning-based translation.  
						Instruction 2: Do not translate or modify any content inside square brackets [] and Do not translate any URL. These are shortcodes or dynamic placeholders and must remain exactly as they are.
						Instruction 3: Preserve all HTML tags and their attributes such as class, id, data-*, etc. Do not alter any part of the HTML structure.
						Instruction 4: Return the translation in the format of a JSON object with the keys being numeric values (matching the source keys), and the values being the translated strings.
						Instruction 5: Do not escape double quotes with backslashes. Output must be valid JSON without extra slashes.
						Instruction 6: Translate the provided JSON array from %s into %s language, regardless of whether the values are the same, and ensure the JSON is well-formed and complete.
						Instruction 7: Decode any &lt; and &gt; HTML entities back to < and > symbols in the output and preserve and maintain whitespace.
						Instruction 8: Return the output as a valid JSON object. Do not wrap the output in a string or markdown code block. Ensure the JSON is clean, parseable, and properly formatted.
					
						Please ensure that the output follows the format: {"key(numeric value)": "(translations of the strings in %s language)"}
					
						Strings are :- %s',
						sanitize_text_field($source_language),
						sanitize_text_field($target_language),
						sanitize_text_field($source_language),
						sanitize_text_field($target_language),
						sanitize_text_field($source_language),
						sanitize_text_field($target_language),
						sanitize_text_field($target_language),
						json_encode($strings)
					);

					// If the custom prompt is not empty, add it to the content
					if ( $custom_prompt && ! empty( $custom_prompt ) ) {
						$content .= 'Instruction 9: ' . sanitize_text_field( $custom_prompt );
					}

					if ( $service_slug === 'deepl' ) {
						$atfpp_deepl_option_name = $atfpp_is_wp_ai_client_exist ? 'connectors_ai_deepl_api_key' : 'Atfpp_Ai_Translate_deepl_api_key';
						$deepl_api_key = sanitize_text_field( get_option( sanitize_text_field( $atfpp_deepl_option_name ) ) );

						$content = $this->create_deepl_data( $source_language, $target_language, $strings, $has_glossary_terms, $matched_terms, $custom_prompt, $deepl_api_key );

						$deepl_data = json_decode( $content, true );
					}

					// If glossary instructions are present, add them as a separate instruction
					if ( $glossary_instructions && ! empty( $glossary_instructions ) && $service_slug !== 'deepl' ) {
						$instruction_number = ( $custom_prompt && ! empty( $custom_prompt ) ) ? 9 : 8;
						$content           .= 'Instruction ' . $instruction_number . ': ' . $glossary_instructions;
					}

					// Try to generate the text
					try {
						$text = $this->translate_text($content, $service_slug, $selected_model, $ai_request_timeout);

						// Clean the text
						$cleanText = preg_replace( '/(^```json\n|```$)/', '', $text );

						$cleanText = str_replace( '<ATFPP_NEW_L>', '\n', $cleanText );
						$cleanText = str_replace( '<ATFPP_NEW_R>', '\r', $cleanText );

						// Replace the double backslashes with a single backslash
						$final_text = preg_replace( '/\\\\{2,}([\'"n])/', '\\\$1', $cleanText );

						$translated_text = json_decode( $final_text, true );

						if ( is_array( $translated_text ) && count( $translated_text ) === 1 ) {
							$key            = array_keys( $translated_text )[0];
							$orignal_string = json_decode( $translated_text[ $key ], true );
							if ( isset( $translated_text[ $key ] ) && json_decode( $translated_text[ $key ] ) !== null && isset( $orignal_string[ $key ] ) && json_decode( $orignal_string[ $key ] ) === null ) {
								$translated_text[ $key ] = json_decode( $translated_text[ $key ], true )[ $key ];
								$final_text = json_encode( $translated_text );
							}
						}

						if(is_string($final_text) && (str_starts_with($final_text, '"') || str_ends_with($final_text, '"'))){
							$final_text = trim( $final_text, '"' );
						}

						// Return the data
						$data = array(
							'translate_data' => json_decode( $final_text ),
							'text'           => $cleanText,
						);

						$deepl_glossary_type = get_option( 'atfpp_deepl_glossary_type', 'default' );

						// If we created a DeepL glossary, clean it up
						if ( $service_slug === 'deepl' && isset( $deepl_data['glossary_id'] ) && $deepl_glossary_type !== 'deepl' ) {
							wp_remote_request(
								ATFPP_Helper::deepl_base_url( $deepl_api_key ) . '/v3/glossaries/' . $deepl_data['glossary_id'],
								array(
									'method'  => 'DELETE',
									'headers' => array(
										'Authorization' => 'DeepL-Auth-Key ' . $deepl_api_key,
									),
								)
							);
						}

						wp_send_json_success( $data );
					} catch ( Exception $e ) {
						wp_send_json_error( 'Error during text generation: ' . $e->getMessage() );
					}
				} else {
					wp_send_json_error(
						sprintf(
							'%s service is not available.',
							$service_slug === 'google' ? 'GeminiAI' : ucfirst( $service_slug )
						)
					);
				}
			}

				wp_send_json_error( 'You are not authorized to perform this action.' );
		}

		/**
		 * Translate the text
		 *
		 * @param string $content The content to translate.
		 * @param string $provider The provider to use.
		 * @param string $selected_model The model to use.
		 * @param int $timeout The timeout.
		 * @return string The translated text.
		 */
		private function translate_text( $content, $provider, $selected_model, $timeout = 120 ) {
			$is_wp_ai_client_exist=ATFPP_Helper::is_wp_ai_client_exist();

			$text='';
			
			if($is_wp_ai_client_exist){
				add_filter( 'wp_ai_client_default_request_timeout', function($time) use ($timeout){
					return $timeout;
				}, 10, 1 );

				$registry = \WordPress\AiClient\AiClient::defaultRegistry();
				$builder = wp_ai_client_prompt();
				$provider_class = $registry->getProviderClassName( $provider );
				
				if(!empty($selected_model)){
					$model = $provider_class::model( $selected_model );
					
					$builder->using_model( $model );
				}

				if($provider === 'deepl'){
					$model = $provider_class::model('deepl-translate');
					$builder->using_model( $model );
				}

				$text     = $builder
					->using_provider( $provider )
                    ->with_text( $content )
                    ->generate_text();
			}else{
				$model_params = array(
					'feature'      => 'my-test-feature',
					'capabilities' => array( AI_Capability::TEXT_GENERATION ),
				);
	
				if ( ! empty( $selected_model ) ) {
					$model_params['model'] = $selected_model;
				}
	
				// Get the service
				$service = atfpp_ai_services()->get_available_service( $provider );
	
				$candidates = $service
					->get_model( $model_params, array( 'timeout' => (int) $timeout ) )
					->generate_text( $content );
	
				// Get the text from the candidates
				$text = Helpers::get_text_from_contents(
					Helpers::get_candidate_contents( $candidates )
				);
			}

			return $text;
		}

		public function get_pending_posts_ids( $params ) {
			if ( ! is_user_logged_in() ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}
			if ( ! current_user_can( 'edit_posts' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			if ( ! wp_verify_nonce( $params['privateKey'], 'atfpp_pending_posts_ids_nonce' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			if ( ! isset( $params['lang'] ) || empty( $params['lang'] ) ) {
				wp_send_json_error( 'Empty target language Select at least one language' );
			}
			
			if ( ! isset( $params['ids'] ) || empty( $params['ids'] ) ) {
				wp_send_json_error( 'Empty post IDs Select at least one post to translate' );
			}

			$slug_translation_option = '';

			$post_ids        = json_decode( $params['ids'] );
			$post_ids        = array_map( 'absint', $post_ids );
			// check language exists or not
			$translate_lang = json_decode( $params['lang'] );
			$translate_lang = array_map( 'sanitize_text_field', $translate_lang );
			$posts_translate    = array();
			$re_translate_posts = array();
			$gutenberg_block    = false;
			$atfpp_taxonomy_type      = isset( $params['taxonomy_type'] ) ? sanitize_text_field( $params['taxonomy_type'] ) : '';
			global $polylang;
			
			$post_meta_sync = true;
			if ( ! isset( PLL()->options['sync'] ) || ( isset( PLL()->options['sync'] ) && ! in_array( 'post_meta', PLL()->options['sync'] ) ) ) {
				$post_meta_sync = false;
			}
			
			if(!$post_meta_sync){
				$allowed_meta_fields = ATFPP_Helper::get_instance()->get_allowed_custom_fields('post');
			}else{
				$allowed_meta_fields = array();
			}

			$pll_langs           = $polylang->model->get_languages_list();
			$pll_langs_slugs     = array_column( $pll_langs, 'slug' );

			
			$defalt_language = pll_default_language( 'slug' );

			foreach ( $post_ids as $post_id ) {
				$post_id = intval( $post_id );
				
				if ( isset($atfpp_taxonomy_type) && !empty($atfpp_taxonomy_type) ) {
					// Check if user can edit taxonomy term if $atfpp_taxonomy_type is set
					if ( taxonomy_exists( $atfpp_taxonomy_type ) ) {
						$term = get_term( $post_id, $atfpp_taxonomy_type );
						if ( is_a( $term, 'WP_Term' ) ) {
							if ( ! current_user_can( 'edit_term', $term->term_id ) ) {
								continue;
							}
						} else {
							// Term does not exist or error.
							continue;
						}
					} else {
						// Fallback: check for post editing capability (back-compat).
						if( ! current_user_can( 'edit_post', $post_id ) ) {
							continue;
						}
					}
				}else if(!current_user_can( 'edit_post', $post_id )) {
					continue;
				}
				
				$all_post_ids        = isset($atfpp_taxonomy_type) && !empty($atfpp_taxonomy_type) ? pll_get_term_translations( $post_id ) : pll_get_post_translations( $post_id );

				$current_source_lang = isset($atfpp_taxonomy_type) && !empty($atfpp_taxonomy_type) ? $polylang->model->term->get_language( $post_id )->slug : $polylang->model->post->get_language( $post_id )->slug;

				$already_exist = false;

				$stored_post_ids = array_keys( $posts_translate );

				$intersect_values = array_intersect( $all_post_ids, $stored_post_ids );

				$re_translate_post_found    = false;
				$re_translation_parent_post = array();

				if ( count( $intersect_values ) > 0 ) {
					if ( $current_source_lang === $defalt_language ) {
						foreach ( $intersect_values as $intersect_value ) {
							unset( $posts_translate[ $intersect_value ] );
						}
					} else {
						$already_exist = true;
					}
				}

				if ( $already_exist ) {
					continue;
				}

				if(!empty($atfpp_taxonomy_type)){
					$editor_type = 'taxonomy';
				}

				if(!$gutenberg_block && empty($atfpp_taxonomy_type)){
					$post_data = get_post( $post_id );
					$editor_type= has_blocks( $post_data->post_content ) ? 'block' : 'classic';
					$elementor_enabled = get_post_meta( $post_id, '_elementor_edit_mode', true );

					if(ATFPP_Helper::compare_divi_version()){
						$is_divi_editor = $this->get_editor_type($post_id);
						if($is_divi_editor === 'Divi'){
							$editor_type = 'divi';
						}
					}
				
					if ( $elementor_enabled && 'builder' === $elementor_enabled && defined( 'ELEMENTOR_VERSION' ) ) {
						$elementor_data = get_post_meta( $post_id, '_elementor_data', true );
		
						if ( $elementor_data && '' !== $elementor_data ) {
							$editor_type = 'elementor';
						}
					}
		
					if ( $editor_type === 'block' ) {
						$gutenberg_block = true;
					}
				}

				$posts_translate[ $post_id ] = array(
					'title' => get_the_title( $post_id ),
				);

				foreach ( $translate_lang as $lang ) {
					if ( in_array( $lang, $pll_langs_slugs ) ) {
						$post_translate_status = isset($atfpp_taxonomy_type) && !empty($atfpp_taxonomy_type) ? $polylang->model->term->get_translation( $post_id, $lang ) : $polylang->model->post->get_translation( $post_id, $lang );
						if ( ! $post_translate_status ) {
							$posts_translate[ $post_id ]['languages'][] = $lang;
						}
					}
				}

				$exist_parent_post = $this->re_translation_entries( $all_post_ids, $polylang, $translate_lang, $re_translate_post_found, $re_translation_parent_post, $posts_translate, true );

				if($re_translate_post_found && count($re_translation_parent_post) > 0){
					foreach($re_translation_parent_post as $parent_post_id => $updated_fields){
						if(!isset($posts_translate[ $parent_post_id ])){
							$posts_translate[ $parent_post_id ] = array(
								'title' => get_the_title( $parent_post_id ),
							);
						}
					}
				}
			}

			$data=array('posts' => $posts_translate);

			if ( ! $post_meta_sync ) {
				$data['allowedMetaFields'] = json_encode( $allowed_meta_fields );
			}

			if ( $gutenberg_block ) {
				$block_parse_rules       = ATFPP_Helper::get_instance()->get_block_parse_rules();
				$data['blockParseRules'] = json_encode( $block_parse_rules );
			}

			wp_send_json_success( $data );
		}

		public function bulk_translate_entries( $params ) {
			// Check if the user is logged in and has the necessary capabilities
			if ( ! is_user_logged_in() ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}
			if ( ! current_user_can( 'edit_posts' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			// Verify the nonce
			if ( ! wp_verify_nonce( $params['privateKey'], 'atfpp_bulk_translate_entries_nonce' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			global $polylang;

			$slug_translation_option = get_option( 'atfp_slug_translation_option', 'title_translate' );

			// check language exists or not
			$translate_lang = json_decode( $params['lang'] );
			$translate_lang = array_map( 'sanitize_text_field', $translate_lang );

			$post_ids           = json_decode( $params['ids'] );
			$posts_translate    = array();
			$re_translate_posts = array();
			$gutenberg_block    = false;

			$post_meta_sync = true;
			if ( ! isset( PLL()->options['sync'] ) || ( isset( PLL()->options['sync'] ) && ! in_array( 'post_meta', PLL()->options['sync'] ) ) ) {
				$post_meta_sync = false;
			}

			$defalt_language = pll_default_language( 'slug' );

			if ( count( $translate_lang ) > 0 && ! ( count( $post_ids ) < 1 ) ) {
				$pll_langs           = $polylang->model->get_languages_list();
				$pll_langs_slugs     = array_column( $pll_langs, 'slug' );
				$allowed_meta_fields = ATFPP_Helper::get_instance()->get_allowed_custom_fields('post');

				foreach ( $post_ids as $postId ) {

					$post_id = intval( $postId );
					if ( ! current_user_can( 'edit_post', $postId ) ) {
						continue;
					}

					$all_post_ids        = pll_get_post_translations( $post_id );
					$current_source_lang = $polylang->model->post->get_language( $postId )->slug;

					$already_exist = false;

					$stored_post_ids = array_keys( $posts_translate );

					$intersect_values = array_intersect( $all_post_ids, $stored_post_ids );

					$re_translate_post_found    = false;
					$re_translation_parent_post = array();

					if ( count( $intersect_values ) > 0 ) {
						if ( $current_source_lang === $defalt_language ) {
							foreach ( $intersect_values as $intersect_value ) {
								unset( $posts_translate[ $intersect_value ] );
							}
						} else {
							$already_exist = true;
						}
					}

					if ( $already_exist ) {
						continue;
					}

					$posts_translate[ $postId ]['sourceLanguage'] = $current_source_lang;
					$this->fetch_translation_data( $post_id, $posts_translate, $translate_lang, $slug_translation_option, $allowed_meta_fields, $post_meta_sync, $pll_langs_slugs, $gutenberg_block );

					$exist_parent_post = $this->re_translation_entries( $all_post_ids, $polylang, $translate_lang, $re_translate_post_found, $re_translation_parent_post, $posts_translate );

					if ( $re_translate_post_found && count( $re_translation_parent_post ) > 0 ) {
						foreach ( $re_translation_parent_post as $parent_post_id => $updated_fields ) {
							$this->fetch_translation_data( $parent_post_id, $posts_translate, $translate_lang, $slug_translation_option, $allowed_meta_fields, $post_meta_sync, $pll_langs_slugs, $gutenberg_block, true, $updated_fields );
						}
					}

					if ( $exist_parent_post && count( $exist_parent_post ) > 0 ) {
						foreach ( $exist_parent_post as $parent_post_id ) {
							if ( isset( $posts_translate[ $parent_post_id ] ) && ! isset( $posts_translate[ $parent_post_id ]['languages'] ) || count( $posts_translate[ $parent_post_id ]['languages'] ) < 1 ) {
								$re_translate_fields = array();
								$re_translate_posts  = $posts_translate[ $parent_post_id ]['ReTranslatePosts'];
								$valid_fields        = ATFP_Re_Translation::re_translate_fields();

								foreach ( $re_translate_posts as $re_translate_posts ) {
									foreach ( $re_translate_posts as $key => $value ) {
										$key_name = substr( $key, 13 );
										if ( true === $value && in_array( $key_name, $valid_fields ) && ! isset( $re_translate_fields[ $key_name ] ) ) {
											$re_translate_fields[ $key_name ] = true;
										}
									}
								}

								foreach ( $valid_fields as $valid_field ) {
									if ( ! isset( $re_translate_fields[ $valid_field ] ) && $valid_field !== 'title' ) {
										if ( isset( $posts_translate[ $parent_post_id ][ $valid_field ] ) ) {
											unset( $posts_translate[ $parent_post_id ][ $valid_field ] );
										}
									}
								}
							}
						}
					}
				}
			}

			$data = array(
				'posts'                    => $posts_translate,
				'CreateTranslatePostNonce' => wp_create_nonce( 'atfpp_create_translate_post_nonce' ),
			);

			if ( ! $post_meta_sync ) {
				$data['allowedMetaFields'] = json_encode( $allowed_meta_fields );
			}

			if ( $gutenberg_block ) {
				$block_parse_rules       = ATFPP_Helper::get_instance()->get_block_parse_rules();
				$data['blockParseRules'] = json_encode( $block_parse_rules );
			}

			if ( count( $posts_translate ) > 0 ) {
				wp_send_json_success( $data );
			} else {
				wp_send_json_error( 'No posts to translate' );
			}
		}

		private function re_translation_entries( $all_post_ids, $polylang, $translate_lang, &$re_translation_post, &$re_translation_parent_post, &$posts_translate, $only_languages = false ) {
			$exist_parent_post = array();

			foreach ( $all_post_ids as $transalted_post ) {
				$translated_post_id   = intval( $transalted_post );
				$translated_post_lang = $polylang->model->post->get_language( $translated_post_id )->slug;

				if ( in_array( $translated_post_lang, $translate_lang ) ) {
					$re_translate_data = ATFP_Re_Translation::retranslation_status( $translated_post_id );
					
					if ( isset( $re_translate_data['re_translation_status'] ) && true === $re_translate_data['re_translation_status'] && isset( $re_translate_data['parent_post_id'] ) && ! empty( $re_translate_data['parent_post_id'] ) ) {
						
						if ( ! isset( $re_translate_posts[ $translated_post_id ] ) ) {
							$parent_post_id = intval( $re_translate_data['parent_post_id'] );

							if($only_languages){
								if ( ! isset( $posts_translate[ $parent_post_id ] ) ) {
									$posts_translate[ $parent_post_id ] = array(
										'title' => get_the_title( $parent_post_id ),
									);
								}
	
								$posts_translate[ $parent_post_id ]['languages'][] = $translated_post_lang;
								continue;
							}

							$retranslate_fields = ATFP_Re_Translation::re_translate_fields();

							$nonce_key='';

							if ( ! isset( $posts_translate[ $parent_post_id ] ) ) {
								$re_translation_post                           = true;
								$re_translation_parent_post[ $parent_post_id ] = array();
								$update_post_source_lang                       = $polylang->model->post->get_language( $parent_post_id )->slug;
								$posts_translate[ $parent_post_id ]['sourceLanguage'] = $update_post_source_lang;
							} else {
								$exist_parent_post[] = $parent_post_id;
							}

							foreach ( $retranslate_fields as $retranslate_field ) {
								$retranslate_key = 're_translate_' . $retranslate_field;
								if ( isset( $re_translate_data[ $retranslate_key ] ) && true === $re_translate_data[ $retranslate_key ] ) {
									$nonce_key.=$retranslate_field === 'metaFields' ? 'meta_fields_' : $retranslate_field.'_';

									if ( ! isset( $posts_translate[ $parent_post_id ][$retranslate_field] ) ) {
										$re_translation_parent_post[ $parent_post_id ][ $retranslate_field ] = true;
									}
								}
							}

							if ( ! isset( $posts_translate[ $parent_post_id ]['ReTranslatePosts'] ) ) {
								$posts_translate[ $parent_post_id ]['ReTranslatePosts'] = array();
							}
							
							$posts_translate[ $parent_post_id ]['ReTranslatePosts'][ $translated_post_id ]             = $re_translate_data;
							$posts_translate[ $parent_post_id ]['ReTranslatePosts'][ $translated_post_id ]['language'] = $translated_post_lang;

							if(!empty($nonce_key)){
								$nonce_value=ATFP_Re_Translation::generate_retranslation_nonce(sanitize_text_field($nonce_key.$translated_post_id));
								$posts_translate[ $parent_post_id ]['ReTranslatePosts'][ $translated_post_id ]['validation_key'] = $nonce_value;
							}

							if(isset($re_translate_data['re_translate_metaFields']) && true === $re_translate_data['re_translate_metaFields']){
								$filtered_meta_fields=ATFP_Re_Translation::get_updated_post_metas((int) $translated_post_id, (int) $parent_post_id);
								$posts_translate[ $parent_post_id ]['ReTranslatePosts'][ $translated_post_id ]['metaFields'] = $filtered_meta_fields;
							}
						}
					}
				}
			}

			return $exist_parent_post;
		}

		private function fetch_translation_data( $post_id, &$Object, $target_language, $slug_translation, &$allowed_meta_fields, $post_meta_sync, $pll_langs_slugs, &$gutenberg_block = false, $re_translate = false, $re_transalte_fields = array() ) {
			global $polylang;

			$postId    = intval( $post_id );
			$post_data = get_post( $postId );

			$excerpt_fetch       = false === $re_translate || ( $re_translate && isset( $re_transalte_fields['excerpt'] ) && true === $re_transalte_fields['excerpt'] );
			$content_fetch       = false === $re_translate || ( $re_translate && isset( $re_transalte_fields['content'] ) && true === $re_transalte_fields['content'] );
			$custom_fields_fetch = false === $re_translate || ( $re_translate && isset( $re_transalte_fields['metaFields'] ) && true === $re_transalte_fields['metaFields'] );

			if ( ! $Object[ $postId ]['sourceLanguage'] ) {
				$Object[ $postId ]['sourceLanguage'] = false;
				$Object[ $postId ]['title'] = $post_data->post_title;
				$Object[ $postId ]['editor_type'] = has_blocks( $post_data->post_content ) ? 'block' : 'classic';
				$Object[ $postId ]['post_link']   = html_entity_decode( get_edit_post_link( $postId ) );
				return;
			}

			$elementor_enabled = get_post_meta( $postId, '_elementor_edit_mode', true );

			if ( ! $post_data ) {
				return;
			}

			if ( $slug_translation === 'slug_translate' ) {
				$Object[ $postId ]['post_name'] = urldecode( get_post_field( 'post_name', $postId ) );
			}

			$Object[ $postId ]['title'] = $post_data->post_title;

			if ( $content_fetch ) {
				$Object[ $postId ]['content'] = has_blocks( $post_data->post_content ) ? parse_blocks( $post_data->post_content ) : $post_data->post_content;
				$Object[ $postId ]['content'] = has_blocks( $post_data->post_content ) ? parse_blocks( $post_data->post_content ) : $post_data->post_content;
			}

			$Object[ $postId ]['editor_type'] = has_blocks( $post_data->post_content ) ? 'block' : 'classic';

			if ( isset( $post_data->post_excerpt ) && ! empty( $post_data->post_excerpt ) && $excerpt_fetch ) {
				$Object[ $postId ]['excerpt'] = $post_data->post_excerpt;
			}

			$Object[ $postId ]['sourceLanguage'] = ! isset( $Object[ $postId ]['sourceLanguage'] ) ? pll_default_language() : $Object[ $postId ]['sourceLanguage'];

			if ( ! $post_meta_sync && $custom_fields_fetch ) {
				$post_meta_fields    = get_post_meta( $postId );
				$existed_meta_fields = array_intersect( array_keys( $post_meta_fields ), array_keys( $allowed_meta_fields ) );

				foreach ( $existed_meta_fields as $key ) {
					if ( isset( $post_meta_fields[ $key ] ) && ! empty( $post_meta_fields[ $key ] ) && isset( $allowed_meta_fields[ $key ]['status'] ) && true === $allowed_meta_fields[ $key ]['status'] ) {
						$value                                   = $allowed_meta_fields[ $key ]['type'] && is_array( $post_meta_fields[ $key ] ) ? maybe_unserialize( $post_meta_fields[ $key ][0] ) : maybe_unserialize( $post_meta_fields[ $key ] );
						if($key === '_product_attributes' && is_array($value)){
							if(!empty($value)){
								foreach($value as $attribute_key => $attribute_value){
									$attribute_value_array=explode('|', $attribute_value['value']);
									$attribute_value_array=array_map('trim', $attribute_value_array);
									
									foreach($attribute_value_array as $index => $attribute_value){
										$allowed_meta_fields[ $key.'_atfpp_'.$attribute_key.'_atfpp_'.$index ]['type'] = gettype($attribute_value);
										$allowed_meta_fields[ $key.'_atfpp_'.$attribute_key.'_atfpp_'.$index ]['status'] = true;
										$Object[ $postId ]['metaFields'][ $key.'_atfpp_'.$attribute_key.'_atfpp_'.$index ] = $attribute_value;
									}
								}
							}
						}else{
							$Object[ $postId ]['metaFields'][ $key ] = $value;
						}
					}
				}
			}

			if(ATFPP_Helper::compare_divi_version()){
				$editor_type = $this->get_editor_type($postId);
				if($editor_type === 'Divi'){
					$Object[ $postId ]['editor_type'] = 'divi';
					$Object[ $postId ]['content']=$post_data->post_content;
					$elementor_enabled = false;
				}
			}

			$Object[ $postId ]['post_link'] = get_the_permalink( $postId );

			if ( $elementor_enabled && 'builder' === $elementor_enabled && defined( 'ELEMENTOR_VERSION' ) ) {
				$elementor_data = get_post_meta( $postId, '_elementor_data', true );

				if ( $elementor_data && '' !== $elementor_data ) {
					$Object[ $postId ]['editor_type'] = 'elementor';
					$elementor_data                   = array();

					if ( class_exists( '\Elementor\Plugin' ) && property_exists( '\Elementor\Plugin', 'instance' ) && $content_fetch ) {
						$elementor_data = \Elementor\Plugin::$instance->documents->get( $postId )->get_elements_data();
					}

					if ( $content_fetch ) {
						$Object[ $postId ]['content'] = $elementor_data;
					}

					if ( $custom_fields_fetch ) {
						unset( $Object[ $postId ]['metaFields']['_elementor_data'] );
					}
				}
			}

			if ( $Object[ $postId ]['editor_type'] === 'block' && ! $gutenberg_block ) {
				$gutenberg_block = true;
			}

			if ( $re_translate ) {
				return;
			}

			foreach ( $target_language as $lang ) {
				if ( in_array( $lang, $pll_langs_slugs ) ) {
					$post_translate_status = $polylang->model->post->get_translation( $postId, $lang );
					if ( ! $post_translate_status ) {
						$Object[ $postId ]['languages'][] = $lang;
					}
				}
			}
		}

		public function create_translate_post( $params ) {
			$re_translate = $this->validate_retranslation( $params->get_params() );

			if ( ! isset( $params['source_language'] ) || empty( $params['source_language'] ) ) {
				wp_send_json_error( 'Invalid source language' );
			}
			if ( ! isset( $params['post_id'] ) || ! isset( $params['target_language'] ) || ( ! isset( $params['post_title'] ) && ! isset( $params['post_content'] ) && ! $re_translate ) ) {
				wp_send_json_error( 'Invalid request' );
			}
			if ( ! isset( $params['target_language'] ) && empty( $params['target_language'] ) ) {
				wp_send_json_error( 'Invalid target language' );
			}
			if ( ! wp_verify_nonce( $params['privateKey'], 'atfpp_create_translate_post_nonce' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}
			if ( empty( $params['post_title'] ) && empty( $params['post_content'] ) && ! $re_translate ) {
				wp_send_json_error( 'Invalid request content & title empty' );
			}

			$params = $params->get_params();

			$post_id         = intval( sanitize_text_field( $params['post_id'] ) );
			$target_language = sanitize_text_field( $params['target_language'] );
			$editor_type     = sanitize_text_field( $params['editor_type'] );
			$source_language = sanitize_text_field( $params['source_language'] );

			$title = isset( $params['post_title'] ) ? sanitize_text_field( $params['post_title'] ) : false;

			$slug = isset( $params['post_name'] ) && ! empty( $params['post_name'] ) ? sanitize_text_field( $params['post_name'] ) : false;

			$excerpt = isset( $params['post_excerpt'] ) ? wp_kses_post( $params['post_excerpt'] ) : false;

			$content = isset( $params['post_content'] ) ? $params['post_content'] : '';

			$meta_fields = isset( $params['post_meta_fields'] ) ? $params['post_meta_fields'] : '';

			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			if ( isset( $re_translate['status'] ) && isset( $re_translate['post_id'] ) && ! current_user_can( 'edit_post', $re_translate['post_id'] ) ) {
				wp_send_json_error( 'You are not authorized to perform Re-Translation action.' );
			}

			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- ATFPP is our plugin prefix
			define( 'DOING_ATFPP_BULK_POST_TRANSLATION', true );

			$post_data = array(
				'post_content' => $content,
			);

			if ( $title && ! empty( $title ) ) {
				$post_data['post_title'] = sanitize_text_field( $title );
			}

			if ( $excerpt && ! empty( $excerpt ) ) {
				$post_data['post_excerpt'] = sanitize_text_field( $excerpt );
			}

			if ( $meta_fields && ! empty( $meta_fields ) ) {
				$post_data['post_meta_fields'] = json_decode( $meta_fields, true );
			}

			if ( ! isset( $re_translate['status'] ) ) {
				$slug_translation_option = get_option( 'atfp_slug_translation_option', 'title_translate' );

				if ( $slug_translation_option === 'slug_translate' && $slug && ! empty( $slug ) ) {
					$post_data['post_name'] = sanitize_title( $slug );
				} elseif ( $slug_translation_option === 'slug_keep' ) {
					$post_data['post_name'] = sanitize_text_field( get_post_field( 'post_name', $post_id ) );
				} else {
					$post_data['post_name'] = sanitize_title( $title );
				}
			}

			if ( isset( $post_data['post_content'] ) && ! empty( $post_data['post_content'] ) ) {
				$source_post_content=get_post_field('post_content', $post_id);
				if ( $editor_type === 'elementor' ) {
					$post_data['meta_fields']['_elementor_data'] = $post_data['post_content'];
					unset( $post_data['post_content'] );
				} elseif ( $editor_type === 'block') {

					$blocks = json_decode( $post_data['post_content'], true );

					$atfpp_sanitized_content = new ATFP_Sanitized_Content( $source_post_content );
					$post_data['post_content'] = $atfpp_sanitized_content->get_sanitized_content(serialize_blocks( $blocks ));
					
				}elseif ( $editor_type === 'divi' ) {
					$blocks = json_decode( $post_data['post_content'], true );

					$atfpp_sanitized_content = new ATFP_Sanitized_Content( $source_post_content );
					$divi_content = $atfpp_sanitized_content->get_sanitized_content(serialize_blocks( $blocks ));

					if(class_exists(MigrationUtils::class) && method_exists(MigrationUtils::class, 'ensure_placeholder_wrapper')){
						$post_data['post_content'] = MigrationUtils::ensure_placeholder_wrapper($divi_content);
					}else{
						$post_data['post_content'] = "<!-- wp:divi/placeholder -->\n" . $divi_content . "\n<!-- /wp:divi/placeholder -->";
					}
				} elseif ( $editor_type === 'classic' ) {
					$class_editor_content = json_decode( $params['post_content'], true );

				 	$atfpp_sanitized_content = new ATFP_Sanitized_Content( $source_post_content );
					$post_data['post_content'] = $atfpp_sanitized_content->get_sanitized_content($class_editor_content);
				}else {
					$atfpp_sanitized_content = new ATFP_Sanitized_Content( $source_post_content );
					$post_data['post_content'] = $atfpp_sanitized_content->get_sanitized_content($post_data['post_content']);
				}
			}

			global $polylang;
			$post_clone = new ATFP_Posts_Clone( $polylang );
			$post_id    = $post_clone->copy_post( $post_id, $source_language, $target_language, false, $post_data, $re_translate );

			if ( ! $post_id ) {
				wp_send_json_error( 'Unable to create the translated post for parent post ID ' . $post_id . ' in ' . $target_language . '.' );
			} else {

				$post_link      = html_entity_decode( get_the_permalink( $post_id ) );
				$post_title     = html_entity_decode( get_the_title( $post_id ) );
				$post_edit_link = html_entity_decode( get_edit_post_link( $post_id ) );

				if(isset($re_translate['status']) && true === $re_translate['status']){
					ATFP_Re_Translation::delete_re_translation_data((int) $post_id);
				}

				wp_send_json_success(
					array(
						'post_id'                     => $post_id,
						'target_language'             => $target_language,
						'post_link'                   => $post_link,
						'post_title'                  => $post_title,
						'post_edit_link'              => $post_edit_link,
						'update_translate_data_nonce' => wp_create_nonce( 'atfp_translate_nonce' ),
					)
				);
			}
		}

		private function validate_retranslation( $data ) {

			if ( isset( $data['reTranslateData'] ) && ! empty( $data['reTranslateData'] ) ) {
				$re_translation_data = json_decode( $data['reTranslateData'], true );

				if ( json_last_error() !== JSON_ERROR_NONE ) {
					wp_send_json_error( __( 'Retranslation data is not valid', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				}

				if ( isset( $re_translation_data['status'] ) && false === $re_translation_data['status'] ) {
					return false;
				}

				if ( ! isset( $re_translation_data['status'] ) || true !== $re_translation_data['status'] ) {
					wp_send_json_error( __( 'Retranslation data is not valid', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				}

				if ( ! isset( $re_translation_data['privateKey'] ) || empty( $re_translation_data['privateKey'] ) ) {
					wp_send_json_error( __( 'ReTranslate Nonce key not exist', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				}
				$private_key = sanitize_text_field( wp_unslash( $re_translation_data['privateKey'] ) );

				if ( ! isset( $re_translation_data['postId'] ) || empty( $re_translation_data['postId'] ) ) {
					wp_send_json_error( __( 'Post ID not exist in retranslation data', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				}

				if ( ! isset( $re_translation_data['fieldsType'] ) || empty( $re_translation_data['fieldsType'] ) ) {
					wp_send_json_error( __( 'Valid translation fields key not exist in retranslation data', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				}

				$current_post_id = (int) sanitize_text_field( wp_unslash( $re_translation_data['postId'] ) );

				if ( ! is_array( $re_translation_data['fieldsType'] ) || empty( $re_translation_data['fieldsType'] ) ) {
					wp_send_json_error( __( 'Valid translation fields key not exist in retranslation data', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				}

				$valid_fields = array_map( 'sanitize_text_field', wp_unslash( $re_translation_data['fieldsType'] ) );

				if ( in_array( 'metaFields', $valid_fields ) ) {
					$meta_field_index = array_search( 'metaFields', $valid_fields );

					$valid_fields[ $meta_field_index ] = 'meta_fields';
				}

				$unique_key = 'atfp-re-translation-nonce-' . implode( '_', $valid_fields ) . '_' . $current_post_id;

				if ( ! wp_verify_nonce( $private_key, sanitize_text_field( wp_unslash( $unique_key ) ) ) ) {
					wp_send_json_error( __( 'ReTranslate Nonce validation failed', 'autopoly-ai-translation-for-polylang-pro' ), 400 );
				}

				return array(
					'status'     => $re_translation_data['status'],
					'postId'     => $current_post_id,
					'fieldsType' => $valid_fields,
				);
			}
			return false;
		}

		public function bulk_translate_taxonomy_entries( $params ) {
			if ( ! isset( $params['taxonomy'] ) || empty( $params['taxonomy'] ) ) {
				wp_send_json_error( 'Invalid taxonomy' );
			}
			if ( ! isset( $params['lang'] ) || empty( $params['lang'] ) ) {
				wp_send_json_error( 'Invalid language' );
			}
			if ( ! isset( $params['privateKey'] ) || empty( $params['privateKey'] ) ) {
				wp_send_json_error( 'Invalid private key' );
			}
			if ( ! isset( $params['ids'] ) || empty( $params['ids'] ) ) {
				wp_send_json_error( 'Invalid ids' );
			}

			// Check if the user is logged in and has the necessary capabilities
			if ( ! is_user_logged_in() ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}
			if ( ! current_user_can( 'edit_posts' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			$params = $params->get_params();

			// Verify the nonce
			if ( ! wp_verify_nonce( $params['privateKey'], 'atfpp_bulk_translate_entries_nonce' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			$slug_translation_option = get_option( 'atfp_slug_translation_option', 'title_translate' );

			$translate_lang = json_decode( $params['lang'] );

			$taxonomy_translate = array();

			$meta_fields_fetch = false;

			if ( $translate_lang && count( $translate_lang ) > 0 ) {
				global $polylang;
				$pll_langs       = $polylang->model->get_languages_list();
				$pll_langs_slugs = array_column( $pll_langs, 'slug' );

				$taxonomy     = sanitize_text_field( $params['taxonomy'] );
				$taxonomy_ids = json_decode( $params['ids'] );
				
				$post_meta_sync = false;
				$allowed_meta_fields = array();

				$allowed_meta_fields = ATFPP_Helper::get_instance()->get_allowed_custom_fields('term');

				foreach ( $taxonomy_ids as $taxonomy_id ) {
					$taxonomy_translate[ $taxonomy_id ]['sourceLanguage'] = pll_get_term_language( $taxonomy_id );
					$taxonomy_data                                        = get_term( $taxonomy_id, $taxonomy );

					if ( ! $taxonomy_translate[ $taxonomy_id ]['sourceLanguage'] ) {
						$taxonomy_translate[ $taxonomy_id ]['sourceLanguage'] = false;
						$taxonomy_translate[ $taxonomy_id ]['title']          = $taxonomy_data->name;
						$taxonomy_translate[ $taxonomy_id ]['editor_type']    = 'taxonomy';
						$taxonomy_translate[ $taxonomy_id ]['post_link']      = html_entity_decode( get_edit_term_link( $taxonomy_data->term_id, $taxonomy_data->taxonomy ) );
						continue;
					}

					$taxonomy_translate[ $taxonomy_id ]['title'] = $taxonomy_data->name;

					if ( $slug_translation_option === 'slug_translate' ) {
						$taxonomy_translate[ $taxonomy_id ]['post_name'] = urldecode( $taxonomy_data->slug );
					}

					$taxonomy_translate[ $taxonomy_id ]['editor_type'] = 'taxonomy';

					if ( $taxonomy_data->description && ! empty( $taxonomy_data->description ) ) {
						$taxonomy_translate[ $taxonomy_id ]['content'] = $taxonomy_data->description;
					}

					if ( ! $post_meta_sync ) {
						$taxonomy_meta_fields=get_term_meta( $taxonomy_id );
						$existed_meta_fields = array_intersect( array_keys( $taxonomy_meta_fields ), array_keys( $allowed_meta_fields ) );

						if(count($existed_meta_fields) > 0 && !$meta_fields_fetch){
							$meta_fields_fetch = true;
						}
		
						foreach ( $existed_meta_fields as $key ) {
							if ( isset( $taxonomy_meta_fields[ $key ] ) && ! empty( $taxonomy_meta_fields[ $key ] ) && isset( $allowed_meta_fields[ $key ]['status'] ) && true === $allowed_meta_fields[ $key ]['status'] ) {
								$value                                   = $allowed_meta_fields[ $key ]['type'] && is_array( $taxonomy_meta_fields[ $key ] ) ? maybe_unserialize( $taxonomy_meta_fields[ $key ][0] ) : maybe_unserialize( $taxonomy_meta_fields[ $key ] );
								$taxonomy_translate[ $taxonomy_id ]['metaFields'][ $key ] = $value;
							}
						}
					}

					foreach ( $translate_lang as $lang ) {
						if ( in_array( $lang, $pll_langs_slugs ) ) {
							$post_translate_status = pll_get_term( $taxonomy_id, $lang );

							if ( ! $post_translate_status ) {
								$taxonomy_translate[ $taxonomy_id ]['languages'][] = $lang;
							} else {
								$term = get_term( $post_translate_status, $taxonomy );

								$title = isset( $term->name ) ? $term->name : '';
								$slug  = get_term_link( $post_translate_status, $taxonomy );

								if ( is_wp_error( $slug ) || empty( $slug ) ) {
									$slug = '';
								}

								$taxonomy_translate[ $taxonomy_id ]['postExists'][ $lang ] = array(
									'post_title' => $title,
									'post_url'   => $slug,
								);
							}
						}
					}
				}
			}

			$data = array(
				'posts'                    => $taxonomy_translate,
				'CreateTranslatePostNonce' => wp_create_nonce( 'atfpp_create_translate_taxonomy_nonce' ),
			);

			if ( ! $post_meta_sync && $meta_fields_fetch ) {
				$data['allowedMetaFields'] = json_encode( $allowed_meta_fields );
			}

			if ( count( $taxonomy_translate ) > 0 ) {
				wp_send_json_success( $data );
			} else {
				wp_send_json_error( 'No taxonomy posts to translate' );
			}
		}

		public function create_translate_taxonomy( $params ) {
			if ( ! isset( $params['term_id'] ) || empty( $params['term_id'] ) ) {
				wp_send_json_error( 'Invalid term id' );
			}
			if ( ! isset( $params['target_language'] ) || empty( $params['target_language'] ) ) {
				wp_send_json_error( 'Invalid target language' );
			}
			if ( ! isset( $params['taxonomy'] ) || empty( $params['taxonomy'] ) ) {
				wp_send_json_error( 'Invalid taxonomy' );
			}
			if ( ! isset( $params['source_language'] ) || empty( $params['source_language'] ) ) {
				wp_send_json_error( 'Invalid source language' );
			}
			if ( ! wp_verify_nonce( $params['privateKey'], 'atfpp_create_translate_taxonomy_nonce' ) ) {
				wp_send_json_error( 'You are not authorized to perform this action.' );
			}

			$params = $params->get_params();

			$term_id                 = intval( sanitize_text_field( $params['term_id'] ) );
			$target_language         = isset( $params['target_language'] ) ? sanitize_text_field( $params['target_language'] ) : '';
			$taxonomy                = isset( $params['taxonomy'] ) ? sanitize_text_field( $params['taxonomy'] ) : '';
			$taxonomy_name           = isset( $params['taxonomy_name'] ) ? sanitize_text_field( $params['taxonomy_name'] ) : '';
			$taxonomy_slug           = isset( $params['taxonomy_slug'] ) ? sanitize_title( $params['taxonomy_slug'] ) : '';
			$taxonomy_description    = isset( $params['taxonomy_description'] ) ? wp_kses_post( $params['taxonomy_description'] ) : '';
			$meta_fields             = isset( $params['meta_fields'] ) ? json_decode( $params['meta_fields'], true ) : '';
			$slug_translation_option = get_option( 'atfp_slug_translation_option', 'title_translate' );

			if ( ! $target_language ) {
				wp_send_json_error( 'Invalid target language' );
			}
			if ( ! $taxonomy ) {
				wp_send_json_error( 'Invalid taxonomy' );
			}

			$get_term = get_term( $term_id, $taxonomy );

			$translations = new Translations();

			if ( $taxonomy_name && ! empty( $taxonomy_name ) ) {
				$entry = $this->create_translation_entry( $get_term->name, $taxonomy_name, 'name' );
				$translations->add_entry( $entry );
			}

			if ( $taxonomy_description && ! empty( $taxonomy_description ) ) {
				$entry = $this->create_translation_entry( $get_term->description, $taxonomy_description, 'description' );
				$translations->add_entry( $entry );
			}

			if ( $slug_translation_option === 'slug_translate' && $taxonomy_slug && ! empty( $taxonomy_slug ) ) {
				$taxonomy_slug = sanitize_title( $taxonomy_slug );
			} elseif ( $slug_translation_option === 'slug_keep' ) {
				$taxonomy_slug = sanitize_text_field( $get_term->slug );
			} else {
				$taxonomy_slug = sanitize_title( $taxonomy_name );
			}

			if ( $taxonomy_slug && ! empty( $taxonomy_slug ) ) {
				$entry = $this->create_translation_entry( $get_term->slug, $taxonomy_slug, 'slug' );
				$translations->add_entry( $entry );
			}

			if($meta_fields && !empty($meta_fields) && count($meta_fields) > 0){
				$original_meta_fields = get_term_meta( $term_id );
				foreach($meta_fields as $key => $value){
					if(isset($original_meta_fields[ $key ]) && !empty($original_meta_fields[ $key ])){
						$entry = $this->create_translation_entry( $original_meta_fields[ $key ], $value, 'meta_fields_'. $key );
						$translations->add_entry( $entry );
					}
				}
			}

			global $polylang;

			$target_language_object = $polylang->model->get_language( $target_language );
			$post_clone             = new ATFP_Term_Clone( $polylang );

			$term_id = $post_clone->translate(
				array(
					'id'   => $term_id,
					'data' => $translations,
				),
				$target_language_object,
				$meta_fields
			);

			if ( ! $term_id ) {
				wp_send_json_error( 'Unable to create the translated post for parent post ID ' . $term_id . ' in ' . $target_language_object . '.' );
				exit;
			}

			$term_url       = get_term_link( $term_id, $taxonomy );
			$term           = get_term( $term_id, $taxonomy );
			$term_title     = html_entity_decode( $term->name );
			$term_link      = $term_url && is_string( $term_url ) ? html_entity_decode( $term_url ) : '';
			$term_edit_link = html_entity_decode( get_edit_term_link( $term_id, $taxonomy ) );

			wp_send_json_success(
				array(
					'post_id'                     => $term_id,
					'target_language'             => $target_language,
					'post_link'                   => $term_link,
					'post_title'                  => $term_title,
					'post_edit_link'              => $term_edit_link,
					'update_translate_data_nonce' => wp_create_nonce( 'atfp_translate_nonce' ),
				)
			);
		}

		public function create_translation_entry( $singular, $translation, $context ) {
			$entry = new Translation_Entry(
				array(
					'singular'    => $singular,
					'translation' => array( $translation ),
					'context'     => $context,
				)
			);
			return $entry;
		}

		public function create_deepl_data( $source_language, $target_language, $strings, $has_glossary_terms, $matched_terms, $custom_prompt, $deepl_api_key ) {
			$data = array();

			$strings = str_replace( '\\n', '<ATFPP_NEW_L>', $strings );
			$strings = str_replace( '\\r', '<ATFPP_NEW_R>', $strings );

			$data['text']         = json_decode( $strings, true );
			$data['target_lang']  = $target_language;
			$data['tag_handling'] = 'html';

			// Get DeepL API key from options
			$deepl_glossary_type = get_option( 'atfpp_deepl_glossary_type', 'default' );
			$deepl_glossary_id   = get_option( 'atfpp_deepl_glossary_id', '' );

			// If DeepL glossary type is set to 'deepl' and DeepL glossary ID is set, use DeepL glossary
			if ( $deepl_glossary_type === 'deepl' && ! empty( $deepl_glossary_id ) ) {
				$data['glossary_id'] = $deepl_glossary_id;
			} elseif ( $has_glossary_terms && ! empty( $matched_terms ) && $deepl_glossary_type !== 'deepl' ) {
				// If DeepL glossary type is not set to 'deepl' and has glossary terms, create a new glossary
				// Format glossary entries for DeepL TSV format
				$entries = '';
				foreach ( $matched_terms as $term ) {
					$entries .= $term['term'] . "\t" . $term['translation'] . "\n";
				}

				$url = ATFPP_Helper::deepl_base_url( $deepl_api_key ) . '/v2/glossaries';

				// Create glossary in DeepL
				$glossary_response = wp_remote_post(
					$url,
					array(
						'headers' => array(
							'Authorization' => 'DeepL-Auth-Key ' . sanitize_text_field( $deepl_api_key ),
							'Content-Type'  => 'application/json',
						),
						'body'    => wp_json_encode(
							array(
								'name'           => 'AutoPoly Glossary ' . current_time( 'timestamp' ),
								'source_lang'    => $source_language,
								'target_lang'    => $target_language,
								'entries'        => $entries,
								'entries_format' => 'tsv',
							)
						),
						'timeout' => 20,
					)
				);


				if ( ! is_wp_error( $glossary_response ) ) {
					$glossary_data = json_decode( wp_remote_retrieve_body( $glossary_response ), true );
					if ( isset( $glossary_data['glossary_id'] ) ) {
						$data['glossary_id'] = $glossary_data['glossary_id'];
					}
				}
			}

			if ( isset( $custom_prompt ) && ! empty( $custom_prompt ) ) {
				$data['context'] = $custom_prompt;
			}

			if ( isset( $data['glossary_id'] ) ) {
				$data['source_lang'] = $source_language;
			}

			$content = json_encode( $data );
			return $content;
		}

		public function get_editor_type(int $post_id): string {
			$editor = '';

			if ('builder' === get_post_meta($post_id, '_elementor_edit_mode', true) && defined('ELEMENTOR_VERSION')) {
				$editor = 'Elementor';
			}else if ('on' === get_post_meta($post_id, '_et_pb_use_builder', true) && defined('ET_CORE')) {
				$editor = 'Divi';
			}

			return $editor;
		}
	}
endif;
