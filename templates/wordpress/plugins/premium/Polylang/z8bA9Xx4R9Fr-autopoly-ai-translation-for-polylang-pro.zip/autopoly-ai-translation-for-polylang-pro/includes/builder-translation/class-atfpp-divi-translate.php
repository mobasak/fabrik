<?php
/**
 * Do not access the page directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'ATFPP_DIVI_Translate' ) ) {
    /**
	 * Class ATFPP_DIVI_Translate
	 *
	 * This class handles the tran;ation for the DIVI Pages.
	 *
	 * @package ATFPP
	 */
    class ATFPP_DIVI_Translate{
        /**
		 * Singleton instance.
		 *
		 * @var ATFPP_DIVI_Translate
		 */
        private static $instance;

        /**
		 * Get the singleton instance.
		 *
		 * @return ATFPP_DIVI_Translate
		 */
        public static function get_instance() {
            if ( ! isset( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
		 * Constructor.
		 */
        public function __construct() {
            add_action('add_meta_boxes', array($this, 'atfpp_divi_post_languages'));
            add_action('divi_visual_builder_assets_before_enqueue_top_window_scripts', array($this, 'divi_translate_button'));
        }
        
        public function divi_translate_button()
        {
            $post_translate_status = get_post_meta(get_the_ID(), '_atfpp_divi_translate_status', true);
            $parent_post_id=get_post_meta(get_the_ID(), '_atfpp_divi_parent_post_id', true);
            
            $re_translate_data = ATFP_Re_Translation::retranslation_status(get_the_ID());
            $re_translate_status=isset($re_translate_data['re_translation_status']) && $re_translate_data['re_translation_status'] === true ? true : false;

            if((!isset($post_translate_status) || 'pending' !== $post_translate_status || !isset($parent_post_id)) && !$re_translate_status) {
                return;
            }
            
            wp_register_script('atfp-divi-translate', ATFPP_URL . 'assets/js/atfp-divi-editor.min.js', array('jquery'), ATFPP_V, true);
            wp_register_style('atfp-divi-translate', ATFPP_URL . 'assets/css/atfp-divi-editor.min.css', array(), ATFPP_V);

            $data = array(
                'postId' => get_the_ID(),
                'postType' => get_post_type(),
                'targetLangObject' => array(
                    'name' => pll_get_post_language(get_the_ID(), 'name'),
                ),
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'atfpUrl' => esc_url(ATFPP_URL),
            );

            $initial_translation_popup_hidden = get_post_meta(get_the_ID(), '_atfpp_initial_translation_popup_hidden', true);

            if(!$initial_translation_popup_hidden){
                $data['popupHiddenNonce'] = wp_create_nonce('atfp_hide_initial_translation_popup_'.get_the_ID());
            }

            if('true' === $initial_translation_popup_hidden){
                $data['hideInitialTranslationPopup'] = true;
            }

            if(is_array($re_translate_data) && count($re_translate_data) > 0){
                $data['re_translate_page']=true;
            }

            wp_localize_script('atfp-divi-translate', 'atfpDiviTranslateData', $data);

            wp_enqueue_script('atfp-divi-translate');
            wp_enqueue_style('atfp-divi-translate');
        }

        /**
         * Fetch the languages for translation of divi pages.
		 */
        function atfpp_divi_post_languages() {

            if(!ATFPP_Helper::compare_divi_version()){
                return;
            }
            
            $atfp_new_post=ATFPP_Helper::is_atfp_new_post();

            
			if ( $atfp_new_post ) {
                global $post;
                $current_post_id = $post->ID;

                $parent_post_id = 0;

                if(isset($_GET['from_post']) && isset($_GET['_wpnonce']) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'new-post-translation' )){
                    $parent_post_id = absint(isset( $_GET['from_post'] ) ? sanitize_key( $_GET['from_post'] ) : '');
                }

                if(!$parent_post_id) return;

                $editor = $this->get_editor_type($parent_post_id);

                if($editor !== 'Divi'){
                    return;
                }

                ATFPP_Helper::delete_initial_translation_data($current_post_id);

				if ( function_exists( 'PLL' ) ) {

					ATFP_Re_Translation::delete_re_translation_data( $current_post_id );

                    update_post_meta($current_post_id, '_atfpp_divi_translate_status', 'pending');
                    update_post_meta($current_post_id, '_atfpp_divi_parent_post_id', $parent_post_id);

				}
			}
		}

        private function get_editor_type(int $post_id): string {
            $editor = '';

            if ('on' === get_post_meta($post_id, '_et_pb_use_builder', true) && defined('ET_CORE')) {
                $editor = 'Divi';
            }

            return $editor;
        }
    }
}

