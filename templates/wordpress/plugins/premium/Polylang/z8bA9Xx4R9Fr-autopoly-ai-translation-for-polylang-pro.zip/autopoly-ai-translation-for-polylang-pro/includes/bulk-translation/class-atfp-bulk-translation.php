<?php

if(!defined('ABSPATH')) exit;

if(!class_exists('ATFPP_Bulk_Translation')):
    class ATFPP_Bulk_Translation
    {
        /**
         * Single instance of the class
         *
         * @var self
         */
        private static $instance;

        public static function get_instance()
        {
            if(!isset(self::$instance)) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        public function __construct()
        {
            add_action('current_screen', array($this, 'bulk_translate_btn'));
        }

        public function bulk_translate_btn($screen)
        {
            global $polylang;
        
            if(!$polylang || !property_exists($polylang, 'model')){
                return;
            }
            
            if(!class_exists('ATFPP_Helper') || !ATFPP_Helper::bulk_translation_render($screen)){
                return;
            }

            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is not required here
            $post_status=isset($_GET['post_status']) ? sanitize_text_field(wp_unslash($_GET['post_status'])) : '';
            
            if('trash' === $post_status){
                return;
            }

            add_filter( "views_{$screen->id}", array($this, 'atfpp_bulk_translate_button') );

            add_action('admin_footer', array($this, 'bulk_translate_container'));
        }

        public function atfpp_bulk_translate_button($views)
        {
            echo "<button class='button button-primary atfpp-bulk-translate-btn' style='display:none;'>Bulk Translate</button>";

            return $views;
        }

        public function bulk_translate_container()
        {
            echo "<div id='atfpp-bulk-translate-wrapper'></div>";
        }
    }
endif;