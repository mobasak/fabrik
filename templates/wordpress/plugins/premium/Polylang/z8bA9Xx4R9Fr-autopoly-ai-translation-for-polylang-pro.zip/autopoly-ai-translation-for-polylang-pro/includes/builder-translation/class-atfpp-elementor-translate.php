<?php
/**
 * Do not access the page directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'ATFPP_Elementor_Translate' ) ) {
    /**
	 * Class ATFPP_Elementor_Translate
	 *
	 * This class handles the tran;ation for the Elementor Pages.
	 *
	 * @package ATFPP
	 */
    class ATFPP_Elementor_Translate{
        /**
		 * Singleton instance.
		 *
		 * @var ATFPP_Elementor_Translate
		 */
        private static $instance;

        /**
		 * Get the singleton instance.
		 *
		 * @return ATFPP_Elementor_Translate
		 */
        public static function get_instance() {
            if ( ! isset( self::$instance ) ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
		 * Constructor.
		 */
        public function __construct() {
			add_action('add_meta_boxes', array($this, 'atfpp_elementor_post_languages'));
        }

        /**
		 * Fetch the languages for translation of elementor pages.
		 */
		function atfpp_elementor_post_languages() {
			$atfp_new_post=ATFPP_Helper::is_atfp_new_post();

			if ( $atfp_new_post ) {
				global $post;
				$current_post_id = $post->ID;

				$editor_type = $this->get_editor_type($current_post_id);

				if($editor_type !== 'Elementor'){
					return;
				}

				ATFPP_Helper::delete_initial_translation_data($current_post_id);

				if ( function_exists( 'PLL' ) ) {

					$parent_post_id = 0;

					if(isset($_GET['from_post']) && isset($_GET['_wpnonce']) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'new-post-translation' )){
						$parent_post_id = isset( $_GET['from_post'] ) ? absint( $_GET['from_post'] ) : 0;
					}

					if(!$parent_post_id) return;
					
					$parent_editor=get_post_meta($parent_post_id, '_elementor_edit_mode', true);
					$parent_elementor_data = get_post_meta( $parent_post_id, '_elementor_data', true );

					if($parent_editor === 'builder' || !empty($parent_elementor_data)){
						// Delete this old post meta data
						delete_post_meta( $parent_post_id, 'atfpp_elementor_translated' );
						delete_post_meta( $parent_post_id, 'atfp_parent_post_language_slug' );
						delete_post_meta( $current_post_id, 'atfpp_elementor_translated' );
						delete_post_meta( $current_post_id, 'atfp_parent_post_language_slug' );

						ATFP_Re_Translation::delete_re_translation_data( $current_post_id );

						$parent_post_language_slug = pll_get_post_language( $parent_post_id, 'slug' );
						update_post_meta( $current_post_id, '_atfp_parent_post_language_slug', $parent_post_language_slug );
					}
				}
			}
		}

		private function get_editor_type(int $post_id): string {
            $editor = '';

            if ('builder' === get_post_meta($post_id, '_elementor_edit_mode', true) && defined('ELEMENTOR_VERSION')) {
                $editor = 'Elementor';
            }

            return $editor;
        }
    }
}

