<?php
/**
 * Handles migration of legacy API keys to new provider option names for AI translation providers.
 *
 * This class provides methods to securely migrate, decrypt, and map API keys/options
 * for supported AI translation services during plugin upgrades, including OpenAI and Google.
 *
 * @package ATFPP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ATFPP_Provider_Key_Migration' ) ) {

	/**
	 * Class ATFPP_Provider_Key_Migration
	 *
	 * Migrates AI provider API keys from legacy to new option structure, handling decryption.
	 */
	class ATFPP_Provider_Key_Migration {

		/**
		 * Constructor: Attach migration routine to WordPress 'init' action.
		 */
		public function __construct() {
			$this->atfpp_migrate_connectors_api_keys();
		}

		/**
		 * Performs the migration of legacy API keys if required and not already migrated.
		 *
		 * Avoids double migration or migration if client/class doesn't exist.
		 *
		 * @return void
		 */
		private function atfpp_migrate_connectors_api_keys() {
			$is_wp_ai_client_exist = ATFPP_Helper::is_wp_ai_client_exist();
			$is_migrated           = get_option( 'atfpp_migrate_connectors_api_keys' );

			if ( true === $is_migrated || ! $is_wp_ai_client_exist ) {
				return;
			}

			$current_google_key = get_option( 'connectors_ai_google_api_key' );
			$current_openai_key = get_option( 'connectors_ai_openai_api_key' );
			$current_deepl_key = get_option( 'connectors_ai_deepl_api_key' );
			$legacy_google_raw  = get_option( 'Atfpp_Ai_Translate_google_api_key' );
			$legacy_openai_raw  = get_option( 'Atfpp_Ai_Translate_openai_api_key' );
			$legacy_deepl_raw  = get_option( 'Atfpp_Ai_Translate_deepl_api_key' );

			$legacy_google_plain = $this->get_plaintext_api_key_from_legacy_option( $legacy_google_raw );
			$legacy_openai_plain = $this->get_plaintext_api_key_from_legacy_option( $legacy_openai_raw );
			$legacy_deepl_plain = $this->get_plaintext_api_key_from_legacy_option( $legacy_deepl_raw );

			$enc_prefix = self::get_encrypted_option_prefix();

			// If decryption fails due to a changed salt/key, abort migration for this key.
			if (
				is_string( $legacy_google_raw ) &&
				'' !== $legacy_google_raw &&
				'' === $legacy_google_plain &&
				str_starts_with( $legacy_google_raw, $enc_prefix )
			) {
				return;
			}

			if (
				is_string( $legacy_openai_raw ) &&
				'' !== $legacy_openai_raw &&
				'' === $legacy_openai_plain &&
				str_starts_with( $legacy_openai_raw, $enc_prefix )
			) {
				return;
			}

			if (
				is_string( $legacy_deepl_raw ) &&
				'' !== $legacy_deepl_raw &&
				'' === $legacy_deepl_plain &&
				str_starts_with( $legacy_deepl_raw, $enc_prefix )
			) {
				return;
			}

			if ( ! empty( $legacy_google_plain ) && empty( $current_google_key ) ) {
				update_option( 'connectors_ai_google_api_key', $legacy_google_plain );
				delete_option( 'Atfpp_Ai_Translate_google_api_key' );
			}

			if ( ! empty( $legacy_openai_plain ) && empty( $current_openai_key ) ) {
				update_option( 'connectors_ai_openai_api_key', $legacy_openai_plain );
				delete_option( 'Atfpp_Ai_Translate_openai_api_key' );
			}

			if ( ! empty( $legacy_deepl_plain ) && empty( $current_deepl_key ) ) {
				update_option( 'connectors_ai_deepl_api_key', $legacy_deepl_plain );
				delete_option( 'Atfpp_Ai_Translate_deepl_api_key' );
			}

			update_option( 'atfpp_migrate_connectors_api_keys', true );
		}

		/**
		 * Attempts to extract the plaintext API key from a legacy option value.
		 * Handles both plaintext and encrypted formats.
		 *
		 * @param mixed $value Option value.
		 * @return string Plain API key, or empty string if unavailable.
		 */
		private function get_plaintext_api_key_from_legacy_option( $value ): string {
			if ( ! is_string( $value ) || '' === $value ) {
				return '';
			}

			$prefix = self::get_encrypted_option_prefix();

			if ( ! str_starts_with( $value, $prefix ) ) {
				return $value;
			}

			$decrypted = self::decrypt_encrypted_option_payload( substr( $value, strlen( $prefix ) ) );
			if ( '' === $decrypted ) {
				return '';
			}

			$unpacked = maybe_unserialize( $decrypted );

			return is_string( $unpacked ) ? $unpacked : '';
		}

		/**
		 * Returns the prefix expected for encrypted options.
		 * (Must match format used in the original Data_Encryption class.)
		 *
		 * @return string The encryption prefix.
		 */
		private static function get_encrypted_option_prefix(): string {
			return 'enc::';
		}

		/**
		 * Decrypts an encrypted legacy option value (base64(iv+ciphertext)).
		 *
		 * @param string $raw_value Encoded option value after prefix.
		 * @return string Plaintext value, or empty string on error.
		 */
		private static function decrypt_encrypted_option_payload( string $raw_value ): string {
			if ( ! extension_loaded( 'openssl' ) ) {
				return '';
			}

			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			$decoded_value = base64_decode( $raw_value, true );
			if ( false === $decoded_value ) {
				return '';
			}

			$method = 'aes-256-ctr';
			$ivlen  = openssl_cipher_iv_length( $method );
			$iv     = substr( $decoded_value, 0, $ivlen );
			$body   = substr( $decoded_value, $ivlen );
			$key    = self::get_encryption_key();
			$salt   = self::get_encryption_salt();

			$decrypted_value = openssl_decrypt( $body, $method, $key, 0, $iv );
			if ( ! $decrypted_value || substr( $decrypted_value, - strlen( $salt ) ) !== $salt ) {
				return '';
			}

			return substr( $decrypted_value, 0, - strlen( $salt ) );
		}

		/**
		 * Provides the default encryption key for migration, mimicking legacy logic.
		 *
		 * @return string Encryption key used for legacy API option decryption.
		 */
		private static function get_encryption_key(): string {
			if ( defined( 'AI_SERVICES_ENCRYPTION_KEY' ) && '' !== AI_SERVICES_ENCRYPTION_KEY ) {
				return AI_SERVICES_ENCRYPTION_KEY;
			}
			if ( defined( 'LOGGED_IN_KEY' ) && '' !== LOGGED_IN_KEY ) {
				return LOGGED_IN_KEY;
			}

			return 'test-key';
		}

		/**
		 * Provides the default encryption salt for migration, mirroring Data_Encryption.
		 *
		 * @return string Encryption salt used for legacy API option decryption.
		 */
		private static function get_encryption_salt(): string {
			if ( defined( 'AI_SERVICES_ENCRYPTION_SALT' ) && '' !== AI_SERVICES_ENCRYPTION_SALT ) {
				return AI_SERVICES_ENCRYPTION_SALT;
			}
			if ( defined( 'LOGGED_IN_SALT' ) && '' !== LOGGED_IN_SALT ) {
				return LOGGED_IN_SALT;
			}

			return 'test-salt';
		}
	}

	new ATFPP_Provider_Key_Migration();
}