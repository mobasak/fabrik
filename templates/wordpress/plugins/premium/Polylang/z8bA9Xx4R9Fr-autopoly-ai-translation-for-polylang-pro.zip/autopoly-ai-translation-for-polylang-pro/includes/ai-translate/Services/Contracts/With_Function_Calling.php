<?php
/**
 * Interface ATFPP\AI_Translate\Services\Contracts\With_Function_Calling
 *
 * @since 0.5.0
 * @package ai-services
 */

namespace ATFPP\AI_Translate\Services\Contracts;

/**
 * Interface for a model which supports function calling.
 *
 * @since 0.5.0
 */
interface With_Function_Calling {

}
