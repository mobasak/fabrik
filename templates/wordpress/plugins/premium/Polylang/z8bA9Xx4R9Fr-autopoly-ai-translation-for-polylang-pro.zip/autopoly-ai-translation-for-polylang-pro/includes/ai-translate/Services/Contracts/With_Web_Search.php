<?php
/**
 * Interface ATFPP\AI_Translate\Services\Contracts\With_Web_Search
 *
 * @since 0.7.0
 * @package ai-services
 */

namespace ATFPP\AI_Translate\Services\Contracts;

/**
 * Interface for a model which supports web search.
 *
 * @since 0.7.0
 */
interface With_Web_Search {

}
