<?php
/**
 * @package AutoPoly - AI Translation For Polylang (Pro)
 */
if(!defined('ABSPATH')) exit;

/**
 * Model for synchronizing WooCommerce products
 */
class ATFP_WooCommerce_Attributes_Clone {

	/**
	 * The ID of the source product.
	 *
	 * @var int
	 */
    private $source_product_id = 0;

	/**
	 * The ID of the target product.
	 *
	 * @var int
	 */
    private $target_product_id = 0;
	
	/**
	 * The ID of the source product.
	 *
	 * @var array
	 */
    private $source_product_attributes = array();
	
	/**
	 * The ID of the target product.
	 *
	 * @var array
	 */
    private $target_product_attributes = array();

	/**
	 * The ID of the target product.
	 *
	 * @var array
	 */
    private $translated_attributes = array();

	/**
	 * The ID of the source product.
	 *
	 * @var WC_Product_Variation
	 */
    private $target_product_variation = null;

	/**
	 * Constructor for ATFP_WooCommerce_Attributes_Clone.
	 *
	 * @since 1.0.0
	 *
	 * @param int $source_product_id The ID of the source product.
	 * @param int $target_product_id The ID of the target product.
	 */
	public function __construct($source_product_id, $target_product_id, $post_meta_fields) {
		if(!defined('DOING_ATFPP_BULK_POST_TRANSLATION')) return;

		$this->source_product_id = $source_product_id;
		$this->target_product_id = $target_product_id;
		$this->update_translated_attributes($post_meta_fields);
		$this->clone_variation();
	}

	private function update_translated_attributes($post_meta_fields){
		$target_product_attributes=get_post_meta($this->target_product_id, '_product_attributes', true);
		$updated_target_product_attributes=$target_product_attributes;
		$allowed_meta_fields = ATFPP_Helper::get_allowed_custom_fields('post');

		if(!isset($allowed_meta_fields['_product_attributes']) || !isset($allowed_meta_fields['_product_attributes']['status']) || $allowed_meta_fields['_product_attributes']['status'] !== true) return;
		
		foreach($target_product_attributes as $product_attribute_key => $product_attribute_value){
			if(isset($product_attribute_value['value']) && !empty($product_attribute_value['value'])){
				$atfp_product_values=explode('|', $product_attribute_value['value']);
				$translated_values=$atfp_product_values;
				
				foreach($atfp_product_values as $index => $atfp_product_value){
					if(!is_string($atfp_product_value)) continue;

					if(isset($post_meta_fields['_product_attributes_atfpp_'.$product_attribute_key.'_atfpp_'.$index])){
						$atfpp_product_transalted_value=$post_meta_fields['_product_attributes_atfpp_'.$product_attribute_key.'_atfpp_'.$index];

						if(!is_string($atfpp_product_transalted_value)) continue;

						$atfpp_product_source_value=$atfp_product_value;

						// Get leading spaces
						preg_match('/^\s*/', $atfpp_product_source_value, $start);
						$leading = $start[0];

						// Get trailing spaces
						preg_match('/\s*$/', $atfpp_product_source_value, $end);
						$trailing = $end[0];

						// Trim translated text
						$atfpp_product_transalted_value = trim($atfpp_product_transalted_value);

						// Add spaces back
						$atfpp_product_transalted_value = $leading . $atfpp_product_transalted_value . $trailing;

						$translated_values[$index] = $atfpp_product_transalted_value;
					}
				}

				if(count($translated_values) > 0){
					$updated_target_product_attributes[$product_attribute_key]['value'] = implode('|', $translated_values);
				}
			}
		}

		update_post_meta($this->target_product_id, '_product_attributes', $updated_target_product_attributes);
	}

	/**
	 * Clone the variations of the product
	 *
	 * @return void
	 */
    private function clone_variation(){
		if(!$this->source_product_id || !$this->target_product_id || !function_exists('wc_get_product') || !wc_get_product($this->source_product_id) || !wc_get_product($this->target_product_id)) return;

		$atfpp_target_language=pll_get_post_language($this->target_product_id);
		$atfpp_language_object=PLL()->model->get_language($atfpp_target_language);
		$atfpp_language_direction=$atfpp_language_object->is_rtl ? 'rtl' : 'ltr';

		$source_product_variable = wc_get_product($this->source_product_id);

		if(!method_exists($source_product_variable, 'get_type')) return;

		if(!method_exists($source_product_variable, 'get_children')) return;

		if($source_product_variable->get_type() !== 'variable') return;

		$atfp_product_childrens=$source_product_variable->get_children();

		if(empty($atfp_product_childrens) || !is_array($atfp_product_childrens)) return;


		$this->source_product_attributes=get_post_meta($this->source_product_id, '_product_attributes', true);
		$this->target_product_attributes=get_post_meta($this->target_product_id, '_product_attributes', true);

		foreach($this->source_product_attributes as $source_attribute_key => $source_attribute_value){
			if(isset($this->target_product_attributes[$source_attribute_key]) && !isset($this->translated_attributes[$source_attribute_key])){
				if($this->source_attribute_value['value'] !== $this->target_product_attributes[$source_attribute_key]['value']){
					$source_attribute_value_array=explode('|', $source_attribute_value['value']);
					$source_attribute_value_array=array_map('trim', $source_attribute_value_array);
					$target_attribute_value_array=explode('|', $this->target_product_attributes[$source_attribute_key]['value']);
					$target_attribute_value_array=array_map('trim', $target_attribute_value_array);


					$this->translated_attributes[$source_attribute_key] = array('source_attribute_value'=>$source_attribute_value_array, 'target_attribute_value'=>$target_attribute_value_array);
				}
			}
		}

		foreach($atfp_product_childrens as $atfp_product_child){
			$atfp_product_child_data=wc_get_product($atfp_product_child);
			$this->target_product_variation = null;

			if(!$atfp_product_child_data) continue;

			$atfp_product_variation = new WC_Product_Variation($atfp_product_child);
			$atfp_product_variation->set_parent_id($this->target_product_id);
			$atfp_product_variation->set_id(0);

			$this->target_product_variation = $atfp_product_variation;

			$this->translate_product_attributes();
			$atfp_product_variation->save();
		}
	}

	private function translate_product_attributes(){
		if(!$this->target_product_variation) return;
		if(!$this->source_product_attributes || empty($this->source_product_attributes)) return;
		if(!$this->target_product_attributes || empty($this->target_product_attributes)) return;

		$target_product_variation_attributes=$this->target_product_variation->get_variation_attributes();

		if(is_array($target_product_variation_attributes) && count($target_product_variation_attributes) > 0){
			$updated_transalted_attributes=array();
			foreach($target_product_variation_attributes as $target_product_variation_attribute_key => $target_product_variation_attribute_value){
				$attribute_key=str_replace('attribute_', '', $target_product_variation_attribute_key);

				$updated_transalted_attributes[$attribute_key] = $target_product_variation_attribute_value;

				if(isset($this->translated_attributes[$attribute_key])){
					$translated_value_index=array_search($target_product_variation_attribute_value, $this->translated_attributes[$attribute_key]['source_attribute_value']);
					$translated_value=$this->translated_attributes[$attribute_key]['target_attribute_value'][$translated_value_index];

					$updated_transalted_attributes[$attribute_key] = $translated_value;
				}
			}

			$this->target_product_variation->set_attributes($updated_transalted_attributes);
			
			$updated_transalted_attributes_summary = [];

			foreach ($updated_transalted_attributes as $atfpp_attribute_key => $atfpp_attribute_value) {
				$updated_transalted_attributes_summary[] = ucfirst($atfpp_attribute_key) . ': ' . $atfpp_attribute_value;
			}

			if(count($updated_transalted_attributes_summary) > 0){
				$this->target_product_variation->set_attribute_summary(implode(', ', $updated_transalted_attributes_summary));
			}
		}
		
	}
}