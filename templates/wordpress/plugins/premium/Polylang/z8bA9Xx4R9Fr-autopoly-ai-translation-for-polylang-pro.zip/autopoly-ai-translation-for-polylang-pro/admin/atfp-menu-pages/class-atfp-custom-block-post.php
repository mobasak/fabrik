<?php
/**
 * Do not access the page directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ATFPP_Custom_Block_Post' ) ) {
	/**
	 * Class ATFPP_Custom_Block_Post
	 *
	 * This class handles the custom block post type for the AutoPoly - AI Translation For Polylang plugin.
	 * It manages the registration of the custom post type, adds submenu pages under the Polylang menu,
	 * and handles post save actions.
	 *
	 * @package ATFPP
	 */
	class ATFPP_Custom_Block_Post {
		/**
		 * Singleton instance.
		 *
		 * @var Atfpp_Custom_Block_Post
		 */
		private static $instance = null;

		/**
		 * Constructor.
		 */
		private function __construct() {
			add_action( 'init', array( $this, 'register_custom_post_type' ) );
			add_action( 'save_post', array( $this, 'on_save_post' ), 10, 3 );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		}

		/**
		 * Enqueue scripts.
		 */
		public function enqueue_scripts( $hook ) {
			$current_screen = get_current_screen();
			if ( 'atfp_add_blocks' === $current_screen->post_type && is_object( $current_screen ) && 'post.php' === $hook && $current_screen->is_block_editor ) {
				wp_enqueue_script( 'atfp-add-new-block', ATFPP_URL . 'assets/js/atfp-add-new-block.min.js', array( 'jquery','wp-data', 'wp-element' ), ATFPP_V, true );
				wp_enqueue_style( 'atfp-supported-blocks', ATFPP_URL . 'assets/css/atfp-custom-data-table.min.css', array(), ATFPP_V, 'all' );

				wp_localize_script( 'atfp-add-new-block', 'atfpAddBlockVars', array(
					'atfp_demo_page_url' => esc_url('https://docs.coolplugins.net/doc/ai-translation-polylang-video-tutorials/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=custom_block_post#custom-blocks-translation'),
				) );
			}
		}

		/**
		 * Function to run on post save or update.
		 *
		 * @param int          $post_id The ID of the post being saved.
		 * @param WP_Post|null $post The post object.
		 * @param bool         $update Whether this is an existing post being updated.
		 */
		public function on_save_post( $post_id, $post, $update ) {
			if(!current_user_can('edit_post', $post_id)){
				return;
			}

			if ( isset( $post->post_type ) && 'atfp_add_blocks' === $post->post_type ) {
				if (strpos($post->post_content, 'Make This Content Available for Translation') !== false) {
					update_option( 'atfp_custom_block_data', $post->post_content );
				}else{
					delete_option( 'atfp_custom_block_data' );
				}
			}
		}

		/**
		 * Get the singleton instance.
		 *
		 * @return Atfpp_Custom_Block_Post
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Register custom post type.
		 */
		public function register_custom_post_type() {
			$labels = array(
				'name'               => _x( 'Automatic Translations', 'post type general name', 'autopoly-ai-translation-for-polylang-pro' ),
				'singular_name'      => _x( 'Automatic Translation', 'post type singular name', 'autopoly-ai-translation-for-polylang-pro' ),
				'menu_name'          => _x( 'Automatic Translations', 'admin menu', 'autopoly-ai-translation-for-polylang-pro' ),
				'name_admin_bar'     => _x( 'Automatic Translation', 'add new on admin bar', 'autopoly-ai-translation-for-polylang-pro' ),
				'add_new'            => _x( 'Add New', 'Automatic Translation', 'autopoly-ai-translation-for-polylang-pro' ),
				'add_new_item'       => __( 'Add New Automatic Translation', 'autopoly-ai-translation-for-polylang-pro' ),
				'new_item'           => __( 'New Automatic Translation', 'autopoly-ai-translation-for-polylang-pro' ),
				'edit_item'          => __( 'Edit Automatic Translation', 'autopoly-ai-translation-for-polylang-pro' ),
				'view_item'          => __( 'View Automatic Translation', 'autopoly-ai-translation-for-polylang-pro' ),
				'all_items'          => __( 'Automatic Translations', 'autopoly-ai-translation-for-polylang-pro' ),
				'search_items'       => __( 'Search Automatic Translations', 'autopoly-ai-translation-for-polylang-pro' ),
				'not_found'          => __( 'No Automatic Translations found.', 'autopoly-ai-translation-for-polylang-pro' ),
				'not_found_in_trash' => __( 'No Automatic Translations found in Trash.', 'autopoly-ai-translation-for-polylang-pro' ),
			);

			$args = array(
				'labels'             => $labels,
				'public'             => false,
				'publicly_queryable' => true,
				'show_ui'            => true,
				'show_in_menu'       => false, // Ensure it shows in the menu
				'show_in_nav_menus'  => false,
				'query_var'          => true,
				'rewrite'            => array( 'slug' => 'automatic-translation' ),
				'capability_type'    => 'page',
				'has_archive'        => true,
				'hierarchical'       => true,
				'menu_position'      => 0,
				'show_in_rest'       => true,
				'supports'           => array( 'editor' ), // Added support for excerpt and thumbnail
				'capabilities'       => array(
					'create_post'  => false,
					'create_posts' => false,
					'delete_post'  => false,
					'edit_post'    => 'edit_pages',
					'delete_posts' => false,
					'edit_posts'   => 'edit_pages',
					'edit_pages'   => 'edit_pages',
					'edit_page'    => 'edit_pages'
				),
			);

			register_post_type( 'atfp_add_blocks', $args );
		}
	}

	// Initialize the class
	Atfpp_Custom_Block_Post::get_instance();
}
