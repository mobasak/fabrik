<?php

if(!defined('ABSPATH')) exit;

/**
 * Renders the license activation page
 */
function atfpp_render_license_page() {
    $purchase_email = get_option('AIAutomaticTranslationsForPolylang_lic_email', get_bloginfo('admin_email'));
    
    // Escape early for security
    $admin_url = esc_url(admin_url('admin-post.php'));
    $purchase_email_escaped = esc_attr($purchase_email);
    ?>
    <div class="atfpp-dashboard-license">
        <div class="atfpp-dashboard-license-container">
            <div class="header">
                <h1>🔑 <?php echo esc_html__('Activate License', 'autopoly-ai-translation-for-polylang-pro'); ?></h1>
            </div>
            <div class="atfpp-dashboard-license-form">
                <form method="post" action="<?php echo esc_url($admin_url); ?>">
                    <input type="hidden" name="action" value="AIAutomaticTranslationsForPolylang_el_activate_license"/>
                    <?php wp_nonce_field('el-atfpp-license'); ?>
                    
                    <div class="atfpp-dashboard-license-field">
                        <label for="license_code"><?php esc_html_e('License Key', 'autopoly-ai-translation-for-polylang-pro'); ?></label>
                        <input type="text" name="license_code" id="license_code" required 
                            placeholder="<?php esc_attr_e('xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx', 'autopoly-ai-translation-for-polylang-pro'); ?>">
                    </div>
                    
                    <div class="atfpp-dashboard-license-field">
                        <label for="email"><?php esc_html_e('Email Address', 'autopoly-ai-translation-for-polylang-pro'); ?></label>
                        <input type="email" name="email" id="email" required 
                            value="<?php echo esc_attr($purchase_email_escaped); ?>">
                        <small class="atfpp-dashboard-activation-note"><?php esc_html_e("Plugin updates news will be sent to this email. Don't worry, we hate spam.", 'autopoly-ai-translation-for-polylang-pro'); ?></small>
                    </div>
                    
                    <button type="submit" class="button button-primary">
                        <?php echo esc_html__('Activate License', 'autopoly-ai-translation-for-polylang-pro'); ?>
                    </button>
                </form>

                <p class="activation-note">
                    <?php echo esc_html__('Activate to receive automatic plugin updates and support.', 'autopoly-ai-translation-for-polylang-pro'); ?>
                </p>

                <?php atfpp_render_license_help_buttons(); ?>
            </div>
        </div>
        <?php
           $file_prefix = ATFPP_DIR_PATH . 'admin/atfpp-dashboard/views/';
           $footer_file = $file_prefix . 'footer.php';
           if (file_exists($footer_file)) {
               require_once $footer_file;
           }
        ?>
    </div>
<?php
}

/**
 * Renders the license information page for Pro users
 * 
 * @param object|null $license_info License information object
 */
function atfpp_render_license_page_pro($license_info = null) {
    
    // Early return if invalid license info
    if (!$license_info) {
        $license_info = AI_Automatic_Translations_For_Polylang_Base::GetRegisterInfo();
    }

    if (!is_object($license_info) || !isset($license_info->is_valid) || !isset($license_info->license_title) || !isset($license_info->expire_date)) {
        wp_die(esc_html__('Error: Invalid license information', 'autopoly-ai-translation-for-polylang-pro'));
        return;
    }
    
    // Sanitize license key before masking
    $license_key = sanitize_text_field(get_option('AIAutomaticTranslationsForPolylang_lic_Key', ''));
    $masked_key = !empty($license_key) ? 
        esc_html(substr($license_key, 0, 8) . '-XXXXXXXX-XXXXXXXX-' . substr($license_key, -8)) :
        '';
    
    $admin_url = esc_url(admin_url('admin-post.php'));
?>
    <div class="atfpp-dashboard-license">
        <div class="atfpp-dashboard-license-pro-container">
            <div class="atfpp-dashboard-license-header-container" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h1>🔒 <?php esc_html_e('Your License Info', 'autopoly-ai-translation-for-polylang-pro'); ?></h1>
                <?php if (atfpp_needs_refresh($license_info)): ?>

                    <button type="button" class="atfpp-refresh-btn" id="atfpp-refresh-license-btn">
                        <?php esc_html_e('🔄Check license status', 'autopoly-ai-translation-for-polylang-pro'); ?>

                    </button>
                <?php endif; ?>
            </div>
            <ul>
                <li><strong><?php esc_html_e('Status:', 'autopoly-ai-translation-for-polylang-pro'); ?></strong> 
                    <span class="validity">
                        <?php if ($license_info->is_valid): ?>

                            <?php if (atfpp_is_license_expired($license_info)): ?>

                                <strong>❌ <?php esc_html_e('License Expired', 'autopoly-ai-translation-for-polylang-pro'); ?></strong>

                            <?php elseif (atfpp_is_support_expired($license_info)): ?>

                                <strong>❌ <?php esc_html_e('Support Expired', 'autopoly-ai-translation-for-polylang-pro'); ?></strong>

                            <?php else: ?>

                                <strong class="valid">✅ <?php esc_html_e('Valid', 'autopoly-ai-translation-for-polylang-pro'); ?></strong>

                            <?php endif; ?>

                        <?php else: ?>

                        <strong>❌ <?php esc_html_e('Invalid', 'autopoly-ai-translation-for-polylang-pro'); ?></strong>
                        
                        <?php endif; ?>
                    </span>
                </li>
                <li><strong><?php esc_html_e('License Type:', 'autopoly-ai-translation-for-polylang-pro'); ?></strong> <span class="license-type"><?php echo esc_html($license_info->license_title); ?></span></li>
                <li><strong><?php esc_html_e('Plugin Updates & Support Validity:', 'autopoly-ai-translation-for-polylang-pro'); ?></strong> <span class="validity">

                    <?php 
                    $current_time = time();
                 
                    // Handle "No expiry" case for expire_date
                    $expire_date_expired = false;
                    if (strtolower($license_info->expire_date) !== 'no expiry') {
                        $expire_date_timestamp = strtotime($license_info->expire_date);
                        $expire_date_expired = $expire_date_timestamp && $expire_date_timestamp < $current_time;
                    }
                    
                    // Handle "no support" case for support_end
                    if (strtolower($license_info->support_end) === 'no support') {

                        esc_html_e('No Support', 'autopoly-ai-translation-for-polylang-pro');

                    } else {

                        // Handle "unlimited" case for support_end
                        $support_end_expired = false;

                        if (strtolower($license_info->support_end) !== 'unlimited') {

                            $support_end_timestamp = strtotime($license_info->support_end);
                            $support_end_expired = $support_end_timestamp && $support_end_timestamp < $current_time;

                        }
                        if ($expire_date_expired) {
                            
                            echo esc_html(atfpp_pro_formatLicenseDate($license_info->expire_date));

                        } elseif ($support_end_expired) {                            
                            
                            echo esc_html(atfpp_pro_formatLicenseDate($license_info->support_end));
                          
                        } else {

                            echo esc_html(atfpp_pro_formatLicenseDate($license_info->expire_date));
                            
                        }
                       
                    }
                    ?>
                    </span>
                </li>

                <li><strong><?php echo esc_html__('Your License Key:', 'autopoly-ai-translation-for-polylang-pro'); ?></strong> <span class="license-key"><?php echo esc_html($masked_key); ?></span></li>
            </ul>

            <div class="atfpp-dashboard-license-pro-container-deactivate-btn">
                <p><?php esc_html_e('Want to deactivate the license for any reason?', 'autopoly-ai-translation-for-polylang-pro'); ?></p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="AIAutomaticTranslationsForPolylang_el_deactivate_license" />
                    <?php wp_nonce_field('el-atfpp-license'); ?>
                    <button type="submit" class="deactivate-btn">
                        <?php echo esc_html__('Deactivate License', 'autopoly-ai-translation-for-polylang-pro'); ?>
                    </button>
                </form>
            </div>
            <?php if (atfpp_is_license_expired($license_info)): ?>

            <div class="notice notice-error" style="margin-top: 10px; color: #d63638;">
                <?php atfpp_render_expiry_message($license_info, 'license'); ?>
            </div>

            <?php elseif (atfpp_is_support_expired($license_info)): ?>

            <div class="notice notice-error" style="margin-top: 10px; color: #d63638;">
                <?php atfpp_render_expiry_message($license_info, 'support'); ?>
            </div>

            <?php endif; ?>

            <?php atfpp_render_license_help_buttons(); ?>
        </div>
        <?php
           $file_prefix = ATFPP_DIR_PATH . 'admin/atfpp-dashboard/views/';
           $footer_file = $file_prefix . 'footer.php';
           if (file_exists($footer_file)) {
               require_once $footer_file;
           }
        ?>
    </div>
<?php
}

/**
 * Renders the license buttons section
 */
function atfpp_render_license_help_buttons() {
    ?>
    <div class="atfpp-dashboard-license-pro-container-buttons">
        <p><?php esc_html_e('Want to know more about the license key?', 'autopoly-ai-translation-for-polylang-pro'); ?></p>
        <div class="btns">
            <a href="https://my.coolplugins.net/account/" target="_blank" class="atfpp-dashboard-btn">
                <?php echo esc_html__('Check Account', 'autopoly-ai-translation-for-polylang-pro'); ?>
            </a>
            <a href="https://coolplugins.net/support/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=support&utm_content=dashboard_license" target="_blank" class="atfpp-dashboard-btn">
                <?php echo esc_html__('Contact Support', 'autopoly-ai-translation-for-polylang-pro'); ?>
            </a>
        </div>
    </div>
    <?php
}

function atfpp_is_license_expired($license_info) {

    return $license_info->is_valid === 'license_expired';
}

function atfpp_is_support_expired($license_info) {

    return $license_info->support_end === 'no support' || 
          ($license_info->is_valid === 'support_expired' || 
          (strtolower($license_info->support_end) !== 'unlimited' && 
          strtotime($license_info->support_end) < time()));
}

function atfpp_needs_refresh($license_info) {

    return atfpp_is_license_expired($license_info) || atfpp_is_support_expired($license_info);
}


function atfpp_render_expiry_message($license_info, $type = 'license') {
    // Generate version available message using common helper
    $version_available_message = AutoPolyPro::atfppGetVersionAvailableMessage();
    
    if ($license_info->msg === 'limit_reached') {
        $support_link = sprintf('<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>', esc_url('https://my.coolplugins.net/account/support-tickets/'), esc_html__('clicking here', 'autopoly-ai-translation-for-polylang-pro'));
        echo wp_kses_post(sprintf(
            /* translators: %s: link to support ticket page */
            __('There was an issue with your account. Please contact our plugin support team by %s.', 'autopoly-ai-translation-for-polylang-pro'),
            $support_link
        ));
        return;
    }

    $message = $type === 'license' 
        ? __('Your license has expired,', 'autopoly-ai-translation-for-polylang-pro') 
        : __('Your support has expired,', 'autopoly-ai-translation-for-polylang-pro');

    $renew_link = isset($license_info->market) && $license_info->market === 'E'
        ? ''
        : ' <a href="'.esc_url('https://my.coolplugins.net/account/subscriptions/').'" target="_blank" rel="noopener noreferrer">'.esc_html__('Renew now', 'autopoly-ai-translation-for-polylang-pro').'</a>';

     $final_message = '';
    
    // Add version message if available
    if (!empty($version_available_message)) {

        wp_enqueue_script('thickbox');
        wp_enqueue_style('thickbox');
        
        $final_message .= wp_kses_post($version_available_message) . ' ';
    }
    
    // Add license expiry message
    $final_message .= esc_html($message) . $renew_link . esc_html__(' to continue receiving updates and priority support.', 'autopoly-ai-translation-for-polylang-pro');
    
    echo wp_kses_post($final_message);
}

function atfpp_pro_formatLicenseDate($dateString) {

if (!empty($dateString) && strtolower($dateString) !== 'no expiry') {
     
        $date = new DateTime($dateString);
        return $date->format('d M Y');
    }
    return $dateString;
}

