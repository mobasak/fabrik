<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

function atfpp_render_settings_page( $is_pro = false ) {
	$atfpp_is_wp_ai_client_exist = ATFPP_Helper::is_wp_ai_client_exist();
	// Define APIs configuration
	$apis = array(
		'google'                            => array(
			'name'        => 'Gemini',
			'option_key'  => 'Atfpp_Ai_Translate_google_api_key',
			'docs_url'    => 'https://docs.coolplugins.net/doc/generate-gemini-api-key/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=settings_gemini_pro',
			'option_info' => array(
				array( 'value', $atfpp_is_wp_ai_client_exist ? 'connectors_ai_google_api_key' : 'Atfpp_Ai_Translate_google_api_key', '' ),
			),
		),
		'openai'                            => array(
			'name'        => 'OpenAI',
			'option_key'  => 'Atfpp_Ai_Translate_openai_api_key',
			'docs_url'    => 'https://docs.coolplugins.net/doc/generate-open-ai-api-key/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=settings_openai_pro',
			'option_info' => array(
				array( 'value', $atfpp_is_wp_ai_client_exist ? 'connectors_ai_openai_api_key' : 'Atfpp_Ai_Translate_openai_api_key', '' ),
			),
		),
		'deepl'                             => array(
			'name'        => 'DeepL',
			'option_key'  => 'Atfpp_Ai_Translate_deepl_api_key',
			'docs_url'    => 'https://docs.coolplugins.net/doc/generate-deepl-api-key/',
			'option_info' => array(
				array( 'value', $atfpp_is_wp_ai_client_exist ? 'connectors_ai_deepl_api_key' : 'Atfpp_Ai_Translate_deepl_api_key', '' ),
				array( 'glossary_type', 'atfpp_deepl_glossary_type', 'default' ),
				array( 'glossary_id', 'atfpp_deepl_glossary_id', '' ),
			),
		),
		'context_aware'                     => array(
			'name'        => 'Context Aware',
			'option_key'  => 'atfp_context_aware',
			'option_info' => array(
				array( 'value', 'atfp_context_aware', '' ),
			),
		),
		'atfpp_bulk_post_status'            => array(
			'name'        => 'Bulk Translation default Post Status',
			'option_key'  => 'atfp_bulk_post_status',
			'options'     => array(
				'publish' => 'Published',
				'draft'   => 'Draft',
			),
			'option_info' => array(
				array( 'value', 'atfp_bulk_post_status', 'draft' ),
			),
		),
		'atfp_slug_translation_option'      => array(
			'name'        => 'Slug Translation Settings',
			'option_key'  => 'atfp_slug_translation_option',
			'options'     => array(
				'title_translate' => 'Use Translated Title',
				'slug_translate'  => 'Translate Original Slug',
				'slug_keep'       => 'Keep Original Slug',
			),
			'option_info' => array(
				array( 'value', 'atfp_slug_translation_option', 'title_translate' ),
			),
		),
		'atfp_retranslation_enabled'        => array(
			'name'        => 'Enable Re-Translation',
			'option_key'  => 'atfp_retranslation_enabled',
			'option_info' => array(
				array( 'value', 'atfp_retranslation_enabled', 'true' ),
			),
		),
		'atfp_ai_request_token_per_request' => array(
			'name'        => 'AI Token Per Request',
			'option_key'  => 'atfp_ai_request_token_per_request',
			'option_info' => array(
				array( 'value', 'atfp_ai_request_token_per_request', '500' ),
			),
		),
		'atfp_ai_request_batch_size'        => array(
			'name'        => 'AI Batch Size',
			'option_key'  => 'atfp_ai_request_batch_size',
			'option_info' => array(
				array( 'value', 'atfp_ai_request_batch_size', '5' ),
			),
		),
		'atfp_ai_request_timeout'           => array(
			'name'        => 'AI Timeout',
			'option_key'  => 'atfp_ai_request_timeout',
			'option_info' => array(
				array( 'value', 'atfp_ai_request_timeout', '120' ),
			),
		),
	);

	atfpp_render_settings_page_html( $apis, $is_pro );
}

function atfpp_get_api_configurations( &$apis, $is_pro = false ) {
	foreach ( $apis as &$atfp_provider_data ) {
		if ( isset( $atfp_provider_data['option_info'] ) ) {
			$atfp_provider_options = $atfp_provider_data['option_info'];
			unset( $atfp_provider_data['option_info'] );

			foreach ( $atfp_provider_options as $atfp_provider_option ) {
				if ( ! $is_pro ) {
					$atfp_provider_data[ sanitize_text_field( $atfp_provider_option[0] ) ] = '';
				} else {
					$atfp_provider_data[ sanitize_text_field( $atfp_provider_option[0] ) ] = get_option( sanitize_text_field( $atfp_provider_option[1] ), $atfp_provider_option[2] );
				}
			}
		}
	}
}

function atfpp_check_form_submission() {
	return isset( $_POST['nonce'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'atfpp_api_keys' ) &&
			current_user_can( 'manage_options' ) &&
			isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] === 'POST';
}

function atfpp_wp_connectors_client_provider_key_validate( $provider_id, $api_key ) {
	if ( ! $provider_id || ! $api_key ) {
		return array( 'message' => __( 'Provider and API key are required.', 'autopoly-ai-translation-for-polylang-pro' ) );
	}
	// Basic format validation - reject obviously invalid keys before API call.
	$key_trimmed = trim( $api_key );
	if ( strlen( $key_trimmed ) < 10 ) {
		return array( 'message' => __( 'API key appears to be invalid or too short.', 'autopoly-ai-translation-for-polylang-pro' ) );
	}
	// Reject keys with HTML/script characters or obvious junk.
	if ( preg_match( '/[<>"\']/', $key_trimmed ) ) {
		return array( 'message' => __( 'Invalid API key format. Please check your credentials.', 'autopoly-ai-translation-for-polylang-pro' ) );
	}
	// OpenAI keys must start with sk-
	if ( 'openai' === strtolower( $provider_id ) && ! preg_match( '/^sk-[a-zA-Z0-9_-]{20,}$/', $key_trimmed ) ) {
		return array( 'message' => __( 'OpenAI API keys must start with sk- and be in the correct format.', 'autopoly-ai-translation-for-polylang-pro' ) );
	}

	if ( ! class_exists( 'WordPress\AiClient\AiClient' ) ) {
		return array( 'message' => __( 'AI client is not available.', 'autopoly-ai-translation-for-polylang-pro' ) );
	}

	$registry = \WordPress\AiClient\AiClient::defaultRegistry();
	if ( ! $registry->hasProvider( $provider_id ) ) {
		return array( 'message' => __( 'Invalid AI provider.', 'autopoly-ai-translation-for-polylang-pro' ) );
	}

	$is_gemini = ( 'google' === strtolower( $provider_id ) ) || str_contains( strtolower( $provider_id ), 'gemini' );
	$cooldown  = 5;
	$lock_key  = 'atfpp_connectors_ai_test_lock_' . md5( $provider_id . '|' . $api_key );

	if ( get_transient( $lock_key ) ) {
		return array(
			'message' => __( 'Please wait a few seconds before testing again.', 'autopoly-ai-translation-for-polylang-pro' ),
		);
	}

	// Inject the test API key into the registry (same as the REST controller does).
	$auth_class = 'WordPress\AiClient\Providers\Http\DTO\ApiKeyRequestAuthentication';
	$registry->setProviderRequestAuthentication(
		$provider_id,
		new $auth_class( $api_key )
	);

	set_transient( $lock_key, 1, $cooldown );

	try {
		$provider_classname    = $registry->getProviderClassName( $provider_id );
		$provider_availability = $provider_classname::availability();

		if ( ! $provider_availability->isConfigured() ) {
			// translators: %s: Provider name (e.g. "Google", "OpenAI").
			return array( 'message' => sprintf( __( 'Invalid API key for %s. Please check your key.', 'autopoly-ai-translation-for-polylang-pro' ), $provider_id ) );
		}

		$model_metadata_directory = $provider_classname::modelMetadataDirectory();
		$model_metadata_directory->listModelMetadata(); // throws on invalid key

	} catch ( \Exception $e ) {
		$msg = $e->getMessage();
		if ( str_contains( strtolower( $msg ), '429' ) ) {
			return array(
				'message' => $is_gemini
					? __( 'Gemini free tier rate limit exceeded. Please wait and try again.', 'autopoly-ai-translation-for-polylang-pro' )
					: __( 'Rate limit exceeded. Please try again later.', 'autopoly-ai-translation-for-polylang-pro' ),
			);
		}
		return array( 'message' => __( 'Invalid API key. Please check your credentials.', 'autopoly-ai-translation-for-polylang-pro' ) );
	}

	return true;
}

function atfpp_validate_google_api_key( $key ) {
	if ( empty( $key ) ) {
		return false;
	}

	if ( ! preg_match( '/^AIza[0-9A-Za-z\-_]{35}$/', $key ) ) {
		atfpp_show_admin_notice( 'error', 'Invalid Gemini API Key.' );
		return false;
	}

	$response = wp_remote_get(
		'https://generativelanguage.googleapis.com/v1beta/models?key=' . $key,
		array(
			'headers' => array( 'Content-Type' => 'application/json' ),
			'timeout' => 30,
		)
	);

	if ( is_wp_error( $response ) ) {
		atfpp_show_admin_notice( 'error', 'API request failed: ' . $response->get_error_message() );
		return false;
	}

	$body = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( ! isset( $body['models'] ) || empty( $body['models'] ) ) {
		atfpp_show_admin_notice( 'error', 'Invalid or unauthorized Gemini API Key.' );
		return false;
	}

	$text_models = array();
	foreach ( $body['models'] as $model ) {
		if (
		empty( $model['name'] ) ||
		empty( $model['supportedGenerationMethods'] ) ||
		! is_array( $model['supportedGenerationMethods'] ) ||
		! in_array( 'generateContent', $model['supportedGenerationMethods'], true )
		) {
			continue;
		}

		$model_name = $model['name'];

		if (
		( isset( $model['state'] ) && $model['state'] !== 'ACTIVE' ) ||
		preg_match( '/(tts|image|vision)/i', $model_name )
		) {
			continue;
		}

		$clean_name = str_replace( 'models/', '', $model_name );

		$text_models[] = $clean_name;
	}

	update_option( 'atfpp_google_models', $text_models );

	return true;
}

function atfpp_validate_openai_api_key( $key ) {
	if ( empty( $key ) ) {
		return false;
	}

	$response = wp_remote_get(
		'https://api.openai.com/v1/models',
		array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $key,
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		atfpp_show_admin_notice( 'error', 'Unable to connect to OpenAI API.' );
		return false;
	}

	$response_data = json_decode( wp_remote_retrieve_body( $response ), true );

	if ( ! empty( $response_data['error'] ) ) {
		$error_message = $response_data['error']['message'] ?? 'Invalid OpenAI API Key.';
		atfpp_show_admin_notice( 'error', str_replace( '<a ', '<a target="_blank" ', make_clickable( $error_message ) ) );
		return false;
	}

	if ( empty( $response_data['data'] ) ) {
		atfpp_show_admin_notice( 'error', 'No models found. Your API key may not have access.' );
		return false;
	}

	$model_ids = array_reduce(
		$response_data['data'],
		function ( array $ids, array $model_data ) {
			$model_slug = $model_data['id'];

			if (
				( str_starts_with( $model_slug, 'gpt-' ) || str_starts_with( $model_slug, 'o1-' ) )
				&& ! str_contains( $model_slug, '-instruct' )
				&& ! str_contains( $model_slug, '-realtime' )
				&& ! str_contains( $model_slug, '-audio' )
				&& ! str_contains( $model_slug, '-tts' )
				&& ! str_contains( $model_slug, '-transcribe' )
				&& ! str_contains( $model_slug, '-image' )
				&& $model_slug !== 'o1-pro'
				&& $model_slug !== 'o1-pro-2025-03-19'
			) {
				$ids[] = $model_slug;
			}

			return $ids;
		},
		array()
	);

	update_option( 'atfpp_openai_models', $model_ids );

	return true;
}

function atfpp_validate_deepl_api_key( $key ) {
	if ( empty( $key ) ) {
		return false;
	}

	$client = new Client();

	$key = sanitize_text_field( $key );

	try {
		$url = ATFPP_Helper::deepl_base_url( $key ) . '/v2/usage';

		$response = $client->request(
			'GET',
			$url,
			array(
				'headers' => array(
					'Authorization' => 'DeepL-Auth-Key ' . $key,
				),
			)
		);

		$statusCode = $response->getStatusCode();
		$reason     = $response->getReasonPhrase(); // short HTTP reason like "Unauthorized"

		if ( $statusCode === 200 ) {
			return true;
		} else {
			atfpp_show_admin_notice( 'error', str_replace( '<a ', '<a target="_blank" ', make_clickable( $reason ) ) );
			return false;
		}
	} catch ( RequestException $e ) {
		if ( $e->hasResponse() ) {
			// Extract error details from response body
			$errorBody = (string) $e->getResponse()->getBody();

			// Decode JSON response to array
			$errorData = json_decode( $errorBody, true );

			// Get error message if available
			$errorMessage = $errorData['message'] ?? $errorBody;
		} else {
			// Use exception message if no response body is available
			$errorMessage = $e->getMessage();
		}

		atfpp_show_admin_notice( 'error', str_replace( '<a ', '<a target="_blank" ', make_clickable( $errorMessage ) ) );
		return false;
	}

	atfpp_show_admin_notice( 'error', 'Invalid DeepL API Key.' );
	return false;
}

function atfpp_show_admin_notice( $type, $message ) {
	if ( ! isset( $GLOBALS['atfpp_admin_notices'] ) ) {
		$GLOBALS['atfpp_admin_notices'] = array();
	}
	$GLOBALS['atfpp_admin_notices'][] = wp_kses(
		'<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible"><p>' . wp_kses(
			$message,
			array(
				'a' => array(
					'href'   => array(),
					'target' => array(),
				),
			)
		) . '</p></div>',
		array(
			'div' => array( 'class' => true ),
			'p'   => array(),
			'a'   => array(
				'href'   => array(),
				'target' => array(),
			),
		)
	);
}

function atfpp_handle_api_key_submission() {
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'atfpp_api_keys' ) ) {
		atfpp_show_admin_notice( 'error', 'Invalid nonce.' );
		return false;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		atfpp_show_admin_notice( 'error', 'You are not allowed to perform this action.' );
		return false;
	}
	// Clear any existing notices at the start
	$GLOBALS['atfpp_admin_notices'] = array();
	$atfpp_is_wp_ai_client_exist    = ATFPP_Helper::is_wp_ai_client_exist();

	if ( isset( $_POST['reset_google_api_key'] ) ) {
		$atfpp_google_option_name = $atfpp_is_wp_ai_client_exist ? 'connectors_ai_google_api_key' : 'Atfpp_Ai_Translate_google_api_key';
		delete_option( $atfpp_google_option_name );
		delete_option( 'atfpp_google_models' );
		delete_option( 'atfpp_selected_google_model' );
		atfpp_show_admin_notice( 'success', 'Gemini API Key has been removed.' );
		return true;
	}

	if ( isset( $_POST['reset_openai_api_key'] ) ) {
		$atfpp_openai_option_name = $atfpp_is_wp_ai_client_exist ? 'connectors_ai_openai_api_key' : 'Atfpp_Ai_Translate_openai_api_key';
		delete_option( $atfpp_openai_option_name );
		delete_option( 'atfpp_openai_models' );
		delete_option( 'atfpp_selected_openai_model' );
		atfpp_show_admin_notice( 'success', 'OpenAI API Key has been removed.' );
		return true;
	}

	if ( isset( $_POST['reset_deepl_api_key'] ) ) {
		$atfpp_deepl_option_name = $atfpp_is_wp_ai_client_exist ? 'connectors_ai_deepl_api_key' : 'Atfpp_Ai_Translate_deepl_api_key';
		delete_option( $atfpp_deepl_option_name );
		delete_option( 'atfp_deepl_api_key_type' );
		delete_option( 'atfpp_deepl_glossary_type' );
		delete_option( 'atfpp_deepl_glossary_id' );
		atfpp_show_admin_notice( 'success', 'DeepL API Key has been removed.' );
		return true;
	}

	if ( isset( $_POST['reset_deepl_glossary_id'] ) ) {
		delete_option( 'atfpp_deepl_glossary_id' );
		atfpp_show_admin_notice( 'success', 'DeepL Glossary ID has been removed.' );
		return true;
	}

	if ( isset( $_POST['submit_api_keys'] ) ) {
		return atfpp_handle_api_key_save();
	}

	return false;
}

function atfpp_handle_api_key_save() {

	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'atfpp_api_keys' ) ) {
		atfpp_show_admin_notice( 'error', 'Invalid nonce.' );
		return false;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		atfpp_show_admin_notice( 'error', 'You are not allowed to perform this action.' );
		return false;
	}

	$success                  = false;
	$any_validation_attempted = false;
	$has_error                = false;

    $atfpp_is_wp_ai_client_exist = ATFPP_Helper::is_wp_ai_client_exist();

	// Handle Context Aware textarea
	if ( isset( $_POST['atfp_context_aware'] ) ) {
		$context_aware = sanitize_textarea_field( wp_unslash( $_POST['atfp_context_aware'] ) );
		update_option( 'atfp_context_aware', $context_aware );
		// Store the new value in a global variable to use in the render function
		$GLOBALS['atfpp_current_context_aware'] = $context_aware;
		$success                                = true;
	}

	$current_openai_model = get_option( 'atfpp_selected_openai_model', '' );
	$current_google_model = get_option( 'atfpp_selected_google_model', '' );

	// Save selected OpenAI model if set and validate
	if ( !$atfpp_is_wp_ai_client_exist && isset( $_POST['atfpp_selected_openai_model'] ) && $_POST['atfpp_selected_openai_model'] !== $current_openai_model ) {
		$selected_model = sanitize_text_field( wp_unslash( $_POST['atfpp_selected_openai_model'] ) );
		$openai_key     = get_option( 'Atfpp_Ai_Translate_openai_api_key', '' );
		$is_valid       = false;
		$error_message  = '';

		if ( $selected_model === '' ) {
			update_option( 'atfpp_selected_openai_model', '' );
			atfpp_show_admin_notice( 'success', 'OpenAI model selection has been cleared.' );
		} else {
			if ( $openai_key && $selected_model ) {
				$response = wp_remote_post(
					'https://api.openai.com/v1/chat/completions',
					array(
						'headers' => array(
							'Content-Type'  => 'application/json',
							'Authorization' => 'Bearer ' . $openai_key,
						),
						'body'    => wp_json_encode(
							array(
								'model'                 => $selected_model,
								'messages'              => array(
									array(
										'role'    => 'user',
										'content' => 'Test',
									),
								),
								'max_completion_tokens' => 20,
							)
						),
						'timeout' => 20,
					)
				);

				if ( is_wp_error( $response ) ) {
					$error_message = $response->get_error_message();
				} else {
					$body = json_decode( wp_remote_retrieve_body( $response ), true );
					if ( empty( $body['error'] ) ) {
						$is_valid = true;
					} else {
						$error_message = $body['error']['message'] ?? 'Unknown error from OpenAI.';
					}
				}
			}

			if ( $is_valid ) {
				update_option( 'atfpp_selected_openai_model', $selected_model );
				atfpp_show_admin_notice( 'success', 'The OpenAI model has been successfully validated and saved.' );
			} else {
				atfpp_show_admin_notice( 'error', 'OpenAI API Error: ' . esc_html( $error_message ) );
			}
		}
	}

	if ( !$atfpp_is_wp_ai_client_exist && isset( $_POST['atfpp_selected_google_model'] ) && $_POST['atfpp_selected_google_model'] !== $current_google_model ) {

		$selected_model = sanitize_text_field( wp_unslash( $_POST['atfpp_selected_google_model'] ) );
		$google_key     = get_option( 'Atfpp_Ai_Translate_google_api_key', '' );
		$is_valid       = false;
		$error_message  = '';

		if ( $selected_model === '' ) {
			delete_option( 'atfpp_selected_google_model' );
			atfpp_show_admin_notice( 'success', 'The Google Gemini model selection has been cleared.' );
		} else {
			if ( $google_key && $selected_model ) {
				$response = wp_remote_post(
					'https://generativelanguage.googleapis.com/v1beta/models/' . $selected_model . ':generateContent?key=' . $google_key,
					array(
						'headers' => array( 'Content-Type' => 'application/json' ),
						'body'    => json_encode(
							array(
								'contents' => array( array( 'parts' => array( array( 'text' => 'Test' ) ) ) ),
							)
						),
						'timeout' => 60,
					)
				);

				if ( ! is_wp_error( $response ) ) {
					$body = json_decode( wp_remote_retrieve_body( $response ), true );
					if ( empty( $body['error'] ) ) {
						$is_valid = true;
					} elseif ( ! empty( $body['error']['message'] ) ) {
						$error_message = $body['error']['message'];
					}
				} else {
					$error_message = $response->get_error_message();
				}
			}

			if ( $is_valid ) {
				update_option( 'atfpp_selected_google_model', $selected_model );
				atfpp_show_admin_notice( 'success', 'The Gemini model has been successfully validated and saved.' );
			} else {
				$notice = $error_message ? $error_message : 'The selected Gemini model is not valid or not accessible with your API key.';
				atfpp_show_admin_notice( 'error', esc_html( $notice ) );
			}
		}
	}

	// Handle feedback checkbox
	$feedback_opt_in = null;
	if ( get_option( 'cpfm_opt_in_choice_cool_translations' ) ) {
		$feedback_opt_in = isset( $_POST['atfpp-dashboard-feedback-checkbox'] ) ? 'yes' : 'no';
		update_option( 'atfp_feedback_opt_in', $feedback_opt_in );
	}

	// If user opted out, remove the cron job
	if ( $feedback_opt_in === 'no' && wp_next_scheduled( 'atfpp_extra_data_update' ) ) {
		wp_clear_scheduled_hook( 'atfpp_extra_data_update' );
	}

	if ( $feedback_opt_in === 'yes' && ! wp_next_scheduled( 'atfpp_extra_data_update' ) ) {

		wp_schedule_event( time(), 'every_30_days', 'atfpp_extra_data_update' );

	}

	if ( isset( $_POST['atfpp_deepl_glossary_type'] ) ) {
		$deepl_glossary_type = sanitize_text_field( wp_unslash( $_POST['atfpp_deepl_glossary_type'] ) );
		update_option( 'atfpp_deepl_glossary_type', $deepl_glossary_type );

		if ( $deepl_glossary_type === 'deepl' && isset( $_POST['atfpp_deepl_glossary_id'] ) && ! empty( $_POST['atfpp_deepl_glossary_id'] ) ) {

			$deepl_glossary_id = sanitize_text_field( wp_unslash( $_POST['atfpp_deepl_glossary_id'] ) );
			$atfpp_deepl_option_name = $atfpp_is_wp_ai_client_exist ? 'connectors_ai_deepl_api_key' : 'Atfpp_Ai_Translate_deepl_api_key';
			$deepl_key         = get_option( sanitize_text_field( $atfpp_deepl_option_name ), '' );

			$base_url = ATFPP_Helper::deepl_base_url( $deepl_key );
			$url      = $base_url . '/v3/glossaries/' . sanitize_text_field( $deepl_glossary_id );

			$response = wp_remote_get(
				$url,
				array(
					'headers' => array(
						'Authorization' => 'DeepL-Auth-Key ' . sanitize_text_field( $deepl_key ),
					),
				)
			);

			if ( ! is_wp_error( $response ) ) {
				$body = json_decode( wp_remote_retrieve_body( $response ), true );

				if ( isset( $body['glossary_id'] ) && $body['glossary_id'] === $deepl_glossary_id ) {
					atfpp_show_admin_notice( 'success', 'DeepL Glossary ID is valid and saved.' );
					update_option( 'atfpp_deepl_glossary_id', $deepl_glossary_id );
				} else {
					$deepl_error_message = isset( $body['message'] ) ? $body['message'] : 'Unknown error from DeepL.';
					atfpp_show_admin_notice( 'error', 'DeepL Glossary ID is not valid. Error: ' . esc_html( $deepl_error_message ) );
				}
			} else {
				atfpp_show_admin_notice(
					'error',
					'DeepL Glossary ID is not valid. Error: ' . esc_html( $response->get_error_message() ) . ' ' . esc_html( $response->get_error_code() )
				);
			}
		} else {
			delete_option( 'atfpp_deepl_glossary_id' );
		}
	}

	if ( isset( $_POST['atfp_bulk_post_status'] ) ) {
		$bulk_post_status = sanitize_text_field( wp_unslash( $_POST['atfp_bulk_post_status'] ) );
		update_option( 'atfp_bulk_post_status', $bulk_post_status );
		$success = true;
	}

	if ( isset( $_POST['atfp_slug_translation_option'] ) ) {
		$slug_translation_option = sanitize_text_field( wp_unslash( $_POST['atfp_slug_translation_option'] ) );
		update_option( 'atfp_slug_translation_option', $slug_translation_option );
		$success = true;
	}

	if ( isset( $_POST['atfp_retranslation_enabled'] ) ) {
		$retranslation_enabled = sanitize_text_field( wp_unslash( $_POST['atfp_retranslation_enabled'] ) );
		update_option( 'atfp_retranslation_enabled', $retranslation_enabled );
		$success = true;
	} else {
		update_option( 'atfp_retranslation_enabled', 'false' );
		$success = true;
	}

	if ( isset( $_POST['atfp_ai_request_token_per_request'] ) ) {
		$ai_token_per_request = sanitize_text_field( wp_unslash( $_POST['atfp_ai_request_token_per_request'] ) );

		if ( $ai_token_per_request < 100 || $ai_token_per_request > 10000 || empty( $ai_token_per_request ) ) {
			atfpp_show_admin_notice( 'error', 'AI Token Per Request must be between 100 and 10000.' );
			return false;
		}

		update_option( 'atfp_ai_request_token_per_request', $ai_token_per_request );
		$success = true;
	}

	if ( isset( $_POST['atfp_ai_request_batch_size'] ) ) {
		$ai_batch_size = sanitize_text_field( wp_unslash( $_POST['atfp_ai_request_batch_size'] ) );

		if ( $ai_batch_size < 1 || $ai_batch_size > 10 || empty( $ai_batch_size ) ) {
			atfpp_show_admin_notice( 'error', 'AI Batch Size must be between 1 and 10.' );
			return false;
		}

		update_option( 'atfp_ai_request_batch_size', $ai_batch_size );
		$success = true;
	}

	if ( isset( $_POST['atfp_ai_request_timeout'] ) ) {
		$ai_timeout = sanitize_text_field( wp_unslash( $_POST['atfp_ai_request_timeout'] ) );

		if ( $ai_timeout < 10 || $ai_timeout > 1200 || empty( $ai_timeout ) ) {
			atfpp_show_admin_notice( 'error', 'AI Timeout must be between 10 and 1200.' );
			return false;
		}

		update_option( 'atfp_ai_request_timeout', $ai_timeout );
		$success = true;
	}

	// Validate all API keys first before saving any
	$valid_keys                  = array();

	if ( ! empty( $_POST['Atfpp_Ai_Translate_google_api_key'] ) ) {
		$new_google_key           = sanitize_text_field( wp_unslash( $_POST['Atfpp_Ai_Translate_google_api_key'] ) );
		$any_validation_attempted = true;
		if ( $atfpp_is_wp_ai_client_exist ) {
			$result = atfpp_wp_connectors_client_provider_key_validate( 'google', $new_google_key );
			if ( is_array( $result ) && isset( $result['message'] ) ) {
				atfpp_show_admin_notice( 'error', $result['message'] );
				$has_error = true;
			} elseif ( true === $result ) {
				$valid_keys['google'] = $new_google_key;
				delete_transient( 'atfpp_google_models' );
			}
		} elseif ( atfpp_validate_google_api_key( $new_google_key ) ) {
			$valid_keys['google'] = $new_google_key;
		} else {
			$has_error = true;
		}
	}

	if ( ! empty( $_POST['Atfpp_Ai_Translate_openai_api_key'] ) ) {
		$new_openai_key           = sanitize_text_field( wp_unslash( $_POST['Atfpp_Ai_Translate_openai_api_key'] ) );
		$any_validation_attempted = true;
		if ( $atfpp_is_wp_ai_client_exist ) {
			$result = atfpp_wp_connectors_client_provider_key_validate( 'openai', $new_openai_key );
			if ( is_array( $result ) && isset( $result['message'] ) ) {
				atfpp_show_admin_notice( 'error', $result['message'] );
				$has_error = true;
			} elseif ( true === $result ) {
				$valid_keys['openai'] = $new_openai_key;
				delete_transient( 'atfpp_openai_models' );
			}
		} elseif ( atfpp_validate_openai_api_key( $new_openai_key ) ) {
			$valid_keys['openai'] = $new_openai_key;
		} else {
			$has_error = true;
		}
	}

	if ( ! empty( $_POST['Atfpp_Ai_Translate_deepl_api_key'] ) ) {
		$new_deepl_key            = sanitize_text_field( wp_unslash( $_POST['Atfpp_Ai_Translate_deepl_api_key'] ) );
		$any_validation_attempted = true;
		if ( $atfpp_is_wp_ai_client_exist ) {
			$result = atfpp_wp_connectors_client_provider_key_validate( 'deepl', $new_deepl_key );
			if ( is_array( $result ) && isset( $result['message'] ) ) {
				atfpp_show_admin_notice( 'error', $result['message'] );
				$has_error = true;
			} elseif ( true === $result ) {
				$valid_keys['deepl'] = $new_deepl_key;
			}
		} elseif ( atfpp_validate_deepl_api_key( $new_deepl_key ) ) {
			$valid_keys['deepl'] = $new_deepl_key;
		} else {
			$has_error = true;
		}
	}

	$atfpp_valie_api_option_name = array( 'openai', 'google', 'deepl' );

	// Only save and show success if there were no errors
	if ( ! $has_error && ! empty( $valid_keys ) ) {
		foreach ( $valid_keys as $key => $value ) {
			if ( ! in_array( $key, $atfpp_valie_api_option_name ) ) {
				continue;
			}

			if ( $atfpp_is_wp_ai_client_exist ) {
				$atfpp_api_option_name = 'connectors_ai_' . sanitize_text_field( $key ) . '_api_key';
			} else {
				$atfpp_api_option_name = 'Atfpp_Ai_Translate_' . sanitize_text_field( $key ) . '_api_key';
			}

			update_option( sanitize_text_field( $atfpp_api_option_name ), $value );
		}
		atfpp_show_admin_notice( 'success', 'Settings saved successfully.' );
		return true;
	} elseif ( $any_validation_attempted && ! isset( $GLOBALS['atfpp_admin_notices'] ) ) {
		atfpp_show_admin_notice( 'error', 'Please enter valid values.' );
	}

	return false;
}

function atfpp_get_ai_model_list( $atfpp_api_provider_id, $exclude_patterns = array() ) {

	if ( ! in_array( $atfpp_api_provider_id, array( 'openai', 'google', 'deepl' ) ) ) {
		return array();
	}

	$atfpp_is_wp_ai_client_exist = ATFPP_Helper::is_wp_ai_client_exist();
	if ( $atfpp_is_wp_ai_client_exist ) {
		$atfpp_api_provider_models_cache_key = 'atfpp_' . $atfpp_api_provider_id . '_models';
		$atfpp_api_provider_models           = get_transient( $atfpp_api_provider_models_cache_key );

		if ( false !== $atfpp_api_provider_models && is_array( $atfpp_api_provider_models ) ) {
			return $atfpp_api_provider_models;
		} else {
			try {
				if (
					class_exists( '\WordPress\AiClient\Providers\Models\DTO\ModelRequirements' ) &&
					class_exists( '\WordPress\AiClient\Providers\Models\Enums\CapabilityEnum' )
				) {
					$atfpp_wp_connectors_registry = \WordPress\AiClient\AiClient::defaultRegistry();

					$automlp_requirements    = new \WordPress\AiClient\Providers\Models\DTO\ModelRequirements(
						array( \WordPress\AiClient\Providers\Models\Enums\CapabilityEnum::textGeneration() ),
						array()
					);
					$automlp_models_metadata = $atfpp_wp_connectors_registry->findProviderModelsMetadataForSupport( 'openai', $automlp_requirements );

					$atfpp_api_provider_models = array_map(
						static function ( $model ) {
							/** @var \WordPress\AiClient\Providers\Models\DTO\ModelMetadata $model */
							return $model->getId();
						},
						$automlp_models_metadata
					);

					// Filter out non-translation models (audio, transcribe, search, codex, etc.)
					$atfpp_api_provider_models = array_filter(
						$atfpp_api_provider_models,
						function ( $model_id ) use ( $exclude_patterns ) {
							$model_lower = strtolower( $model_id );
							foreach ( $exclude_patterns as $pattern ) {
								if ( strpos( $model_lower, $pattern ) !== false ) {
									return false;
								}
							}
							return true;
						}
					);

					set_transient( $atfpp_api_provider_models_cache_key, $atfpp_api_provider_models, 24 * HOUR_IN_SECONDS );

					return $atfpp_api_provider_models;
				}
			} catch ( \Throwable $e ) {
				return array();
			}
		}
	} else {
		$atfpp_ai_model_option_name = 'Atfpp_Ai_Translate_' . sanitize_text_field( $atfpp_api_provider_id ) . '_models';
		return get_option( $atfpp_ai_model_option_name, array() );
	}
	return array();
}

function atfpp_render_settings_page_html( $apis, $is_pro = false ) {
	// Process form submission before rendering
	$form_processed = false;
	if ( $is_pro && defined( 'ATFPP_SETTINGS_PRO' ) && ATFPP_SETTINGS_PRO && atfpp_check_form_submission() ) {
		$form_processed = atfpp_handle_api_key_submission();
	}

	$is_pro = defined( 'ATFPP_SETTINGS_PRO' ) && ATFPP_SETTINGS_PRO;

	// Refresh API values after form processing
	if ( $form_processed ) {
		atfpp_get_api_configurations( $apis, $is_pro );
	} else {
		atfpp_get_api_configurations( $apis, $is_pro );
	}

	// Update the context aware value if it was just saved
	if ( isset( $GLOBALS['atfpp_current_context_aware'] ) ) {
		$apis['context_aware']['value'] = $GLOBALS['atfpp_current_context_aware'];
	}

	if ( isset( $apis['deepl']['glossary_id'] ) ) {
		$apis['deepl']['glossary_id'] = get_option( 'atfpp_deepl_glossary_id', '' );
	}

	if ( isset( $apis['deepl']['glossary_type'] ) ) {
		$apis['deepl']['glossary_type'] = get_option( 'atfpp_deepl_glossary_type', 'default' );
	}

	if ( isset( $apis['atfpp_bulk_post_status']['value'] ) ) {
		$apis['atfpp_bulk_post_status']['value'] = get_option( 'atfp_bulk_post_status', 'draft' );
	}

	if ( isset( $apis['atfp_slug_translation_option']['value'] ) ) {
		$apis['atfp_slug_translation_option']['value'] = get_option( 'atfp_slug_translation_option', 'title_translate' );
	}

	if ( isset( $apis['atfp_retranslation_enabled']['value'] ) ) {
		$apis['atfp_retranslation_enabled']['value'] = get_option( 'atfp_retranslation_enabled', 'true' );
	}

	if ( isset( $apis['atfp_ai_request_token_per_request']['value'] ) ) {
		$apis['atfp_ai_request_token_per_request']['value'] = get_option( 'atfp_ai_request_token_per_request', 500 );
	}

	if ( isset( $apis['atfp_ai_request_batch_size']['value'] ) ) {
		$apis['atfp_ai_request_batch_size']['value'] = get_option( 'atfp_ai_request_batch_size', 5 );
	}

	if ( isset( $apis['atfp_ai_request_timeout']['value'] ) ) {
		$apis['atfp_ai_request_timeout']['value'] = get_option( 'atfp_ai_request_timeout', 120 );
	}

	$atfpp_openai_models  = isset( $apis['openai']['value'] ) && ! empty( $apis['openai']['value'] ) ? atfpp_get_ai_model_list(
		'openai',
		array(
			'audio',
			'transcribe',
			'search',
			'codex',
			'diarize',
			'whisper',
			'tts',
			'dall-e',
			'embedding',
			'image',
		)
	) : array();
	$current_openai_model = get_option( 'atfpp_selected_openai_model', '' );
	$atfpp_google_models  = isset( $apis['google']['value'] ) && ! empty( $apis['google']['value'] ) ? atfpp_get_ai_model_list(
		'google',
		array(
			'audio',
			'transcribe',
			'search',
			'vision',
			'embedding',
			'code',
			'imagen',
			'musiclm',
			'image',
		)
	) : array();
	$current_google_model = get_option( 'atfpp_selected_google_model', '' );
	?>
	<div class="atfpp-dashboard-settings">
		<div class="atfpp-dashboard-settings-container">
		<?php
		// Show notices at the top of the container
		if ( isset( $GLOBALS['atfpp_admin_notices'] ) ) {
			foreach ( $GLOBALS['atfpp_admin_notices'] as $notice ) {
				echo wp_kses_post( $notice );
			}
		}
		?>
			<div class="header">
				<h1><?php echo esc_html__( 'Settings', 'autopoly-ai-translation-for-polylang-pro' ); ?></h1>
			</div>

			<?php if ( $is_pro ) : ?>
			<p class="api-settings-description">
				<?php echo esc_html__( 'Configure your settings for the Polylang Addon to optimize your translation experience. Enter your API keys and manage your preferences for seamless integration.', 'autopoly-ai-translation-for-polylang-pro' ); ?>
			</p>
			<?php else : ?>
				<p class="api-settings-description">
				<?php
				// translators: 1: License key
				printf( esc_html__( 'Configure your settings for the Polylang Addon to optimize your translation experience. Start by entering your %s. Once it\'s activated, you\'ll be able to add your Gemini or OpenAI API keys and manage your preferences for seamless integration.', 'autopoly-ai-translation-for-polylang-pro' ), '<strong><a href="' . esc_url( admin_url( 'admin.php?page=polylang-atfpp-dashboard&tab=license' ) ) . '">' . esc_html__( 'license key', 'autopoly-ai-translation-for-polylang-pro' ) . '</a></strong>' )
				?>
			</p>
				<?php
				endif;
			$atfp_enabled_providers            = get_option( 'atfp_enabled_providers', array( 'chrome-built-in-ai', 'yandex-translate' ) );
			$atfp_polylang_supported_languages = ATFPP_Helper::get_polylang_supported_languages();

			if ( is_array( $atfp_enabled_providers ) && in_array( 'chrome-built-in-ai', $atfp_enabled_providers ) ) {
				?>
					<h2 class="atfpp-section-title atfpp-section-title-with-icon">
						<span class="atfpp-section-icon atfpp-icon-sparkle" aria-hidden="true">
							<img
								src="<?php echo esc_url( ATFPP_URL . 'assets/images/chrome.png' ); ?>"
								alt=""
								width="20"
								height="20"
								loading="lazy"
								decoding="async"
							/>
						</span>
						<?php esc_html_e( 'Chrome AI Configuration', 'autopoly-ai-translation-for-polylang-pro' ); ?>
					</h2>
					<p class="atfpp-section-description">
						<?php esc_html_e( 'Use Chrome’s built-in AI to translate strings. Configure and test it here.', 'autopoly-ai-translation-for-polylang-pro' ); ?>
					</p>
					<div class="atfpp-dashboard-chrome-ai-settings">
						<!-- Chrome Local AI Notice -->
						<div id="atfpp-chrome-local-ai-notice" class="atfpp-chrome-local-ai-notice atfpp-dashboard-settings-card">
						<?php if ( empty( $atfp_polylang_supported_languages ) ) { ?>
							<span class="atfpp-chrome-no-languages-content"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" id="error"><g><rect fill="none"/></g><g><path d="M12 7c.55 0 1 .45 1 1v4c0 .55-.45 1-1 1s-1-.45-1-1V8c0-.55.45-1 1-1zm-.01-5C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm1-3h-2v-2h2v2z"></path></g></svg>
							<?php
								printf(
									wp_kses_post(
										// translators: %s is a link to the Polylang languages page.
										__( 'Add at least %s to use the Chrome AI translation test', 'autopoly-ai-translation-for-polylang-pro' )
									),
									'<a href="' . esc_url( admin_url( 'admin.php?page=mlang' ) ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'one language in Polylang', 'autopoly-ai-translation-for-polylang-pro' ) . '</a>'
								);
							?>
																																																																																																																	</span>
						<?php } else { ?>
							<div class="atfpp-chrome-local-ai-notice-content">
								<h3 id="atfpp-chrome-notice-heading" class="atfpp-chrome-notice-heading"></h3>
								<div id="atfpp-chrome-notice-message" class="atfpp-chrome-notice-message"></div>
							</div>

							<!-- Test Translation Section -->
							<div id="atfpp-chrome-test-translation" class="atfpp-chrome-test-translation">
								<h3 class="atfpp-chrome-test-translation-heading"><?php esc_html_e( 'Chrome AI Translation Test', 'autopoly-ai-translation-for-polylang-pro' ); ?></h3>
								<p class="atfpp-chrome-test-translation-description"><?php esc_html_e( 'Check whether Chrome AI Translation is properly configured by translating a sample text.', 'autopoly-ai-translation-for-polylang-pro' ); ?></p>

								<div class="atfpp-chrome-test-translation-language-pair">
									<label class="atfpp-chrome-test-translation-label"><?php esc_html_e( 'Language Pair:', 'autopoly-ai-translation-for-polylang-pro' ); ?></label>
									<select id="atfpp-test-translation-source" class="atfpp-chrome-test-translation-source"></select>
									<span class="atfpp-chrome-test-translation-arrow">→</span>
									<select id="atfpp-test-translation-target" class="atfpp-chrome-test-translation-target"></select>
								</div>
								
								<input type="text" id="atfpp-test-translation-text" class="atfpp-chrome-test-translation-text" placeholder="<?php esc_attr_e( 'Enter text to translate', 'autopoly-ai-translation-for-polylang-pro' ); ?>" value="Hello, this is a test translation."><br>
								<button id="atfpp-test-translation-btn" class="atfpp-dashboard-btn primary atfpp-chrome-test-translation-btn">
									<?php esc_html_e( 'Test Translation', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</button>

								<div id="atfpp-test-translation-result" class="atfpp-chrome-test-translation-result"></div>
								<div id="atfpp-test-translation-error" class="atfpp-chrome-test-translation-error"></div>
							</div>
						<?php } ?>
						</div>
					</div>
				<?php
			}
			?>
			<div class="atfpp-dashboard-api-settings-container">
					<form method="post">
					<?php wp_nonce_field( 'atfpp_api_keys', 'nonce' ); ?>
					<?php
					foreach ( $apis as $key => $api ) :
						if ( $key === 'google' ) {
							?>
								<h2 class="atfpp-section-title atfpp-section-title-with-icon">
									<span class="atfpp-section-icon atfpp-icon-api" aria-hidden="true">
										<img
											src="<?php echo esc_url( ATFPP_URL . 'assets/images/api-key.svg' ); ?>"
											alt=""
											width="20"
											height="20"
											loading="lazy"
											decoding="async"
										/>
									</span>
								<?php esc_html_e( 'AI API Keys & Models', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</h2>
								<p class="atfpp-section-description">
								<?php esc_html_e( 'Configure your API keys and models for the AI translation providers.', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</p>
								<div class="atfpp-dashboard-api-settings atfpp-dashboard-settings-card">
							<?php } elseif ( $key === 'context_aware' ) { ?>
								<h2 class="atfpp-section-title atfpp-section-title-with-icon">
									<span class="atfpp-section-icon atfpp-icon-translate" aria-hidden="true">
										<img
											src="<?php echo esc_url( ATFPP_URL . 'assets/images/translate.svg' ); ?>"
											alt=""
											width="20"
											height="20"
											loading="lazy"
											decoding="async"
										/>
									</span>
									<?php esc_html_e( 'Translation Settings', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</h2>
								<p class="atfpp-section-description">
									<?php esc_html_e( 'Configure the translation settings for AI translations.', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</p>
								<div class="atfpp-dashboard-translation-settings atfpp-dashboard-settings-card">
							<?php } elseif ( $key === 'atfp_ai_request_token_per_request' ) { ?>
								<h2 class="atfpp-section-title atfpp-section-title-with-icon">
									<span class="atfpp-section-icon atfpp-icon-performance" aria-hidden="true">
										<img
											src="<?php echo esc_url( ATFPP_URL . 'assets/images/ai-performance.svg' ); ?>"
											alt=""
											width="20"
											height="20"
											loading="lazy"
											decoding="async"
										/>
									</span>
									<?php esc_html_e( 'AI Request Performance', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</h2>
								<p class="atfpp-section-description">
									<?php esc_html_e( 'Adjust these settings to optimize the speed, stability, and processing performance of your AI requests.', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</p>
								<div class="atfpp-dashboard-ai-request-container atfpp-dashboard-settings-card">
								<?php
							}
							if ( $key === 'context_aware' ) :
								?>
								<label for="<?php echo esc_attr( $key ); ?>-input" class="api-settings-label">
									<?php echo esc_html__( 'Context Aware', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</label>
								<textarea 
									id="<?php echo esc_attr( $key ); ?>-input" 
									name="<?php echo esc_attr( $api['option_key'] ); ?>"
									placeholder="Provide optional context about WordPress page or post to enhance translation accuracy (e.g. content purpose, target audience, SEO focus, tone)..."
									<?php echo $is_pro ? '' : 'disabled'; ?>
								><?php echo esc_textarea( $api['value'] ); ?></textarea>
								<p class="api-settings-description" style="margin-block: 5px;">
									<?php echo esc_html__( 'This setting only works with Gemini AI and OpenAI.', 'autopoly-ai-translation-for-polylang-pro' ); ?>
								</p>
								<?php
								elseif ( $key === 'atfpp_bulk_post_status' ) :
									?>
								<label for="<?php echo esc_attr( $key ); ?>-input" class="api-settings-label">
									<?php echo esc_html( $api['name'] ); ?>
								</label>
								<div class="atfpp-bulk-translation-post-status-options">
									<?php
									foreach ( $api['options'] as $option_key => $option_value ) :
										?>
									<input type="radio" name="<?php echo esc_attr( $api['option_key'] ); ?>" id="atfpp_bulk_post_status_<?php echo esc_attr( $option_key ); ?>" value="<?php echo esc_attr( $option_key ); ?>" <?php echo esc_attr( $api['value'] ) === $option_key ? 'checked' : ''; ?> <?php echo $is_pro ? '' : 'disabled'; ?>>
									<label for="atfpp_bulk_post_status_<?php echo esc_attr( $option_key ); ?>"><?php echo esc_html( $option_value ); ?></label>
										<?php
								endforeach;
									?>
								</div>
									<?php
							elseif ( $key === 'atfp_slug_translation_option' ) :
								?>
								<label for="<?php echo esc_attr( $key ); ?>-input" class="api-settings-label">
									<?php echo esc_html( $api['name'] ); ?>
								</label>
								<div class="atfpp-bulk-translation-post-status-options">
									<?php
									foreach ( $api['options'] as $option_key => $option_value ) :
										?>
										<input type="radio" name="<?php echo esc_attr( $api['option_key'] ); ?>" id="atfpp_translated_slug_strategy_<?php echo esc_attr( $option_key ); ?>" value="<?php echo esc_attr( $option_key ); ?>" <?php echo esc_attr( $api['value'] ) === $option_key ? 'checked' : ''; ?> <?php echo $is_pro ? '' : 'disabled'; ?>>
										<label for="atfpp_translated_slug_strategy_<?php echo esc_attr( $option_key ); ?>"><?php echo esc_html( $option_value ); ?></label>
										<?php
									endforeach;
									?>
								</div>
								<?php
							elseif ( $key === 'atfp_retranslation_enabled' ) :
								?>
								<div class="atfpp-switch-container">
									<label for="<?php echo esc_attr( $key ); ?>-input" class="atfpp-switch-label api-settings-label atfpp-switch-with-label">
									<?php echo esc_html( $api['name'] ); ?>
									<div class="atfpp-switch-input-container">
										<input type="checkbox" class="atfpp-input-toggle" name="<?php echo esc_attr( $api['option_key'] ); ?>" id="<?php echo esc_attr( $key ); ?>-input" value="true" <?php echo esc_attr( $api['value'] ) === 'true' ? 'checked' : ''; ?> <?php echo $is_pro ? '' : 'disabled'; ?>>
										<span class="atfpp-switch-slider"></span>
									</div>
									</label>
								</div>
								<p class="api-settings-description"><?php echo esc_html__( 'Adds a Re-Translation button in posts and enables automatic re-translation in bulk translation when the source content is updated.', 'autopoly-ai-translation-for-polylang-pro' ); ?></p>
								<?php
								elseif ( $key === 'atfp_ai_request_token_per_request' ) :
									?>
								<div class="atfpp-dashboard-ai-token-container">
									<label for="<?php echo esc_attr( $key ); ?>-input" class="api-settings-label">
										<?php echo esc_html( $api['name'] ); ?>
									</label>
									<div class="atfpp-dashboard-ai-token-container-input">
										<input type="number" min="100" max="10000" step="100" name="<?php echo esc_attr( $api['option_key'] ); ?>" id="<?php echo esc_attr( $key ); ?>-input" value="<?php echo esc_attr( $api['value'] ); ?>" <?php echo $is_pro ? '' : 'disabled'; ?>>
										<p class="api-settings-description">
										<?php
										// translators: 1: span tag, 2: span tag
										printf( __( 'Controls text size per request; higher values give detailed results but slower speed. %1$sRecommended: 500%2$s', 'autopoly-ai-translation-for-polylang-pro' ), '<span>(', ')</span>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- span tags are safe
										?>
										</p>
									</div>
								</div>
									<?php
							elseif ( $key === 'atfp_ai_request_batch_size' ) :
								?>
								<div class="atfpp-dashboard-ai-batch-size-container">
									<label for="<?php echo esc_attr( $key ); ?>-input" class="api-settings-label">
										<?php echo esc_html( $api['name'] ); ?>
									</label>
									<div class="atfpp-dashboard-ai-batch-container-input">
										<input type="number" min="1" max="10" name="<?php echo esc_attr( $api['option_key'] ); ?>" id="<?php echo esc_attr( $key ); ?>-input" value="<?php echo esc_attr( $api['value'] ); ?>" <?php echo $is_pro ? '' : 'disabled'; ?>>
										<p class="api-settings-description">
										<?php
										// translators: 1: span tag, 2: span tag
										printf( __( 'Sets how many items process together; lower values improve speed and stability. %1$sRecommended: 5%2$s', 'autopoly-ai-translation-for-polylang-pro' ), '<span>(', ')</span>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- span tags are safe
										?>
										</p>
									</div>
								</div>
								<?php
							elseif ( $key === 'atfp_ai_request_timeout' ) :
								?>
								<div class="atfpp-dashboard-ai-timeout-container">
									<label for="<?php echo esc_attr( $key ); ?>-input" class="api-settings-label">
										<?php echo esc_html( $api['name'] ); ?>
									</label>
									<div class="atfpp-dashboard-ai-timeout-container-input">
										<input type="number" min="10" max="1200" step="10" name="<?php echo esc_attr( $api['option_key'] ); ?>" id="<?php echo esc_attr( $key ); ?>-input" value="<?php echo esc_attr( $api['value'] ); ?>" <?php echo $is_pro ? '' : 'disabled'; ?>>
										<p class="api-settings-description">
										<?php
										// translators: 1: span tag, 2: span tag
										printf( __( 'Defines wait time before stopping; increase if requests often fail or delay. %1$sRecommended: 120 seconds%2$s', 'autopoly-ai-translation-for-polylang-pro' ), '<span>(', ')</span>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- span tags are safe
										?>
										</p>
									</div>
								</div>
								<?php
							else :
								$has_key      = ! empty( $api['value'] );
								$masked_value = $has_key && $is_pro ?
									esc_attr( substr( $api['value'], 0, 8 ) . str_repeat( '*', 24 ) . substr( $api['value'], -8 ) ) :
									'';
								?>
								<label for="<?php echo esc_attr( $key ); ?>-api" class="api-settings-label">
									<?php
									// translators: 1: API name
									printf( esc_html__( 'Add %s API key', 'autopoly-ai-translation-for-polylang-pro' ), esc_html( $api['name'] ) );
									?>
								</label>
								<div class="input-group">
									<input type="text" 
										id="<?php echo esc_attr( $key ); ?>-api" 
										name="<?php echo esc_attr( $api['option_key'] ); ?>" 
										value="<?php echo esc_attr( $masked_value ); ?>" 
										placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
										<?php echo $has_key || ! $is_pro ? 'disabled' : ''; ?>>
									
									<?php if ( $has_key && $is_pro ) : ?>
										<span style="color: #46b450; font-size: 14px; margin-right: 4px;">✓</span>
										<button type="submit" name="reset_<?php echo esc_attr( $key ); ?>_api_key" class="button button-primary reset-button">
											<?php echo esc_html__( 'Reset', 'autopoly-ai-translation-for-polylang-pro' ); ?>
										</button>
									<?php endif; ?>
								</div>

								<?php
								if ( $key === 'openai' && $has_key && ! empty( $atfpp_openai_models ) ) :
									?>
								<div class="atfpp-dashboard-api-settings-model">
									<label for="atfpp_selected_openai_model" class="api-settings-label">
											<?php esc_html_e( 'Select OpenAI Model', 'autopoly-ai-translation-for-polylang-pro' ); ?>
									</label>
									<select name="atfpp_selected_openai_model" class="atfpp-openai-model-select">
										<option value=""><?php esc_html_e( 'Select model...', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
											<?php foreach ( $atfpp_openai_models as $model ) : ?>
											<option value="<?php echo esc_attr( $model ); ?>" <?php selected( $current_openai_model, $model ); ?>>
												<?php echo esc_html( $model ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
								<?php endif; ?>

								<?php if ( $key === 'google' && $has_key && ! empty( $atfpp_google_models ) ) : ?>
								<div class="atfpp-dashboard-api-settings-model">
									<label for="atfpp_selected_google_model" class="api-settings-label">
										<?php esc_html_e( 'Select Gemini Model', 'autopoly-ai-translation-for-polylang-pro' ); ?>
									</label>
									<select name="atfpp_selected_google_model" class="atfpp-google-model-select">
										<option value=""><?php esc_html_e( 'Select model...', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
										<?php foreach ( $atfpp_google_models as $model ) : ?>
											<option value="<?php echo esc_attr( $model ); ?>" <?php selected( $current_google_model, $model ); ?>>
												<?php echo esc_html( $model ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
							<?php endif; ?>

								<?php
								if ( $key === 'deepl' && $has_key ) :
									$marsket_glossary_id = $api['glossary_id'] ? esc_attr( substr( $api['glossary_id'], 0, 8 ) . str_repeat( '*', 24 ) . substr( $api['glossary_id'], -8 ) . ' ✅' ) : '';
									?>
								<div class="atfpp-dashboard-api-settings-deepl-glossary">
									<label for="atfpp_deepl_glossary_type" class="api-settings-label">
										<?php
										// translators: 1: API name
										printf( esc_html__( '%s Glossary Type', 'autopoly-ai-translation-for-polylang-pro' ), 'DeepL' );
										?>
									</label>

									<select name="atfpp_deepl_glossary_type" 
											class="atfpp-deepl-glossary-select" 
											id="atfpp_deepl_glossary_type">

										<!-- Default: AutoPoly glossaries -->
										<option value="default" <?php selected( $api['glossary_type'], 'default' ); ?>>
												<?php esc_html_e( 'AutoPoly Glossary', 'autopoly-ai-translation-for-polylang-pro' ); ?>
										</option>

										<!-- DeepL native glossary -->
										<option value="deepl" <?php selected( $api['glossary_type'], 'deepl' ); ?>>
												<?php esc_html_e( 'DeepL Glossary', 'autopoly-ai-translation-for-polylang-pro' ); ?>
										</option>
									</select>

									<p class="api-settings-description">
											<?php esc_html_e( 'Choose which glossary system should be applied during translation.', 'autopoly-ai-translation-for-polylang-pro' ); ?>
									</p>
								</div>
								<div class="atfpp-deepl-glossary-id-wrp" style="display: <?php echo ( isset( $api['glossary_type'] ) && $api['glossary_type'] === 'deepl' ) ? 'block' : 'none'; ?>;">
									<label for="atfpp_deepl_glossary_id" class="api-settings-label">
											<?php
											// translators: 1: API name
											printf( esc_html__( 'Add %s Glossary ID', 'autopoly-ai-translation-for-polylang-pro' ), 'DeepL' );
											?>
									</label>
									<div class="input-group">
										<input type="text" 
											id="atfpp_deepl_glossary_id" 
											name="atfpp_deepl_glossary_id" 
											value="<?php echo esc_attr( $marsket_glossary_id ); ?>" 
											placeholder="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
												<?php echo ! empty( $api['glossary_id'] ) ? 'disabled' : ''; ?>>
										
											<?php if ( ! empty( $api['glossary_id'] ) ) : ?>
											<button type="submit" name="reset_deepl_glossary_id" class="button button-primary reset-button">
												<?php echo esc_html__( 'Reset', 'autopoly-ai-translation-for-polylang-pro' ); ?>
											</button>
										<?php endif; ?>
									</div>
								</div>
								<?php endif; ?>
								<?php if ( ! $has_key ) : ?>
									<p class="api-settings-description">
									<?php
									printf(
										// translators: 1: Click Here link, 2: API name
										esc_html__( '%1$s to See How to Generate %2$s API Key', 'autopoly-ai-translation-for-polylang-pro' ),
										'<a href="' . esc_url( $api['docs_url'] ) . '" target="_blank">' . esc_html__( 'Click Here', 'autopoly-ai-translation-for-polylang-pro' ) . '</a>',
										esc_html( $api['name'] )
									);
									?>
									</p>
								<?php endif; ?>
							<?php endif; ?>
							<?php
							if ( $key === 'deepl' ) {
								echo '</div>';
							} elseif ( $key === 'atfp_retranslation_enabled' ) {
								echo '</div>';
							} elseif ( $key === 'atfp_ai_request_timeout' ) {
								echo '</div>';
							}
							endforeach;
					?>
					<?php if ( get_option( 'cpfm_opt_in_choice_cool_translations' ) && $is_pro ) : ?>
							<div class="atfpp-dashboard-feedback-container">
								<div class="atfpp-dashboard-feedback-row">
									<input type="checkbox" 
										id="atfpp-dashboard-feedback-checkbox" 
										name="atfpp-dashboard-feedback-checkbox"
										<?php checked( get_option( 'atfp_feedback_opt_in' ), 'yes' ); ?>>
									<p><?php echo esc_html__( 'Help us make this plugin more compatible with your site by sharing non-sensitive site data.', 'autopoly-ai-translation-for-polylang-pro' ); ?></p>
									<a href="#" class="atfpp-see-terms">[See terms]</a>
								</div>
								<div id="termsBox" style="display: none;padding-left: 20px; margin-top: 10px; font-size: 12px; color: #999;">
										<p><?php echo esc_html__( "Opt in to receive email updates about security improvements, new features, helpful tutorials, and occasional special offers. We'll collect:", 'autopoly-ai-translation-for-polylang-pro' ); ?> <a href="https://my.coolplugins.net/terms/usage-tracking/?utm_source=atfpp_plugin&utm_medium=inside&utm_campaign=terms&utm_content=dashboard" target="_blank"><?php echo esc_html__( 'Click Here', 'autopoly-ai-translation-for-polylang-pro' ); ?></a></p>
										<ul style="list-style-type:auto;">
											<li><?php echo esc_html__( 'Your website home URL and WordPress admin email.', 'autopoly-ai-translation-for-polylang-pro' ); ?></li>
											<li><?php echo esc_html__( 'To check plugin compatibility, we will collect the following: list of active plugins and themes, server type, MySQL version, WordPress version, memory limit, site language and database prefix.', 'autopoly-ai-translation-for-polylang-pro' ); ?></li>
										</ul>
								</div>
							</div>
						<?php endif; ?>
						<div class="atfpp-dashboard-save-btn-container">
							<button type="submit" name="submit_api_keys" class="button button-primary" <?php echo $is_pro ? '' : 'disabled'; ?>>
							<?php echo esc_html__( 'Save', 'autopoly-ai-translation-for-polylang-pro' ); ?>
							</button>
						</div>
					</form>
			</div>
		</div>
			<?php
			$file_prefix = ATFPP_DIR_PATH . 'admin/atfpp-dashboard/views/';
			$footer_file = $file_prefix . 'footer.php';
			if ( file_exists( $footer_file ) ) {
				require_once $footer_file;
			}
			?>
	</div>
		<?php
}

function atfpp_all_apis_configured( $apis ) {
	foreach ( $apis as $api ) {
		if ( empty( $api['value'] ) ) {
			return false;
		}
	}
	return true;
}


