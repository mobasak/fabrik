<?php

if (!defined('ABSPATH')) exit;

$atfpp_glossary_data = get_option('atfpp_glossary_data', []);

if (!is_array($atfpp_glossary_data)) {
    $atfpp_glossary_data = [];
}

// --- Build $atfpp_languages array ONCE at the top and reuse everywhere ---
$atfpp_pll_languages_serialized = get_option('_transient_pll_languages_list');

$atfpp_pll_languages = [];

if (function_exists('PLL') && property_exists(PLL(), 'model')) {
    $atfpp_pll_languages_list = PLL()->model->get_languages_list();

    if (is_array($atfpp_pll_languages_list) && count($atfpp_pll_languages_list) > 0) {
        foreach ($atfpp_pll_languages_list as $atfpp_pll_lang) {
            $atfpp_pll_languages[] = $atfpp_pll_lang->to_array();
        }
    }
}

if (empty($atfpp_pll_languages) && $atfpp_pll_languages_serialized) {
    $atfpp_pll_languages = maybe_unserialize($atfpp_pll_languages_serialized);
}

$atfpp_languages = [];
if (is_array($atfpp_pll_languages)) {
    foreach ($atfpp_pll_languages as $atfpp_pll_lang) {
        $atfpp_languages[] = [
            'code' => $atfpp_pll_lang['slug'],
            'img'  => $atfpp_pll_lang['flag_url'],
            'alt'  => $atfpp_pll_lang['name'],
            'flag' => isset($atfpp_pll_lang['flag']) ? $atfpp_pll_lang['flag'] : '',
        ];
    }
}

// Build a map for quick lookup by code
$atfpp_language_map = [];
foreach ($atfpp_languages as $atfpp_lang) {
    $atfpp_language_map[$atfpp_lang['code']] = $atfpp_lang;
}

$atfpp_supported_languages = array_keys($atfpp_language_map);
$atfpp_grouped_entries = [];

foreach ($atfpp_glossary_data as $atfpp_entry) {
    $term = $atfpp_entry['original_term'];
    $atfpp_lang = $atfpp_entry['original_language_code'];
    $atfpp_key = $term . '||' . $atfpp_lang; // Composite key

    if ($atfpp_lang && !in_array($atfpp_lang, $atfpp_supported_languages)) {
        continue;
    }

    if (!isset($atfpp_grouped_entries[$atfpp_key])) {
        $atfpp_grouped_entries[$atfpp_key] = [
            'term' => $term,
            'original_language_code' => $atfpp_lang,
            'desc' => $atfpp_entry['description'],
            'type' => $atfpp_entry['kind'],
            'type_label' => ucfirst($atfpp_entry['kind']),
            'translations' => [],
        ];
    }

    if (!empty($atfpp_entry['translations']) && is_array($atfpp_entry['translations'])) {
        foreach ($atfpp_entry['translations'] as $atfpp_translation) {
            if (
                $atfpp_translation['target_language_code'] !== $atfpp_lang &&
                !empty($atfpp_translation['translated_term']) &&
                trim($atfpp_translation['translated_term']) !== ''
            ) {
                $atfpp_grouped_entries[$atfpp_key]['translations'][$atfpp_translation['target_language_code']] = trim($atfpp_translation['translated_term']);
            }
        }
    }
}

// Sort glossary entries alphabetically by term (case-insensitive)
uksort($atfpp_grouped_entries, 'strnatcasecmp');

// Collect unique original_language_codes and their counts
$atfpp_language_codes = [];
foreach ($atfpp_glossary_data as $atfpp_entry) {
    if (!empty($atfpp_entry['original_language_code'])) {
        $atfpp_code = $atfpp_entry['original_language_code'];
        if (!isset($atfpp_language_codes[$atfpp_code])) {
            $atfpp_language_codes[$atfpp_code] = 0;
        }
        $atfpp_language_codes[$atfpp_code]++;
    }
}
$atfpp_unique_language_codes = array_keys($atfpp_language_codes);

// Compute the unique original language code
$atfpp_unique_original_language_code = '';
if (count($atfpp_unique_language_codes) === 1) {
    $atfpp_unique_original_language_code = reset($atfpp_unique_language_codes);
}

// Add this for default selected language (first in the list)
$atfpp_default_selected_lang = $atfpp_unique_language_codes[0] ?? '';

// --- ADD THIS BLOCK ---
$atfpp_term_original_lang = [];
foreach ($atfpp_glossary_data as $atfpp_entry) {
    $term = $atfpp_entry['original_term'];
    $atfpp_lang = $atfpp_entry['original_language_code'];

    // Initialize as array if not already
    if (!isset($atfpp_term_original_lang[$term])) {
        $atfpp_term_original_lang[$term] = [];
    }

    // Add only if not already present
    if (!in_array($atfpp_lang, $atfpp_term_original_lang[$term])) {
        $atfpp_term_original_lang[$term][] = $atfpp_lang;
    }
}
// --- END ADD ---

// Count how many languages have entries
$atfpp_language_codes_with_entries = [];
foreach ($atfpp_grouped_entries as $atfpp_entry) {
    $atfpp_code = $atfpp_entry['original_language_code'];
    if (!in_array($atfpp_code, $atfpp_language_codes_with_entries, true)) {
        $atfpp_language_codes_with_entries[] = $atfpp_code;
    }
}
$atfpp_single_language_mode = count($atfpp_language_codes_with_entries) === 1;
$atfpp_single_language_code = $atfpp_single_language_mode ? $atfpp_language_codes_with_entries[0] : '';
?>

<style>
    <?php foreach ($atfpp_languages as $atfpp_lang):
        $atfpp_code = esc_attr($atfpp_lang['code']);
    ?>.atfpp-glossary-table.atfpp-hide-lang-<?php echo esc_attr($atfpp_code); ?>th[data-lang="<?php echo esc_attr($atfpp_code); ?>"],
    .atfpp-glossary-table.atfpp-hide-lang-<?php echo esc_attr($atfpp_code); ?>td[data-lang="<?php echo esc_attr($atfpp_code); ?>"] {
        display: none !important;
    }

    <?php endforeach; ?>
</style>

<div class="atfpp-glossary">
    <div class="atfpp-glossary-container">
        <?php wp_nonce_field('atfpp_glossary_nonce', 'atfpp_glossary_nonce'); ?>
        <header class="atfpp-header">
            <h1><?php esc_html_e('Glossary', 'autopoly-ai-translation-for-polylang-pro'); ?></h1>
            <p><?php esc_html_e('Define how you want to translate – or not translate – important words and phrases.', 'autopoly-ai-translation-for-polylang-pro'); ?></p>
            <ul>
                <li><?php esc_html_e('Specific translations you want to use;', 'autopoly-ai-translation-for-polylang-pro'); ?></li>
                <li><?php esc_html_e('Terms you want to exclude from being translated;', 'autopoly-ai-translation-for-polylang-pro'); ?></li>
                <li><?php esc_html_e('Additional context for each term.', 'autopoly-ai-translation-for-polylang-pro'); ?></li>
            </ul>
            <a href="<?php echo esc_url('https://docs.coolplugins.net/doc/glossary-feature-in-autopoly/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_glossary_pro'); ?>" target="_blank"><?php esc_html_e('Learn more about adding and managing glossary terms.', 'autopoly-ai-translation-for-polylang-pro'); ?></a>
        </header>

        <div class="atfpp-controls">
            <input type="text" class="atfpp-search" placeholder="<?php esc_attr_e('Search', 'autopoly-ai-translation-for-polylang-pro'); ?>" />

            <select class="atfpp-glossary-type" name="glossary_type">
                <option value=""><?php esc_html_e('Glossary Type', 'autopoly-ai-translation-for-polylang-pro'); ?></option>
                <option value="name"><?php esc_html_e('Name', 'autopoly-ai-translation-for-polylang-pro'); ?></option>
                <option value="general"><?php esc_html_e('General', 'autopoly-ai-translation-for-polylang-pro'); ?></option>
            </select>

            <button class="atfpp-add-btn button button-primary">
                <?php esc_html_e('Add glossary entry', 'autopoly-ai-translation-for-polylang-pro'); ?>
            </button>
            <button class="atfpp-import-btn button button-primary">
                <?php esc_html_e('Import glossary', 'autopoly-ai-translation-for-polylang-pro'); ?>
            </button>
            <button class="atfpp-export-btn button button-primary">
                <?php esc_html_e('Export glossary', 'autopoly-ai-translation-for-polylang-pro'); ?>
            </button>

            <!-- Modal -->
            <div id="atfpp-glossary-modal-add" class="atfpp-glossary-modal atfpp-hidden">
                <div class="atfpp-glossary-modal-content">
                    <div class="atfpp-glossary-modal-header">
                        <h2><?php esc_html_e('Add New Glossary Term', 'autopoly-ai-translation-for-polylang-pro'); ?></h2>
                        <button type="button" class="atfpp-modal-close-btn" aria-label="Close">&times;</button>
                    </div>
                    <form id="atfpp-add-glossary-form">
                        <div class="atfpp-glossary-modal-body">
                            <label for="atfpp-add-term"><?php esc_html_e('Term', 'autopoly-ai-translation-for-polylang-pro'); ?></label>
                            <textarea id="atfpp-add-term" name="term" class="atfpp-add-term" required placeholder="<?php esc_attr_e('Enter the term to be translated', 'autopoly-ai-translation-for-polylang-pro'); ?>"></textarea>
                            <div class="atfpp-translation-error"></div>

                            <label for="atfpp-add-desc"><?php esc_html_e('Description', 'autopoly-ai-translation-for-polylang-pro'); ?></label>
                            <textarea id="atfpp-add-desc" name="description" class="atfpp-add-desc" rows="3" placeholder="<?php esc_attr_e('Add a description to provide context for translators', 'autopoly-ai-translation-for-polylang-pro'); ?>"></textarea>
                            <div class="atfpp-translation-error"></div>

                            <label for="atfpp-add-source-lang"><?php esc_html_e('Original Language', 'autopoly-ai-translation-for-polylang-pro'); ?></label>
                            <select id="atfpp-add-source-lang" name="source_lang" class="atfpp-add-source-lang" required>
                                <option value=""><?php esc_html_e('Select language', 'autopoly-ai-translation-for-polylang-pro'); ?></option>
                                <?php foreach ($atfpp_languages as $atfpp_lang): ?>
                                    <option value="<?php echo esc_attr($atfpp_lang['code']); ?>">
                                        <?php echo esc_html($atfpp_lang['alt']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <label for="atfpp-add-type"><?php esc_html_e('Type', 'autopoly-ai-translation-for-polylang-pro'); ?></label>
                            <select id="atfpp-add-type" name="type" class="atfpp-add-type" required>
                                <option value="general"><?php esc_html_e('General', 'autopoly-ai-translation-for-polylang-pro'); ?></option>
                                <option value="name"><?php esc_html_e('Name', 'autopoly-ai-translation-for-polylang-pro'); ?></option>
                            </select>
                            <div class="atfpp-add-translations atfpp-translations-grid">
                                <?php foreach ($atfpp_languages as $atfpp_lang): ?>
                                    <div class="atfpp-translation-field atfpp-translation-field-<?php echo esc_attr($atfpp_lang['code']); ?>">
                                        <label>
                                            <div class="atfpp-translation-label-row">
                                                <?php if (!empty($atfpp_lang['img'])): ?>
                                                    <img src="<?php echo esc_attr($atfpp_lang['img']); ?>" alt="<?php echo esc_attr($atfpp_lang['alt']); ?>" class="atfpp-lang-flag">
                                                <?php endif; ?>
                                                <span class="atfpp-lang-name"><?php echo esc_html($atfpp_lang['alt']); ?></span>
                                                <span class="atfpp-lang-translation-label"><?php esc_html_e('Translation', 'autopoly-ai-translation-for-polylang-pro'); ?></span>
                                            </div>
                                            <textarea name="translation_<?php echo esc_attr($atfpp_lang['code']); ?>" class="atfpp-add-translation" rows="2" placeholder="<?php esc_attr_e('Custom Translation', 'autopoly-ai-translation-for-polylang-pro'); ?>"></textarea>
                                            <div class="atfpp-translation-error"><?php esc_html_e('Too long, must be less than 240 characters', 'autopoly-ai-translation-for-polylang-pro'); ?></div>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="atfpp-glossary-modal-actions" style="margin-top: 18px;">
                            <button class="atfpp-glossary-modal-actions-left" style="cursor:pointer;"><?php esc_html_e('Cancel', 'autopoly-ai-translation-for-polylang-pro'); ?></button>
                            <button type="submit" id="add-glossary-term-btn" class="button button-primary"><?php esc_html_e('Add Term', 'autopoly-ai-translation-for-polylang-pro'); ?></button>
                        </div>
                    </form>
                    <div id="add-glossary-success" class="atfpp-import-success atfpp-hidden">
                        <div class="import-success-icon">
                            <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/success.svg'); ?>" alt="Success Icon" />
                        </div>
                        <div class="atfpp-import-success-message">
                            <?php esc_html_e('Glossary term added successfully!', 'autopoly-ai-translation-for-polylang-pro'); ?>
                        </div>
                        <button id="atfpp-glossary-success-close" class="button button-primary" type="button"><?php esc_html_e('Close', 'autopoly-ai-translation-for-polylang-pro'); ?></button>
                    </div>
                </div>
            </div>
            <!-- End Modal -->

            <div id="atfpp-glossary-modal-import" class="atfpp-glossary-modal atfpp-hidden">
                <div class="atfpp-glossary-modal-content">
                    <div class="atfpp-import-glossary" id="atfpp-import-glossary-ui">
                        <div class="atfpp-glossary-modal-header">
                            <h2 class="atfpp-title"><?php esc_html_e('Import glossary', 'autopoly-ai-translation-for-polylang-pro'); ?></h2>
                            <button type="button" class="atfpp-modal-close-btn" aria-label="Close">&times;</button>
                        </div>
                        <div class="atfpp-glossary-modal-body">
                            <label class="atfpp-upload-box" id="upload-label">
                                <input type="file" accept=".csv" id="atfpp-csv-upload" hidden>
                                <div class="atfpp-upload-area">
                                    <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/csv.svg'); ?>" alt="CSV Icon" />
                                    <span id="file-name-display"><?php esc_html_e('Select a CSV file to upload', 'autopoly-ai-translation-for-polylang-pro'); ?></span>
                                </div>
                            </label>
                            <a
                                href="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/sample-glossary.csv'); ?>"
                                class="atfpp-download-link"
                                download="sample-glossary.csv">
                                <?php esc_html_e('Download sample glossary CSV file', 'autopoly-ai-translation-for-polylang-pro'); ?>
                            </a>
                        </div>
                    </div>
                    <!-- Success UI (hidden by default) -->
                    <div id="atfpp-import-success-ui" class="atfpp-hidden">
                        <div id="atfpp-import-success" class="atfpp-import-success">
                            <div class="import-success-icon">
                                <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/success.svg'); ?>" alt="Success Icon" />
                            </div>
                            <div class="import-success-file">
                                <span id="importing-file-label"><?php esc_html_e('Importing:', 'autopoly-ai-translation-for-polylang-pro'); ?></span>
                                <span id="importing-file-name"></span>
                            </div>
                            <div class="atfpp-import-success-message">
                                <?php esc_html_e('Glossary terms imported successfully', 'autopoly-ai-translation-for-polylang-pro'); ?>
                            </div>
                            <button class="atfpp-import-close-btn button button-primary" type="button">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <nav class="atfpp-alphabet" aria-label="<?php esc_attr_e('Glossary Alphabet Navigation', 'autopoly-ai-translation-for-polylang-pro'); ?>">
            <?php
            $atfpp_alphabet = array_merge(['123'], range('A', 'Z'), ['#&à']);

            // Build a set of enabled letters based on $atfpp_glossary_data
            $atfpp_enabled_letters = [];
            foreach ($atfpp_glossary_data as $atfpp_entry) {
                if (!empty($atfpp_entry['original_term'])) {
                    $atfpp_first = mb_substr(trim($atfpp_entry['original_term']), 0, 1, 'UTF-8');
                    if (is_numeric($atfpp_first)) {
                        $atfpp_enabled_letters['123'] = true;
                    } elseif (preg_match('/[A-Za-z]/u', $atfpp_first)) {
                        $atfpp_enabled_letters[strtoupper($atfpp_first)] = true;
                    } else {
                        $atfpp_enabled_letters['#&à'] = true;
                    }
                }
            }

            $atfpp_first_active_set = false;
            foreach ($atfpp_alphabet as $atfpp_char) {
                $atfpp_enabled = isset($atfpp_enabled_letters[$atfpp_char]) ? '' : 'disabled';
                $atfpp_active = '';
                if ($atfpp_enabled === '' && !$atfpp_first_active_set) {
                    $atfpp_first_active_set = true;
                }
                printf(
                    '<button class="atfpp-alphabet-btn%s" %s data-letter="%s">%s</button>',
                    esc_attr($atfpp_active),
                    esc_attr($atfpp_enabled),
                    esc_attr($atfpp_char),
                    esc_html($atfpp_char)
                );
            }
            ?>
        </nav>

        <!-- Language Filter Buttons -->
        <?php
        if (count($atfpp_language_codes_with_entries) > 1): ?>
            <div class="atfpp-language-filters">
                <?php foreach ($atfpp_language_codes_with_entries as $atfpp_index => $atfpp_code): ?>
                    <?php
                    // Skip if language code not in map
                    if (!isset($atfpp_language_map[$atfpp_code])) {
                        continue;
                    }
                    $atfpp_lang = $atfpp_language_map[$atfpp_code];
                    ?>
                    <button class="atfpp-lang-filter-btn<?php echo $atfpp_index === 0 ? ' active' : ''; ?>" data-lang="<?php echo esc_attr($atfpp_code); ?>">
                        <?php if (!empty($atfpp_lang['img'])): ?>
                            <img src="<?php echo esc_url($atfpp_lang['img']); ?>" alt="<?php echo esc_attr($atfpp_lang['alt']); ?>" />
                        <?php endif; ?>
                        <?php echo esc_html($atfpp_lang['alt']) . ' Terms'; ?>
                    </button>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="atfpp-glossary-table-wrapper">
            <?php if (!empty($atfpp_grouped_entries)): ?>
                <table class="atfpp-glossary-table" data-default-lang="<?php echo esc_attr($atfpp_default_selected_lang); ?>">
                    <thead>
                        <tr>
                            <th colspan="2"></th>
                            <?php foreach ($atfpp_languages as $atfpp_lang): ?>
                                <?php if ($atfpp_single_language_mode && $atfpp_lang['code'] === $atfpp_single_language_code) continue; ?>
                                <th colspan="2" title="<?php echo esc_attr($atfpp_lang['alt']); ?>"
                                    class="atfpp-lang-header atfpp-lang-col-<?php echo esc_attr($atfpp_lang['code']); ?>"
                                    data-lang="<?php echo esc_attr($atfpp_lang['code']); ?>">
                                    <?php
                                    echo !empty($atfpp_lang['flag'])
                                        ? wp_kses(
                                            $atfpp_lang['flag'],
                                            [
                                                'img' => [
                                                    'src' => true,
                                                    'alt' => true,
                                                    'width' => true,
                                                    'height' => true,
                                                    'style' => true,
                                                ],
                                            ],
                                            ['data']
                                        )
                                        : '<img src="' . esc_attr($atfpp_lang['img']) . '" alt="' . esc_attr($atfpp_lang['alt']) . '" />';
                                    ?>
                                </th>
                            <?php endforeach; ?>
                            <th class="atfpp-actions-cell">
                                <div class="atfpp-action-buttons-header">
                                    <button class="atfpp-actions-header-btn" id="atfpp-actions-header-btn-left" title="Scroll Left">
                                        <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/arrow-left.svg'); ?>" />
                                    </button>
                                    <button class="atfpp-actions-header-btn" id="atfpp-actions-header-btn-right" title="Scroll Right">
                                        <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/arrow-right.svg'); ?>" />
                                    </button>
                                </div>
                            </th>
                        </tr>
                        <tr>
                            <th>Glossary Entry</th>
                            <th>Type</th>
                            <?php foreach ($atfpp_languages as $atfpp_lang): ?>
                                <?php if ($atfpp_single_language_mode && $atfpp_lang['code'] === $atfpp_single_language_code) continue; ?>
                                <th colspan="2" data-lang="<?php echo esc_attr($atfpp_lang['code']); ?>">
                                    <?php echo esc_html($atfpp_lang['alt']); ?>
                                </th>
                            <?php endforeach; ?>
                            <th colspan="2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // UTF-8 safe truncate helper
                        if (! function_exists('atfpp_truncate')) {
                            function atfpp_truncate($str, $limit = 10)
                            {
                                $str = (string) $str;
                                if (mb_strlen($str, 'UTF-8') > $limit) {
                                    return mb_substr($str, 0, $limit, 'UTF-8') . '…';
                                }
                                return $str;
                            }
                        }

                        foreach ($atfpp_grouped_entries as $atfpp_composite_key => $atfpp_data):
                            list($term, $atfpp_original_language_code) = explode('||', $atfpp_composite_key);
                            $atfpp_first = mb_substr(trim($term), 0, 1, 'UTF-8');
                            $atfpp_row_letter = is_numeric($atfpp_first) ? '123' : (preg_match('/[A-Za-z]/u', $atfpp_first) ? strtoupper($atfpp_first) : '#&à');
                        ?>
                            <tr data-type="<?php echo esc_attr($atfpp_data['type']); ?>"
                                data-original-language="<?php echo esc_attr($atfpp_original_language_code); ?>"
                                data-term="<?php echo esc_attr($term); ?>"
                                data-letter="<?php echo esc_attr($atfpp_row_letter); ?>">

                                <td>
                                    <div class="atfpp-entry-title">
                                        <?php echo esc_html($term); ?>
                                    </div>
                                    <div class="atfpp-entry-desc">
                                        <?php echo esc_html($atfpp_data['desc']); ?>
                                    </div>
                                </td>

                                <td>
                                    <span class="atfpp-type-badge <?php echo esc_attr($atfpp_data['type']); ?>">
                                        <?php echo esc_html(ucfirst($atfpp_data['type'])); ?>
                                    </span>
                                </td>

                                <?php
                                foreach ($atfpp_languages as $atfpp_lang):
                                    if ($atfpp_single_language_mode && $atfpp_lang['code'] === $atfpp_single_language_code) continue;
                                    $atfpp_translation = '';
                                    $atfpp_is_source = ($atfpp_lang['code'] === $atfpp_original_language_code);
                                ?>
                                    <td colspan="2" class="atfpp-lang-col-<?php echo esc_attr($atfpp_lang['code']); ?>"
                                        data-lang="<?php echo esc_attr($atfpp_lang['code']); ?>"
                                        data-is-source="<?php echo $atfpp_is_source ? 'true' : 'false'; ?>">
                                        <?php if ($atfpp_is_source): ?>
                                            <span class="atfpp-source-term">
                                                <?php echo esc_html($term); ?>
                                            </span>
                                        <?php else: ?>
                                            <?php
                                            // Get translation from the new data structure
                                            $atfpp_translation = isset($atfpp_data['translations'][$atfpp_lang['code']]) ? $atfpp_data['translations'][$atfpp_lang['code']] : '';
                                            ?>
                                            <?php if (!empty($atfpp_translation) && trim($atfpp_translation) !== ''): ?>
                                                <?php $atfpp_truncated = atfpp_truncate($atfpp_translation, 7); ?>
                                                <span class="atfpp-translated-term"
                                                    title="<?php echo esc_attr($atfpp_translation); ?>"
                                                    data-full-text="<?php echo esc_attr($atfpp_translation); ?>">
                                                    <?php echo esc_html($atfpp_truncated); ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="atfpp-no-translation">
                                                    <button type="button" class="atfpp-edit-btn-svg"
                                                        data-term="<?php echo esc_attr(sanitize_text_field($term)); ?>"
                                                        data-source-lang="<?php echo esc_attr(sanitize_key($atfpp_original_language_code)); ?>">
                                                        <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/file.svg'); ?>"
                                                            alt="<?php esc_attr_e('No translation', 'autopoly-ai-translation-for-polylang-pro'); ?>" />
                                                    </button>
                                                </span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>

                                <td class="atfpp-actions-cell">
                                    <div class="atfpp-action-buttons">
                                        <button type="button" class="atfpp-edit-btn"
                                            data-term="<?php echo esc_attr(sanitize_text_field($term)); ?>"
                                            data-source-lang="<?php echo esc_attr(sanitize_key($atfpp_original_language_code)); ?>">
                                            <?php esc_html_e('Edit', 'autopoly-ai-translation-for-polylang-pro'); ?>
                                        </button>
                                        <button type="button" class="atfpp-delete-btn"
                                            data-term="<?php echo esc_attr(sanitize_text_field($term)); ?>"
                                            data-source-lang="<?php echo esc_attr(sanitize_key($atfpp_original_language_code)); ?>">
                                            <?php esc_html_e('Delete', 'autopoly-ai-translation-for-polylang-pro'); ?>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div id="atfpp-no-results">No glossary entries found.</div>
            <?php endif; ?>
        </div>
        <!-- Move the template outside the table wrapper so it is always present -->
        <?php // phpcs:disable Generic.PHP.DisallowAlternativePHPTags 
        ?>
        <script type="text/template" id="atfpp-glossary-edit-row-template">
            <tr class="atfpp-glossary-edit-row">
                <td>
                    <textarea class="atfpp-edit-term" rows="3" placeholder="<?php esc_attr_e('String Translation', 'autopoly-ai-translation-for-polylang-pro'); ?>"><%= term %></textarea>
                    <div class="atfpp-translation-error"></div>
                    <textarea class="atfpp-edit-desc" rows="4" placeholder="<?php esc_attr_e('Example: The name of the add-on that allows translating strings', 'autopoly-ai-translation-for-polylang-pro'); ?>"><%= desc %></textarea>
                </td>
                <td>
                    <select class="atfpp-edit-type">
                        <option value="general" <%= type === 'general' ? 'selected' : '' %>><?php esc_html_e('General', 'autopoly-ai-translation-for-polylang-pro'); ?></option>
                        <option value="name" <%= type === 'name' ? 'selected' : '' %>><?php esc_html_e('Name', 'autopoly-ai-translation-for-polylang-pro'); ?></option>
                    </select>
                </td>
                <% for (var i = 0; i < languages.length; i++) { 
                    if (languages[i].code === source_lang) continue;
                %>
                    <td colspan="2">
                        <textarea class="atfpp-edit-translation" data-lang="<%= languages[i].code %>" placeholder="<?php esc_attr_e('Custom Translation', 'autopoly-ai-translation-for-polylang-pro'); ?>" rows="9"><%= translations[languages[i].code] || '' %></textarea>
                        <div class="atfpp-translation-error"><?php esc_html_e('Too long, must be less than 220 characters', 'autopoly-ai-translation-for-polylang-pro'); ?></div>
                    </td>
                <% } %>
                <td colspan="2" class="atfpp-actions-cell">
                    <div class="atfpp-action-buttons">
                        <button type="button" class="atfpp-save-edit-btn button button-primary">
                            <?php esc_html_e('Save', 'autopoly-ai-translation-for-polylang-pro'); ?>
                        </button>
                        <button type="button" class="atfpp-cancel-edit-btn">
                            <?php esc_html_e('Cancel', 'autopoly-ai-translation-for-polylang-pro'); ?>
                        </button>
                    </div>
                </td>
            </tr>
        </script>
        <?php // phpcs:enable Generic.PHP.DisallowAlternativePHPTags 
        ?>
    </div>
    <?php
    $file_prefix = ATFPP_DIR_PATH . 'admin/atfpp-dashboard/views/';
    $footer_file = $file_prefix . 'footer.php';
    if (file_exists($footer_file)) {
        require_once $footer_file;
    }
    ?>
</div>