<?php

if(!defined('ABSPATH')) exit;

?>
<div class="atfpp-dashboard-info">
    <div class="atfpp-dashboard-info-links">
        <p>
            <?php echo esc_html__('Made with ❤️ by', 'autopoly-ai-translation-for-polylang-pro'); ?>
            <span class="logo">
                <a href="https://coolplugins.net/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=author_page&utm_content=dashboard_footer_pro" target="_blank">
                    <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/cool-plugins-logo-black.svg'); ?>" alt="<?php esc_attr_e('Cool Plugins Logo', 'autopoly-ai-translation-for-polylang-pro'); ?>">
                </a>
            </span>
        </p>
    </div>
</div>
