<?php
/**
 * Do not access the page directly
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'ATFP_Supported_Blocks' ) ) {
	/**
	 * Class ATFP_Supported_Blocks
	 *
	 * This class handles the supported blocks for the AutoPoly - AI Translation For Polylang plugin.
	 *
	 * @package ATFPP
	 */
	class ATFP_Supported_Blocks {
		/**
		 * Singleton instance.
		 *
		 * @var ATFP_Supported_Blocks
		 */
		private static $instance = null;

		/**
		 * ATFPP plugin category.
		 *
		 * @var array
		 */
		private $atfpp_plugin_category = array();

		/**
		 * Get the singleton instance of the class.
		 *
		 * @return ATFP_Supported_Blocks
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor for the ATFP_Supported_Blocks class.
		 */
		private function __construct() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is not required here
			$tab=isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is not required here
			$page=isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
			if('support-blocks' === $tab && 'polylang-atfpp-dashboard' === $page){
				$this->atfpp_render_support_blocks_page();
				$this->enqueue_editor_assets();
			}
		}

		/**
		 * Enqueue editor CSS for the supported blocks page.
		 */
		public function enqueue_editor_assets( ) {
			wp_enqueue_script( 'atfp-datatable-script', ATFPP_URL . 'assets/js/dataTables.min.js', array(), ATFPP_V, true );
			wp_enqueue_script( 'atfp-datatable-style', ATFPP_URL . 'assets/js/dataTables.min.js', array(), ATFPP_V, true );
			wp_enqueue_style( 'atfp-custom-data-table', ATFPP_URL . 'assets/css/atfp-custom-data-table.min.css', array(), ATFPP_V );
			wp_enqueue_script( 'atfp-custom-data-table', ATFPP_URL . 'assets/js/atfp-custom-data-table.min.js', array('atfp-datatable-script'), ATFPP_V, true );
		}
		/**
		 * Add submenu page under the Polylang menu.
		 */
		public function atfpp_add_submenu_page() {
			add_submenu_page(
				'mlang', // Parent slug
				__( 'Support Blocks', 'autopoly-ai-translation-for-polylang-pro' ), // Page title
				__( '↳ Support Blocks', 'autopoly-ai-translation-for-polylang-pro' ), // Menu title
				'manage_options', // Capability
				'atfp-supported-blocks', // Menu slug
				array( $this, 'atfpp_render_support_blocks_page' ) // Callback function
			);
		}

		/**
		 * Render the support blocks page.
		 */
		public function atfpp_render_support_blocks_page() {
			?>
		<div class="atfp-custom-data-table-wrapper">
			<div class="atfp-custom-data-table-container">
			<h3><?php echo esc_html__('Supported Blocks Translation Settings', 'autopoly-ai-translation-for-polylang-pro'); ?>
			<br>
			<p><?php
			// translators: 1: Plugin name
			echo sprintf(esc_html__('Manage Gutenberg blocks to make them translation-ready with %s.', 'autopoly-ai-translation-for-polylang-pro'), 'AutoPoly'); ?></p>
			</h3>
			<div class="atfp-custom-data-table-filters">
				<div class="atfp-filter-tab" data-column="1" data-default="all">
					<label for="atfp-blocks-category"><?php esc_html_e( 'Block Type Category:', 'autopoly-ai-translation-for-polylang-pro' ); ?></label>
					<select id="atfp-blocks-category" name="atfp_blocks_category">
						<option value="all"><?php esc_html_e( 'All', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
						<option value="core">Core</option>
						<?php $this->atfpp_get_blocks_category(); ?>
					</select>
				</div>
				<div class="atfp-filter-tab" data-column="3" data-default="all">
					<label for="atfp-blocks-filter"><?php esc_html_e( 'Show Blocks:', 'autopoly-ai-translation-for-polylang-pro' ); ?></label>
					<select id="atfp-blocks-filter" name="atfp_blocks_filter">
						<option value="all"><?php esc_html_e( 'All', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
						<option value="supported"><?php esc_html_e( 'Supported Blocks', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
						<option value="unsupported"><?php esc_html_e( 'Unsupported Blocks', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
					</select>
				</div>
			</div>
			<div class="atfp-custom-table-section">
				<div class="atfp-custom-table-lists">
					<table class="atfp-custom-data-table-table" id="atfp-custom-datatable">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Sr.No', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
								<th><?php esc_html_e( 'Block Name', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
								<th><?php esc_html_e( 'Block Title', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
								<th><?php esc_html_e( 'Status', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
								<th><?php esc_html_e( 'Modify', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$this->atfpp_get_supported_blocks_table()
							?>
						</tbody>
					</table>
				</div>
			</div>
			</div>
			<?php
			$file_prefix = ATFPP_DIR_PATH . 'admin/atfpp-dashboard/views/';
			$footer_file = $file_prefix . 'footer.php';
			if (file_exists($footer_file)) {
				require_once $footer_file;
			}
			?>
		</div>
			<?php
		}

		/**
		 * Get the blocks category.
		 */
		public function atfpp_get_blocks_category() {
			$blocks_data                 = WP_Block_Type_Registry::get_instance()->get_all_registered();

			$filter_blocks_data = array_filter( $blocks_data, function( $block ) {
				return !in_array($block->category, array( 'media', 'reusable' ));
			} );
			foreach ( $filter_blocks_data as $block ) {
				$plugin_name = explode('/', $block->name);
				$plugin_name = isset($plugin_name[0]) ? $plugin_name[0] : '';

				if(!empty($plugin_name)){
					$filter_plugin_name = $this->atfpp_supported_block_name($plugin_name);
					$filter_plugin_name=str_replace('-',' ',$filter_plugin_name);
					$filter_plugin_name=ucwords($filter_plugin_name);

					if(in_array($plugin_name, $this->atfpp_plugin_category) || $plugin_name === 'core'){
						continue;
					}

					$this->atfpp_plugin_category[] = $plugin_name;
					echo '<option value="' . esc_attr( $plugin_name ) . '">' . esc_html( $filter_plugin_name ) . '</option>';
				}
			}
		}

		/**
		 * Get the supported blocks.
		 */
		public function atfpp_get_supported_blocks_table() {
			if ( class_exists( 'WP_Block_Type_Registry' ) && method_exists( 'WP_Block_Type_Registry', 'get_all_registered' ) ) {
				$atfp_block_parse_rules      = ATFPP_Helper::get_instance()->get_block_parse_rules();

				$blocks_data                 = WP_Block_Type_Registry::get_instance()->get_all_registered();

				$atfp_supported_blocks       = isset($atfp_block_parse_rules['AtfpBlockParseRules']) ? $atfp_block_parse_rules['AtfpBlockParseRules'] : array();
				$atfp_supported_blocks_names = array_keys( $atfp_supported_blocks );
				$s_no                        = 1;
				$atfp_post_id                = ATFPP_Helper::get_custom_block_post_id();

				$filter_blocks_data=$blocks_data;

				foreach ( $filter_blocks_data as $block ) {

					$block_name  = esc_html( $block->name );
					$block_title = esc_html( $block->title );
					$status      = ! in_array( $block_name, $atfp_supported_blocks_names ) ? 'Unsupported' : 'Supported'; // You can modify this logic based on your requirements
					$modify_text = ! in_array( $block_name, $atfp_supported_blocks_names ) ? esc_html__( 'Add', 'autopoly-ai-translation-for-polylang-pro' ) : esc_html__( 'Edit', 'autopoly-ai-translation-for-polylang-pro' );
					$modify_link = '<a href="' . esc_url( admin_url( 'post.php?post=' . esc_attr( $atfp_post_id ) . '&action=edit&atfp_new_block=' ) . esc_attr( $block_name ) ) . '">' . $modify_text . '</a>'; // Modify link
					$modify_link = '<a href="' . esc_url( admin_url( 'post.php?post=' . esc_attr( $atfp_post_id ) . '&action=edit&atfp_new_block=' ) . esc_attr( $block_name ) ) . '">' . $modify_text . '</a>'; // Modify link

					echo '<tr data-block-name="' . esc_attr( strtolower( $block_name ) ) . '" data-block-status="' . esc_attr( strtolower( $status ) ) . '" >';
					echo '<td>' . esc_html($s_no++) . '</td>';
					echo '<td>' . esc_html($block_name) . '</td>';
					echo '<td>' . esc_html($block_title) . '</td>';
					echo '<td>' . esc_html($status) . '</td>';
					echo '<td>' . wp_kses($modify_link, array('a' => array('href' => array(), 'target' => array(), 'rel' => array()))) . '</td>';
					echo '</tr>';
				}
			}

		}

		private function atfpp_supported_block_name($block_name){
			$predfined_blocks = array(
				'ub' => 'Ultimate Blocks',
				'uagb' => 'Spectra',
				'themeisle-blocks' => 'Otter Blocks'
			);
			
			if(array_key_exists($block_name, $predfined_blocks)){
				return $predfined_blocks[$block_name];
			}

			return $block_name;
		}
	}

	ATFP_Supported_Blocks::get_instance();
}
