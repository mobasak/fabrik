<?php
if(!defined('ABSPATH')){
    exit;
}
?>
<!-- Right Sidebar -->
<div class="atfpp-dashboard-sidebar">
    <div class="atfpp-dashboard-status atfpp-dashboard-card">
        <h3><?php esc_html_e('Auto Translation Status', 'autopoly-ai-translation-for-polylang-pro'); ?></h3>
        <div class="atfpp-dashboard-sts-top">
            <?php

            $atfp_all_translation_data = get_option('cpt_dashboard_data', array());
            
            if (!is_array($atfp_all_translation_data) || !isset($atfp_all_translation_data['atfp'])) {
                $atfp_all_translation_data['atfp'] = []; // Ensure $atfp_all_translation_data['atfp'] is an array
            }

            $atfp_provider_character_count = array();

            $totals = array(
                'string_count'      => 0,
                'character_count'   => 0,
                'time_taken'        => 0,
                'translation_count' => 0
            );

            if ( ! empty( $atfp_all_translation_data['atfp'] ) && is_array( $atfp_all_translation_data['atfp'] ) ) {
                foreach ( $atfp_all_translation_data['atfp'] as $atfp_translation ) {
                    $totals['string_count']    += intval( isset( $atfp_translation['string_count'] ) ? $atfp_translation['string_count'] : 0 );
                    $totals['character_count'] += intval( isset( $atfp_translation['character_count'] ) ? $atfp_translation['character_count'] : 0 );
                    $totals['time_taken']      += intval( isset( $atfp_translation['time_taken'] ) ? $atfp_translation['time_taken'] : 0 );

                    // Count total translations instead of unique post IDs.
                    if ( ! empty( $atfp_translation['post_id'] ) ) {
                        $totals['translation_count']++;
                    }
                }
            }
            // Update the time taken string using the new function
            $atfp_time_taken_str = atfp_format_time_taken($totals['time_taken']);
            ?>
              <span><?php echo esc_html(atfp_format_number($totals['character_count'])); ?></span>
            <span><?php esc_html_e('Total Characters Translated!', 'autopoly-ai-translation-for-polylang-pro'); ?></span>
        </div>
        <ul class="atfpp-dashboard-sts-btm">
            <li><span><?php esc_html_e('Total Strings', 'autopoly-ai-translation-for-polylang-pro'); ?></span> <span><?php echo esc_html(atfp_format_number($totals['string_count'])); ?></span></li>
            <li><span><?php esc_html_e('Total Pages / Posts', 'autopoly-ai-translation-for-polylang-pro'); ?></span> <span><?php echo esc_html($totals['translation_count']); ?></span></li>
            <li><span><?php esc_html_e('Time Taken', 'autopoly-ai-translation-for-polylang-pro'); ?></span> <span><?php echo esc_html($atfp_time_taken_str); ?></span></li>
        </ul>
    </div>
    <div class="atfpp-dashboard-translate-full atfpp-dashboard-card">
        <h3><?php esc_html_e('Automatically Translate Plugins & Themes', 'autopoly-ai-translation-for-polylang-pro'); ?></h3>
        <div class="atfpp-dashboard-addon first">
            <div class="atfpp-dashboard-addon-l">
                <strong><?php echo esc_html(atfp_get_plugin_display_name('automatic-translator-addon-for-loco-translate')); ?></strong>
                <span class="addon-desc"><?php echo esc_html__('Loco addon to translate plugins and themes.', 'autopoly-ai-translation-for-polylang-pro'); ?></span>
                <?php if (atfp_is_plugin_installed('automatic-translator-addon-for-loco-translate')): ?>
                    <span class="installed"><?php echo esc_html__('Installed', 'autopoly-ai-translation-for-polylang-pro'); ?></span>
                <?php else: ?>
                    <a href="<?php echo esc_url(admin_url('plugin-install.php?s=LocoAI+–+Auto+Translate+for+Loco+Translate+by+CoolPlugins&tab=search&type=term') ); ?>" class="atfpp-dashboard-btn" target="_blank"><?php esc_html_e('Install', 'autopoly-ai-translation-for-polylang-pro'); ?></a>
                <?php endif; ?>
            </div>
            <div class="atfpp-dashboard-addon-r">
                <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/atlt-logo.png'); ?>" alt="<?php echo esc_html__('TranslatePress Addon', 'autopoly-ai-translation-for-polylang-pro'); ?>">
            </div>
        </div>
    </div>
    <div class="atfpp-dashboard-translate-support atfpp-dashboard-card">
        <h3><?php esc_html_e('Need Help? 🤝', 'autopoly-ai-translation-for-polylang-pro'); ?></h3>
        <p><?php esc_html_e('Facing any issue with AI translation? Create a support thread and our team will assist you.', 'autopoly-ai-translation-for-polylang-pro'); ?></p>
        <a href="<?php echo esc_url('https://coolplugins.net/support/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=support&utm_content=dashboard_sidebar_pro'); ?>" class="atfpp-dashboard-btn primary" target="_blank"><?php esc_html_e('Get Support →', 'autopoly-ai-translation-for-polylang-pro'); ?></a>
    </div>
    <div class="atfpp-dashboard-rate-us atfpp-dashboard-card">
        <h3><?php esc_html_e('Happy with AutoPoly? ✨', 'autopoly-ai-translation-for-polylang-pro'); ?></h3>
        <p><?php esc_html_e('We\'d love your feedback! Hope this addon made auto-translations easier for you.', 'autopoly-ai-translation-for-polylang-pro'); ?></p>
        <a href="https://wordpress.org/support/plugin/automatic-translations-for-polylang/reviews/#new-post" class="atfpp-dashboard-btn" target="_blank"><?php esc_html_e('Leave a Review ★★★★★', 'autopoly-ai-translation-for-polylang-pro'); ?></a>
    </div>
</div>

<?php

function atfp_format_time_taken($time_taken) {
    if ($time_taken === 0) return esc_html__('0', 'autopoly-ai-translation-for-polylang-pro');
    // translators: 1: Time taken in seconds in number format
    if ($time_taken < 60) return sprintf(esc_html__('%d sec', 'autopoly-ai-translation-for-polylang-pro'), $time_taken);
    if ($time_taken < 3600) {
        $min = floor($time_taken / 60);
        $sec = $time_taken % 60;
        // translators: 1: Time taken in minutes in number format, 2: Time taken in seconds in number format
        return sprintf(esc_html__('%1$d min %2$d sec', 'autopoly-ai-translation-for-polylang-pro'), $min, $sec);
    }
    $hours = floor($time_taken / 3600);
    $min = floor(($time_taken % 3600) / 60);
    // translators: 1: Time taken in hours in number format, 2: Time taken in minutes in number format
    return sprintf(esc_html__('%1$d hours %2$d min', 'autopoly-ai-translation-for-polylang-pro'), $hours, $min);
}

function atfp_is_plugin_installed($plugin_slug) {
    $plugins = get_plugins();
    
    // Check if the plugin is installed
    if ($plugin_slug === 'automatic-translator-addon-for-loco-translate') {
        return isset($plugins['automatic-translator-addon-for-loco-translate/automatic-translator-addon-for-loco-translate.php']) || isset($plugins['loco-automatic-translate-addon-pro/loco-automatic-translate-addon-pro.php']);
    }
    return false; // Return false if no match found
}

function atfp_get_plugin_display_name($plugin_slug) {
    $plugins = get_plugins();

    // Define free and pro plugin paths
    $plugin_paths = [
        'automatic-translator-addon-for-loco-translate' => [
            'free' => 'automatic-translator-addon-for-loco-translate/automatic-translator-addon-for-loco-translate.php',
            'pro'  => 'loco-automatic-translate-addon-pro/loco-automatic-translate-addon-pro.php',
            'free_name' => esc_html__('LocoAI – Auto Translate For Loco Translate', 'autopoly-ai-translation-for-polylang-pro'),
            'pro_name'  => esc_html__('LocoAI – Auto Translate for Loco Translate (Pro)', 'autopoly-ai-translation-for-polylang-pro'),
        ],
    ];

    // Check if the provided plugin slug exists
    if (!isset($plugin_paths[$plugin_slug])) {
        return $plugin_slug['free_name'];
    }

    $free_installed = isset($plugins[$plugin_paths[$plugin_slug]['free']]);
    $pro_installed = isset($plugins[$plugin_paths[$plugin_slug]['pro']]);

    // Determine which version is installed
    if ($pro_installed) {
        return $plugin_paths[$plugin_slug]['pro_name'];
    } elseif ($free_installed) {
        return $plugin_paths[$plugin_slug]['free_name'];
    } else {
        return $plugin_paths[$plugin_slug]['free_name'];
    }
}

function atfp_format_number($number) {
    if ($number >= 1000000000) {
        return round($number / 1000000000, 1) . esc_html__('B', 'autopoly-ai-translation-for-polylang-pro');
    } elseif ($number >= 1000000) {
        return round($number / 1000000, 1) . esc_html__('M', 'autopoly-ai-translation-for-polylang-pro');
    } elseif ($number >= 1000) {
        return round($number / 1000, 1) . esc_html__('K', 'autopoly-ai-translation-for-polylang-pro');
    }
    return $number;
}

