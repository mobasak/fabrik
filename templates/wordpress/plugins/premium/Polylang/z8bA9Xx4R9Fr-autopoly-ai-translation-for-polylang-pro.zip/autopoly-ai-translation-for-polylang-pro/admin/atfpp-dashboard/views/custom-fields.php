<?php

if(!defined('ABSPATH')) exit;

if(!class_exists('ATFP_Custom_Fields')) {

    class ATFP_Custom_Fields {
        private static $instance = null;
        private $atfp_allowed_fields = array();
        private $atfp_meta_type = 'post';
        private $atfp_meta_fields=array();
    
        public static function get_instance() {
            if(null === self::$instance) {
                self::$instance = new self();
            }
            return self::$instance;
        }
    
        private function __construct() {
           // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is not required here
           $tab=isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : '';
           // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verification is not required here
            $page=isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
            if(('custom-fields' === $tab || 'terms-custom-fields' === $tab) && 'polylang-atfpp-dashboard' === $page){
                $this->atfp_meta_type = 'custom-fields' === $tab ? 'post' : 'term';
                $this->atfpp_render_custom_fields_page();
                $this->enqueue_editor_assets();
            }
        }
    
        public function enqueue_editor_assets() {
            wp_enqueue_script( 'atfp-datatable-script', ATFPP_URL . 'assets/js/dataTables.min.js', array(), ATFPP_V, true );
            wp_enqueue_style( 'atfp-editor-custom-fields', ATFPP_URL . 'assets/css/atfp-custom-data-table.css', array(), ATFPP_V );
            wp_enqueue_script( 'atfp-editor-custom-fields', ATFPP_URL . 'assets/js/atfp-custom-data-table.js', array('atfp-datatable-script'), ATFPP_V, true );
        
            wp_localize_script( 'atfp-editor-custom-fields', 'atfpCustomTableDataObject', array(
                'admin_url' => esc_url(admin_url('admin-ajax.php')),
                'save_button_handler' => 'atfp_update_'.$this->atfp_meta_type.'_custom_fields',
                'save_button_nonce' => wp_create_nonce('atfp_update_'.sanitize_text_field($this->atfp_meta_type).'_custom_fields'),
                'save_button_enabled'=>true,
                'save_button_text'=>__('Save Fields', 'autopoly-ai-translation-for-polylang-pro'),
                'save_button_class'=>'atfp-save-custom-fields',
            ) );
        }
    
        public function atfpp_render_custom_fields_page() {
                $this->atfp_allowed_fields = ATFPP_Helper::get_instance()->get_allowed_custom_fields($this->atfp_meta_type);
                $this->atfp_meta_fields = ATFPP_Helper::get_instance()->get_custom_fields_data($this->atfp_meta_type);
                $total_meta_fields = count($this->atfp_meta_fields);

                if($total_meta_fields > 0){
                ?>
                <div class="atfp-custom-data-table-wrapper">
                    <div class="atfp-custom-data-table-container atfp-custom-fields">
                    <h3><?php echo esc_html__('Custom Fields Translation Settings', 'autopoly-ai-translation-for-polylang-pro'); ?>
                    <br>
                    <p><?php 
                    /* translators: %s: Plugin name */
                    echo sprintf(esc_html__('Select which custom fields will be translated by %s.', 'autopoly-ai-translation-for-polylang-pro'), 'AutoPoly'); ?></p>
                    </h3>
                    <button class="button button-primary atfp-save-custom-fields"><?php esc_html_e( 'Save Fields', 'autopoly-ai-translation-for-polylang-pro' ); ?></button>
                    <div class="atfp-custom-data-table-filters">
                        <div class="atfp-filter-tab" data-column="3" data-default="all">
                            <label for="atfp-fields-filter"><?php esc_html_e( 'Show Fields:', 'autopoly-ai-translation-for-polylang-pro' ); ?></label>
                            <select id="atfp-fields-filter" name="atfp_fields_filter">
                                <option value="all"><?php esc_html_e( 'All', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
                                <option value="supported"><?php esc_html_e( 'Translatable', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
                                <option value="unsupported"><?php esc_html_e( 'Non-Translatable', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
                            </select>
                        </div>
                        <div class="atfp-filter-tab" data-column="2" data-default="all">
                            <label for="atfp-fields-filter"><?php esc_html_e( 'Type:', 'autopoly-ai-translation-for-polylang-pro' ); ?></label>
                            <select id="atfp-fields-value-type-filter" name="atfp_fields_value_type_filter">
                                <option value="all"><?php esc_html_e( 'All', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
                                <option value="string"><?php esc_html_e( 'String', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
                                <option value="array"><?php esc_html_e( 'Array', 'autopoly-ai-translation-for-polylang-pro' ); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="atfp-custom-table-section">
                        <div class="atfp-custom-table-lists">
                            <table class="atfp-custom-data-table-table" id="atfp-custom-datatable">
                                <thead>
                                    <tr>
                                        <th><?php esc_html_e( 'Sr.No', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
                                        <th><?php esc_html_e( 'Field Name', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
                                        <th><?php esc_html_e( 'Type', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
                                        <th><?php esc_html_e( 'Status', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
                                        <th align="center"><?php esc_html_e( 'Translate', 'autopoly-ai-translation-for-polylang-pro' ); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $this->get_all_meta_fields_table();
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    </div>
                    <?php
                    $file_prefix = ATFPP_DIR_PATH . 'admin/atfpp-dashboard/views/';
                    $footer_file = $file_prefix . 'footer.php';
                    if (file_exists($footer_file)) {
                        require_once $footer_file;
                    }
                    ?>
                </div>
                <?php
                }else{
                    ?>
					<div class="atfp-custom-data-table-wrapper atfp-custom-fields">
                        <div class="atfp-custom-data-table-container">
						<p align="center">
							<?php
							printf(
                                // translators: 1: Custom field meta type (post or term), 2: Custom field meta type (post or term)
								esc_html__( 'No custom fields are available for %1$s at this time. Custom fields will appear here once they are added in any %2$s.', 'autopoly-ai-translation-for-polylang-pro' ),
								esc_html( $this->atfp_meta_type ),
                                esc_html( $this->atfp_meta_type )
							);
							?>
						</p>
						</div>
                        <?php
                        $file_prefix = ATFPP_DIR_PATH . 'admin/atfpp-dashboard/views/';
                        $footer_file = $file_prefix . 'footer.php';
                        if (file_exists($footer_file)) {
                            require_once $footer_file;
                        }
                        ?>
					</div>
                    <?php
                }
        }

        public function get_all_meta_fields_table() {
            if($this->atfp_meta_fields && is_array($this->atfp_meta_fields)) {
                $s_no                        = 1;
                foreach($this->atfp_meta_fields as $meta_field => $value) { 
                    $checked=isset($this->atfp_allowed_fields[$meta_field]) && !empty($this->atfp_allowed_fields[$meta_field]['status']) ? 'checked' : '';
                    $status=isset($value['status']) && !empty($value['status']) ? $value['status'] : 'Unsupported';
                    $value_type=isset($value['type']) && !empty($value['type']) ? $value['type'] : 'string';
                    
                    echo '<tr>';
                    echo '<td>' . esc_html($s_no++) . '</td>';
                    echo '<td>' . esc_html($meta_field) . '</td>';
                    echo '<td>' . esc_html($value_type) . '</td>';
                    echo '<td>' . esc_html($status) . '</td>';
                    echo '<td align="center"><input type="checkbox" name="atfp_fields_status" value="' . esc_attr($meta_field) . '" ' . esc_attr($checked) . '></td>';
                    echo '</tr>';
                }
            }

            $this->atfp_meta_fields=array();
        }
    }
}

ATFP_Custom_Fields::get_instance();