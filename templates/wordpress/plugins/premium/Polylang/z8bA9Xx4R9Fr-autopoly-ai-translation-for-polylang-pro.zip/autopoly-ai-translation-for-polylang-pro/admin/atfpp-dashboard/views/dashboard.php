<?php

if(!defined('ABSPATH')) exit;

$atfpp_active_providers = get_option('atfp_enabled_providers', array('chrome-built-in-ai', 'yandex-translate', 'google-translate', 'openai', 'deepl', 'gemini'));
?>
    <div class="atfpp-dashboard-left-section">
        
        <!-- Welcome Section -->
        <div class="atfpp-dashboard-get-started">
            <div class="atfpp-dashboard-get-started-container">
                <div class="header">
                    <h1><?php echo esc_html__('Automate the Translation Process', 'autopoly-ai-translation-for-polylang-pro'); ?></h1>
                </div>
                <div class="atfpp-dashboard-get-started-grid">
                <div class="atfpp-dashboard-get-started-grid-content atfpp-welcome-text">
                    <h2><?php echo esc_html__('Welcome to AutoPoly - AI Translation For Polylang', 'autopoly-ai-translation-for-polylang-pro'); ?></h2>
                    <?php
					echo wp_kses_post(
						sprintf(
							/* translators: 1: open span, 2: close span, 3: line break, 4: open span, 5: close span, 6: open ul, 7: open li, 8: open strong, 9: close strong, 10: close li, 11: open li, 12: open strong, 13: close strong, 14: close li, 15: close ul, 16: open span, 17: close span */
							esc_html__(
								'%1$sGo to Pages or Posts and open the item you want to translate. In the Languages section, click the “+” icon next to your target language.%2$s%3$sYou have two ways to translate your content:%4$s%5$s%6$s%7$sSingle Translation:%8$s Click the “+” icon for each post or page, choose your preferred translation provider, and click Translate.%9$s%10$s%11$sBulk Translation:%12$s Click Bulk Translate, select one or multiple languages, and translate multiple posts or pages at once.%13$s%14$s%15$sOnce the translation is complete, review the content and click Update to save your changes.%16$s',
								'autopoly-ai-translation-for-polylang-pro'
							),
							'<p>', '</p>',
							'<strong>', '</strong>',
							'<ul>',
							'<li>', '<strong>', '</strong>', '</li>',
							'<li>', '<strong>', '</strong>', '</li>',
							'</ul>',
							'<p>', '</p>'
						)
					);
                    ?>
                    <div class="atfpp-dashboard-btns-row">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=mlang')); ?>" target="_blank" class="atfpp-dashboard-btn primary"><?php echo esc_html__('Website Languages', 'autopoly-ai-translation-for-polylang-pro'); ?></a>
                        <a href="<?php echo esc_url(admin_url('edit.php?post_type=page')); ?>" target="_blank" class="atfpp-dashboard-btn"><?php echo esc_html__('Page Translation', 'autopoly-ai-translation-for-polylang-pro'); ?></a>
                    </div>
                    <a class="atfpp-dashboard-docs" href="<?php echo esc_url('https://docs.coolplugins.net/plugin/ai-translation-for-polylang/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_pro'); ?>" target="_blank"><img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/document.svg'); ?>" alt="document"> <span><?php echo esc_html__('Read Plugin Docs', 'autopoly-ai-translation-for-polylang-pro'); ?></span></a>
                    </div>
                    <div class="atfpp-dashboard-get-started-grid-content atfpp-welcome-video">
                        <a href="https://docs.coolplugins.net/doc/ai-translation-polylang-video-tutorials/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_pro" target="_blank" class="atfpp-dashboard-video-link">
                        <img decoding="async" src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/youtube-icon.svg'); ?>" class="play-icon" alt="play-icon">
                        <img src="<?php echo esc_url(ATFPP_URL . 'admin/atfpp-dashboard/images/polylang-addon-video.png'); ?>" class="loco-video" alt="loco translate addon preview">
                    </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Translation Providers -->  
        <div class="atfpp-dashboard-translation-providers">
            <h3><?php echo esc_html__('AI Translation Providers', 'autopoly-ai-translation-for-polylang-pro'); ?></h3>
            <div class="atfpp-dashboard-providers-grid">
                
                <?php
                $atfpp_providers = [
                    'gemini' => ["Gemini AI", "geminiai-logo.png", "Pro", ["Unlimited Translations", "Fast Translations via AI", "Gemini API Key Required"], esc_url('https://docs.coolplugins.net/doc/translate-via-gemini-ai-polylang/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_gemini_pro'), esc_url('admin.php?page=polylang-atfpp-dashboard&tab=settings')],
                    'openai' => ["OpenAI", "openai-translate-logo.png", "Pro", ["Unlimited Translations", "Fast Translations via AI", "OpenAI API Key Required"], esc_url('https://docs.coolplugins.net/doc/translate-via-open-ai-polylang/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_openai_pro'), esc_url('admin.php?page=polylang-atfpp-dashboard&tab=settings')],
                    'deepl' =>  ["DeepL", "deepl-logo.png", "Pro", ["Unlimited Translations", "High-Quality Translations", "DeepL API Key Required"], esc_url('https://docs.coolplugins.net/doc/translate-via-deepl-polylang/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_deepl_pro'), esc_url('admin.php?page=polylang-atfpp-dashboard&tab=settings')],
                    'google-translate' => ["Google Translate", "google-translate-logo.png", "Pro", ["Unlimited Free Translations", "Fast & No API Key Required"], esc_url('https://docs.coolplugins.net/doc/google-translate-for-polylang/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_google_pro')],
                    'chrome-built-in-ai' => ["Chrome Built-in AI", "chrome-built-in-ai-logo.png", "Free", ["Fast AI Translations in Browser", "Unlimited Free Translations", "Use Translation Modals"], esc_url('https://docs.coolplugins.net/doc/chrome-ai-translation-polylang/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_chrome_pro')],
                    'yandex-translate' => ["Yandex Translate", "yandex-translate-logo.png", "Free", ["Unlimited Free Translations", "No API & No Extra Cost"], esc_url('https://docs.coolplugins.net/doc/yandex-translate-for-polylang/?utm_source=atfp_plugin&utm_medium=inside&utm_campaign=docs&utm_content=dashboard_yandex_pro')],
                ];

                foreach ($atfpp_providers as $atfpp_provider_key => $atfpp_provider) {
                    ?>
                    <div class="atfpp-dashboard-provider-card atfpp-card-<?php echo esc_attr($atfpp_provider_key); ?>">
                        <div class="atfpp-dashboard-provider-header">
                            <a href="<?php echo esc_url($atfpp_provider[4]); ?>" target="_blank">
                                <img src="<?php echo esc_url(ATFPP_URL . 'assets/images/' . $atfpp_provider[1]); ?>" 
                                    alt="<?php echo esc_html($atfpp_provider[0]); ?>">
                            </a>
                            <div class="atfpp-switch-container">
                                <label class="atfpp-switch-label">
                                    <input type="checkbox" class="atfpp-input-toggle atfpp-provider-toggle" data-provider="<?php echo esc_attr($atfpp_provider_key); ?>" <?php checked(in_array($atfpp_provider_key, $atfpp_active_providers), true); ?>/>
                                    <span class="atfpp-switch-slider"></span>
                                </label>
                            </div>
                        </div>
                        <ul>
                            <?php foreach ($atfpp_provider[3] as $atfpp_feature) { ?>
                                <li>✅ <?php echo esc_html($atfpp_feature); ?></li>
                            <?php } ?>
                        </ul>
                        <div class="atfpp-dashboard-provider-buttons">
                            <a href="<?php echo esc_url($atfpp_provider[4]); ?>" class="atfpp-dashboard-btn" target="_blank">Docs</a>
                            <?php if (isset($atfpp_provider[5])) { ?>
                                <a href="<?php echo esc_url($atfpp_provider[5]); ?>" class="atfpp-dashboard-btn">Settings</a>
                            <?php } 
                             if($atfpp_provider_key === 'chrome-built-in-ai'){ ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=polylang-atfpp-dashboard&tab=settings')); ?>" class="atfpp-chrome-configure-button atfpp-dashboard-btn primary" style="display: none;"><?php echo esc_html__('Configure', 'autopoly-ai-translation-for-polylang-pro'); ?></a>
                            <?php } ?>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
            $file_prefix = ATFPP_DIR_PATH . 'admin/atfpp-dashboard/views/';
            $footer_file = $file_prefix . 'footer.php';
            if (file_exists($footer_file)) {
                require_once $footer_file;
            }
        ?>
    </div>

