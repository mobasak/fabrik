jQuery(document).ready(function($) {
    $('tr.active[data-plugin*="autopoly-ai-translation-for-polylang-pro"]').each(function() {
      var $currentRow = $(this);
      var $nextUpdateRow = $currentRow.nextAll('tr.plugin-update-tr.active.atfpp-pro').first();
  
      if ($nextUpdateRow.length > 0) {
        $currentRow.addClass('update');
      }
    });

    const glossaryType = $('select#atfpp_deepl_glossary_type');

    glossaryType.on('change', function() {
      const value = $(this).val();
      if(value === 'deepl') {
        $('.atfpp-deepl-glossary-id-wrp').show();
      } else {
        $('.atfpp-deepl-glossary-id-wrp').hide();
      }
    });
  });