<?php
/*
Plugin Name: SearchWP Polylang Integration
Plugin URI: https://searchwp.com/
Description: Integrate SearchWP with Polylang
Version: 1.5.0
Author: SearchWP
Author URI: https://searchwp.com/

Copyright 2013-2025 SearchWP, LLC

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'SEARCHWP_POLYLANG_VERSION' ) ) {
	define( 'SEARCHWP_POLYLANG_VERSION', '1.5.0' );
}

if ( ! defined( 'SEARCHWP_POLYLANG_FILE' ) ) {
	define( 'SEARCHWP_POLYLANG_FILE', __FILE__ );
}

/**
 * Instantiate the updater.
 *
 * @since 1.0.0
 */
if ( ! class_exists( 'SWP_Polylang_Updater' ) ) {
	// Load our custom updater.
	include_once __DIR__ . '/vendor/updater.php';
}

/**
 * Set up the updater.
 *
 * @since 1.0.0
 */
function searchwp_polylang_update_check() {

	if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
		return false;
	}

	// Environment check.
	if ( ! defined( 'SEARCHWP_PREFIX' ) ) {
		return false;
	}

	if ( ! defined( 'SEARCHWP_EDD_STORE_URL' ) ) {
		return false;
	}

	$license_key = \SearchWP\License::get_key();

	// Instantiate the updater to prep the environment.
	$searchwp_polylang_updater = new SWP_Polylang_Updater(
		SEARCHWP_EDD_STORE_URL,
		__FILE__,
		[
			'item_id'   => 33648,
			'version'   => SEARCHWP_POLYLANG_VERSION,
			'license'   => $license_key,
			'item_name' => 'Polylang Integration',
			'author'    => 'SearchWP',
			'url'       => site_url(),
		]
	);

	return $searchwp_polylang_updater;
}

add_action( 'admin_init', 'searchwp_polylang_update_check' );

// Include the class file.
require_once __DIR__ . '/class-searchwp-polylang.php';

// Initialize the plugin.
add_action(
	'searchwp\loaded',
	function () {
		new SearchWP_Polylang();
	}
);
