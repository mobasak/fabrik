<?php
/**
 * SearchWP Polylang Integration Class
 *
 * @package SearchWP
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use SearchWP\Mod;

/**
 * SearchWP Polylang Integration.
 *
 * @since 1.0.0
 */
class SearchWP_Polylang {
	/**
	 * The entry object.
	 *
	 * @since 1.0.0
	 *
	 * @var \SearchWP\Entry
	 */
	private $entry;

	/**
	 * Constructor.
	 *
	 * Sets up hooks and filters for the Polylang integration.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function __construct() {

		add_action( 'after_plugin_row_' . plugin_basename( SEARCHWP_POLYLANG_FILE ), [ $this, 'plugin_row' ], 11 );

		add_filter( 'searchwp\query\mods',               [ $this, 'add_mods' ], 10, 2 );
		add_filter( 'searchwp\native\args',              [ $this, 'remove_native_polylang_args' ], 10, 2 );
		add_filter( 'searchwp\entry\update_data\before', [ $this, 'set_polylang_locale' ] );

		// Adds SearchWP Forms Render function to Polylang white list for home_url.
		add_filter( 'pll_home_url_white_list', [ $this, 'filter_home_url_white_list' ] );

		// Add language form field to SearchWP search form.
		add_action( 'searchwp\search_form\fields\after', [ $this, 'add_language_form_field' ] );
	}

	/**
	 * Sets the entry property and adds a filter for locale.
	 *
	 * @since 1.0.0
	 *
	 * @param \SearchWP\Entry $entry The SearchWP entry object.
	 *
	 * @return void
	 */
	public function set_polylang_locale( $entry ) {

		$this->entry = $entry;
		add_filter( 'locale', [ $this, 'locale' ] );
	}

	/**
	 * Filters the WordPress locale based on the Polylang post language.
	 *
	 * @since 1.0.0
	 *
	 * @param string $locale The current locale.
	 *
	 * @return string The filtered locale.
	 */
	public function locale( $locale ) {

		if ( $this->entry instanceof \SearchWP\Entry && function_exists( 'pll_get_post_language' ) ) {
			$post_language = pll_get_post_language( $this->entry->get_id(), 'locale' );
			if ( ! empty( $post_language ) ) {
				$locale = $post_language;
			}
		}

		return $locale;
	}

	/**
	 * Removes Polylang's tax_query from SearchWP native queries.
	 *
	 * @since 1.0.0
	 *
	 * @param array           $args  The query arguments.
	 * @param \SearchWP\Query $query The SearchWP query object.
	 *
	 * @return array The filtered query arguments.
	 */
	public function remove_native_polylang_args( $args, $query ) {

		/**
		 * Filters whether to short-circuit the SearchWP Polylang integration.
		 *
		 * @since 1.3.5
		 *
		 * @param bool  $short_circuit Whether to short-circuit the SearchWP Polylang integration. Default is false.
		 * @param array $args          The arguments passed to the filter.
		 */
		if ( apply_filters( 'searchwp_polylang_short_circuit', false, [ 'query' => $query ] ) ) {
			return $args;
		}

		if ( ! empty( $args['tax_query'] ) ) {
			foreach ( $args['tax_query'] as $key => $val ) {
				if ( isset( $val['taxonomy'] ) && $val['taxonomy'] === 'language' ) {
					unset( $args['tax_query'][ $key ] );
				}
			}

			$args['tax_query'] = array_values( $args['tax_query'] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}

		return $args;
	}

	/**
	 * Adds modifications to SearchWP queries to handle Polylang language filtering.
	 *
	 * @since 1.0.0
	 *
	 * @param array           $mods  The current query modifications.
	 * @param \SearchWP\Query $query The SearchWP query object.
	 *
	 * @return array The filtered query modifications.
	 */
	public function add_mods( $mods, $query ) {

		if ( ! $this->can_apply_polylang_mods() ) {
			return $mods;
		}

		if ( $this->should_short_circuit( $query ) ) {
			return $mods;
		}

		$current_language = $this->get_current_language();

		// Process post sources.
		$post_sources       = $this->get_post_sources( $query );
		$flag               = 'post' . SEARCHWP_SEPARATOR;
		$attachment_flag    = $flag . 'attachment';
		$attachment_sources = array_values(
			array_filter(
				$post_sources,
				function ( $s ) use ( $attachment_flag ) {
					return $s === $attachment_flag;
				}
			)
		);
		$other_post_sources = array_values( array_diff( $post_sources, $attachment_sources ) );

		// Non-attachment post types.
		$post_mods = $this->process_post_sources( $other_post_sources, $current_language );
		$mods      = array_merge( $mods, $post_mods );

		// Attachments handled separately.
		$attachment_mods = $this->process_attachment_sources( $attachment_sources, $current_language );
		$mods            = array_merge( $mods, $attachment_mods );

		// Process taxonomy sources.
		$taxonomy_sources = $this->get_taxonomy_sources( $query );
		$taxonomy_mods    = $this->process_taxonomy_sources( $taxonomy_sources );
		$mods             = array_merge( $mods, $taxonomy_mods );

		return $mods;
	}

	/**
	 * Checks if Polylang functions are available.
	 *
	 * @since 1.4.1
	 *
	 * @return bool
	 */
	private function can_apply_polylang_mods() {

		return function_exists( 'pll_current_language' )
			&& function_exists( 'pll_default_language' )
			&& function_exists( 'pll_is_translated_post_type' )
			&& function_exists( 'pll_is_translated_taxonomy' );
	}

	/**
	 * Checks if integration should be short-circuited.
	 *
	 * @since 1.4.1
	 *
	 * @param \SearchWP\Query $query The SearchWP query object.
	 *
	 * @return bool
	 */
	private function should_short_circuit( $query ) {
		/**
		 * Filters whether to short-circuit the SearchWP Polylang integration.
		 *
		 * @since 1.3.5
		 *
		 * @param bool  $short_circuit Whether to short-circuit the SearchWP Polylang integration. Default is false.
		 * @param array $args          The arguments passed to the filter.
		 */
		return apply_filters( 'searchwp_polylang_short_circuit', false, [ 'query' => $query ] );
	}

	/**
	 * Gets the current language or falls back to default.
	 *
	 * @since 1.4.1
	 *
	 * @return string The current language code.
	 */
	private function get_current_language() {

		$current_language = pll_current_language();

		if ( $current_language === false ) {
			$current_language = pll_default_language();
		}

		return $current_language;
	}

	/**
	 * Gets all post sources from the query engine.
	 *
	 * @since 1.4.1
	 *
	 * @param \SearchWP\Query $query The SearchWP query object.
	 *
	 * @return array Array of post sources.
	 */
	private function get_post_sources( $query ) {

		$flag = 'post' . SEARCHWP_SEPARATOR;

		return array_filter(
			array_map(
				function ( $source ) use ( $flag ) {
					return 0 !== strpos( $source->get_name(), $flag ) ? null : $source->get_name();
				},
				$query->get_engine()->get_sources()
			)
		);
	}

	/**
	 * Gets all taxonomy sources from the query engine.
	 *
	 * @since 1.5.0
	 *
	 * @param \SearchWP\Query $query The SearchWP query object.
	 *
	 * @return array Array of taxonomy sources.
	 */
	private function get_taxonomy_sources( $query ) {

		$flag = 'taxonomy' . SEARCHWP_SEPARATOR;

		return array_filter(
			array_map(
				function ( $source ) use ( $flag ) {
					return 0 !== strpos( $source->get_name(), $flag ) ? null : $source->get_name();
				},
				$query->get_engine()->get_sources()
			)
		);
	}

	/**
	 * Filters post sources to get only translated post types.
	 *
	 * @since 1.4.1
	 *
	 * @param array $sources Array of source names.
	 *
	 * @return array Array of translated source names.
	 */
	private function get_translated_post_sources( $sources ) {

		$flag = 'post' . SEARCHWP_SEPARATOR;

		return array_filter(
			$sources,
			function ( $post_type ) use ( $flag ) {
				$post_type = str_replace( $flag, '', $post_type );

				return pll_is_translated_post_type( $post_type );
			}
		);
	}

	/**
	 * Filters taxonomy sources to get only translated taxonomies.
	 *
	 * @since 1.5.0
	 *
	 * @param array $sources Array of source names.
	 *
	 * @return array Array of translated source names.
	 */
	private function get_translated_taxonomy_sources( $sources ) {

		$flag = 'taxonomy' . SEARCHWP_SEPARATOR;

		return array_filter(
			$sources,
			function ( $taxonomy_source ) use ( $flag ) {
				$taxonomy = str_replace( $flag, '', $taxonomy_source );

				return pll_is_translated_taxonomy( $taxonomy );
			}
		);
	}

	/**
	 * Processes post sources and creates language mods for translated post types.
	 *
	 * @since 1.4.1
	 *
	 * @param array  $sources          Array of post source names.
	 * @param string $current_language The current language code.
	 *
	 * @return array Array of mod objects.
	 */
	private function process_post_sources( $sources, $current_language ) {

		$mods = [];

		if ( empty( $sources ) ) {
			return $mods;
		}

		$translated_sources   = $this->get_translated_post_sources( $sources );
		$untranslated_sources = array_diff( $sources, $translated_sources );

		if ( empty( $translated_sources ) ) {
			return $mods;
		}

		foreach ( $sources as $source_name ) {

			/**
			 * Filters whether to include untranslated post types in the search results.
			 *
			 * @since 1.0.0
			 *
			 * @param bool $include_untranslated_post_types Whether to include untranslated post types. Default is true.
			 */
			$include_untranslated_post_types = apply_filters( 'searchwp_polylang_include_untranslated_post_types', true );

			/**
			 * Filters whether to include untranslated sources in the search results.
			 *
			 * @since 1.5.0
			 *
			 * @param bool   $include_untranslated Whether to include untranslated sources. Default value comes from legacy filters for backward compatibility.
			 * @param string $source_name          The source name (e.g., 'taxonomy.category', 'post.post').
			 */
			$include_untranslated = apply_filters( 'searchwp_polylang_include_untranslated_source', $include_untranslated_post_types, $source_name );

			// For non-attachment post types: if the source is untranslated and
			// we should include untranslated, skip adding a language mod.
			$is_untranslated = in_array( $source_name, $untranslated_sources, true );
			if ( $is_untranslated && $include_untranslated ) {
				continue;
			}

			$mod    = $this->create_post_language_mod( $current_language, $source_name );
			$mods[] = $mod;
		}

		return $mods;
	}

	/**
	 * Processes attachment post sources using Polylang media logic.
	 *
	 * Attachments follow dedicated logic different from other post types.
	 *
	 * @since 1.5.0
	 *
	 * @param array  $sources          Array of post source names that refer to attachments only.
	 * @param string $current_language The current language code.
	 *
	 * @return array Array of mod objects.
	 */
	private function process_attachment_sources( $sources, $current_language ) {

		$mods = [];

		if ( empty( $sources ) ) {
			return $mods;
		}

		/**
		 * Filters whether to include untranslated media in the search results.
		 *
		 * @since 1.3.0
		 *
		 * @param bool $include_untranslated_media Whether to include untranslated media. Default is true.
		 */
		$include_untranslated_media = apply_filters( 'searchwp_polylang_include_untranslated_media', true );

		// Evaluate Polylang media setting once to know if attachments are considered translated.
		// According to Polylang behavior:
		// - If options are empty, or 'media_support' is not set, or true => media is translated.
		// - If 'media_support' is explicitly false => media is NOT translated.
		$pll_options         = get_option( 'polylang' );
		$media_is_translated = ( empty( $pll_options ) || ! isset( $pll_options['media_support'] ) || (bool) $pll_options['media_support'] );

		$flag = 'post' . SEARCHWP_SEPARATOR;

		foreach ( $sources as $source_name ) {
			if ( $source_name !== $flag . 'attachment' ) {
				continue; // Safety: this handler is only for attachments.
			}

			/**
			 * Determine initial value from legacy filters.
			 *
			 * @since 1.5.0
			 *
			 * @param bool   $include_untranslated Whether to include untranslated sources. Default value comes from legacy filters for backward compatibility.
			 * @param string $source_name          The source name (e.g., 'taxonomy.category', 'post.post').
			 */
			$include_untranslated_media = apply_filters( 'searchwp_polylang_include_untranslated_source', $include_untranslated_media, $source_name );

			// If media (attachments) are untranslated and we intend to include
			// untranslated, skip adding a language mod (include all attachments).
			if ( ! $media_is_translated && $include_untranslated_media ) {
				continue;
			}

			// Otherwise add the language mod which will:
			// - Restrict to current language when media is translated; or
			// - Effectively exclude attachments when media is untranslated and include_untranslated=false.
			$mods[] = $this->create_post_language_mod( $current_language, $source_name );
		}

		return $mods;
	}

	/**
	 * Processes taxonomy sources and creates language mods for translated taxonomies.
	 *
	 * @since 1.5.0
	 *
	 * @param array $sources Array of taxonomy source names.
	 *
	 * @return array Array of mod objects.
	 */
	private function process_taxonomy_sources( $sources ) {

		$mods = [];

		if ( empty( $sources ) ) {
			return $mods;
		}

		/**
		 * Filters whether to include untranslated taxonomies in the search results.
		 *
		 * @since 1.5.0
		 *
		 * @param bool $include_untranslated_taxonomies Whether to include untranslated taxonomies. Default is true.
		 */
		$include_untranslated_taxonomies = apply_filters( 'searchwp_polylang_include_untranslated_taxonomies', true );

		$flag                 = 'taxonomy' . SEARCHWP_SEPARATOR;
		$translated_sources   = $this->get_translated_taxonomy_sources( $sources );
		$untranslated_sources = array_diff( $sources, $translated_sources );

		foreach ( $sources as $source_name ) {

			/**
			 * Filters whether to include untranslated sources in the search results.
			 *
			 * @since 1.5.0
			 *
			 * @param bool   $include_untranslated Whether to include untranslated sources. Default value comes from legacy filters for backward compatibility.
			 * @param string $source_name          The source name (e.g., 'taxonomy.category', 'post.post').
			 */
			$include_untranslated_taxonomies = apply_filters( 'searchwp_polylang_include_untranslated_source', $include_untranslated_taxonomies, $source_name );

			// Check if untranslated and should be included.
			if ( in_array( $source_name, $untranslated_sources, true ) && $include_untranslated_taxonomies ) {
				// To include untranslated taxonomies, we need to skip the create_taxonomy_language_mod. So we can just continue.
				continue;
			}

			// Handle untranslated sources when include_untranslated=false.
			if ( in_array( $source_name, $untranslated_sources, true ) && ! $include_untranslated_taxonomies ) {
				// Create mod with exclusion WHERE clause to exclude all results.
				$mod = $this->create_taxonomy_language_mod( $source_name, [], true );
				if ( $mod ) {
					$mods[] = $mod;
				}
				continue;
			}

			// Only process translated taxonomies.
			if ( ! in_array( $source_name, $translated_sources, true ) ) {
				continue;
			}

			// Extract taxonomy name from source name.
			$taxonomy = str_replace( $flag, '', $source_name );

			// Get all terms for this taxonomy. Polylang automatically filters by current language.
			$terms = get_terms(
				[
					'taxonomy'   => $taxonomy,
					'fields'     => 'all',
					'hide_empty' => false,
				]
			);

			// Skip if get_terms returned an error or empty array.
			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				continue;
			}

			// Extract term_taxonomy_id from each term.
			$term_taxonomy_ids = array_map(
				function ( $term ) {
					return absint( $term->term_taxonomy_id );
				},
				$terms
			);

			// Remove any invalid IDs.
			$term_taxonomy_ids = array_filter( $term_taxonomy_ids );

			// Skip if no valid term_taxonomy_ids found.
			if ( empty( $term_taxonomy_ids ) ) {
				continue;
			}

			// Create mod that filters by term_taxonomy_id.
			$mod = $this->create_taxonomy_language_mod( $source_name, $term_taxonomy_ids );
			if ( $mod ) {
				$mods[] = $mod;
			}
		}

		return $mods;
	}

	/**
	 * Creates a query modification for taxonomy language filtering using term_taxonomy_id.
	 *
	 * @since 1.5.0
	 *
	 * @param string $source_name       The source name (e.g., 'taxonomy.category').
	 * @param array  $term_taxonomy_ids Array of term_taxonomy_id values to filter by.
	 * @param bool   $exclude_all       Whether to exclude all results (use 1=0 WHERE clause). Default false.
	 *
	 * @return \SearchWP\Mod|null The query modification object, or null if no valid IDs.
	 */
	private function create_taxonomy_language_mod( $source_name, $term_taxonomy_ids, $exclude_all = false ) {

		global $wpdb;

		$mod   = new Mod( $source_name );
		$alias = 'swppolylang_tt_' . str_replace( '.', '_', $source_name ) . '_';

		// Join to wp_term_taxonomy table.
		// The SearchWP index stores term_id in the id column, so we join on term_id.
		$mod->raw_join_sql(
			function ( $runtime ) use ( $wpdb, $alias ) {
				return "LEFT JOIN {$wpdb->term_taxonomy} {$alias} ON {$alias}.term_id = {$runtime->get_foreign_alias()}.id";
			}
		);

		// If exclude_all is true, use 1=0 to exclude all results.
		if ( $exclude_all ) {
			$mod->raw_where_sql( '1=0' );

			return $mod;
		}

		// Normal filtering by term_taxonomy_id.
		if ( empty( $term_taxonomy_ids ) || ! is_array( $term_taxonomy_ids ) ) {
			return null;
		}

		// Sanitize all IDs.
		$term_taxonomy_ids = array_map( 'absint', $term_taxonomy_ids );
		$term_taxonomy_ids = array_filter( $term_taxonomy_ids );

		if ( empty( $term_taxonomy_ids ) ) {
			return null;
		}

		// Filter by term_taxonomy_id IN (array).
		// Since IDs are already sanitized with absint(), we can safely implode them.
		$mod->raw_where_sql(
			function () use ( $alias, $term_taxonomy_ids ) {
				if ( empty( $term_taxonomy_ids ) ) {
					return '';
				}
				$ids_string = implode( ',', $term_taxonomy_ids );

				return "{$alias}.term_taxonomy_id IN ({$ids_string})";
			}
		);

		return $mod;
	}

	/**
	 * Creates a query modification for language filtering.
	 *
	 * Note: This method is only for post sources. Taxonomy sources should use
	 * create_taxonomy_language_mod() instead.
	 *
	 * @since 1.4.1
	 *
	 * @param string $current_language The current language code.
	 * @param string $source_name      The source name (e.g., 'post.post').
	 *
	 * @return \SearchWP\Mod The query modification object.
	 */
	private function create_post_language_mod( $current_language, $source_name ) {

		global $wpdb;

		$alias = 'swppolylang_' . str_replace( '.','_', $source_name ) . '_';

		$tax_query = new WP_Tax_Query(
			[
				[
					'taxonomy' => 'language',
					'field'    => 'slug',
					'terms'    => sanitize_text_field( $current_language ),
				],
			]
		);

		$tq_sql = $tax_query->get_sql( $alias, 'ID' );
		$mod    = new Mod( $source_name );

		$this->apply_post_tax_query_joins( $mod, $tq_sql, $alias, $wpdb, $tax_query );

		return $mod;
	}

	/**
	 * Applies tax query JOINs and WHERE clauses to the mod.
	 *
	 * Note: This method is only for post sources. Taxonomy sources should use
	 * create_taxonomy_language_mod() instead.
	 *
	 * @since 1.4.1
	 *
	 * @param \SearchWP\Mod $mod       The mod object.
	 * @param array         $tq_sql    The tax query SQL parts.
	 * @param string        $alias     The table alias.
	 * @param wpdb          $wpdb      WordPress database object.
	 * @param WP_Tax_Query  $tax_query The tax query object.
	 *
	 * @return void
	 */
	private function apply_post_tax_query_joins( $mod, $tq_sql, $alias, $wpdb, $tax_query ) {

		// Determine the table and ID column (always posts for this method).
		$table     = $wpdb->posts;
		$id_column = 'ID';

		if ( ! empty( $tq_sql['join'] ) ) {
			// Queue the table JOIN using our alias.
			$mod->raw_join_sql(
				function ( $runtime ) use ( $wpdb, $alias, $table, $id_column ) {
					return "LEFT JOIN {$table} {$alias} ON {$alias}.{$id_column} = {$runtime->get_foreign_alias()}.id";
				}
			);

			// Queue the WP_Tax_Query JOIN with modified alias.
			$join = str_replace( $wpdb->term_relationships . '.', $alias . 'tr.', $tq_sql['join'] );
			$join = str_replace( $wpdb->term_relationships, $wpdb->term_relationships . ' ' . $alias . 'tr', $join );
			$mod->raw_join_sql( $join );

			// Queue the WP_Tax_Query WHERE with modified alias.
			$where = str_replace( $wpdb->term_relationships . '.', $alias . 'tr.', $tq_sql['where'] );
			$where = str_replace( $wpdb->term_relationships, $alias . 'tr', $where );
			$mod->raw_where_sql( '1=1 ' . $where );
		} else {
			// Rebuild tax query using Mod's alias.
			$mod->set_local_table( $table );
			$mod->on( $id_column, [ 'column' => 'id' ] );

			$mod->raw_where_sql(
				function ( $runtime ) use ( $tax_query, $id_column ) {
					$tq_sql = $tax_query->get_sql( $runtime->get_local_table_alias(), $id_column );

					return '1=1 ' . $tq_sql['where'];
				}
			);
		}
	}

	/**
	 * Adds SearchWP Forms to Polylang's home_url white list.
	 *
	 * @since 1.4.0
	 *
	 * @param array $white_list The current Polylang white list.
	 *
	 * @return array The filtered white list.
	 */
	public function filter_home_url_white_list( $white_list ) {

		$white_list[] = [ 'file' => SEARCHWP_PLUGIN_DIR . '/includes/Forms/Frontend.php' ];

		return $white_list;
	}

	/**
	 * Adds a hidden language input field to the search form to maintain language context.
	 *
	 * @since 1.4.0
	 *
	 * @return void
	 */
	public function add_language_form_field() {

		// Check if Polylang is active.
		if ( ! function_exists( 'pll_current_language' ) ) {
			return;
		}

		if ( empty( $_REQUEST['lang'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		// Get Polylang current language.
		$current_language = pll_current_language();

		?>
		<input type="hidden" name="lang" value="<?php echo esc_attr( $current_language ); ?>">
		<?php
	}

	/**
	 * Shows appropriate messages in the WordPress plugins page if SearchWP is not active
	 * or if the version is not compatible.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function plugin_row() {

		// Check if SearchWP is active.
		if ( ! class_exists( 'SearchWP' ) ) {
			?>
			<tr class="plugin-update-tr searchwp">
				<td colspan="4" class="plugin-update">
					<div class="update-message">
						<?php esc_html_e( 'SearchWP must be active to use this Extension' ); ?>
					</div>
				</td>
			</tr>
		<?php
		}
	}
}
