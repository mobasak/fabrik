<?php

/*
	Plugin Name: WP Sheet Editor - Polylang
	Description: Add columns to edit the polylang language and connect the translations on the spreadsheet.
	Version: 1.0.8
	Author:      WP Sheet Editor
	Author URI:  https://wpsheeteditor.com
	Plugin URI: http://wpsheeteditor.com
 */
if ( isset( $_GET['asdfasdfasdf'] ) ) {
	return;
}
if ( ! class_exists( 'WPSE_Polylang' ) ) {

	class WPSE_Polylang {

		private static $instance = false;

		private function __construct() {
		}

		function init() {
			if ( ! defined( 'POLYLANG_VERSION' ) || ! function_exists( 'pll_is_translated_post_type' ) ) {
				return;
			}
			add_action( 'vg_sheet_editor/editor/register_columns', array( $this, 'register_columns' ), 50 );
			add_filter( 'vg_sheet_editor/global_js_data', array( $this, 'always_use_initial_language' ) );
			add_filter( 'vg_sheet_editor/options_page/options', array( $this, 'add_settings_page_options' ) );
			add_filter( 'vg_sheet_editor/data/taxonomy_terms/cache_key', array( $this, 'modify_cache_key' ) );
			add_action( 'vg_sheet_editor/editor_page/after_console_text', array( $this, 'warn_language_not_set' ) );
			add_action( 'vg_sheet_editor/filters/after_advanced_fields_section', array( $this, 'add_language_search' ) );
			add_filter( 'vg_sheet_editor/filters/sanitize_request_filters', array( $this, 'register_custom_filters' ), 10, 2 );
			add_filter( 'posts_clauses', array( $this, 'search_by_translation' ), 10, 2 );
		}
		function search_by_translation( $clauses, $wp_query ) {
			global $wpdb;

			if ( empty( $wp_query->query['wpse_original_filters'] ) || empty( $wp_query->query['wpse_original_filters']['poly_translations_missing'] ) ) {
				return $clauses;
			}
			if ( ! $this->is_default_language() ) {
				return $clauses;
			}

			$missing_languages = $wp_query->query['wpse_original_filters']['poly_translations_missing'];
			
			$languages_raw = get_terms(
				array(
					'taxonomy'               => 'language',
					'hide_empty'             => false,
					'update_term_meta_cache' => false,
				)
			);
			$languages     = wp_list_pluck( $languages_raw, 'name', 'slug' );

			// Sanitize. We remove any value received not found in the active languages,
			// and any value that doesn't have 2 letters only.
			foreach ( $missing_languages as $index => $missing_language ) {
				if ( ! isset( $languages[ $missing_language ] ) || ! preg_match( '/^[A-Za-z]{2}([-][A-Za-z]{2})?$/', $missing_language ) ) {
					unset( $missing_languages[ $index ] );
				}
			}

			$placeholders = array();
			$values       = array();

			foreach ( $missing_languages as $language ) {
				$placeholders[] = 'tt.description LIKE %s';
				$values[]       = '%"' . $language . '"%';
			}

			$where_clause = implode( ' OR ', $placeholders );

			$sql = " AND $wpdb->posts.ID NOT IN (
				SELECT DISTINCT p.ID
				FROM $wpdb->posts p
				INNER JOIN $wpdb->term_relationships tr ON p.ID = tr.object_id
				INNER JOIN $wpdb->term_taxonomy tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
				INNER JOIN $wpdb->terms t ON tt.term_id = t.term_id
				WHERE tt.taxonomy = 'post_translations'
				AND p.post_type = 'post'
				AND ($where_clause)
			) ";

			$clauses['where'] .= $wpdb->prepare( $sql, $values );

			return $clauses;
		}
		function register_custom_filters( $sanitized_filters, $dirty_filters ) {

			if ( isset( $dirty_filters['poly_translations_missing'] ) ) {
				$sanitized_filters['poly_translations_missing'] = array();
				foreach ( $dirty_filters['poly_translations_missing'] as $language ) {
					if ( is_string( $language ) && preg_match( '/^[A-Za-z]{2}([-][A-Za-z]{2})?$/', $language ) ) {
						$sanitized_filters['poly_translations_missing'][] = sanitize_text_field( $language );
					}
				}
			}
			return $sanitized_filters;
		}
		function add_language_search( $spreadsheet_key ) {
			if ( ! VGSE()->helpers->get_current_provider()->is_post_type ) {
				return;
			}
			if ( ! $this->is_default_language() ) {
				return;
			}
			$languages_raw = get_terms(
				array(
					'taxonomy'               => 'language',
					'hide_empty'             => false,
					'update_term_meta_cache' => false,
				)
			);
			$languages     = wp_list_pluck( $languages_raw, 'name', 'slug' );
			?>
						<li class="poly-languages-without-translations">
							<label><?php echo esc_html__( 'Polylang - Missing translations in these languages', 'vg_sheet_editor' ); ?>  <a href="#" data-wpse-tooltip="right" aria-label="<?php esc_attr_e( 'For example, select "Spanish" and "German" here and we\'ll find items that don\'t have spanish translations or german translations.', 'vg_sheet_editor' ); ?>">( ? )</a></label>
							<select name="poly_translations_missing[]" multiple class="select2">
<option value="">--</option>
			<?php
			foreach ( $languages as $code => $display_name ) {
				?>
	<option value="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $display_name ); ?></option>
				<?php
			}
			?>
							</select>
						</li>

						<?php
		}

		function warn_language_not_set() {
			$lang = pll_current_language();
			if ( ! $lang || $lang === 'all' ) {
				echo '<span class="notice-text" style="color: red;">' . __( '. Please select a language in the WordPress toolbar, the sheet editor won\'t work correctly if a language is not selected because we won\'t know what language we\'re editing.', 'vg_sheet_editor' ) . '</span>';
			}
		}

		function modify_cache_key( $cache_key ) {
			return $cache_key . pll_current_language();
		}

		/**
		 * Add fields to options page
		 * @param array $sections
		 * @return array
		 */
		function add_settings_page_options( $sections ) {
			if ( class_exists( 'WooCommerce' ) ) {
				$sections['misc']['fields'][] = array(
					'id'    => 'polylang_wc_product_use_sku',
					'type'  => 'switch',
					'title' => __( 'Polylang: Use product SKUs instead of titles in the column "Translation of"?', 'vg_sheet_editor' ),
					'desc'  => __( 'Each translation needs to be connected to the product in the original language using the column "Polylang - Translation of", and the column uses product titles by default, but this can cause problems if you have duplicate titles. So you can use SKUs instead by activating this option but all your products must have SKUs because products without SKUs won\'t be attached to translations', 'vg_sheet_editor' ),
				);
			}

			return $sections;
		}

		function always_use_initial_language( $settings ) {
			$current_lang = pll_current_language();
			if ( ! $current_lang ) {
				$current_lang = 'all';
			}
			$settings['ajax_url'] = add_query_arg( 'lang', $current_lang, $settings['ajax_url'] );
			return $settings;
		}

		function is_default_language() {
			$current_lang = pll_current_language();
			if ( ! $current_lang ) {
				$current_lang = 'all';
			}
			$default_language_code = pll_default_language();
			return $current_lang === $default_language_code;
		}

		/**
		 * Register spreadsheet columns
		 */
		function register_columns( $editor ) {
			if ( method_exists( $editor, 'init_toolbars' ) ) {
				$editor->init_toolbars();
			}
			foreach ( $editor->args['enabled_post_types'] as $post_type ) {
				$toolbars = $editor->args['toolbars'];
				if ( empty( $toolbars ) ) {
					continue;
				}
				$license_toolbar_for_post_type = $toolbars->get_item( 'wpse_license', $post_type, 'secondary' );
				if ( ! $license_toolbar_for_post_type ) {
					continue;
				}
				$fs_id = (int) $license_toolbar_for_post_type['fs_id'];
				$fs    = freemius( $fs_id );
				if ( ! $fs ) {
					continue;
				}
				$user = $fs->get_user();
				if ( ! $user ) {
					continue;
				}
				$is_post_type_allowed = post_type_exists( $post_type ) && pll_is_translated_post_type( $post_type );
				$is_taxonomy_allowed  = taxonomy_exists( $post_type ) && pll_is_translated_taxonomy( $post_type );
				if ( $is_post_type_allowed ) {
					$editor->args['columns']->register_item(
						'polylang_original_post',
						$post_type,
						array(
							'data_type'           => 'post_data',
							'column_width'        => 210,
							'title'               => __( 'Polylang: Translation of', 'vg_sheet_editor' ),
							'type'                => '',
							'supports_formulas'   => true,
							'formatted'           => array(
								'type'   => 'autocomplete',
								'source' => 'searchPostByKeyword',
							),
							'allow_to_hide'       => true,
							'allow_to_rename'     => true,
							'get_value_callback'  => array( $this, 'get_translation_of_post' ),
							'save_value_callback' => array( $this, 'update_translation_of_post' ),
						)
					);
					$editor->args['columns']->register_item(
						'language',
						$post_type,
						array(
							'data_type'         => 'post_terms',
							'column_width'      => 150,
							'title'             => __( 'Polylang: Language', 'vg_sheet_editor' ),
							'type'              => '',
							'supports_formulas' => true,
							'formatted'         => array(
								'editor'        => 'select',
								'selectOptions' => VGSE()->data_helpers->get_taxonomy_terms( 'language' ),
							),
							'allow_to_hide'     => true,
							'allow_to_rename'   => true,
						)
					);
					if ( $this->is_default_language() ) {
						$editor->args['columns']->register_item(
							'polylang_existing_translations',
							$post_type,
							array(
								'data_type'          => 'post_data',
								'column_width'       => 200,
								'title'              => __( 'Polylang: Existing Translations', 'vg_sheet_editor' ),
								'supports_formulas'  => false,
								'is_locked'          => true,
								'allow_to_save'      => false,
								'get_value_callback' => array( $this, 'get_existing_translations' ),
							)
						);
					}
				}
				if ( $is_taxonomy_allowed ) {
					$editor->args['columns']->register_item(
						'polylang_term_language',
						$post_type,
						array(
							'data_type'           => 'post_terms',
							'column_width'        => 150,
							'title'               => __( 'Polylang: Language', 'vg_sheet_editor' ),
							'type'                => '',
							'supports_formulas'   => true,
							'formatted'           => array(
								'editor'        => 'select',
								'selectOptions' => VGSE()->data_helpers->get_taxonomy_terms( 'language' ),
							),
							'allow_to_hide'       => true,
							'allow_to_rename'     => true,
							'get_value_callback'  => array( $this, 'get_term_language' ),
							'save_value_callback' => array( $this, 'update_term_language' ),
						)
					);
					$editor->args['columns']->register_item(
						'polylang_original_term',
						$post_type,
						array(
							'data_type'             => 'post_data',
							'column_width'          => 210,
							'title'                 => __( 'Polylang: Translation of', 'vg_sheet_editor' ),
							'type'                  => '',
							'formatted'             => array(
								'type'         => 'autocomplete',
								'source'       => 'loadTaxonomyTerms',
								'taxonomy_key' => $post_type,
							),
							'supports_formulas'     => true,
							'supports_sql_formulas' => false,
							'get_value_callback'    => array( $this, 'get_translation_of_term' ),
							'save_value_callback'   => array( $this, 'update_translation_of_term' ),
						)
					);
				}
			}
		}

		function get_existing_translations( $post, $cell_key, $cell_args ) {
			// Only show for main language posts (where the post is the original)
			$translations = pll_get_post_translations( $post->ID );

			// If this post is not the main language version, don't show anything
			if ( ! isset( $translations[ pll_default_language() ] ) || $translations[ pll_default_language() ] !== $post->ID ) {
				return '';
			}

			// Get all translation languages except the default language (main language)
			$language_codes = array_keys( $translations );
			$language_codes = array_diff( $language_codes, array( pll_default_language() ) );

			// Return comma-separated list of language codes
			return implode( ', ', $language_codes );
		}
		function get_term_language( $post, $cell_key, $cell_args ) {
			$value = pll_get_term_language( $post->ID, 'name' );
			if ( ! $value ) {
				$value = '';
			}
			return $value;
		}

		function get_translation_of_term( $post, $cell_key, $cell_args ) {
			$default_language_code = pll_default_language();
			$translations          = pll_get_term_translations( $post->ID );
			$value                 = '';
			if ( is_array( $translations ) && isset( $translations[ $default_language_code ] ) && $translations[ $default_language_code ] !== $post->ID ) {
				$term  = get_term_by( 'term_id', $translations[ $default_language_code ], $post->post_type );
				$value = html_entity_decode( $term->name );
			}
			return $value;
		}

		function get_translation_of_post( $post, $cell_key, $cell_args ) {
			global $wpdb;
			$default_language_code = pll_default_language();
			$translations          = pll_get_post_translations( $post->ID );
			$value                 = '';
			if ( is_array( $translations ) && isset( $translations[ $default_language_code ] ) && $translations[ $default_language_code ] !== $post->ID ) {
				if ( VGSE()->get_option( 'polylang_wc_product_use_sku', false ) && strpos( $post->post_type, 'product' ) === 0 ) {
					$value = get_post_meta( $post->ID, '_sku', true );
				} else {
					$raw_title = $wpdb->get_var( $wpdb->prepare( "SELECT post_title FROM $wpdb->posts WHERE post_type = %s AND ID = %d LIMIT 1", $post->post_type, $translations[ $default_language_code ] ) );
					$value     = html_entity_decode( $raw_title );
				}
			}
			return $value;
		}

		function update_term_language( $post_id, $cell_key, $data_to_save, $post_type, $cell_args, $spreadsheet_columns ) {
			$language = get_term_by( 'name', $data_to_save, 'language' );
			if ( ! $language ) {
				return;
			}
			$language_code = $language->slug;
			if ( ! $data_to_save ) {
				$language_code = pll_default_language();
			}
			pll_set_term_language( $post_id, $language->slug );
		}

		function update_translation_of_term( $post_id, $cell_key, $data_to_save, $post_type, $cell_args, $spreadsheet_columns ) {
			if ( empty( $data_to_save ) ) {
				PLL()->model->term->delete_translation( $post_id );
			} else {
				$current_lang          = pll_current_language();
				$default_language_code = pll_default_language();
				PLL_WPML_API::wpml_switch_language( $default_language_code );
				$terms_saved = VGSE()->data_helpers->prepare_post_terms_for_saving( $data_to_save, $post_type, '====' );
				PLL_WPML_API::wpml_switch_language( $current_lang );

				if ( $terms_saved ) {
					$main_term_id                           = current( $terms_saved );
					$translations                           = pll_get_term_translations( $post_id );
					$translations[ $default_language_code ] = $main_term_id;
					pll_save_term_translations( $translations );
				}
			}
		}

		function update_translation_of_post( $post_id, $cell_key, $data_to_save, $post_type, $cell_args, $spreadsheet_columns ) {
			global $wpdb;
			if ( empty( $data_to_save ) ) {
				PLL()->model->post->delete_translation( $post_id );
			} else {
				if ( VGSE()->get_option( 'polylang_wc_product_use_sku', false ) && strpos( $post_type, 'product' ) === 0 ) {
					$main_post_id = wc_get_product_id_by_sku( $data_to_save );
				} else {
					$main_post_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type = %s AND post_title = %s LIMIT 1", $post_type, $data_to_save ) );
				}

				if ( $main_post_id ) {
					$translations                           = pll_get_post_translations( $post_id );
					$default_language_code                  = pll_default_language();
					$translations[ $default_language_code ] = $main_post_id;
					pll_save_post_translations( $translations );
				}
			}
		}

		/**
		 * Creates or returns an instance of this class.
		 */
		static function get_instance() {
			if ( null == self::$instance ) {
				self::$instance = new WPSE_Polylang();
				self::$instance->init();
			}
			return self::$instance;
		}

		function __set( $name, $value ) {
			$this->$name = $value;
		}

		function __get( $name ) {
			return $this->$name;
		}
	}

}

if ( ! function_exists( 'WPSE_Polylang_Obj' ) ) {

	function WPSE_Polylang_Obj() {
		return WPSE_Polylang::get_instance();
	}
}
add_action( 'vg_sheet_editor/initialized', 'WPSE_Polylang_Obj' );
