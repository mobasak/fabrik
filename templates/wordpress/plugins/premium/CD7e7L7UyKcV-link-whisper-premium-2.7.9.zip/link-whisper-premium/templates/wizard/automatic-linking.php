<?php

$yes_linking = '';
$no_linking = '';
if(isset($existing_settings['wpil_setup_wizard_run_linking']) && !empty($existing_settings['wpil_setup_wizard_run_linking'])){
    $yes_linking = ($existing_settings['wpil_setup_wizard_run_linking'] === 'yes') ? 'checked':'';
    $no_linking = ($existing_settings['wpil_setup_wizard_run_linking'] === 'no') ? 'checked':'';
}

?>
<div class="wpil-setup-wizard wrap wpil_styles wizard-automatic-linking wpil-wizard-page wpil-wizard-page-hidden">
    <div id="wpil-setup-wizard-progress-loading"><div id="wpil-setup-wizard-progress-loading-bar" style="width:calc(100%/5 * 1)"></div></div>
    <div id="wpil-setup-wizard-progress">
        <div class="complete"><a href="<?php echo admin_url('admin.php?page=link_whisper_wizard&wpil_wizard=license');?>" class="wpil-wizard-link" data-wpil-wizard-link-id="license"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('License Activation', 'wpil'); ?></a></div>
        <!--<div class="complete"><a href="<?php echo admin_url('admin.php?page=link_whisper_wizard&wpil_wizard=about-you');?>" class="wpil-wizard-link" data-wpil-wizard-link-id="about-you"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Settings Configuration', 'wpil'); ?></a></div>-->
        <div class="complete"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Automatic Linking', 'wpil'); ?></div>
        <div><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Connect to Google Search Console', 'wpil'); ?></div>
        <div><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Connect to AI', 'wpil'); ?></div>
        <div><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Complete Installation', 'wpil'); ?></div>
    </div>
    <div class="wpil-setup-wizard-content">
        <a href="<?php echo admin_url();?>" class="wpil-wizard-exit-button">EXIT WIZARD</a>
        <div id="wpil-setup-wizard-heading-container">
            <img src="<?php echo WP_INTERNAL_LINKING_PLUGIN_URL . '/images/lw-icon.png' ?>" width="128px" height="128px">
            <h1 id="wpil-setup-wizard-heading"><?php esc_html_e('Automatically create links using best practices?', 'wpil'); ?></h1>
        </div>
        <div class="wpil-setup-wizard-radio-button-wrapper">
            <div class="wpil-setup-wizard-radio-button-container">
                <label class="wpil-setup-wizard-radio-button" <?php echo $yes_linking; ?>><input type="radio" class="wpil-setup-wizard-radio" name="wpil_setup_wizard_run_linking" value="yes" required <?php echo $yes_linking;?>><div style="margin-left:35px;font-size:19px;font-weight:400;"><?php esc_html_e('Yes, go for it! 🙂', 'wpil'); ?></div></label>
            </div>
            <div class="wpil-setup-wizard-radio-button-container">
                <label class="wpil-setup-wizard-radio-button <?php echo $no_linking; ?>"><input type="radio" class="wpil-setup-wizard-radio" name="wpil_setup_wizard_run_linking" value="no" <?php echo $no_linking;?>><div style="margin-left:35px;font-size:19px;font-weight:400;"><?php esc_html_e('No, I\'ll take care of it.', 'wpil'); ?></div></label>
            </div>
        </div>
        <br><br>
        <div style="position:relative; display:inline-block;">
            <a class="button-primary <?php echo (empty($yes_linking) && empty($no_linking)) ? 'button-disabled': ''; ?> wpil-setup-wizard-main-button wpil-wizard-automatic-linking-next-button" data-wpil-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'wpil_wizard_save_nonce'); ?>"><?php esc_html_e('Next', 'wpil'); ?></a>
            <div style="display:none;" class="wpil-setup-wizard-loading la-ball-clip-rotate la-md"><div></div></div>
        </div>
    </div>
</div>