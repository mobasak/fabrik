<?php
$yes_settings = '';
$no_settings = '';
if(isset($existing_settings['wpil_setup_wizard_configure_settings']) && !empty($existing_settings['wpil_setup_wizard_configure_settings'])){
    $yes_settings = ($existing_settings['wpil_setup_wizard_configure_settings'] === 'yes') ? 'checked':'';
    $no_settings = ($existing_settings['wpil_setup_wizard_configure_settings'] === 'no') ? 'checked':'';
}

?>
<div class="wpil-setup-wizard wrap wpil_styles wizard-about-you wpil-wizard-page wpil-wizard-page-hidden">
    <div id="wpil-setup-wizard-progress-loading"><div id="wpil-setup-wizard-progress-loading-bar" style="width:calc(100%/6 * 1)"></div></div>
    <div id="wpil-setup-wizard-progress">
        <div class="complete"><a href="<?php echo admin_url('admin.php?page=link_whisper_wizard&wpil_wizard=license');?>" class="wpil-wizard-link" data-wpil-wizard-link-id="license"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('License Activation', 'wpil'); ?></a></div>
        <div class="complete"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Settings Configuration', 'wpil'); ?></div>
        <div><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Automatic Linking', 'wpil'); ?></div>
        <div><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Connect to Google Search Console', 'wpil'); ?></div>
        <div><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Connect to AI', 'wpil'); ?></div>
        <div><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e('Complete Installation', 'wpil'); ?></div>
    </div>
    <div class="wpil-setup-wizard-content" style="/*height: 580px;*/">
        <a href="<?php echo admin_url();?>" class="wpil-wizard-exit-button">EXIT WIZARD</a>
        <div id="wpil-setup-wizard-heading-container">
            <img src="<?php echo WP_INTERNAL_LINKING_PLUGIN_URL . '/images/lw-icon.png' ?>" width="128px" height="128px">
            <h1 id="wpil-setup-wizard-heading"><?php esc_html_e('Use best practices for Link Whisper setup?', 'wpil'); ?></h1>
        </div>
        <div class="wpil-setup-wizard-radio-button-wrapper">
            <div class="wpil-setup-wizard-radio-button-container">
                <label class="wpil-setup-wizard-radio-button <?php echo $yes_settings; ?>"><input type="radio" class="wpil-setup-wizard-radio" name="wpil_setup_wizard_configure_settings" value="yes" required <?php echo $yes_settings;?>><div style="margin-left:35px;font-size:19px;font-weight:400;"><?php esc_html_e('Yes, configure away, genius! 🙂', 'wpil'); ?></div></label>
            </div>
            <div class="wpil-setup-wizard-radio-button-container">
                <label class="wpil-setup-wizard-radio-button <?php echo $no_settings; ?>"><input type="radio" class="wpil-setup-wizard-radio" name="wpil_setup_wizard_configure_settings" value="no" <?php echo $no_settings;?>><div style="margin-left:35px;font-size:19px;font-weight:400;"><?php esc_html_e('No, I will set it up.', 'wpil'); ?></div></label>
            </div>
        </div>
        <br><br>
        <div style="position:relative; display:inline-block;">
            <a class="button-primary <?php echo (empty($yes_settings) && empty($no_settings)) ? 'button-disabled': ''; ?> wpil-setup-wizard-main-button wpil-wizard-about-you-next-button" data-wpil-nonce="<?php echo wp_create_nonce(get_current_user_id() . 'wpil_wizard_save_nonce'); ?>"><?php esc_html_e('Next', 'wpil'); ?></a>
            <div style="display:none;" class="wpil-setup-wizard-loading la-ball-clip-rotate la-md"><div></div></div>
        </div>
    </div>
</div>