<?php
/**
 * Correct Spelling Grammar
 *
 * @package     AutomatorWP\Integrations\OpenAI\Actions\Correct_Spelling_Grammar
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

class AutomatorWP_OpenAI_Correct_Spelling_Grammar extends AutomatorWP_Integration_Action {

    public $integration = 'openai';
    public $action = 'openai_correct_spelling_grammar';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'       => $this->integration,
            'label'             => __( 'Correct a text', 'automatorwp-openai' ),
            'select_option'     => __( 'Correct a <strong>text</strong>', 'automatorwp-openai' ),
            /* translators: %1$s: Prompt. */
            'edit_label'        => sprintf( __( 'Correct a %1$s', 'automatorwp-openai' ), '{prompt}' ),
            /* translators: %1$s: Prompt. */
            'log_label'         => sprintf( __( 'Correct a %1$s', 'automatorwp-openai' ), '{prompt}' ),
            'options'           => array(
                'prompt' => array(
                    'default' => __( 'text', 'automatorwp-openai' ),
                    'fields' => array(
                        'prompt' => array(
                            'name' => __( 'Prompt:', 'automatorwp-openai' ),
                            'desc' => __( 'The text to correct the spelling and grammar.', 'automatorwp-openai' ),
                            'type' => 'textarea',
                            'required'  => true,
                            'default' => ''
                        ),
                    )
                    ),
            ),
            'tags' => automatorwp_openai_get_actions_response_tags()
        ) );

    }

    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {
       
        $default_prompt =  __( 'Fix grammar and spelling errors in the following content and return the corrected content', 'automatorwp-openai' );
        
        // Bail if prompt is empty
        if ( empty( $action_options['prompt'] ) ) {
            $this->result = __( 'Prompt field is empty.', 'automatorwp-openai' );
            return;
        }

        $payload = array(
            'prompt'    => $default_prompt . ': ' . $action_options['prompt'],
        );

        $this->result = '';
        $this->response = '';
        
        $api = automatorwp_openai_get_api();

        if( ! $api ) {
            return $options;
        }

        $this->response = automatorwp_openai_chat_completions_response( $payload );

        if ( ! $this->response || isset( $this->response['error'] ) ) {
			
			if ( isset( $this->response['error']['message'] ) ){
				$this->result = sprintf( __( '%s', 'automatorwp-openai' ), $this->response['error']['message'] );
			} else {
				$this->result = __( 'Error: Please check your OpenAI configuration.', 'automatorwp-openai' );	
			}
			$this->response = '';
            return;
        }
    
        $this->result = sprintf( __( '%s', 'automatorwp-openai' ), $this->response );

        }

    /**
     * Register required hooks
     *
     * @since 1.0.0
     */
    public function hooks() {

        // Configuration notice
        add_filter( 'automatorwp_automation_ui_after_item_label', array( $this, 'configuration_notice' ), 10, 2 );

        // Log meta data
        add_filter( 'automatorwp_user_completed_action_log_meta', array( $this, 'log_meta' ), 10, 5 );

        // Log fields
        add_filter( 'automatorwp_log_fields', array( $this, 'log_fields' ), 10, 5 );

        parent::hooks();

    }

    /**
     * Configuration notice
     *
     * @since 1.0.0
     *
     * @param stdClass  $object     The trigger/action object
     * @param string    $item_type  The object type (trigger|action)
     */
    public function configuration_notice( $object, $item_type ) {

        // Bail if action type don't match this action
        if( $item_type !== 'action' ) {
            return;
        }

        if( $object->type !== $this->action ) {
            return;
        }

        // Warn user if the authorization has not been setup from settings
        if( ! automatorwp_openai_get_api() ) : ?>
            <div class="automatorwp-notice-warning" style="margin-top: 10px; margin-bottom: 0;">
                <?php echo sprintf(
                    __( 'You need to configure the <a href="%s" target="_blank">OpenAI settings</a> to get this action to work.', 'automatorwp-openai' ),
                    get_admin_url() . 'admin.php?page=automatorwp_settings&tab=opt-tab-openai'
                ); ?>
                <?php echo sprintf(
                    __( '<a href="%s" target="_blank">Documentation</a>', 'automatorwp-openai' ),
                    'https://automatorwp.com/docs/openai/'
                ); ?>
            </div>
        <?php endif;

    }

    /**
     * Action custom log meta
     *
     * @since 1.0.0
     *
     * @param array     $log_meta           Log meta data
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     *
     * @return array
     */
    public function log_meta( $log_meta, $action, $user_id, $action_options, $automation ) {

        // Bail if action type don't match this action
        if( $action->type !== $this->action ) {
            return $log_meta;
        }

        // Store the action's result
        $log_meta['result'] = $this->result;
        $log_meta['response'] = ( isset( $this->response ) ? $this->response : '' );

        return $log_meta;
    }

    /**
     * Action custom log fields
     *
     * @since 1.0.0
     *
     * @param array     $log_fields The log fields
     * @param stdClass  $log        The log object
     * @param stdClass  $object     The trigger/action/automation object attached to the log
     *
     * @return array
     */
    public function log_fields( $log_fields, $log, $object ) {

        // Bail if log is not assigned to an action
        if( $log->type !== 'action' ) {
            return $log_fields;
        }

        // Bail if action type don't match this action
        if( $object->type !== $this->action ) {
            return $log_fields;
        }

        $log_fields['result'] = array(
            'name' => __( 'Result:', 'automatorwp-openai' ),
            'type' => 'text',
        );

        return $log_fields;
    }

}

new AutomatorWP_OpenAI_Correct_Spelling_Grammar();