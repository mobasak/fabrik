<?php
/**
 * Admin
 *
 * @package     AutomatorWP\Integrations\OpenAI\Admin
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/**
 * Shortcut function to get plugin options
 *
 * @since  1.0.0
 *
 * @param string    $option_name
 * @param bool      $default
 *
 * @return mixed
 */
function automatorwp_openai_get_option( $option_name, $default = false ) {

    $prefix = 'automatorwp_openai_';

    return automatorwp_get_option( $prefix . $option_name, $default );
}

/**
 * Register plugin settings sections
 *
 * @since  1.0.0
 *
 * @return array
 */
function automatorwp_openai_settings_sections( $automatorwp_settings_sections ) {

    $automatorwp_settings_sections['openai'] = array(
        'title' => __( 'OpenAI', 'automatorwp-openai' ),
        'icon' => 'dashicons-openai',
    );

    return $automatorwp_settings_sections;

}
add_filter( 'automatorwp_settings_sections', 'automatorwp_openai_settings_sections' );

/**
 * Register plugin settings meta boxes
 *
 * @since  1.0.0
 *
 * @return array
 */
function automatorwp_openai_settings_meta_boxes( $meta_boxes )  {

    $prefix = 'automatorwp_openai_';

    $meta_boxes['automatorwp-openai-settings'] = array(
        'title' => automatorwp_dashicon( 'openai' ) . __( 'OpenAI', 'automatorwp-openai' ),
        'fields' => apply_filters( 'automatorwp_openai_settings_fields', array(
            $prefix . 'token' => array(
                'name' => __( 'API token:', 'automatorwp-openai' ),
                'desc' => sprintf( __( 'Your OpenAI API token.'), 'automatorwp-openai' ),
                'type' => 'text',
            ),
            $prefix . 'model' => array(
                'name' => __( 'OpenAI Model:', 'automatorwp-openai' ),
                'desc' => sprintf( __( 'OpenAI model to use in requests.'), 'automatorwp-openai' ),
                'type' => 'select',
                'options'          => array(
                    'gpt-3.5-turbo' => __( 'gpt-3.5-turbo', 'automatorwp-openai' ),
                    'gpt-4'   => __( 'gpt-4', 'automatorwp-openai' ),
                ),
            ),
            $prefix . 'authorize' => array(
                'type' => 'text',
                'render_row_cb' => 'automatorwp_openai_authorize_display_cb'
            ),
        ) ),
    );

    return $meta_boxes;

}
add_filter( "automatorwp_settings_openai_meta_boxes", 'automatorwp_openai_settings_meta_boxes' );


/**
 * Display callback for the authorize setting
 *
 * @since  1.0.0
 *
 * @param array      $field_args Array of field arguments.
 * @param CMB2_Field $field      The field object
 */
function automatorwp_openai_authorize_display_cb( $field_args, $field ) {

    $field_id = $field_args['id'];
    
    $token = automatorwp_openai_get_option( 'token', '' );

    ?>
    <div class="cmb-row cmb-type-custom cmb2-id-automatorwp-openai-authorize table-layout" data-fieldtype="custom">
        <div class="cmb-th">
            <label><?php echo __( 'Connect with OpenAI:', 'automatorwp-openai' ); ?></label>
        </div>
        <div class="cmb-td">
            <a id="<?php echo $field_id; ?>" class="button button-primary" href="#"><?php echo __( 'Save credentials', 'automatorwp-openai' ); ?></a>
            <p class="cmb2-metabox-description"><?php echo __( 'Add you OpenAI API Token and click on "Authorize" to connect.', 'automatorwp-openai' ); ?></p>
            <?php if ( ! empty( $token ) ) : ?>
                <div class="automatorwp-notice-success"><?php echo __( 'Site connected with OpenAI successfully.', 'automatorwp-openai' ); ?></div>
            <?php endif; ?>
        </div>    
    </div>
    <?php
}