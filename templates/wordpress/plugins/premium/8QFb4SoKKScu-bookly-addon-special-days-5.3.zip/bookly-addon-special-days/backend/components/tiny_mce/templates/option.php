<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<option value="bookly-staff-special-days"><?php esc_html_e( 'Add Staff Special Days', 'bookly' ) ?></option>