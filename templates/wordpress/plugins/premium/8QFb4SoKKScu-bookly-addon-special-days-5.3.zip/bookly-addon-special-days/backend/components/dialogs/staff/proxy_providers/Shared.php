<?php
namespace BooklySpecialDays\Backend\Components\Dialogs\Staff\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Components\Dialogs\Staff\Proxy;
use BooklySpecialDays\Lib\Entities;

class Shared extends Proxy\Shared
{
    /**
     * @inheriDoc
     */
    public static function duplicateStaff( $original_staff_id, $new_staff )
    {
        /** @var Entities\StaffSpecialDay $special_days */
        $special_days = Entities\StaffSpecialDay::query()
            ->where( 'staff_id', $original_staff_id )
            ->find();

        foreach ( $special_days as $special_day ) {
            $new_special_day = new Entities\StaffSpecialDay();
            $new_special_day
                ->setStaffId( $new_staff->getId() )
                ->setLocationId( $special_day->getLocationId() )
                ->setDate( $special_day->getDate() )
                ->setStartTime( $special_day->getStartTime() )
                ->setEndTime( $special_day->getEndTime() )
                ->save();

            $new_special_day_id = $new_special_day->getId();

            /** @var Entities\StaffSpecialDayBreak[] $special_day_breaks */
            $special_day_breaks = Entities\StaffSpecialDayBreak::query()
                ->where( 'staff_special_day_id', $special_day->getId() )
                ->find();

            foreach ( $special_day_breaks as $break ) {
                $new_break = new Entities\StaffSpecialDayBreak();
                $new_break
                    ->setStaffSpecialDayId( $new_special_day_id )
                    ->setStartTime( $break->getStartTime() )
                    ->setEndTime( $break->getEndTime() )
                    ->save();
            }
        }

        return $original_staff_id;
    }
}