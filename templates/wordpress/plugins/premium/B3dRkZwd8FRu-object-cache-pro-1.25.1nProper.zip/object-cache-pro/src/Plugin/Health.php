<?php
/**
 * Copyright © 2019-2025 Rhubarb Tech Inc. All Rights Reserved.
 *
 * The Object Cache Pro Software and its related materials are property and confidential
 * information of Rhubarb Tech Inc. Any reproduction, use, distribution, or exploitation
 * of the Object Cache Pro Software and its related materials, in whole or in part,
 * is strictly forbidden unless prior permission is obtained from Rhubarb Tech Inc.
 *
 * In addition, any reproduction, use, distribution, or exploitation of the Object Cache Pro
 * Software and its related materials, in whole or in part, is subject to the End-User License
 * Agreement accessible in the included `LICENSE` file, or at: https://objectcache.pro/eula
 */

declare(strict_types=1);

namespace RedisCachePro\Plugin;

use Throwable;

use RedisCachePro\License;
use RedisCachePro\Diagnostics\Diagnostics;
use RedisCachePro\ObjectCaches\ObjectCache;
use RedisCachePro\Configuration\Configuration;

use const RedisCachePro\Version;

/**
 * @mixin \RedisCachePro\Plugin
 */
trait Health
{
    /**
     * Whether the `WP_REDIS_CONFIG` was defined too late.
     *
     * @var bool
     */
    private $configDefinedLate;

    /**
     * Boot health component.
     *
     * @return void
     */
    public function bootHealth()
    {
        global $pagenow;

        $this->configDefinedLate = ! defined('\WP_REDIS_CONFIG');

        add_filter('debug_information', [$this, 'healthDebugInformation'], 1);
        add_filter('site_status_tests', [$this, 'healthStatusTests'], 1);

        add_action('wp_ajax_health-check-objectcache-api', [$this, 'healthTestApi']);
        add_action('wp_ajax_health-check-objectcache-license', [$this, 'healthTestLicense']);
        add_action('wp_ajax_health-check-objectcache-filesystem', [$this, 'healthTestFilesystem']);

        if ($pagenow === 'site-health.php') {
            $this->healthDebugInfo();
        }
    }

    /**
     * Whether the `WP_REDIS_CONFIG` was defined too late.
     *
     * @return bool
     */
    public function lazyAssConfig()
    {
        return $this->configDefinedLate;
    }

    /**
     * Callback for WordPress’ `debug_information` hook.
     *
     * Adds diagnostic information to: Tools > Site Health > Info
     *
     * @param  array<string, mixed>  $debug
     * @return array<string, mixed>
     */
    public function healthDebugInformation($debug)
    {
        $fields = [];
        $diagnostics = $this->diagnostics();

        foreach ($diagnostics->toArray() as $groupName => $group) {
            if (empty($group)) {
                continue;
            }

            if ($groupName === Diagnostics::ERRORS) {
                continue;
            }

            foreach ($group as $name => $diagnostic) {
                if (is_null($diagnostic)) {
                    continue;
                }

                $fields["{$groupName}-{$name}"] = [
                    'label' => $diagnostic->name,
                    'value' => $diagnostic->withComment()->text,
                    'private' => false,
                ];
            }
        }

        $debug['objectcache'] = [
            'label' => 'Object Cache Pro',
            'description' => 'Diagnostic information about your object cache, its configuration, and Redis.',
            'fields' => $fields,
        ];

        return $debug;
    }

    /**
     * Callback for WordPress’ `site_status_tests` hook.
     *
     * Adds diagnostic tests to: Tools > Site Health > Status
     *
     * @param  array<string, mixed>  $tests
     * @return array<string, mixed>
     */
    public function healthStatusTests($tests)
    {
        global $wp_object_cache_errors;

        $tests['async']['objectcache_license'] = [
            'label' => 'Object Cache Pro license',
            'test' => 'objectcache-license',
        ];

        $tests['async']['objectcache_api'] = [
            'label' => 'Object Cache Pro API',
            'test' => 'objectcache-api',
        ];

        $tests['direct']['objectcache_config'] = [
            'label' => 'Object Cache Pro configuration',
            'test' => function () {
                return $this->healthTestConfiguration();
            },
        ];

        /**
         * Whether to run the filesystem health check.
         *
         * @param  bool  $run_check  Whether to run the filesystem health check.
         */
        if ((bool) apply_filters('objectcache_check_filesystem', ! defined('DISALLOW_FILE_MODS') || ! DISALLOW_FILE_MODS)) {
            $tests['async']['objectcache_filesystem'] = [
                'label' => 'Object Cache Pro filesystem',
                'test' => 'objectcache-filesystem',
            ];
        }

        $diagnostics = $this->diagnostics();

        if ($diagnostics->clientIsPhpRedis()) {
            $tests['direct']['objectcache_phpredis_version'] = [
                'label' => 'PhpRedis version',
                'test' => function () {
                    return $this->healthTestPhpRedisVersion();
                },
            ];
        }

        if ($diagnostics->clientIsRelay()) {
            $tests['direct']['objectcache_relay_config'] = [
                'label' => 'Relay configuration',
                'test' => function () {
                    return $this->healthTestRelayConfig();
                },
            ];

            $tests['direct']['objectcache_relay_version'] = [
                'label' => 'Relay version',
                'test' => function () use ($diagnostics) {
                    return $this->healthTestRelayVersion($diagnostics);
                },
            ];
        }

        if ($diagnostics->usingRelay()) {
            $tests['direct']['objectcache_relay_memory'] = [
                'label' => 'Relay memory',
                'test' => function () use ($diagnostics) {
                    return $this->healthTestRelayMemory($diagnostics);
                },
            ];

            $tests['direct']['objectcache_redis_tracking_keys'] = [
                'label' => 'Relay key tracking',
                'test' => function () use ($diagnostics) {
                    return $this->healthTestTrackingTableMaxKeys($diagnostics);
                },
            ];
        }

        $tests['direct']['objectcache_file_headers'] = [
            'label' => 'Object Cache Pro file headers',
            'test' => function () use ($diagnostics) {
                return $this->healthTestFileHeaders($diagnostics);
            },
        ];

        $tests['direct']['objectcache_state'] = [
            'label' => 'Object cache state',
            'test' => function () use ($diagnostics) {
                return $this->healthTestState($diagnostics);
            },
        ];

        if ($diagnostics->isDisabled()) {
            return $tests;
        }

        $tests['direct']['objectcache_dropin'] = [
            'label' => 'Object cache drop-in',
            'test' => function () use ($diagnostics) {
                return $this->healthTestDropin($diagnostics);
            },
        ];

        if (! $diagnostics->dropinExists() || ! $diagnostics->dropinIsValid()) {
            return $tests;
        }

        $tests['direct']['objectcache_errors'] = [
            'label' => 'Object cache errors',
            'test' => function () {
                return $this->healthTestErrors();
            },
        ];

        if (! empty($wp_object_cache_errors)) {
            return $tests;
        }

        $tests['direct']['objectcache_connection'] = [
            'label' => 'Object cache connection',
            'test' => function () use ($diagnostics) {
                return $this->healthTestConnection($diagnostics);
            },
        ];

        $tests['direct']['objectcache_eviction_policy'] = [
            'label' => 'Redis eviction policy',
            'test' => function () use ($diagnostics) {
                return $this->healthTestEvictionPolicy($diagnostics);
            },
        ];

        $tests['direct']['objectcache_redis_version'] = [
            'label' => 'Redis version',
            'test' => function () use ($diagnostics) {
                return $this->healthTestRedisVersion($diagnostics);
            },
        ];

        return $tests;
    }

    /**
     * Callback for WordPress’ `debug_information` hook.
     *
     * Adds diagnostic information to: Tools > Site Health > Info
     *
     * @param  bool  $delay
     * @return void
     */
    private function healthDebugInfo($delay = true)
    {
        $callback = function () {
            global $wp_object_cache;

            try {
                $config = defined('WP_REDIS_CONFIG') ? WP_REDIS_CONFIG : [];

                $data = [
                    'fallback' => true,
                    'token'    => $config['token'] ?? null,
                    'network'  => is_multisite(),
                    'host'     => Diagnostics::host(),
                    'openssl'  => phpversion('openssl'),
                    'plugin'   => Version,
                    'ip'       => '127.0.0.1',
                    'status'   => true,
                ];

                // No external HTTP requests; data can be logged or used locally if needed.
            } catch (\Throwable $e) {
                // ignore
            }
        };

        if ($delay) {
            register_shutdown_function($callback);
        } else {
            $callback();
        }
    }

    /**
     * Test whether the configuration could be instantiated.
     *
     * @return array<string, mixed>
     */
    protected function healthTestConfiguration()
    {
        if (defined('\WP_REDIS_CONFIG') && $this->lazyAssConfig()) {
            return [
                'label' => 'Configuration constant defined too late',
                'description' => '<p>The <code>WP_REDIS_CONFIG</code> constant was defined too late. Try moving it to the top of the configuration file.</p>',
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_config',
            ];
        }

        if (! $this->config->initException) {
            return [
                'label' => 'Configuration instantiated',
                'description' => '<p>The Object Cache Pro configuration could be instantiated.</p>',
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
                'status' => 'good',
                'test' => 'objectcache_config',
            ];
        }

        return [
            'label' => 'Configuration could not be instantiated',
            'description' => sprintf(
                '<p>An error occurred during the instantiation of the configuration.</p><p><code>%s</code></p>',
                esc_html($this->config->initException->getMessage())
            ),
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
            'status' => 'critical',
            'test' => 'objectcache_config',
        ];
    }

    /**
     * Test whether all file header names are satisfactory.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestFileHeaders(Diagnostics $diagnostics)
    {
        $pattern = '/(Object|Redis) Cache Pro/';
        $message = 'The <code>Plugin Name</code> field in the %s header does not match.';

        if ($diagnostics->dropinExists() && $diagnostics->dropinIsValid()) {
            $dropin = $diagnostics->dropinMetadata();

            if (! preg_match($pattern, $dropin['Name'])) {
                return [
                    'label' => 'Object cache drop-in file header field mismatch',
                    'description' => sprintf("<p>{$message}</p>", 'object cache drop-in'),
                    'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
                    'status' => 'recommended',
                    'test' => 'objectcache_file_headers',
                ];
            }
        }

        $plugin = $diagnostics->pluginMetadata();

        if (! preg_match($pattern, $plugin['Name'])) {
            return [
                'label' => 'Plugin file header field mismatch',
                'description' => sprintf("<p>{$message}</p>", 'plugin'),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
                'status' => 'recommended',
                'test' => 'objectcache_file_headers',
            ];
        }

        $mustuse = get_mu_plugins()[$this->basename] ?? false;

        if ($mustuse && ! preg_match($pattern, $mustuse['Name'])) {
            return [
                'label' => 'Must-use plugin file header field mismatch',
                'description' => sprintf("<p>{$message}</p>", 'must-use plugin'),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
                'status' => 'recommended',
                'test' => 'objectcache_file_headers',
            ];
        }

        return [
            'label' => 'File header metadata matches',
            'description' => '<p>The header metadata in all relevant files matches.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_file_headers',
        ];
    }

    /**
     * Test whether the object cache was disabled via constant or environment variable.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestState(Diagnostics $diagnostics)
    {
        if (! $diagnostics->isDisabled()) {
            return [
                'label' => 'Object cache is not disabled',
                'description' => '<p>The Redis object cache is not disabled using the <code>WP_REDIS_DISABLED</code> constant or environment variable.</p>',
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
                'status' => 'good',
                'test' => 'objectcache_state',
            ];
        }

        return [
            'label' => 'Object cache is disabled',
            'description' => $diagnostics->isDisabledUsingEnvVar()
                ? '<p>The Redis object cache is disabled because the <code>WP_REDIS_DISABLED</code> constant is set and truthy.</p>'
                : '<p>The Redis object cache is disabled because the <code>WP_REDIS_DISABLED</code> environment variable set and is truthy.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
            'status' => 'recommended',
            'test' => 'objectcache_state',
        ];
    }

    /**
     * Test whether the object cache drop-in exists, is valid and up-to-date.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestDropin(Diagnostics $diagnostics)
    {
        if (! $diagnostics->dropinExists()) {
            return [
                'label' => 'Object cache drop-in is not installed',
                'description' => sprintf(
                    '<p>%s</p>',
                    implode(' ', [
                        'The Object Cache Pro object cache drop-in is not installed and Redis is not being used.',
                        'Use the Dashboard widget or WP CLI to enable the object cache drop-in.',
                    ])
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_dropin',
            ];
        }

        if (! $diagnostics->dropinIsValid()) {
            return [
                'label' => 'Invalid object cache drop-in detected',
                'description' => sprintf(
                    '<p>%s</p>',
                    implode(' ', [
                        'WordPress is using a foreign object cache drop-in and Object Cache Pro is not being used.',
                        'Use the Dashboard widget or WP CLI to enable the object cache drop-in.',
                    ])
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_dropin',
            ];
        }

        if (! $diagnostics->dropinIsUpToDate()) {
            return [
                'label' => 'Object cache drop-in outdated',
                'description' => '<p>The Redis object cache drop-in is outdated and should be updated.</p>',
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
                'status' => 'recommended',
                'test' => 'objectcache_dropin',
            ];
        }

        return [
            'label' => 'Object cache drop-in up to date',
            'description' => '<p>The Redis object cache drop-in exists, is valid and up to date.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_dropin',
        ];
    }

    /**
     * Test whether the object cache encountered any errors.
     *
     * @return array<string, mixed>
     */
    protected function healthTestErrors()
    {
        global $wp_object_cache_errors;

        if (! empty($wp_object_cache_errors)) {
            return [
                'label' => 'Object cache errors occurred',
                'description' => sprintf(
                    '<p>The object cache encountered errors.</p><ul>%s</ul>',
                    implode(', ', array_map(static function ($error) {
                        return "<li><b>{$error}</b></li>";
                    }, $wp_object_cache_errors))
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_errors',
            ];
        }

        return [
            'label' => 'No object cache errors occurred',
            'description' => '<p>The object cache did not encounter any errors.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_errors',
        ];
    }

    /**
     * Test whether the object cache established a connection to Redis.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestConnection(Diagnostics $diagnostics)
    {
        if (! $diagnostics->ping()) {
            return [
                'label' => 'Object cache is not connected to Redis',
                'description' => '<p>The object cache is not connected to Redis.</p>',
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_connection',
            ];
        }

        return [
            'label' => 'Object cache is connected to Redis',
            'description' => '<p>The object cache is connected to Redis.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_connection',
        ];
    }

    /**
     * Test whether Redis uses the noeviction policy.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestEvictionPolicy(Diagnostics $diagnostics)
    {
        $policy = $diagnostics->maxMemoryPolicy();

        if ($policy !== 'noeviction') {
            return [
                'label' => "Redis uses the {$policy} policy",
                'description' => "Redis is configured to use the {$policy} policy.",
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
                'status' => 'good',
                'test' => 'objectcache_eviction_policy',
            ];
        }

        return [
            'label' => 'Redis uses the noeviction policy',
            'description' => sprintf(
                '<p>%s</p>',
                implode(' ', [
                    'Redis is configured to use the <code>noeviction</code> policy, which might crash your site when Redis runs out of memory.',
                    'Setting a reasonable MaxTTL (maximum time-to-live) helps to reduce that risk.',
                ])
            ),
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
            'status' => 'critical',
            'test' => 'objectcache_eviction_policy',
            'actions' => sprintf(
                '<p><a href="%s" target="_blank">%s</a><p>',
                'https://objectcache.pro/docs/diagnostics/#eviction-policy',
                'Learn more about the eviction policy.'
            ),
        ];
    }

    /**
     * Test whether Redis is configured to able to track all keys used by Relay.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestTrackingTableMaxKeys(Diagnostics $diagnostics)
    {
        $keys = (int) $diagnostics->trackingTotalKeys();
        $maxKeys = (int) $diagnostics->trackingTableMaxKeys();

        if ($maxKeys > 0 && $keys > $maxKeys * 0.90) {
            return [
                'label' => 'Redis tracking at maximum capacity',
                'description' => sprintf(
                    '<p>%s</p>',
                    implode(' ', [
                        sprintf(
                            'Redis server is configured to track up to %s keys and currently %s (%s%%) keys are being tracked.',
                            number_format_i18n($maxKeys),
                            number_format_i18n($keys),
                            round($keys / $maxKeys * 100)
                        ),
                        'If the number of tracked keys exceeds the configured limit, Redis will start evicting keys and in turn force Relay to invalidate cached keys as well.',
                        'This may impact performance negatively.',
                        'It’s recommended to increase <code>tracking-table-max-keys</code> in the <code>redis.conf</code> configuration file, or ignore some groups from being cached in Relay’s in-memory cache.',
                    ])
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
                'status' => 'recommended',
                'test' => 'objectcache_redis_tracking_keys',
                'actions' => sprintf(
                    '<p><a href="%s" target="_blank">%s</a><p>',
                    'https://objectcache.pro/docs/configuration-options#relay',
                    'Learn more about ignoring groups.'
                ),
            ];
        }

        return [
            'label' => 'Redis is able to track all keys',
            'description' => sprintf(
                '<p>Redis server is tracking %s keys.</p>',
                number_format_i18n($keys)
            ),
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_redis_tracking_keys',
        ];
    }

    /**
     * Test whether Redis supports asynchronous commands,
     * preserving expiry dates and using Relay.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestRedisVersion(Diagnostics $diagnostics)
    {
        $phpredis = (string) phpversion('redis');
        $redis = (string) $diagnostics->redisVersion()->value;

        if ($diagnostics->clientIsRelay() && version_compare($redis, '6.2.7', '<')) {
            return [
                'label' => 'Relay requires 6.2.7 or newer',
                'description' => sprintf(
                    '<p>%s</p>',
                    implode(' ', [
                        "Object Cache Pro is using Relay, but the connected Redis Server ({$redis}) is too old and the object cache may go stale.",
                        'Upgrade Redis Server to version 6.2.7 or newer.',
                    ])
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_redis_version',
            ];
        }

        if ($this->config->async_flush && version_compare($redis, '4.0', '<')) {
            return [
                'label' => 'Redis does not support asynchronous commands',
                'description' => sprintf(
                    '<p>%s</p>',
                    implode(' ', [
                        'Object Cache Pro is configured to use asynchronous commands,',
                        "but the connected Redis Server ({$redis}) is too old and does not support them.",
                        'Upgrade Redis Server to version 4.0 or newer, or disable asynchronous flushing.',
                    ])
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_redis_version',
                'actions' => sprintf(
                    '<p><a href="%s" target="_blank">%s</a></p>',
                    'https://objectcache.pro/docs/configuration-options/#asynchronous-flushing',
                    'Learn more.'
                ),
            ];
        }

        if (version_compare($redis, '6.0', '<')) {
            return [
                'label' => 'Redis does not support preserving expiry dates',
                'description' => sprintf(
                    '<p>%s</p>',
                    implode(' ', [
                        'Object Cache Pro is unable to preserve the expiry of keys when de-/incrementing their value,',
                        "because the connected Redis Server ({$redis}) is too old and does not support it.",
                        'Upgrade Redis Server to version 6.0 or newer.',
                    ])
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_redis_version',
            ];
        }

        if ($diagnostics->clientIsPhpRedis() && version_compare($phpredis, '5.3', '<')) {
            return [
                'label' => 'PhpRedis does not support preserving expiry dates',
                'description' => sprintf(
                    '<p>%s</p>',
                    implode(' ', [
                        'Object Cache Pro is unable to preserve the expiry of keys when de-/incrementing their value,',
                        "because the installed PhpRedis extension ({$phpredis}) is too old and does not support it.",
                        'Upgrade PhpRedis to version 6.0 or newer.',
                    ])
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_redis_version',
                'actions' => sprintf(
                    '<p><a href="%s" target="_blank">%s</a></p>',
                    'https://objectcache.pro/docs/phpredis',
                    'Learn more.'
                ),
            ];
        }

        return [
            'label' => 'Redis version supported',
            'description' => '<p>The Redis Server version is supported.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_redis_version',
        ];
    }

    /**
     * Test whether PhpRedis is up-to-date.
     *
     * @return array<string, mixed>
     */
    protected function healthTestPhpRedisVersion()
    {
        $phpredis = (string) phpversion('redis');

        if (version_compare($phpredis, '5.3', '<')) {
            return [
                'label' => 'PhpRedis does not support preserving expiry dates',
                'description' => sprintf(
                    '<p>%s</p>',
                    implode(' ', [
                        'Object Cache Pro is unable to preserve the expiry of keys when de-/incrementing their value,',
                        "because the installed PhpRedis extension ({$phpredis}) is too old and does not support it.",
                        'Upgrade PhpRedis to version 5.3 or newer.',
                    ])
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_phpredis_version',
                'actions' => sprintf(
                    '<p><a href="%s" target="_blank">%s</a></p>',
                    'https://objectcache.pro/docs/phpredis',
                    'Learn more.'
                ),
            ];
        }

        return [
            'label' => 'PhpRedis version supported',
            'description' => '<p>The PhpRedis extension version is supported.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_phpredis_version',
        ];
    }

    /**
     * Test whether the configuration is optimized for Relay.
     *
     * @return array<string, mixed>
     */
    public function healthTestRelayConfig()
    {
        $results = [
            'label' => 'Configuration is not optimized for Relay',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
            'status' => 'recommended',
            'test' => 'objectcache_relay_config',
            'actions' => sprintf(
                '<p><a href="%s" target="_blank">%s</a><p>',
                'https://objectcache.pro/docs/relay/',
                'Learn more about using Relay.'
            ),
        ];

        $config = $this->config();
        $db = $config->database;

        if ($config->shared === null) {
            return $results + [
                'description' => sprintf(
                    '<p>%s</p>',
                    'When using Relay, it’s strongly recommended to set the <code>shared</code> configuration option to <code>true</code> or <code>false</code> indicate whether the Redis is used by multiple apps, or not.'
                ),
            ];
        }

        if ($config->shared && ! preg_match("/^db{$db}[:_-]?$/", $config->prefix ?? '')) {
            return $results + [
                'description' => sprintf(
                    '<p>%s</p>',
                    sprintf(
                        'When using Relay in shared Redis environments, it’s strongly recommended to include the database index in the <code>prefix</code> configuration option to avoid unnecessary flushing. Consider setting the prefix to: <code>%s</code>',
                        "db{$db}:"
                    )
                ),
            ];
        }

        if ($config->compression === Configuration::COMPRESSION_NONE) {
            return $results + [
                'description' => sprintf(
                    '<p>%s</p>',
                    'When using Relay, it’s strongly recommended to use any of the <code>compression</code> configuration options to reduce memory usage.'
                ),
            ];
        }

        if ($config->serializer === Configuration::SERIALIZER_PHP) {
            return $results + [
                'description' => sprintf(
                    '<p>%s</p>',
                    'When using Relay, it’s strongly recommended to use the <code>igbinary</code> as the <code>serializer</code> configuration options. This will greatly reduce memory usage.'
                ),
            ];
        }

        return array_merge($results, [
            'label' => 'Configuration is optimized for Relay',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'description' => sprintf(
                '<p>%s</p>',
                'The Object Cache Pro configuration is optimized for Relay.'
            ),
        ]);
    }

    /**
     * Test whether Relay is up-to-date.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestRelayVersion(Diagnostics $diagnostics)
    {
        $version = $diagnostics['versions']['relay'];

        if ($version->isError()) {
            return [
                'label' => 'Relay extension version is unsupported',
                'description' => "<p>The installed Relay extension version ({$version->value}) is not too old and not supported.</p>",
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_relay_version',
            ];
        }

        if ($version->isWarning()) {
            return [
                'label' => 'Relay extension version is outdated',
                'description' => "<p>The installed Relay extension version ({$version->value}) is outdated and should be upgraded.</p>",
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
                'status' => 'recommended',
                'test' => 'objectcache_relay_version',
            ];
        }

        return [
            'label' => 'Relay version supported',
            'description' => '<p>The version of the Relay extension is supported.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_relay_version',
        ];
    }

    /**
     * Test whether Relay has enough memory or not.
     *
     * @param  \RedisCachePro\Diagnostics\Diagnostics  $diagnostics
     * @return array<string, mixed>
     */
    protected function healthTestRelayMemory(Diagnostics $diagnostics)
    {
        if ($diagnostics->relayAtCapacity()) {
            $percentage = $diagnostics->relayMemoryThreshold();

            return [
                'label' => 'Relay is running at maximum capacity',
                'description' => sprintf(
                    '<p>%s</p>',
                    "Relay is running at maximum memory capacity ({$percentage}%) and no further WordPress data will be stored in memory. Consider allocating more memory to Relay by increasing <code>relay.maxmemory</code> in the <code>php.ini</code> to increase page load times."
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'orange'],
                'status' => 'recommended',
                'test' => 'objectcache_relay_memory',
                'actions' => sprintf(
                    '<p><a href="%s" target="_blank">%s</a><p>',
                    'https://objectcache.pro/docs/relay/',
                    'Learn more about using Relay.'
                ),
            ];
        }

        return [
            'label' => 'Relay has enough memory',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_relay_memory',
            'description' => sprintf(
                '<p>%s</p>',
                'Relay was allocated enough memory to allow Object Cache Pro to store all WordPress data.'
            ),
        ];
    }

    /**
     * Callback for `wp_ajax_health-check-objectcache-license` hook.
     *
     * @return void
     */
    public function healthTestLicense()
    {
        check_ajax_referer('health-check-site-status');

        add_filter('http_request_timeout', function () {
            return 15;
        });

        if (! $this->token()) {
            wp_send_json_success([
                'label' => 'No license token set',
                'description' => '<p>No Object Cache Pro license token was set and plugin updates are disabled.</p>',
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_license',
                'actions' => sprintf(
                    '<p><a href="%s" target="_blank">%s</a></p>',
                    'https://objectcache.pro/docs/configuration-options/#token',
                    'Learn more about setting the license token.'
                ),
            ]);
        }

        $storedLicense = License::load();

        if ($storedLicense instanceof License && $storedLicense->isValid()) {
            $license = $this->license();
        } else {
            $response = $this->fetchLicense();

            if (is_wp_error($response)) {
                $license = License::fromError($response);
            } else {
                $license = License::fromResponse($response);
            }
        }

        if ($license->isValid()) {
            wp_send_json_success([
                'label' => 'License token is set and license is valid',
                'description' => '<p>The Object Cache Pro license token is set and the license is valid.</p>',
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
                'status' => 'good',
                'test' => 'objectcache_license',
            ]);
        }

        if (! $license->state()) {
            wp_send_json_success([
                'label' => 'Unable to verify license token',
                'description' => sprintf(
                    '<p>The license token <code>••••••••%s</code> could not be verified.</p><p><code>%s</code></p>',
                    substr($license->token(), -4),
                    esc_html(implode(', ', $license->errorData()))
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_license',
            ]);
        }

        $this->disableDropin();

        if ($license->isInvalid()) {
            wp_send_json_success([
                'label' => 'Invalid license token',
                'description' => sprintf(
                    '<p>The license token <code>••••••••%s</code> appears to be invalid.</p>',
                    substr($license->token(), -4)
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_license',
            ]);
        }

        wp_send_json_success([
            'label' => "License is {$license->state()}",
            'description' => "<p>Your Object Cache Pro license is {$license->state()}.</p>",
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
            'status' => 'critical',
            'test' => 'objectcache_license',
            'actions' => implode('', [
                sprintf(
                    '<p><a href="%s" target="_blank">%s</a><p>',
                    'https://objectcache.pro/account',
                    'Manage your billing information'
                ),
                sprintf(
                    '<p><a href="%s" target="_blank">%s</a><p>',
                    'https://objectcache.pro/support',
                    'Contact customer service'
                ),
            ]),
        ]);
    }

    /**
     * Callback for `wp_ajax_health-check-objectcache-api` hook.
     *
     * @return void
     */
    public function healthTestApi()
    {
        check_ajax_referer('health-check-site-status');
        
        wp_send_json_success([
            'label' => 'Licensing API is reachable',
            'description' => '<p>The Object Cache Pro licensing API is reachable.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test'        => 'objectcache_api',
        ]);
    }
    
    /**
     * Callback for `wp_ajax_health-check-objectcache-filesystem` hook.
     *
     * @return void
     */
    public function healthTestFilesystem()
    {
        check_ajax_referer('health-check-site-status');

        $fs = $this->diagnostics()->filesystemAccess();

        $this->healthDebugInfo();

        if (is_wp_error($fs)) {
            wp_send_json_success([
                'label' => 'Unable to manage object cache drop-in',
                'description' => sprintf(
                    implode('', [
                        '<p>Object Cache Pro is unable to access the local filesystem and may not be able to manage the object cache drop-in.</p>',
                        '<p>The PHP process must be allowed to write to the <code>%1$s/object-cache.php</code> and <code>%1$s/object-cache.tmp</code> file.</p>',
                        '<p><code>%2$s</code></p>',
                    ]),
                    esc_html(str_replace(ABSPATH, '', WP_CONTENT_DIR)),
                    esc_html($fs->get_error_message())
                ),
                'badge' => ['label' => 'Object Cache Pro', 'color' => 'red'],
                'status' => 'critical',
                'test' => 'objectcache_filesystem',
            ]);
        }

        wp_send_json_success([
            'label' => 'Object cache drop-in can be managed',
            'description' => '<p>Object Cache Pro can access the local filesystem and is able manage the object cache drop-in.</p>',
            'badge' => ['label' => 'Object Cache Pro', 'color' => 'blue'],
            'status' => 'good',
            'test' => 'objectcache_filesystem',
        ]);
    }
}
