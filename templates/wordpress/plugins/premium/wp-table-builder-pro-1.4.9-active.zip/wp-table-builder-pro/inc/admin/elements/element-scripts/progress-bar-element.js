function controlsChange(inputs, element) {
    if (inputs && typeof inputs === "object") {
        if (inputs.hasOwnProperty("progressBarValue")) {
            changeValue(element, inputs.progressBarValue.eventValue);
        }
    }
}

function changeValue(element, value) {
    element
        .querySelector(".wptb-progress-bar-path")
        .style.setProperty("stroke-dashoffset", `${100 - value}px`);

    element.querySelector(".wptb-progress-bar-label").innerText = `${value}%`;
}

WPTB_Helper.controlsInclude(element, controlsChange, true);
