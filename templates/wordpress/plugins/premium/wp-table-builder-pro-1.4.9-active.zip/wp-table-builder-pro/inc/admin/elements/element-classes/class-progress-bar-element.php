<?php

namespace WP_Table_Builder_Pro\Inc\Admin\Elements\Element_Classes;

use WP_Table_Builder\Inc\Admin\Element_Classes\Base\Element_Base as Element_Base;
use WP_Table_Builder\Inc\Admin\Managers\Controls_Manager as Controls_Manager;
use WP_Table_Builder\Inc\Admin\Managers\Elements_Manager;
use WP_Table_Builder_Pro as WPTBNS;

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

class Progress_Bar_Element extends Element_Base {

    /**
     * Get element name.
     *
     * Retrieve button editor element name.
     *
     * @return string element name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'progress_bar';
    }

    /**
     * Get element button.
     *
     * Retrieve button editor element.
     *
     * @return string Element title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return esc_html_e('Progress Bar', 'wp-table-builder-pro');
    }

    /**
     * Get directory icon.
     *
     * Retrieve directory progress-bar editor element icon.
     *
     * @return string Directory Element icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_directory_icon() {
        return WPTBNS\WP_TABLE_BUILDER_PRO_DIR . 'inc/admin/elements/icons/progress-bar.svg';
    }

    /**
     * Get url icon.
     *
     * Return url progress-bar icon
     *
     * @return string Url Element icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_url_icon() {
        return wp_normalize_path(WPTBNS\WP_TABLE_BUILDER_PRO_URL . 'inc/admin/elements/icons/progress-bar.svg');
    }

    /**
     * Include file with js script for element progress-bar
     * @since 1.0.0
     * @access protected
     */
    public function element_script() {
        return wp_normalize_path(WPTBNS\WP_TABLE_BUILDER_PRO_DIR . 'inc/admin/elements/element-scripts/progress-bar-element.js');
    }

    /**
     * Register the element controls.
     *
     * Adds different fields to allow the user to change and customize the element settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls() {
        $this->add_control(
            'section_header',
            [
                'label'      => __('Progress Bar Options', 'wp-table-builder-pro'),
                'type'       => Controls_Manager::SECTION_HEADER,
                'buttonBack' => true
            ]
        );

        $this->add_control(
            'progressBarValue',
            [
                'label' => esc_html__('Value', 'wp-table-builder-pro'),
                'type' => Controls_Manager::RANGE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-progress-bar-label',
                        'type' => Controls_Manager::STYLE,
                        'key' => 'width',
                        'format' => '{$}%'
                    ],
                ],
                'min' => 0,
                'max' => 100,
                'defaultValue' => 35,
                'postFix' => '%'
            ]
        );

        $this->add_control(
            'barThickness',
            [
                'label' => esc_html__('Bar Thickness', 'wp-table-builder-pro'),
                'type' => Controls_Manager::RANGE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-progress-bar-trail',
                        'type' => Controls_Manager::STYLE,
                        'key' => 'stroke-width'
                    ],
                    [
                        'query' => '{{{data.container}}} .wptb-progress-bar-path',
                        'type' => Controls_Manager::STYLE,
                        'key' => 'stroke-width'
                    ]
                ],
                'min' => 1,
                'max' => 10,
                'defaultValue' => 5,
            ]
        );

        $this->add_control(
            'barColorPrimary',
            [
                'label' => esc_html__('Primary Color', 'wp-table-builder-pro'),
                'type' => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-progress-bar .wptb-progress-bar-path',
                        'type' => Controls_Manager::ATTRIBUTE,
                        'key' => 'stroke'
                    ]
                ],
                'defaultValue' => '#3C87B1'
            ]
        );

        $this->add_control(
            'barColorSecondary',
            [
                'label' => esc_html__('Secondary Color', 'wp-table-builder-pro'),
                'type' => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-progress-bar .wptb-progress-bar-trail',
                        'type' => Controls_Manager::ATTRIBUTE,
                        'key' => 'stroke'
                    ]
                ],
                'defaultValue' => '#CCCCCC'
            ]
        );

        $this->add_control(
            'labelColor',
            [
                'label' => esc_html__('Label Color', 'wp-table-builder-pro'),
                'type' => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-progress-bar-label',
                        'type' => Controls_Manager::STYLE,
                        'key' => 'color'
                    ]
                ],
                'defaultValue' => '#3C87B1'
            ]
        );
    }

    /**
     * Render progress bar element output in the editor.
     *
     * Written as a wp js template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _content_template() {
?>
        <div class="wptb-progress-bar-wrapper">
            <svg class="wptb-progress-bar" viewBox="0 0 100 10" preserveAspectRatio="none">
                <path class="wptb-progress-bar-trail" />
                <path class="wptb-progress-bar-path" />
            </svg>
            <div class="wptb-progress-bar-label">%</div>
        </div>
<?php
    }

    public function get_type() {
        return Elements_Manager::PRO;
    }
}
