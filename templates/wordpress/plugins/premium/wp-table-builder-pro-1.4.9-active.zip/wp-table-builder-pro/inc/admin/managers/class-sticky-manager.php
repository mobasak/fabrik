<?php

namespace WP_Table_Builder_Pro\Inc\Admin\Managers;

use WP_Table_Builder\Inc\Admin\Base\Element_Base_Object;
use WP_Table_Builder\Inc\Admin\Controls\Control_Section_Group_Collapse;
use WP_Table_Builder\Inc\Admin\Managers\Controls_Manager;
use WP_Table_Builder\Inc\Admin\Managers\Frontend_Data_Manager;
use WP_Table_Builder\Inc\Admin\Views\Builder\Table_Element\Table_Setting_Element;
use WP_Table_Builder\Inc\Common\Traits\Init_Once;
use WP_Table_Builder\Inc\Common\Traits\Singleton_Trait;
use function add_action;
use function esc_html__;

/**
 * Sticky manager for handling sticky column/row operations.
 */
class Sticky_Manager {
	use Singleton_Trait;
	use Init_Once;

	/**
	 * Function to be called during initialization process.
	 */
	public static function init_process() {
		$instance = static::get_instance();
		$instance->manager_controls();

		Frontend_Data_Manager::add_builder_translations( [ static::get_instance(), 'builder_frontend_data' ] );
	}

	/**
	 * Frontend data for builder menu.
	 * @return array data
	 */
	public function builder_frontend_data() {
		return [
			'stickyFirstColumnInfoMessage' => 'Sticky first column will only be available for desktop and disabled responsive breakpoints.'
		];
	}

	/**
	 * Register manager table controls.
	 *
	 * @return void
	 */
	public function manager_controls() {
		$sticky_controls = [
			'topRowSticky'      =>
				[
					'label'     => __( 'Make Top Row Sticky', 'wp-table-builder-pro' ),
					'type'      => Controls_Manager::TOGGLE,
					'selectors' => [
						'{{{data.container}}} tbody tr:nth-child(1)' => [ 'data-wptb-sticky-row', 'true', null ]
					],
				],
			'firstColumnSticky' => [
				'label'        => esc_html__( 'Make First Column Sticky', 'wp-table-builder-pro' ),
				'type'         => Controls_Manager::TOGGLE3,
				'selectors'    => [
					[
						'query' => '{{{data.container}}}',
						'type'  => Controls_Manager::DATASET,
						'key'   => 'wptbFirstColumnSticky'
					]
				],
				'defaultValue' => false
			]
		];

		Table_Setting_Element::add_settings_section( 'pro_table_settings_sticky', esc_html__( 'sticky', 'wp-table-builder-pro' ), $sticky_controls, 'thumbtack' );
	}
}
