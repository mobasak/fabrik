window.addEventListener("wptb:table:generated", () => {
    let tbody = document.querySelector(".wptb-table-setup tbody");

    const dataFontColor = "data-global-font-color";
    const dataLinkColor = "data-global-link-color";
    const dataFontSize = "data-global-font-size";

    var observer = new MutationObserver(function (mutations) {
        if (mutations.length > 1) return; // all attrs are mutated when controls are rendered, skip

        switch (mutations[0].attributeName) {
            case dataFontColor:
                const color = tbody.getAttribute(dataFontColor);
                applyGlobalFontColor(tbody, color);
                break;

            case dataLinkColor:
                const linkColor = tbody.getAttribute(dataLinkColor);
                applyGlobalLinkColor(tbody, linkColor);
                break;

            case dataFontSize:
                const fontSize = tbody.getAttribute(dataFontSize);
                applyGlobalFontSize(tbody, fontSize);
                break;
        }
    });

    observer.observe(tbody, {
        attributes: true,
        attributeFilter: [dataFontColor, dataLinkColor, dataFontSize],
    });
});

function applyGlobalFontColor(element, color) {
    element.querySelectorAll(".wptb-text-container").forEach((container) => {
        container.style.setProperty("color", color);
    });

    element
        .querySelectorAll(".wptb-list-item-content p")
        .forEach((container) => {
            container.style.setProperty("color", color);
        });

    element
        .querySelectorAll(".wptb-styled-list-item-content p")
        .forEach((element) => {
            element.style.setProperty("color", color);
        });

    element
        .querySelectorAll(
            ".wptb-element-text-icon-wrapper > div:nth-of-type(2)"
        )
        .forEach((element) => {
            element.style.setProperty("color", color);
        });
}

function applyGlobalLinkColor(element, linkColor) {
    element.querySelectorAll(".wptb-text-container a").forEach((element) => {
        element.style.setProperty("color", linkColor);
    });
}

function applyGlobalFontSize(element, fontSize) {
    element.querySelectorAll(".wptb-text-container").forEach((container) => {
        container.style.setProperty("font-size", fontSize);
    });

    element.querySelectorAll(".wptb-list-item-content p").forEach((element) => {
        element.style.setProperty("font-size", fontSize);
    });

    element
        .querySelectorAll(".wptb-styled-list-item-content p")
        .forEach((element) => {
            element.style.setProperty("font-size", fontSize);
        });

    element
        .querySelectorAll(".wptb-text_icon_element-container")
        .forEach((element) => {
            element.style.setProperty("font-size", fontSize);
        });
}
