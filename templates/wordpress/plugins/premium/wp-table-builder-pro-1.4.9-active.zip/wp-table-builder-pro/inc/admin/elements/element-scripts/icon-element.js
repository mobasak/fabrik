/* eslint-disable no-undef */
(function addBackwardsCompatibility() {
    const iconElementWrapper = element.querySelector(".wptb-icon-wrapper");

    (function fixSingleIcon() {
        if (element.querySelector("span") || element.querySelector("a")) return;

        if (iconElementWrapper) {
            console.log("fix single icon");
            const linkTargetElement = document.createElement("span");
            linkTargetElement.classList.add("wptb-icon-link-target-1");

            const currentHtmlContent = element.querySelector(".wptb-icon");
            currentHtmlContent.classList.add("wptb-icon-1");

            iconElementWrapper.removeChild(currentHtmlContent);
            iconElementWrapper.appendChild(linkTargetElement);
            linkTargetElement.appendChild(currentHtmlContent);

            createNewIcons();
        }
    })();

    (function fixSingleIconWithAnchor() {
        const anchor = element.querySelector("a");

        if (anchor) {
            const newElement = anchor.href
                ? document.createElement("a")
                : document.createElement("span");
            newElement.classList.add("wptb-icon-link-target-1");

            const oldIcon = element.querySelector(".wptb-icon");
            const oldIconName = oldIcon.dataset.wptbIconSrc;
            const oldStyles = oldIcon.getAttribute("style");

            iconElementWrapper.removeChild(element.querySelector("a"));
            iconElementWrapper.appendChild(newElement);

            WPTB_IconManager.getIcon(oldIconName, "wptb-icon").then((icon) => {
                icon.classList.add(`wptb-icon-1`);
                icon.setAttribute("style", oldStyles);
                newElement.appendChild(icon);
            });

            if (anchor.href) newElement.href = anchor.href;

            createNewIcons();
        }
    })();

    function createNewIcons() {
        for (let i = 2; i <= 5; i++) {
            const linkTargetElement = document.createElement("span");
            linkTargetElement.classList.add(`wptb-icon-link-target-${i}`);

            iconElementWrapper.appendChild(linkTargetElement);

            WPTB_IconManager.getIcon("star", "wptb-icon").then((icon) => {
                icon.classList.add(`wptb-icon-${i}`);
                icon.style.setProperty("display", "none");
                linkTargetElement.appendChild(icon);
            });
        }
    }
})();

element.querySelectorAll("a").forEach((anchor) => {
    anchor.addEventListener("click", (e) => e.preventDefault());
});

const dataIconNumber = "data-wptb-icon-number";

function updateControlsVisibility() {
    const elementNo = elementId.split("wptb-element-icon-")[1];

    const iconControlSelector = (i) =>
        `#wptb-el-icon-${elementNo}-buttonIcon${i}`;
    const colorControlSelector = (i) =>
        `#wptb-el-icon-${elementNo}-iconColor${i}`;
    const linkHeaderSelector = (i) =>
        `#wptb-el-icon-${elementNo}-iconLink${i}-header`;
    const linkControlsSelector = (i) =>
        `#wptb-el-icon-${elementNo}-iconLink${i}-controls`;

    const allControlsSelector = (i) =>
        `${iconControlSelector(i)},
        ${colorControlSelector(i)},
        ${linkHeaderSelector(i)},
        ${linkControlsSelector(i)}`;

    const numIcons = element.getAttribute(dataIconNumber) || 1;

    for (let i = 1; i <= numIcons; i++) {
        const elementsToShow = document.querySelectorAll(
            allControlsSelector(i)
        );

        elementsToShow.forEach((el) => {
            el.style.removeProperty("display");
        });
    }

    for (let i = Number(numIcons) + 1; i <= 5; i++) {
        const elementsToHide = document.querySelectorAll(
            allControlsSelector(i)
        );

        elementsToHide.forEach((el) => {
            el.style.setProperty("display", "none");
        });
    }
}

function updateIconVisibility() {
    const numIcons = element.getAttribute(dataIconNumber) || 1;

    for (let i = 1; i <= numIcons; i++) {
        const iconElement = element.querySelector(`.wptb-icon-${i}`);
        iconElement.style.removeProperty("display");
    }

    for (let i = Number(numIcons) + 1; i <= 5; i++) {
        const iconElement = element.querySelector(`.wptb-icon-${i}`);
        iconElement.style.setProperty("display", "none");
    }
}

const observer = new MutationObserver(function (mutations) {
    if (mutations[0].attributeName === dataIconNumber) {
        updateControlsVisibility();
        updateIconVisibility();
    }
});

observer.observe(element, {
    attributes: true,
    attributeFilter: [dataIconNumber],
});

document.addEventListener("element:controls:active", (eventEl) => {
    if (element === eventEl.target) {
        updateControlsVisibility();
        updateIconVisibility();
    }
});
