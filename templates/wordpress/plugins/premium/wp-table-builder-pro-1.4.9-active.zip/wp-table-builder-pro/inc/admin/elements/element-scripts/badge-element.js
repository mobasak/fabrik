/**
 * Badge element.
 *
 * @param elementWrapper
 * @constructor
 */
function BadgeElement(elementWrapper) {
    this.element = elementWrapper.querySelector('.wptb-badge');

    /**
     * Initiate text editor support for text icon element
     * @private
     */
    const tinyMCEStart = () => {
        tinyMCE.init({
            target: this.element,
            inline: true,
            plugins: "link",
            dialog_type: "modal",
            theme: "modern",
            menubar: false,
            force_br_newlines: false,
            force_p_newlines: false,
            forced_root_block: "",
            fixed_toolbar_container: "#wpcd_fixed_toolbar",
            toolbar: "bold italic strikethrough",
            extended_valid_elements: "svg[*]",
            verify_html: false,
            body_class: "test_class",
            setup(ed) {
                ed.on("keydown", function (e) {
                    const p = e.target.querySelector(".wptb-badge");

                    if(p){
                        let pText = p.innerHTML.replace(/\s+/g, " ").trim();
                        pText = pText.replace(/&nbsp;/g, "").trim();

                        // TODO [ErdemBircan] remove for production
                        console.log(pText) ;

                        if (!window.buttonElemPTextKeyDown) {
                            window.buttonElemPTextKeyDown = pText;
                        }
                    }

                });

                ed.on("keyup", function (e) {
                    const p = e.target.querySelector(".wptb-badge");

                    if (p) {
                        let pText = p.innerHTML.replace(/\s+/g, " ").trim();
                        pText = pText.replace(/&nbsp;/g, "").trim();
                        if (pText !== window.buttonElemPTextKeyDown) {
                            e.target.onblur = function () {
                                const wptbTableStateSaveManager =
                                    new WPTB_TableStateSaveManager();
                                wptbTableStateSaveManager.tableStateSet();

                                window.buttonElemPTextKeyDown = "";
                                e.target.onblur = "";
                            };
                        } else {
                            e.target.onblur = "";
                        }
                    }
                });
            },
            init_instance_callback(editor) {
                window.currentEditor = editor;
                editor.on("focus", function (e) {
                    const totalWidth =
                        document.getElementsByClassName("wptb-builder-panel")[0]
                            .offsetWidth;
                    if (
                        window.currentEditor &&
                        document.getElementById("wptb_builder").scrollTop >=
                            55 &&
                        window.currentEditor.bodyElement.style.display != "none"
                    ) {
                        document.getElementById(
                            "wpcd_fixed_toolbar"
                        ).style.position = "fixed";
                        document.getElementById(
                            "wpcd_fixed_toolbar"
                        ).style.right = `${
                            totalWidth / 2 -
                            document.getElementById("wpcd_fixed_toolbar")
                                .offsetWidth /
                                2
                        }px`;
                        document.getElementById(
                            "wpcd_fixed_toolbar"
                        ).style.top = "100px";
                    } else {
                        document.getElementById(
                            "wpcd_fixed_toolbar"
                        ).style.position = "static";
                        delete document.getElementById("wpcd_fixed_toolbar")
                            .style.right;
                        delete document.getElementById("wpcd_fixed_toolbar")
                            .style.top;
                    }
                });
            },
        });
        this.element.removeEventListener("mouseover", tinyMCEStart, false);
    };

    /**
     * Element startUp lifecycle hook.
     *
     * This hook will be called at the start of text icon element.
     */
    this.startUp = () => {
        // start tinyMCE for text part of element
        this.element.addEventListener("mouseover", tinyMCEStart, false);
    };
}

// instantiate and start up text icon element
const badgeElement = new BadgeElement(element);
badgeElement.startUp();
