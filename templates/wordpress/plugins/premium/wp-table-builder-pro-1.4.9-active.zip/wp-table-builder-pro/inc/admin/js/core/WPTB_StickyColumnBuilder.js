window.addEventListener('DOMContentLoaded', () => {
    const context = self || global;
    const {WPTB_ControlsManager} = context

    if (WPTB_ControlsManager) {
        // subscribe to control to give info to user
        WPTB_ControlsManager.subscribeToTableControl('firstColumnSticky', 'firstColumnSticky', (e) => {
            if (e) {
                const infoMessage = WPTB_Store.getTranslation('stickyFirstColumnInfoMessage');

                // give info to user about the workings of sticky column regarding compatibility with responsive builder
                WPTB_NotificationManager.sendNotification({
                    message: infoMessage,
                    type: WPTB_NotificationManager.notificationTypes.info
                });

                // auto enable horizontal scrolling
                WPTB_ControlsManager.updateTableControlValue('horizontalScrollEnable', true)
            }
        }, true);
    }
});
