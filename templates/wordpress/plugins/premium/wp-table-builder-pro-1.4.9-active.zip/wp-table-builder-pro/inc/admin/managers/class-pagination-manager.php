<?php

namespace WP_Table_Builder_Pro\Inc\Admin\Managers;

use WP_Table_Builder\Inc\Admin\Managers\Controls_Manager;
use WP_Table_Builder\Inc\Admin\Managers\Icon_Manager;
use WP_Table_Builder\Inc\Admin\Views\Builder\Table_Element\Table_Setting_Element;
use WP_Table_Builder\Inc\Common\Traits\Init_Once;
use WP_Table_Builder\Inc\Common\Traits\Singleton_Trait;
use WP_Table_Builder\Inc\Core\Init;
use function add_filter;
use function esc_html__;

/**
 * Pagination manager for handling multiple pages.
 */
class Pagination_Manager {
	use Singleton_Trait;
	use Init_Once;

	/**
	 * Function to be called during initialization process.
	 */
	public static function init_process() {
		$instance = static::get_instance();
		$instance->manager_controls();

		add_filter( 'wp-table-builder-pro/filter/frontend_data', [ $instance, 'add_client_data' ], 10, 1 );

	}

	/**
	 * Add client data for frontend scripts.
	 *
	 * @param array $client_data client data array
	 *
	 * @return array client data
	 */
	public function add_client_data( $client_data ) {
		/**
		 * Icon manager instance.
		 * @var Icon_Manager $icon_manager
		 */
		$icon_manager    = Init::instance()->get_icon_manager();
		$pagination_data = [
			'icons'        => [
				'nav_normal_forward' => $icon_manager->get_icon( 'angle-right' ),
				'nav_fast_forward'   => $icon_manager->get_icon( 'angle-double-right' ),
				'nav_normal_back'    => $icon_manager->get_icon( 'angle-left' ),
				'nav_fast_back'      => $icon_manager->get_icon( 'angle-double-left' ),
				'caret_down'         => $icon_manager->get_icon( 'caret-down' ),
			],
			'translations' => [
				'perPage' => esc_html__( 'Per Page', 'wp-table-builder-pro' )
			]
		];

		$client_data['pagination'] = $pagination_data;

		return $client_data;
	}

	/**
	 * Register manager table controls.
	 *
	 * @return void
	 */
	public function manager_controls() {
		$pagination_section_group_controls = [
			'paginationEnable' => [
				'label'     => __( 'Enable Pagination', 'wp-table-builder-pro' ),
				'type'      => Controls_Manager::TOGGLE,
				'selectors' => [
					'{{{data.container}}}' => [ 'data-wptb-pagination-enable', 'true', null ]
				],
			],
			'topRowAsHeader'   => [
				'label'                 => esc_html__( 'Keep top row as header', 'wp-table-builder-pro' ),
				'type'                  => Controls_Manager::TOGGLE3,
				'appearDependOnControl' => [ 'paginationEnable', [ 'checked' ], [ 'unchecked' ] ],
				'selectors'             => [
					[
						'query' => '{{{data.container}}}',
						'type'  => Controls_Manager::DATASET,
						'key'   => 'wptbProPaginationTopRowHeader'
					]
				],
				'defaultValue'          => true
			],
			'rowsPerPage'      =>
				[
					'label'                 => __( 'Rows per page', 'wp-table-builder-pro' ),
					'type'                  => Controls_Manager::RANGE,
					'selectors'             => [
						[
							'query' => '{{{data.container}}}',
							'type'  => Controls_Manager::DATASET,
							'key'   => 'wptbRowsPerPage',
						]
					],
					'appearDependOnControl' => [ 'paginationEnable', [ 'checked' ], [ 'unchecked' ] ],
					'min'                   => 3,
					'max'                   => 50,
					'defaultValue'          => 3,
				],
			'rowsChangeable'   => [
				'label'                 => __( 'Let visitors change <br />rows per page', 'wp-table-builder-pro' ),
				'type'                  => Controls_Manager::TOGGLE,
				'appearDependOnControl' => [ 'paginationEnable', [ 'checked' ], [ 'unchecked' ] ],
				'selectors'             => [
					'{{{data.container}}}' => [ 'data-wptb-rows-changeable', 'true', null ]
				],
			]
		];

		Table_Setting_Element::add_settings_section( 'table_settings_pagination', esc_html__( 'pagination', "wp-table-builder-pro" ), $pagination_section_group_controls, 'pager' );
	}
}
