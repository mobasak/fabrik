<?php

namespace WP_Table_Builder_Pro\Inc\Admin\Elements\Element_Classes;

use WP_Table_Builder\Inc\Admin\Element_Classes\Base\Element_Base as Element_Base;
use WP_Table_Builder\Inc\Admin\Managers\Controls_Manager as Controls_Manager;
use WP_Table_Builder\Inc\Admin\Managers\Elements_Manager;
use WP_Table_Builder_Pro as WPTBNS;
use WP_Table_Builder\Inc\Admin\Controls\Control_Section_Group_Collapse;

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

class Icon_Element extends Element_Base {
    public $default_icon = 'star';

    /**
     * Get element name.
     *
     * Retrieve button editor element name.
     *
     * @return string element name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name() {
        return 'icon';
    }

    /**
     * Get element button.
     *
     * Retrieve button editor element.
     *
     * @return string Element title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title() {
        return esc_html_e('Icon', 'wp-table-builder-pro');
    }

    /**
     * Get directory icon.
     *
     * Retrieve directory element's editor icon
     *
     * @return string Directory Element icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_directory_icon() {
        return WPTBNS\WP_TABLE_BUILDER_PRO_DIR . 'inc/admin/elements/icons/icon.svg';
    }

    /**
     * Get url icon.
     *
     * Return url element icon
     *
     * @return string Url Element icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_url_icon() {
        return wp_normalize_path(WPTBNS\WP_TABLE_BUILDER_PRO_URL . 'inc/admin/elements/icons/icon.svg');
    }

    /**
     * Include file with js script for element icon
     *
     * @since 1.0.0
     * @access protected
     */
    public function element_script() {
        return wp_normalize_path(WPTBNS\WP_TABLE_BUILDER_PRO_DIR . 'inc/admin/elements/element-scripts/icon-element.js');
    }

    /**
     * Register the element controls.
     *
     * Adds different fields to allow the user to change and customize the element settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function _register_controls() {
        $this->add_control(
            'section_header',
            [
                'label'      => __('Icon Options', 'wp-table-builder-pro'),
                'type'       => Controls_Manager::SECTION_HEADER,
                'buttonBack' => true
            ]
        );

        $this->add_control(
            'numberOfIcons',
            [
                'label' => __('Number of icons', 'wp-table-builder-pro'),
                'type'      => Controls_Manager::NUMBER,
                'selectors' => [
                    '{{{data.container}}}' => 'data-wptb-icon-number'
                ],
                'min' => 1,
                'max' => 5,
                'defaultValue' => 1
            ]
        );

        $this->add_control(
            'buttonIcon1',
            [
                'label'        => __('Icon 1', 'wp-table-builder-pro'),
                'type'         => Controls_Manager::ICON_SELECT,
                'icons'        => $this->read_icons('svg'),
                'perPage'      => 20,
                'selectors'    => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-1',
                        'type'  => Controls_Manager::DATASET,
                        'key'   => 'wptbIconSrc'
                    ]
                ],
                'defaultValue' => $this->default_icon
            ]
        );

        $this->add_control(
            'iconColor1',
            [
                'label'     => __('Icon Color 1', 'wp-table-builder-pro'),
                'type'      => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-1',
                        'type'  => Controls_Manager::STYLE,
                        'key'   => 'fill',
                    ]
                ]
            ]
        );

        $this->add_control(
            'iconLink1',
            [
                'label'    => __('Icon Link 1', 'wp-table-builder-pro'),
                'type'     => Controls_Manager::URL,
                'selector' => '{{{data.container}}} .wptb-icon-wrapper .wptb-icon-link-target-1'
            ]
        );

        $this->add_control(
            'buttonIcon2',
            [
                'label'        => __('Icon 2', 'wp-table-builder-pro'),
                'type'         => Controls_Manager::ICON_SELECT,
                'icons'        => $this->read_icons('svg'),
                'perPage'      => 20,
                'selectors'    => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-2',
                        'type'  => Controls_Manager::DATASET,
                        'key'   => 'wptbIconSrc'
                    ]
                ],
                'defaultValue' => $this->default_icon,
            ]
        );

        $this->add_control(
            'iconColor2',
            [
                'label'     => __('Icon 2 Color', 'wp-table-builder-pro'),
                'type'      => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-2',
                        'type'  => Controls_Manager::STYLE,
                        'key'   => 'fill',
                    ]
                ]
            ]
        );

        $this->add_control(
            'iconLink2',
            [
                'label'    => __('Icon Link 2', 'wp-table-builder-pro'),
                'type'     => Controls_Manager::URL,
                'selector' => '{{{data.container}}} .wptb-icon-wrapper .wptb-icon-link-target-2'
            ]
        );

        $this->add_control(
            'buttonIcon3',
            [
                'label'        => __('Icon 3', 'wp-table-builder-pro'),
                'type'         => Controls_Manager::ICON_SELECT,
                'icons'        => $this->read_icons('svg'),
                'perPage'      => 20,
                'selectors'    => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-3',
                        'type'  => Controls_Manager::DATASET,
                        'key'   => 'wptbIconSrc'
                    ]
                ],
                'defaultValue' => $this->default_icon
            ]
        );

        $this->add_control(
            'iconColor3',
            [
                'label'     => __('Icon 3 Color', 'wp-table-builder-pro'),
                'type'      => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-3',
                        'type'  => Controls_Manager::STYLE,
                        'key'   => 'fill',
                    ]
                ]
            ]
        );

        $this->add_control(
            'iconLink3',
            [
                'label'    => __('Icon Link 3', 'wp-table-builder-pro'),
                'type'     => Controls_Manager::URL,
                'selector' => '{{{data.container}}} .wptb-icon-wrapper .wptb-icon-link-target-3'
            ]
        );

        $this->add_control(
            'buttonIcon4',
            [
                'label'        => __('Icon 4', 'wp-table-builder-pro'),
                'type'         => Controls_Manager::ICON_SELECT,
                'icons'        => $this->read_icons('svg'),
                'perPage'      => 20,
                'selectors'    => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-4',
                        'type'  => Controls_Manager::DATASET,
                        'key'   => 'wptbIconSrc'
                    ]
                ],
                'defaultValue' => $this->default_icon
            ]
        );

        $this->add_control(
            'iconColor4',
            [
                'label'     => __('Icon 4 Color', 'wp-table-builder-pro'),
                'type'      => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-4',
                        'type'  => Controls_Manager::STYLE,
                        'key'   => 'fill',
                    ]
                ]
            ]
        );

        $this->add_control(
            'iconLink4',
            [
                'label'    => __('Icon Link 4', 'wp-table-builder-pro'),
                'type'     => Controls_Manager::URL,
                'selector' => '{{{data.container}}} .wptb-icon-wrapper .wptb-icon-link-target-4'
            ]
        );

        $this->add_control(
            'buttonIcon5',
            [
                'label'        => __('Icon 5', 'wp-table-builder-pro'),
                'type'         => Controls_Manager::ICON_SELECT,
                'icons'        => $this->read_icons('svg'),
                'perPage'      => 20,
                'selectors'    => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-5',
                        'type'  => Controls_Manager::DATASET,
                        'key'   => 'wptbIconSrc'
                    ]
                ],
                'defaultValue' => $this->default_icon
            ]
        );

        $this->add_control(
            'iconColor5',
            [
                'label'     => __('Icon 5 Color', 'wp-table-builder-pro'),
                'type'      => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-5',
                        'type'  => Controls_Manager::STYLE,
                        'key'   => 'fill',
                    ]
                ]
            ]
        );

        $this->add_control(
            'iconLink5',
            [
                'label'    => __('Icon Link 5', 'wp-table-builder-pro'),
                'type'     => Controls_Manager::URL,
                'selector' => '{{{data.container}}} .wptb-icon-wrapper .wptb-icon-link-target-5'
            ]
        );

        $this->add_control(
            'iconSize',
            [
                'label'        => __('Size', 'wp-table-builder-pro'),
                'type'         => Controls_Manager::RANGE,
                'selectors'    => [
                    [
                        'query'  => '{{{data.container}}} .wptb-icon',
                        'type'   => Controls_Manager::STYLE,
                        'key'    => ['width', 'height'],
                        'format' => '{$}px'
                    ]
                ],
                'min'          => 10,
                'max'          => 200,
                'defaultValue' => 25,
                'postFix'      => 'px'
            ]
        );

        $this->add_control(
            'iconAlignmentCheckbox',
            [
                'label'        => __('Icon Alignment', 'wp-table-builder-pro'),
                'type'         => Controls_Manager::ALIGNMENT2,
                'selectors'    => [
                    [
                        'query' => '{{{data.container}}} .wptb-icon-wrapper',
                        'type'  => Controls_Manager::STYLE,
                        'key'   => 'textAlign',
                    ]
                ],
                'defaultValue' => 'center'
            ]
        );
    }

    /**
     * Render text editor element output in the editor.
     *
     * Written as a wp js template and used to generate the live preview.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function _content_template() {
?>
        <div class="wptb-icon-wrapper" style="text-align: center;">
            <span class="wptb-icon-link-target-1">
                <div class="wptb-icon wptb-icon-1" style="width: 25px; height: 25px;">
                    <?php $this->get_icon($this->default_icon, true); ?>
                </div>
            </span>
            <span class="wptb-icon-link-target-2">
                <div class="wptb-icon wptb-icon-2" style="width: 25px; height: 25px;">
                    <?php $this->get_icon($this->default_icon, true); ?>
                </div>
            </span>
            <span class="wptb-icon-link-target-3">
                <div class="wptb-icon wptb-icon-3" style="width: 25px; height: 25px;">
                    <?php $this->get_icon($this->default_icon, true); ?>
                </div>
            </span>
            <span class="wptb-icon-link-target-4">
                <div class="wptb-icon wptb-icon-4" style="width: 25px; height: 25px;">
                    <?php $this->get_icon($this->default_icon, true); ?>
                </div>
            </span>
            <span class="wptb-icon-link-target-5">
                <div class="wptb-icon wptb-icon-5" style="width: 25px; height: 25px;">
                    <?php $this->get_icon($this->default_icon, true); ?>
                </div>
            </span>
        </div>
<?php
    }

    public function get_type() {
        return Elements_Manager::PRO;
    }
}
