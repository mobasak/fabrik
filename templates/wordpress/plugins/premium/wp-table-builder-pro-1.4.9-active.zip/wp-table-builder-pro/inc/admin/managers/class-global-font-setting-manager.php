<?php

namespace WP_Table_Builder_Pro\Inc\Admin\Managers;

use WP_Table_Builder\Inc\Admin\Views\Builder\Table_Element\Table_Setting_Element;
use WP_Table_Builder\Inc\Admin\Managers\Controls_Manager;
use WP_Table_Builder\Inc\Common\Traits\Init_Once;
use WP_Table_Builder\Inc\Common\Traits\Singleton_Trait;
use function esc_html__;

/**
 * Pagination manager for handling mutiple pages
 */
class Global_Font_Setting_Manager {
    use Singleton_Trait;
    use Init_Once;

    /**
     * Function to be called during initialization process.
     */
    public static function init_process() {
        $instance = static::get_instance();
        $instance->manager_controls();
    }

    /**
     * Register manager table controls.
     *
     * @param Element_Base_Object $context element base object
     *
     * @return void
     */
    public function manager_controls() {
        $global_fonts_section_group_controls = [
            'fontColor' => [
                'label' => __('Font Color', 'wp-table-builder-pro'),
                'type' => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} tbody',
                        'type'  => Controls_Manager::DATASET,
                        'key'   => 'globalFontColor',
                    ],
                ]
            ],
            'linkColor' => [
                'label' => __('Link Color', 'wp-table-builder-pro'),
                'type' => Controls_Manager::COLOR_PALETTE,
                'selectors' => [
                    [
                        'query' => '{{{data.container}}} tbody',
                        'type'  => Controls_Manager::DATASET,
                        'key'   => 'globalLinkColor',
                    ]
                ]
            ],
            'fontSize' => [
                'label' => __('Font Size', 'wp-table-builder-pro'),
                'type' => Controls_Manager::RANGE,
                'selectors'    => [
                    [
                        'query'  => '{{{data.container}}} tbody',
                        'type'   => Controls_Manager::DATASET,
                        'key'    => 'globalFontSize',
                        'format' => '{$}px'
                    ]
                ],
                'min'          => 10,
                'max'          => 50,
                'defaultValue' => 15,
                'postFix'      => 'px'
            ],
        ];

        Table_Setting_Element::add_settings_section('table_settings_global_fonts', esc_html__('Global Font Style', "wp-table-builder-pro"), $global_fonts_section_group_controls, 'font', 2);
    }
}
