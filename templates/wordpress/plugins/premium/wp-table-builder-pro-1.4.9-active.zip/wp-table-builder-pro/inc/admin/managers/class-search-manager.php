<?php

namespace WP_Table_Builder_Pro\Inc\Admin\Managers;

use WP_Table_Builder\Inc\Admin\Managers\Controls_Manager;
use WP_Table_Builder\Inc\Admin\Views\Builder\Table_Element\Table_Setting_Element;
use WP_Table_Builder\Inc\Common\Traits\Init_Once;
use WP_Table_Builder\Inc\Common\Traits\Singleton_Trait;
use function esc_html__;

/**
 * Search manager for handling multiple pages
 */
class Search_Manager {
	use Singleton_Trait;
	use Init_Once;

	/**
	 * Function to be called during initialization process.
	 */
	public static function init_process() {
		$instance = static::get_instance();
		$instance->manager_controls();
	}

	/**
	 * Register manager table controls.
	 *
	 * @return void
	 */
	public function manager_controls() {
		$search_section_group_controls = [
			'searchEnable'         => [
				'label'     => __( 'Enable Search', 'wp-table-builder-pro' ),
				'type'      => Controls_Manager::TOGGLE,
				'selectors' => [
					'{{{data.container}}}' => [ 'data-wptb-search-enable', 'true', null ]
				],
			],
			'searchTopRowAsHeader' => [
				'label'                 => esc_html__( 'Keep top row as header', 'wp-table-builder-pro' ),
				'type'                  => Controls_Manager::TOGGLE3,
				'appearDependOnControl' => [ 'searchEnable', [ 'checked' ], [ 'unchecked' ] ],
				'selectors'             => [
					[
						'query' => '{{{data.container}}}',
						'type'  => Controls_Manager::DATASET,
						'key'   => 'wptbProSearchTopRowHeader'
					]
				],
				'defaultValue'          => true
			],
			'searchbarPosition'    => [
				'label'                 => esc_html__( 'Search Bar Position', 'wp-table-builder-pro' ),
				'type'                  => Controls_Manager::SELECT2,
				'options'               => [
					'left'  => 'left',
					'right' => 'right',
				],
				'defaultValue'          => 'left',
				'appearDependOnControl' => [ 'searchEnable', [ 'checked' ], [ 'unchecked' ] ],
				'selectors'             => [
					[
						'query' => '{{{data.container}}}',
						'type'  => Controls_Manager::ATTRIBUTE,
						'key'   => 'data-wptb-searchbar-position'
					]
				]
			]
		];

		Table_Setting_Element::add_settings_section( 'table_settings_search', esc_html__( 'search', "wp-table-builder-pro" ), $search_section_group_controls, 'search' );
	}
}
