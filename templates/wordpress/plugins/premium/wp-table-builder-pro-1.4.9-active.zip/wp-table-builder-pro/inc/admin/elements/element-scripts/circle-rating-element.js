const infArr = element.className.match(/wptb-element-((.+-)\d+)/i);
const elementControlUnicClassRatingSize = `wptb-el-${infArr[1]}-circleRatingSize`;

function updateCircleRating(percentage, displayValue) {
    let ratingCircleSlice = element.querySelector(".wptb-rating-circle-slice");
    let ratingCircleBar = element.querySelector(".wptb-rating-circle-bar");
    let ratingCircleFill = element.querySelector(".wptb-rating-circle-fill");
    let numberRatingElem = element.querySelector(
        ".wptb-rating-circle-wrapper span"
    );
    if (
        ratingCircleSlice &&
        ratingCircleBar &&
        ratingCircleFill &&
        numberRatingElem
    ) {
        if (percentage > 50) {
            ratingCircleSlice.style.clip = "rect(auto, auto, auto, auto)";
            ratingCircleBar.style.transform = "rotate(180deg)";
        } else {
            ratingCircleSlice.style.clip = "rect(0em, 1em, 1em, 0.5em)";
            ratingCircleBar.style.transform = "rotate(0deg)";
        }

        numberRatingElem.innerHTML = displayValue;

        let degrees = percentage * 3.6;
        ratingCircleFill.style.transform = "rotate(" + degrees + "deg)";
    }
}

function controlsChange(inputs, element) {
    if (inputs && typeof inputs === "object") {
        if (inputs.hasOwnProperty("circleRatingSize")) {
            if (inputs.circleRatingSize.eventValue > element.offsetWidth) {
                let ratingCircleWrapper = element.querySelector(
                    ".wptb-rating-circle-wrapper"
                );
                ratingCircleWrapper.style.fontSize = element.offsetWidth + "px";
                let elementsControlRatingSize = document.querySelectorAll(
                    "." + elementControlUnicClassRatingSize
                );
                elementsControlRatingSize = [...elementsControlRatingSize];
                elementsControlRatingSize.map((input) => {
                    input.value = element.offsetWidth;
                });
            }
        }

        const ratingType =
            element.getAttribute("data-wptb-rating-type") ?? "percent";

        if (inputs.hasOwnProperty("circlePercentage")) {
            if (ratingType === "percent")
                updateCircleRating(
                    inputs.circlePercentage.eventValue,
                    inputs.circlePercentage.eventValue + "%"
                );
        }
        if (inputs.hasOwnProperty("ratingNumber")) {
            if (ratingType === "number") {
                const ratingNumber = inputs.ratingNumber.eventValue ?? 3.5;
                const totalNumber =
                    element.getAttribute("data-wptb-total-number") ?? 10;
                const percent = (ratingNumber / totalNumber) * 100;

                percent > 100
                    ? updateCircleRating(100, totalNumber)
                    : updateCircleRating(percent, ratingNumber);
            }
        }
        if (inputs.hasOwnProperty("totalNumber")) {
            if (ratingType === "number") {
                const ratingNumber =
                    element.getAttribute("data-wptb-rating-number") ?? 3.5;
                const totalNumber = inputs.totalNumber.eventValue ?? 10;
                const percent = (ratingNumber / totalNumber) * 100;

                percent > 100
                    ? updateCircleRating(100, totalNumber)
                    : updateCircleRating(percent, ratingNumber);
            }
        }
        if (inputs.hasOwnProperty("ratingType")) {
            if (inputs.ratingType.eventValue === "percent") {
                const percent =
                    element.getAttribute("data-percentage-count") ?? 35;

                updateCircleRating(percent, percent + "%");
            }
            if (inputs.ratingType.eventValue === "number") {
                const ratingNumber =
                    element.getAttribute("data-wptb-rating-number") ?? 3.5;
                const totalNumber =
                    element.getAttribute("data-wptb-total-number") ?? 10;
                const percent = (ratingNumber / totalNumber) * 100;

                percent > 100
                    ? updateCircleRating(100, totalNumber)
                    : updateCircleRating(percent, ratingNumber);
            }
        }
    }
}

WPTB_Helper.controlsInclude(element, controlsChange, true);
