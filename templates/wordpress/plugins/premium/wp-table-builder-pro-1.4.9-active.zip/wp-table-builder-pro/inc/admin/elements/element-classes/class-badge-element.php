<?php

namespace WP_Table_Builder_Pro\Inc\Admin\Elements\Element_Classes;

use WP_Table_Builder\Inc\Admin\Element_Classes\Base\Element_Base as Element_Base;
use WP_Table_Builder\Inc\Admin\Managers\Controls_Manager as Controls_Manager;
use WP_Table_Builder\Inc\Admin\Managers\Elements_Manager;
use WP_Table_Builder_Pro as WPTBNS;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Badge_Element extends Element_Base {

	/**
	 * Get element name.
	 *
	 * Retrieve button editor element name.
	 *
	 * @return string element name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'badge';
	}

	/**
	 * Get element button.
	 *
	 * Retrieve button editor element.
	 *
	 * @return string Element title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return esc_html_e( 'Badge', 'wp-table-builder-pro' );
	}

	/**
	 * Get directory icon.
	 *
	 * Retrieve directory badge editor element icon.
	 *
	 * @return string Directory Element icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_directory_icon() {
		return WPTBNS\WP_TABLE_BUILDER_PRO_DIR . 'inc/admin/elements/icons/badge.svg';
	}

	/**
	 * Get url icon.
	 *
	 * Return url badge icon
	 *
	 * @return string Url Element icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_url_icon() {
		return wp_normalize_path( WPTBNS\WP_TABLE_BUILDER_PRO_URL . 'inc/admin/elements/icons/badge.svg' );
	}

	/**
	 * Include file with js script for element badge
	 * @since 1.0.0
	 * @access protected
	 */
	public function element_script() {
		return wp_normalize_path( WPTBNS\WP_TABLE_BUILDER_PRO_DIR . 'inc/admin/elements/element-scripts/badge-element.js' );
	}

	/**
	 * Register the element controls.
	 *
	 * Adds different fields to allow the user to change and customize the element settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function _register_controls() {
		$this->add_control(
			'sectionHeader',
			[
				'label'      => __( 'Badge Options', 'wp-table-builder-pro' ),
				'type'       => Controls_Manager::SECTION_HEADER,
				'buttonBack' => true
			]
		);

		$this->add_control(
			'fontSize',
			[
				'label'        => esc_html__( 'Font Size', 'wp-table-builder-pro' ),
				'type'         => Controls_Manager::RANGE,
				'selectors'    => [
					[
						'query'  => '{{{data.container}}} .wptb-badge-wrapper',
						'type'   => Controls_Manager::STYLE,
						'key'    => 'fontSize',
						'format' => '{$}px'
					],
				],
				'min'          => 10,
				'max'          => 50,
				'defaultValue' => 15,
				'postFix'      => 'px'
			]
		);

		$this->add_control(
			'fontColor',
			[
				'label'        => esc_html__( 'Font Color', 'wp-table-builder-pro' ),
				'type'         => Controls_Manager::COLOR_PALETTE,
				'selectors'    => [
					[
						'query' => '{{{data.container}}} .wptb-badge-wrapper',
						'type'  => Controls_Manager::STYLE,
						'key'   => 'color'
					]
				],
				'defaultValue' => '#19aa59'
			]
		);

		$this->add_control(
			'bgColor',
			[
				'label'        => esc_html__( 'Secondary Color', 'wp-table-builder-pro' ),
				'type'         => Controls_Manager::COLOR_PALETTE,
				'selectors'    => [
					[
						'query' => '{{{data.container}}} .wptb-badge-wrapper',
						'type'  => Controls_Manager::STYLE,
						'key'   => 'backgroundColor'
					]
				],
				'defaultValue' => '#e5f5e9'
			]
		);

		$this->add_control(
			'badgeAlignment',
			[
				'label'        => __( 'Alignment', 'wp-table-builder-pro' ),
				'type'         => Controls_Manager::ALIGNMENT2,
				'selectors'    => [
					[
						'query' => '{{{data.container}}}',
						'type'  => Controls_Manager::STYLE,
						'key'   => 'justifyContent',
					],
				],
				'keyMaps'      => [
					'left'   => 'flex-start',
					'center' => 'center',
					'right'  => 'flex-end',
				],
				'defaultValue' => 'flex-start'
			]
		);
	}

	/**
	 * Render badge element output in the editor.
	 *
	 * Written as a wp js template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _content_template() {
		?>
        <div class="wptb-badge-wrapper">
            <p class="wptb-badge">
				<?php esc_html_e( 'Enter text...', 'wp-table-builder-pro' ); ?>
            </p>
        </div>
		<?php
	}

	public function get_type() {
		return Elements_Manager::PRO;
	}
}
