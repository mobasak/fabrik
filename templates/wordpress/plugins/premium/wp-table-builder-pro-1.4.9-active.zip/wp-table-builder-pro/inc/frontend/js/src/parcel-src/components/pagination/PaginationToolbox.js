import React, { useState } from 'react';

/**
 * Pagination toolbox component.
 *
 * @param {Object} props component properties
 * @param {boolean} [props.startupCollapsedStatus=true] component startup collapsed status
 * @param {string} props.toggleIcon toggle icon
 * @param {Array<JSX.Element> | JSX.Element} props.children component children
 * @class
 */
function PaginationToolbox({ startupCollapsedStatus = true, toggleIcon, children }) {
	const [collapsedStatus, setCollapsedStatus] = useState(startupCollapsedStatus);

	/**
	 * Toggle collapsed status.
	 */
	const toggleCollapsedStatus = () => {
		setCollapsedStatus(!collapsedStatus);
	};

	return (
		<div className={'pagination-toolbox'}>
			<div data-collapsed={collapsedStatus} className={'toolbox-controls-wrapper'}>
				{children}
			</div>
			{/* eslint-disable-next-line jsx-a11y/click-events-have-key-events,jsx-a11y/interactive-supports-focus */}
			<div
				role={'button'}
				data-collapsed={collapsedStatus}
				className={'toolbox-toggle-button'}
				dangerouslySetInnerHTML={{ __html: toggleIcon }}
				onClick={toggleCollapsedStatus}
			></div>
		</div>
	);
}

/**
 * @module PaginationToolbox
 */
export default PaginationToolbox;
