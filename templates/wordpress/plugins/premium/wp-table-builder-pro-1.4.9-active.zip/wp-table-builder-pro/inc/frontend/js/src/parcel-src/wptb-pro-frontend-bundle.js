import PaginationManager from './containers/PaginationManager';

// startup pagination manager
PaginationManager.init();
