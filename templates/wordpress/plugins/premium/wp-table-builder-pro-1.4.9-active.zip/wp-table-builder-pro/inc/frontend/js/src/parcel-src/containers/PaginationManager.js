import PaginationBase from './PaginationBase';

/**
 * Manager to handle pagination operations on all available tables on current page.
 *
 * @class
 */
function PaginationManager() {
	/**
	 * Find pagination enabled table wrappers on current active page.
	 *
	 * @return {Array<HTMLElement>} pagination enabled table containers
	 */
	const gatherPaginationEnabledTables = () => {
		return Array.from(document.querySelectorAll('.wptb-table-container-matrix')).filter((tWrap) => {
			const targetTable = tWrap.querySelector('table.wptb-preview-table');

			return targetTable && targetTable.dataset.wptbPaginationEnable === 'true';
		});
	};

	/**
	 * Assign pagination functionality to target table container.
	 *
	 * @param {HTMLElement} targetTableContainer table container
	 */
	const assignPaginationToTable = (targetTableContainer) => {
		document.addEventListener('DOMContentLoaded', () => {
			// eslint-disable-next-line no-undef
			const { icons, translations } = WptbProClientData.pagination;
			const paginationBase = new PaginationBase(targetTableContainer, icons, translations);
			paginationBase.mount();
		});
	};

	/**
	 * Initialize manager.
	 */
	this.init = () => {
		const targetTables = gatherPaginationEnabledTables();

		targetTables.map(assignPaginationToTable);
	};
}

/**
 * @module PaginationManager
 */
export default new PaginationManager();
