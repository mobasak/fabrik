// eslint-disable-next-line no-unused-vars
import React from 'react';
import { createRoot } from 'react-dom/client';
import Pagination from '../components/pagination/Pagination';

/**
 * Base of operations for pagination and related components.
 *
 * @param {HTMLElement} targetContainer target table container
 * @param {Object} icons pagination related icons
 * @param {Object} translations pagination related translations
 * @class
 */
function PaginationBase(targetContainer, icons, translations) {
	/**
	 * Table id
	 *
	 * @type {number | null}
	 */
	this.tableId = null;

	/**
	 * Get table id.
	 *
	 * @throws {Error} invalid table id
	 * @return {number} table id.
	 */
	const extractIdFromContainer = () => {
		const fullId = targetContainer.getAttribute('id');
		const regExp = new RegExp(/^wptb-table-id-(\d+)$/);
		try {
			// eslint-disable-next-line no-unused-vars,@wordpress/no-unused-vars-before-return
			const [_, rawId] = regExp.exec(fullId);

			return Number.parseInt(rawId, 10);
		} catch (e) {
			throw new Error("wptb-pro: target table don't have a valid id");
		}
	};

	/**
	 * Base startup operations.
	 */
	const baseStartup = () => {
		this.tableId = extractIdFromContainer();
	};

	/**
	 * Mount pagination component to table.
	 */
	this.mount = () => {
		const mountId = `wptb-pro-pagination-${this.tableId}`;
		const mountPointElement = document.createElement('div');
		mountPointElement.setAttribute('id', mountId);

		targetContainer.appendChild(mountPointElement);
		const pluginTable = targetContainer.querySelector('table.wptb-preview-table');

		// extra options for pagination component
		const extraOptions = {
			rowsPerPage: Number.parseInt(pluginTable.dataset.wptbRowsPerPage, 10),
			topRowHeader: pluginTable.dataset.wptbProPaginationTopRowHeader === 'true',
			icons,
			translations,
			toolboxEnabled: pluginTable.dataset.wptbRowsChangeable === 'true',
		};

		const root = createRoot(mountPointElement);
		root.render(
			<React.StrictMode>
				<Pagination targetTable={pluginTable} {...extraOptions} />
			</React.StrictMode>
		);
	};

	// start the base up
	baseStartup();
}

/**
 * @module PaginationBase
 */
export default PaginationBase;
