import React from 'react';

/**
 * Pagination navigation button component.
 *
 * @param {Object} props component properties
 * @param {boolean} [props.active=false] button active status
 * @param {string | number} props.targetPage target page assigned to this button
 * @param {Function} props.onClick click callback
 * @param {boolean} [props.disabled=false] button disabled status
 * @param {Array<JSX.Element> | JSX.Element} props.children component children
 * @class
 */
function PaginationNavButton({ targetPage, active = false, onClick, disabled = false, children }) {
	return (
		// eslint-disable-next-line jsx-a11y/click-events-have-key-events,jsx-a11y/interactive-supports-focus
		<div
			role={'button'}
			className={'pagination-nav-button'}
			data-active={active}
			data-disabled={disabled}
			onClick={() => onClick(targetPage)}
		>
			{children}
		</div>
	);
}

/**
 * @module PaginationNavButton
 */
export default PaginationNavButton;
