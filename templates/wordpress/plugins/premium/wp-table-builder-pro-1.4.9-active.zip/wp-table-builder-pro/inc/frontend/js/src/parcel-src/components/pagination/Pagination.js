// eslint-disable-next-line no-unused-vars
import React, { Fragment, useEffect, useState } from 'react';
import PaginationNavButton from './PaginationNavButton';
import PaginationToolbox from './PaginationToolbox';

/**
 * Pagination component.
 *
 * @param {Object} props component properties
 * @param {HTMLTableElement} props.targetTable target table
 * @param {number} props.rowsPerPage rows per page
 * @param {boolean} props.topRowHeader whether to use top row as header on pagination operations
 * @param {number} [props.visibleDirectPages=3]  maximum number of direct navigation buttons (direct navigation is when assigned element navigate directly to their assigned page)
 * @param {Object} props.icons icons object
 * @param {boolean} [props.toolboxEnabled=false] toolbox enabled status
 * @param {Object} props.translations pagination translations
 * @class
 */
function Pagination({
	targetTable,
	rowsPerPage,
	topRowHeader,
	visibleDirectPages = 3,
	icons,
	toolboxEnabled = false,
	translations,
}) {
	const [currentPage, setCurrentPage] = useState(1);
	const [totalPages, setTotalPages] = useState(1);
	const [dataPerPage, setDataPerPage] = useState(rowsPerPage);
	const [tableRows, setTableRows] = useState([]);
	const [cachedTableObject, setCachedTableObject] = useState(null);

	/**
	 * Hide table element.
	 *
	 * @param {HTMLTableElement} tEl table element
	 */
	const hideTable = (tEl) => {
		// eslint-disable-next-line no-param-reassign
		tEl.style.display = 'none';
	};

	/**
	 * Show table element.
	 *
	 * @param {HTMLTableElement} tEl table element
	 */
	const showTable = (tEl) => {
		// eslint-disable-next-line no-param-reassign
		tEl.style.display = 'table';
	};

	/**
	 * Check if target table is eligible for responsive search.
	 *
	 * @return {boolean} status
	 */
	const isTargetEligibleForResponsiveSearch = () => {
		const tableResponsiveDirectives = wptbResponsiveFrontendInstance.getDirective(targetTable);

		if (tableResponsiveDirectives) {
			const currentBreakpoint = wptbResponsiveFrontendInstance.calculateRangeIdFromTable(targetTable);

			const { modeOptions, responsiveMode } = tableResponsiveDirectives;

			const { topRowAsHeader } = modeOptions[responsiveMode];

			return (
				wptbResponsiveFrontendInstance.isResponsiveEnabledForCurrentBreakpoint &&
				topRowAsHeader[currentBreakpoint]
			);
		}

		return false;
	};

	/**
	 * Switch responsive table back to non-responsive and then responsive again and call supplied function in between these operations.
	 *
	 * @param {Function} callbackInBetween callback function
	 */
	const switchBackForthResponsiveTable = (callbackInBetween) => {
		const tableResponsiveDirectives = wptbResponsiveFrontendInstance.getDirective(targetTable);
		const {
			breakpoints: {
				desktop: { width },
			},
		} = tableResponsiveDirectives;

		const tableIdFull = targetTable.parentNode.getAttribute('id');
		const regexp = new RegExp(/^wptb-table-id-(\d+)$/);
		// eslint-disable-next-line no-unused-vars
		const [_, tableId] = regexp.exec(tableIdFull);

		const tableObjContainer =
			cachedTableObject !== null
				? { el: targetTable, tableObject: cachedTableObject }
				: wptbResponsiveFrontendInstance.getTableElementObject(Number.parseInt(tableId, 10));
		if (tableObjContainer) {
			const { el, tableObject } = tableObjContainer;

			hideTable(el);

			// remove table appear animations for faster renders between rebuild operations
			el.style.opacity = '1';
			el.style.animation = 'none';

			// rebuild original table
			wptbResponsiveFrontendInstance.rebuildTable(el, width, tableObject);

			// call in-between function
			callbackInBetween(el);

			const targetSize = wptbResponsiveFrontendInstance.calculateInnerSize(el);
			const { TableObject } = wptbResponsiveFrontendInstance;

			// build responsive version of table
			wptbResponsiveFrontendInstance.rebuildTable(el, targetSize, new TableObject(el));

			showTable(el);
		}
	};

	/**
	 * Set visibility status for target row element.
	 *
	 * @param {HTMLTableRowElement} rowEl row element
	 * @param {boolean} status status
	 */
	const setRowVisibility = (rowEl, status) => {
		if (isTargetEligibleForResponsiveSearch()) {
			wptbResponsiveFrontendInstance.markRowForResponsive(rowEl, !status);
		} else {
			// eslint-disable-next-line no-param-reassign
			rowEl.dataset.wptbPaginationVisibility = JSON.stringify(status);
		}
	};

	/**
	 * Main logic for pagination process.
	 */
	const startPaginationProcess = () => {
		/**
		 * Inner pagination process.
		 */
		const innerPaginationProcess = () => {
			const minIndexToShow = dataPerPage * (currentPage - 1);
			const maxIndexToShow = minIndexToShow + (dataPerPage - 1);

			// eslint-disable-next-line array-callback-return
			tableRows.map((tRow, index) => {
				setRowVisibility(tRow, index >= minIndexToShow && index <= maxIndexToShow);
			});
		};

		if (isTargetEligibleForResponsiveSearch()) {
			switchBackForthResponsiveTable(innerPaginationProcess);
		} else {
			hideTable(targetTable);

			innerPaginationProcess();

			showTable(targetTable);
		}
	};

	/**
	 * Calculate data necessary for base of operations related to pagination functionality.
	 *
	 * @param {HTMLTableElement} tableElement target table element
	 */
	const calculateBaseData = (tableElement) => {
		const responsiveStatus = isTargetEligibleForResponsiveSearch();

		/**
		 * Inner function for calculations.
		 */
		const innerCalculate = () => {
			const rows = Array.from(tableElement.querySelectorAll('tr'))
				.filter((_, index) => {
					return topRowHeader ? index > 0 : true;
				})
				.filter((rowEl) => {
					return !rowEl.classList.contains('search-hidden');
				});

			setTableRows(rows);

			const totalRows = rows.length;

			// total pages
			setTotalPages(Math.ceil(totalRows / dataPerPage));
		};

		if (responsiveStatus) {
			switchBackForthResponsiveTable(innerCalculate);
		} else {
			innerCalculate();
		}
	};

	/**
	 * Navigation button active status.
	 *
	 * @param {number} pageNum button page number
	 * @return {boolean} status
	 */
	const isNavButtonActive = (pageNum) => {
		return pageNum === currentPage;
	};

	/**
	 * Render navigation button.
	 *
	 * @param {number | null} targetPage target page index
	 * @param {string | number | JSX.Element | Array<JSX.Element>} children  button children
	 * @param {string | number | null} key component key identifier, if null is supplied targetPage will be used as key value
	 * @param {null | boolean} activeStatus button active status, if null supplied this value will be automatically calculated based on current page and button target page index
	 * @param {Function | null} [clickCallback=null] click callback handler
	 * @param {boolean} [disabledStatus=false] button disabled status
	 */
	const renderNavButton = (
		targetPage,
		children,
		key = null,
		activeStatus = null,
		clickCallback = null,
		disabledStatus = false
	) => {
		return (
			<PaginationNavButton
				key={key === null ? targetPage : key}
				active={activeStatus === null ? isNavButtonActive(targetPage) : activeStatus}
				targetPage={targetPage}
				onClick={clickCallback || setCurrentPage}
				disabled={disabledStatus}
			>
				{children}
			</PaginationNavButton>
		);
	};

	/**
	 * Render first page button.
	 *
	 * @return {JSX.Element} first page button
	 */
	const renderFirstPageButton = () => {
		return renderNavButton(1, 1);
	};

	/**
	 * Render first page button.
	 *
	 * @return {JSX.Element | null} first page button
	 */
	const renderLastPageButton = () => {
		return totalPages !== 1 ? renderNavButton(totalPages, totalPages) : null;
	};

	/**
	 * Render buttons related to previous page navigations.
	 *
	 * @return {JSX.Element } nav buttons
	 */
	const renderPreviousNavButtons = () => {
		// eslint-disable-next-line camelcase
		const { nav_normal_back, nav_fast_back } = icons;
		return (
			<Fragment>
				{renderNavButton(
					1,
					<div
						className={'navigation-button-icon'}
						dangerouslySetInnerHTML={{ __html: nav_fast_back }}
					></div>,
					'firstPage',
					false,
					null,
					currentPage === 1
				)}
				{renderNavButton(
					currentPage - 1,
					<div
						className={'navigation-button-icon'}
						dangerouslySetInnerHTML={{ __html: nav_normal_back }}
					></div>,
					'previousPage',
					false,
					null,
					currentPage === 1
				)}
			</Fragment>
		);
	};

	/**
	 * Render buttons related to next page navigations.
	 *
	 * @return {JSX.Element } nav buttons
	 */
	const renderNextNavButtons = () => {
		// eslint-disable-next-line camelcase
		const { nav_normal_forward, nav_fast_forward } = icons;
		return (
			<Fragment>
				{renderNavButton(
					currentPage + 1,
					<div
						className={'navigation-button-icon'}
						dangerouslySetInnerHTML={{ __html: nav_normal_forward }}
					></div>,
					'nextPage',
					false,
					null,
					currentPage === totalPages
				)}
				{renderNavButton(
					totalPages,
					<div
						className={'navigation-button-icon'}
						dangerouslySetInnerHTML={{ __html: nav_fast_forward }}
					></div>,
					'lastPage',
					false,
					null,
					currentPage === totalPages
				)}
			</Fragment>
		);
	};

	/**
	 * Render a nav button represent there are wrapper items between any end of the navigation pages.
	 *
	 * @param {string} idSuffix suffix for button id
	 * @return {JSX.Element | null } wrapper button
	 */
	const renderWrapperButton = (idSuffix) => {
		return renderNavButton(null, '...', `wrapper-${idSuffix}`, false, () => {}, true);
	};

	/**
	 * Render nav buttons between first-last pages.
	 *
	 * @return {JSX.Element | null } nav buttons
	 */
	const renderInBetweenNavButtons = () => {
		const totalInBetweenLength = totalPages - 2;

		const currentPageIndexInBetween = Math.ceil(visibleDirectPages / 2);
		const prevIndexAmount = currentPageIndexInBetween - 1;
		const nextIndexAmount = visibleDirectPages - currentPageIndexInBetween;

		/**
		 * Render visible pages navigation buttons.
		 *
		 * @return {Array<null | JSX.Element> | JSX.Element} navigation buttons
		 */
		const renderVisiblePagesNav = () => {
			const startIndex = currentPage - currentPageIndexInBetween;

			// eslint-disable-next-line no-array-constructor
			return (
				<Fragment>
					{Array(visibleDirectPages)
						.fill(() => 0)
						.map((_, index) => {
							const currentNavIndex = startIndex + index + 1;

							if (currentNavIndex > 1 && currentNavIndex < totalPages) {
								return renderNavButton(currentNavIndex, currentNavIndex);
							}
							return null;
						})}
				</Fragment>
			);
		};

		return (
			<Fragment>
				{/* eslint-disable-next-line no-nested-ternary */}
				{totalInBetweenLength > 1
					? currentPage - prevIndexAmount > 2
						? renderWrapperButton('prev')
						: null
					: null}
				{renderVisiblePagesNav()}
				{/* eslint-disable-next-line no-nested-ternary */}
				{totalInBetweenLength > 1
					? totalPages - (currentPage + nextIndexAmount) > nextIndexAmount
						? renderWrapperButton('next')
						: null
					: null}
			</Fragment>
		);
	};

	/**
	 * Pre table search callback.
	 */
	const preTableSearch = () => {};

	/*
	 * Post table search callback.
	 *
	 * @param {Event} event event object
	 * @param {Object} event.detail detail data
	 */
	const postTableSearch = ({ detail }) => {
		const { tObj } = detail;

		setCachedTableObject(tObj);
		setCurrentPage(1);
		calculateBaseData(targetTable);
	};

	/**
	 * Component useEffect hook calls.
	 */
	const useEffects = () => {
		useEffect(() => {
			calculateBaseData(targetTable);
		}, [dataPerPage, cachedTableObject]);

		useEffect(() => {
			startPaginationProcess();
		}, [currentPage, dataPerPage, tableRows, cachedTableObject]);

		// reset current page on data per page value changes for valid pagination renders since current page might not be available on re-rendered table
		useEffect(() => {
			setCurrentPage(1);
		}, [dataPerPage]);

		// subscribe to table search events to maintain compatibility between these two components
		useEffect(() => {
			// remove event first to make sure only and only one listener will be attached to target table
			targetTable.removeEventListener('pre-table-search', preTableSearch);
			targetTable.addEventListener('pre-table-search', preTableSearch);

			targetTable.removeEventListener('post-table-search', postTableSearch);
			targetTable.addEventListener('post-table-search', postTableSearch);
		}, []);
	};

	// initialize useEffect hooks
	useEffects();

	return (
		<div className={'wptb-pro-pagination-wrapper'}>
			<div className={'pagination-nav-bar'}>
				{renderPreviousNavButtons()}
				{renderFirstPageButton()}
				{renderInBetweenNavButtons()}
				{renderLastPageButton()}
				{renderNextNavButtons()}
			</div>
			{toolboxEnabled && (
				<PaginationToolbox startupCollapsedStatus={true} toggleIcon={icons.caret_down}>
					<div className={'toolbox-control-row'}>
						<div className={'control-label'}>{translations.perPage}:</div>
						<div className={'control-wrapper'}>
							{/* eslint-disable-next-line jsx-a11y/no-onchange */}
							<select
								onChange={({ target: { value } }) => {
									setDataPerPage(Number.parseInt(value, 10));
								}}
							>
								{[rowsPerPage, 10, 20, 50, 100]
									.sort((valA, valB) => {
										if (valA === valB) {
											return 0;
										}

										return valA < valB ? -1 : 1;
									})
									.map((perPageVal) => {
										return (
											<option key={perPageVal} value={perPageVal}>
												{perPageVal}
											</option>
										);
									})}
							</select>
						</div>
					</div>
				</PaginationToolbox>
			)}
		</div>
	);
}

/**
 * @module Pagination
 */
export default Pagination;
