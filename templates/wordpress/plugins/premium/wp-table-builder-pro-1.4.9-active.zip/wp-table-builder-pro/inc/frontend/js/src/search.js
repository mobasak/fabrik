// debouncer base implementation
const DebouncerBase = () => {
    let timeoutId = null;

    return (callback, timeoutDuration) => {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
        timeoutId = setTimeout(callback, timeoutDuration);
    };
};

const Debouncer = DebouncerBase();

function setSearch() {
    const wptbWrappers = Array.from(
        document.querySelectorAll(".wptb-table-container-matrix")
    );

    // Apply search function to all tables
    // eslint-disable-next-line array-callback-return
    wptbWrappers.map((wptbTableWrapper) => {
        const wptbTable = wptbTableWrapper.querySelector(
            "table.wptb-preview-table"
        );

        if (wptbTable) {
            const isSearchEnable = wptbTable.getAttribute(
                "data-wptb-search-enable"
            );
            if (isSearchEnable) {
                const searchBarPosition = wptbTable.getAttribute(
                    "data-wptb-searchbar-position"
                );
                applySearch(searchBarPosition);
            }
        }

        /**
         * Get status of top row enabled search option.
         *
         * @param {HTMLTableElement} tElement target table element
         * @return {boolean} option value
         */
        const isTopRowEnabled = (tElement) => {
            return tElement.dataset.wptbProSearchTopRowHeader === "true";
        };

        /**
         * Apply table search functionality.
         *
         * @param {string} barPos search bar relative position to table element
         */
        function applySearch(barPos) {
            // Create a search field
            const searchBarTemplate = `
          <input class="wptb-searchbar" placeholder="search..."/>
          <div class="dashicons dashicons-search"></div>
        `;

            const searchField = document.createElement("span");
            searchField.style.position = "relative";
            searchField.style.float = barPos;
            searchField.innerHTML = searchBarTemplate;
            wptbTableWrapper.prepend(searchField);

            const searchInput = searchField.querySelector(
                "input.wptb-searchbar"
            );

            // Display 'no items match'
            const noItemDisplay = noItemsMatch();
            wptbTableWrapper.insertBefore(
                noItemDisplay,
                wptbTableWrapper.children[2]
            );

            /**
             * Hide row element as a search result.
             *
             * @param {HTMLTableRowElement} rowEl row element
             */
            const hideRow = (rowEl) => {
                rowEl.classList.add("search-hidden");
            };

            /**
             * Hide row element as a basic search result.
             *
             * @param {HTMLTableRowElement} rowEl row element
             */
            const showRow = (rowEl) => {
                rowEl.classList.remove("search-hidden");
            };

            /**
             * Generate match status object.
             *
             * @param {boolean} status status
             * @param {TableObject | null} tObj table object, will be used for responsive operations
             * @return {{tObj, status}} status object
             */
            const generateMatchStatusObject = (status, tObj) => {
                return { status, tObj };
            };

            /**
             * Basic search logic.
             *
             * @param {string} queryString query string
             * @param {HTMLTableElement} targetTable target table
             * @return {Object} match status object
             */
            const basicSearch = (queryString, targetTable) => {
                let searchMatchStatus = false;
                const rows = Array.from(targetTable.getElementsByTagName("tr"));

                if (isTopRowEnabled(targetTable)) {
                    rows.shift();
                }

                // eslint-disable-next-line array-callback-return
                rows.map((row) => {
                    hideRow(row);

                    // Loop through all the cols
                    const cols = Array.from(row.getElementsByTagName("td"));

                    const rowMatchStatus = cols.some((col) => {
                        const content = col.textContent.toLowerCase();
                        const status = content.indexOf(queryString) >= 0;

                        if (status) {
                            showRow(row);
                        }

                        return status;
                    });

                    if (rowMatchStatus) {
                        searchMatchStatus = rowMatchStatus;
                    }
                });

                return generateMatchStatusObject(searchMatchStatus, null);
            };

            /**
             * Search logic for responsive tables.
             *
             * @param {string} queryString query
             * @param {HTMLTableElement} targetTable target table
             *
             * @return {Object} match status object
             */
            const responsiveSearch = (queryString, targetTable) => {
                const tableResponsiveDirectives =
                    wptbResponsiveFrontendInstance.getDirective(targetTable);
                const {
                    breakpoints: {
                        desktop: { width },
                    },
                } = tableResponsiveDirectives;

                const tableIdFull = targetTable.parentNode.getAttribute("id");
                const regexp = new RegExp(/^wptb-table-id-(\d+)$/);
                const [_, tableId] = regexp.exec(tableIdFull);

                const tableObjContainer =
                    wptbResponsiveFrontendInstance.getTableElementObject(
                        Number.parseInt(tableId, 10)
                    );

                if (tableObjContainer) {
                    const { el, tableObject } = tableObjContainer;

                    el.style.display = "none";

                    // remove table appear animations for faster renders between search inputs
                    el.style.opacity = 1;
                    el.style.animation = "none";

                    wptbResponsiveFrontendInstance.rebuildTable(
                        el,
                        width,
                        tableObject
                    );

                    const matchStatus = Array.from(el.querySelectorAll("tr"))
                        .filter(
                            (rowEl) =>
                                !rowEl.classList.contains("wptb-table-head")
                        )
                        .map((rowElement) => {
                            const cells = Array.from(
                                rowElement.querySelectorAll("td.wptb-cell")
                            );

                            const cellMatchStatus = cells.some((cell) => {
                                const cellContent = cell.textContent
                                    .toLowerCase()
                                    .trim();

                                return cellContent.includes(queryString);
                            });

                            wptbResponsiveFrontendInstance.markRowForResponsive(
                                rowElement,
                                !cellMatchStatus
                            );

                            return cellMatchStatus;
                        })
                        .every((status) => status === false);

                    const targetSize =
                        wptbResponsiveFrontendInstance.calculateInnerSize(el);
                    const { TableObject } = wptbResponsiveFrontendInstance;

                    const updatedTableObject = new TableObject(el);
                    wptbResponsiveFrontendInstance.rebuildTable(
                        el,
                        targetSize,
                        updatedTableObject
                    );

                    el.style.display = "table";

                    return generateMatchStatusObject(
                        !matchStatus,
                        updatedTableObject
                    );
                }

                return generateMatchStatusObject(true, null);
            };

            /**
             * Check if target table is eligible for responsive search.
             *
             * @param {HTMLTableElement} targetTable target table
             * @return {boolean} status
             */
            const isTargetEligibleForResponsiveSearch = (targetTable) => {
                const tableResponsiveDirectives =
                    wptbResponsiveFrontendInstance.getDirective(targetTable);

                if (tableResponsiveDirectives) {
                    const currentBreakpoint =
                        wptbResponsiveFrontendInstance.calculateRangeIdFromTable(
                            targetTable
                        );

                    const { modeOptions, responsiveMode } =
                        tableResponsiveDirectives;

                    const { topRowAsHeader } = modeOptions[responsiveMode];

                    return (
                        wptbResponsiveFrontendInstance.isResponsiveEnabledForCurrentBreakpoint &&
                        topRowAsHeader[currentBreakpoint]
                    );
                }

                return false;
            };

            /**
             * Input handler for search input.
             *
             * @param {Event} e event object
             */
            const inputHandler = (e) => {
                // compatibility check for style pass
                const currentTarget = e.target.value ? e.target : searchInput;

                // Get the search query
                const query = currentTarget.value.toLowerCase().trim();
                const minimumQueryLength = 3;
                const finalQuery =
                    query.length >= minimumQueryLength ? query : "";

                noItemDisplay.classList.add("wptb-hidden");

                wptbTable.dispatchEvent(new Event("pre-table-search"));

                const logicFunction = isTargetEligibleForResponsiveSearch(
                    wptbTable
                )
                    ? responsiveSearch
                    : basicSearch;
                const { status, tObj } = logicFunction.call(
                    this,
                    finalQuery,
                    wptbTable
                );

                wptbTable.dispatchEvent(
                    new CustomEvent("post-table-search", { detail: { tObj } })
                );

                if (!status) {
                    wptbTable.classList.add("wptb-hidden");
                    noItemDisplay.classList.remove("wptb-hidden");
                } else {
                    wptbTable.classList.remove("wptb-hidden");
                }
            };

            // When the user types in the search field
            searchInput.addEventListener("input", (e) =>
                Debouncer(() => inputHandler(e), 200)
            );
        }

        function noItemsMatch() {
            const noItemDisplay = document.createElement("p");
            noItemDisplay.style.textAlign = "center";
            noItemDisplay.style.fontSize = "20px";
            noItemDisplay.innerHTML = "No items match";
            noItemDisplay.classList.add("wptb-hidden");
            return noItemDisplay;
        }
    });
}

setSearch();
