=== AutomatorWP - FluentCRM ===
Contributors: automatorwp, rubengc, eneribs
Tags: crm, fluentcrm, automatorwp, marketing, funnel, automation
Requires at least: 4.4
Tested up to: 6.6
Stable tag: 1.1.2
License: GNU AGPLv3
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Connect AutomatorWP with FluentCRM

== Description ==

[FluentCRM](https://wordpress.org/plugins/fluent-crm/ "FluentCRM") is a complete feature-rich Email Marketing & CRM solution that lets you manage your customer relationships, build your email lists, send email campaigns, build funnels, and make more profit and increase your conversion rates.

= Triggers =

* A tag added to the user.
* A tag removed to the user.
* User gets added to a list.
* User gets removed from a list.
* User status change to a status.

= Anonymous Triggers =

* A tag added to a contact.
* A tag removed to a contact.
* Contact gets added to a list.
* Contact gets removed from a list.
* Contact status change to a status.

= Actions =

* Create a contact.
* Add or remove tag to the user.
* Add or remove user from list.
* Add or remove tag to contact.
* Add or remove contact from list.
* Create tag and assign to contact.
* Change contact status.

= Tags =

* Contact field tags to access to the contact fields values.
* Contact custom field tags to access to the contact custom fields values.

= Filters =

* User has tag.
* User does not have tag.
* User is in list.
* User is not in list.

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.1.2 =

* **New Features**
* New filter: User is in list.
* New filter: User is not in list.

= 1.1.1 =

* **New Features**
* New action: Change contact status.

= 1.1.0 =

* **Improvements**
* Added support for contact custom values.

= 1.0.9 =

* **Improvements**
* Added support for custom values in country field.
* **Bug Fixes**
* Fixed Country field to adapt to FluentCRM latest version.

= 1.0.8 =

* **Bug Fixes**
* Fixed function to get the WordPress user ID.

= 1.0.7 =

* **New Features**
* New filter: User has tag.
* New filter: User does not have tag.

= 1.0.6 =

* **Improvements**
* Performance improvement reducing the database queries to build the contact tags.

= 1.0.5 =

* **New Features**
* New action: Create tag and assign to contact.

= 1.0.4 =

* **New Features**
* New trigger: User status change to a status.
* New tags: Contact field and custom field tags.
* New anonymous trigger: A tag added to a contact.
* New anonymous trigger: A tag removed to a contact.
* New anonymous trigger: Contact gets added to a list.
* New anonymous trigger: Contact gets removed from a list.
* New anonymous trigger: Contact status change to a status.

= 1.0.3 =

* **New Features**
* New action: Add or remove tag to contact.
* New action: Add or remove contact from list.

= 1.0.2 =

* **New Features**
* Added support to the AutomatorWP custom values feature.

= 1.0.1 =

* **New Features**
* New action: Create a contact.

= 1.0.0 =

* Initial release.
