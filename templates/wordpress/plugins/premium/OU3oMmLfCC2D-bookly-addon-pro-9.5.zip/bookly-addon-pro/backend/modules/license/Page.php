<?php
namespace BooklyPro\Backend\Modules\License;

use Bookly\Lib as BooklyLib;

class Page extends BooklyLib\Base\Component
{
    /**
     * Render page.
     */
    public static function render()
    {
        // license required page
    }
}