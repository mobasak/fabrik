<?php
/**
 * Shows the review voting success message.
 *
 * @var WP_Comment $review
 */

$css_class = 'edd-review-vote';
if ( $this->is_ajax_request() ) {
	$css_class .= ' edd-yellowfade';
}
?>

<div class="<?php echo esc_attr( $css_class ); ?>">
	<p>
		<?php echo wp_kses_post( apply_filters( 'edd_reviews_thank_you_for_voting_message', __( 'Thank you for your feedback.', 'edd-reviews' ) ) ); ?>
	</p>
	<?php edd_reviews()->voting->display_voting_stats( $review ); ?>
</div>
