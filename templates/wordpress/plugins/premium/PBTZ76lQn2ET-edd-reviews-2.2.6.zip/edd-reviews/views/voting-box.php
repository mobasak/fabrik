<?php
/**
 * Outputs the voting box for a review.
 *
 * @var WP_Comment $review
 */
$yes_vote = add_query_arg(
	array(
		'edd_review_vote' => 'yes',
		'edd_c'           => get_comment_ID(),
	)
);
$no_vote  = add_query_arg(
	array(
		'edd_review_vote' => 'no',
		'edd_c'           => get_comment_ID(),
	)
);
?>
<div class="edd-review-review-helpful">
	<div class="edd-review-vote">
		<?php do_action( 'edd_reviews_voting_box_before' ); ?>
		<?php edd_reviews()->voting->display_voting_stats( $review ); ?>
		<p>
			<?php echo wp_kses_post( apply_filters( 'edd_reviews_voting_intro_text', __( 'Help other customers find the most helpful reviews', 'edd-reviews' ) ) ); ?>
		</p>
		<p>
			<?php echo wp_kses_post( apply_filters( 'edd_reviews_review_helpful_text', __( 'Did you find this review helpful?', 'edd-reviews' ) ) ); ?>
			<span class="edd-reviews-voting-buttons">
				<a
					class="vote-yes"
					data-edd-reviews-comment-id="<?php echo esc_attr( get_comment_ID() ); ?>"
					data-edd-reviews-vote="yes"
					rel="nofollow"
					href="<?php echo esc_url( $yes_vote ); ?>"
				>
					<?php esc_html_e( 'Yes', 'edd-reviews' ); ?>
				</a>
				<a
					class="vote-no"
					data-edd-reviews-comment-id="<?php echo esc_attr( get_comment_ID() ); ?>"
					data-edd-reviews-vote="no"
					rel="nofollow"
					href="<?php echo esc_url( $no_vote ); ?>"
				>
					<?php esc_html_e( 'No', 'edd-reviews' ); ?>
				</a>
			</span>
		</p>
		<?php do_action( 'edd_reviews_voting_box_after' ); ?>
	</div>
</div>
