<?php
/**
 * ApiV1.php
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2022, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2.2
 */

namespace EDD\Reviews;

use EDD\Reviews\Interfaces\InitializerInterface;
use WP_Comment;

class ApiV1 implements InitializerInterface {

	/**
	 * @inheritDoc
	 */
	public function init() {
		add_filter( 'edd_api_valid_query_modes', array( $this, 'register_api_mode' ) );
		add_filter( 'edd_api_output_data', array( $this, 'api_output' ), 10, 3 );
		add_filter( 'query_vars', array( $this, 'query_vars' ) );
	}

	/**
	 * Register API Query Mode
	 *
	 * @since 1.0
	 * @access public
	 * @param array $modes Whitelisted query modes
	 * @return array $modes Updated list of query modes
	 */
	public function register_api_mode( $modes ) {
		$modes[] = 'reviews';

		return $modes;
	}

	/**
	 * Add 'review_id' Query Var into WordPress Whitelisted Query Vars
	 *
	 * @since 1.0
	 * @access public
	 * @param array $vars Array of WordPress allowed query vars
	 * @return array $vars Updated array of WordPress query vars to allow
	 *  Reviews to integrate with the EDD API
	 */
	public function query_vars( $vars ) {
		$vars[] = 'review_id';
		$vars[] = 'download_id';

		return $vars;
	}

	/**
	 * Processes the Data Outputted when an API Call for Reviews is Triggered
	 *
	 * @since 1.0
	 * @access public
	 * @global object $wp_query Used to access the query vars
	 *
	 * @param array $data Array to hold the output
	 * @param array $query_mode Query mode (i.e. reviews)
	 * @param object $api_object EDD_API Object
	 *
	 * @return array $data All the data for when the API call for reviews is fired
	 */
	public function api_output( $data, $query_mode, $api_object ) {
		// Bail if the query mode isn't reviews
		if ( 'reviews' !== $query_mode ) {
			return $data;
		}

		global $wp_query;

		remove_action( 'pre_get_comments', array( edd_reviews(), 'hide_reviews' ) );
		remove_filter( 'comments_clauses', array( edd_reviews(), 'hide_reviews_from_comment_feeds_compat' ), 10 );
		remove_filter( 'comment_feed_where', array( edd_reviews(), 'hide_reviews_from_comment_feeds' ), 10 );

		// Get the review_id query var
		$review_id   = isset( $wp_query->query_vars['review_id'] ) ? $wp_query->query_vars['review_id'] : null;
		$download_id = isset( $wp_query->query_vars['download_id'] ) ? $wp_query->query_vars['download_id'] : null;
		$number      = isset( $wp_query->query_vars['number'] ) ? $wp_query->query_vars['number'] : null;
		$args        = array(
			'number' => $number,
		);

		if ( $review_id ) {
			try {
				$data['reviews'] = $this->query_single_review( $review_id );
			} catch ( \Exception $e ) {
				return array(
					'error' => $e->getMessage(),
				);
			}
		} elseif ( $download_id ) {
			$args['post_id'] = $download_id;
			$reviews         = $this->get_reviews( $args );

			if ( $reviews ) {
				$i               = 0;
				$data['reviews'] = array();
				foreach ( $reviews as $review ) {
					$data['reviews'][ $i ] = $this->get_single_review_data( $review );
					$i++;
				}
			}
		} else {

			$data['reviews']['total'] = $this->get_total_review_count();

			$i                              = 0;
			$data['reviews']['most_recent'] = array();
			$most_recent_reviews            = $this->get_reviews( $args );
			foreach ( $most_recent_reviews as $most_recent_review ) {
				$data['reviews']['most_recent'][ $i ] = $this->get_single_review_data( $most_recent_review );
				$i++;
			}
		}

		// Allow extensions to add to the data outpt
		$data = apply_filters( 'edd_reviews_api_output_data', $data );

		add_action( 'pre_get_comments', array( edd_reviews(), 'hide_reviews' ) );
		add_filter( 'comments_clauses', array( edd_reviews(), 'hide_reviews_from_comment_feeds_compat' ), 10, 2 );
		add_filter( 'comment_feed_where', array( edd_reviews(), 'hide_reviews_from_comment_feeds' ), 10, 2 );

		return $data;
	}

	/**
	 * Queries the database directly to get a single review.
	 *
	 * @param int $review_id The ID of the review to get.
	 * @return void
	 */
	private function query_single_review( $review_id ) {
		global $wpdb;
		// Get the review from the database
		$review = $wpdb->get_row(
			$wpdb->prepare(
				"
					SELECT *
					FROM {$wpdb->comments}
					INNER JOIN {$wpdb->posts} ON {$wpdb->comments}.comment_post_ID = {$wpdb->posts}.ID
					WHERE comment_ID = '%d' AND comment_type = 'edd_review'
					LIMIT 1
					",
				$review_id
			)
		);

		return ! empty( $review ) ? $this->get_single_review_data( $review ) : false;
	}

	/**
	 * Gets the total review count.
	 *
	 * @since 2.2
	 * @return int
	 */
	private function get_total_review_count() {
		global $wpdb;

		return (int) $wpdb->get_var(
			"
				SELECT COUNT(meta_value)
				FROM {$wpdb->commentmeta}
				LEFT JOIN {$wpdb->comments} ON {$wpdb->commentmeta}.comment_id = {$wpdb->comments}.comment_ID
				WHERE meta_key = 'edd_rating'
				AND comment_type = 'edd_review'
				AND comment_approved = '1'
				AND meta_value > 0
				"
		);
	}

	/**
	 * Gets an array of reviews.
	 *
	 * @since 2.2.2
	 * @param array $args Optionally modify the query.
	 * @return array
	 */
	private function get_reviews( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'post_type'  => 'download',
				'type'       => 'edd_review',
				'meta_query' => array(
					'relation' => 'AND',
					array(
						'key'     => 'edd_review_approved',
						'value'   => '1',
						'compare' => '=',
					),
					array(
						'key'     => 'edd_review_approved',
						'value'   => 'spam',
						'compare' => '!=',
					),
					array(
						'key'     => 'edd_review_approved',
						'value'   => 'trash',
						'compare' => '!=',
					),
				),
			)
		);

		return get_comments( $args );
	}

	/**
	 * Gets the data for a single review for the API response.
	 *
	 * @since 2.2.2
	 * @param WP_Comment $review
	 * @return array
	 */
	private function get_single_review_data( $review ) {
		$type = 'review';
		if ( $review->comment_parent > 0 ) {
			$type = 'reply';
		}

		$data = array(
			'id'             => $review->comment_ID,
			'title'          => get_comment_meta( $review->comment_ID, 'edd_review_title', true ) ?: null,
			'parent'         => $review->comment_parent,
			'download_id'    => $review->comment_post_ID,
			'download_title' => get_the_title( $review->comment_post_ID ),
			'rating'         => get_comment_meta( $review->comment_ID, 'edd_rating', true ) ?: null,
			'author'         => $review->comment_author,
			'email'          => $review->comment_author_email,
			'IP'             => $review->comment_author_IP,
			'date'           => $review->comment_date,
			'date_gmt'       => $review->comment_date_gmt,
			'content'        => $review->comment_content,
			'status'         => get_comment_meta( $review->comment_ID, 'edd_review_approved', true ),
			'user_id'        => $review->user_id,
			'type'           => $type,
		);

		if ( get_comment_meta( $review->comment_ID, 'edd_review_vote_yes', true ) || get_comment_meta( $review->comment_ID, 'edd_review_vote_no', true ) ) {
			$data['votes']['yes'] = get_comment_meta( $review->comment_ID, 'edd_review_vote_yes', true );
			$data['votes']['no']  = get_comment_meta( $review->comment_ID, 'edd_review_vote_no', true );
		} elseif ( $review->comment_parent > 0 ) {
			$data['votes'] = null;
		} else {
			$data['votes']['yes'] = '0';
			$data['votes']['no']  = '0';
		}

		return $data;
	}
}
