const { Component, RawHTML } = wp.element;

class StarRating extends Component {
	constructor( props ) {
		super( props );
	}

	render() {
		let stars = '';

		for( let i = 1; i <= this.props.rating; i++ ) {
			stars += '<span class="dashicons dashicons-star-filled"></span>';
		}

		for ( let i = 5; i > this.props.rating; i-- ) {
			stars += '<span class="dashicons dashicons-star-empty"></span>';
		}

		return (
			<div className="edd-review-meta-rating">
				<RawHTML>
					{ stars }
				</RawHTML>
			</div>
		)
	}
}

export default StarRating;
