/* global eddReviews */

import apiFetch from '@wordpress/api-fetch';

const { Component } = wp.element;
const { __ } = wp.i18n;

class ProductSelectControl extends Component {
	constructor( props ) {
		super( props );

		this.state = {
			selectedProduct: this.props.selectedProduct || '',
			productsLoaded: false,
			products: []
		};
	}

	componentDidUpdate( prevProps, prevState ) {
		if ( this.props.selectedProduct !== this.state.selectedProduct ) {
			this.setState( { selectedProduct: this.props.selectedProduct } );
		}
	}

	componentDidMount() {
		this.loadProducts();
	}

	loadProducts() {
		apiFetch.use( apiFetch.createNonceMiddleware( eddReviews.restNonce ) );
		apiFetch( { url: eddReviews.productsApi } )
			.then( response => {
				if ( ! response.data ) {
					throw new Error( __( 'No products.', 'edd-reviews' ) );
				}

				const products = response.data;

				this.setState( { products } );

				if ( ! this.state.selectedProduct && 'undefined' !== typeof products[0] ) {
					this.handleChange( products[0].id );
				}
			} )
			.catch( e => {
				console.log( 'Error', e );
			} )
			.finally( () => {
				this.setState( { productsLoaded: true } );
			} );
	}

	handleChange( productId ) {
		if ( typeof this.props.onChange === 'function' ) {
			this.props.onChange( productId );
		}
	}

	render() {
		if ( ! this.state.productsLoaded ) {
			return (
				<p>{__( 'Loading products...', 'edd-reviews' )}</p>
			)
		}

		if ( ! this.state.products.length ) {
			return (
				<p>{__( 'No products to choose from.', 'edd-reviews' )}</p>
			);
		}

		const products = this.state.products.map( product => {
			return (
				<option key={product.id} value={product.id}>
					{product.title}
				</option>
			)
		} );

		return (
			<div
				className="edd-reviews-editor__select"
			>
				<label
					className="components-input-control__label"
				>
					{__( 'Select a product', 'edd-reviews' )}
				</label>
				<select
					className="components-select-control__input"
					value={this.state.selectedProduct || ''}
					onChange={( e ) => this.handleChange( e.target.value )}
				>
					{products}
				</select>
			</div>
		)
	}
}

export default ProductSelectControl;
