import ReviewPreview from "../Components/ReviewPreview";
import { Placeholder } from '@wordpress/components';
import ProductSelectControl from "../Components/ProductSelectControl";
import ReviewSelectControl from "../Components/ReviewSelectControl";

const { Component } = wp.element;
const { __ } = wp.i18n;

class SelectReview extends Component {
	constructor( props ) {
		super( props );

		this.state = {
			productId: null,
			reviewId: null
		};
	}

	render() {
		const { attributes, setAttributes } = this.props;

		if ( attributes.id ) {
			return (
				<ReviewPreview id={attributes.id}/>
			);
		} else {
			return (
				<Placeholder
					icon="star-filled"
					label={__( 'Embed a Review', 'edd-reviews' )}
					className="is-large"
					instructions={__( 'Select a product to load its reviews. Then you may select a review to embed.', 'edd-reviews' )}
				>
					<ProductSelectControl
						selectedProduct={this.state.productId}
						onChange={( productId ) => this.setState( { productId } )}
					/>

					{this.state.productId && (
						<ReviewSelectControl
							productId={this.state.productId}
							onChange={( reviewId ) => this.setState( { reviewId } )}
						/>
					)}

					{this.state.productId && this.state.reviewId && (
						<div
							className="edd-reviews-editor__button"
						>
							<button
								type="button"
								className="button button-primary"
								onClick={( e ) => setAttributes( { id: this.state.reviewId } )}
							>
								{__( 'Insert Review', 'edd-reviews' )}
							</button>
						</div>
					)}
				</Placeholder>
			);
		}
	}
}

export default SelectReview;
