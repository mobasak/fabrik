import apiFetch from "@wordpress/api-fetch";
import StarRating from "./StarRating";

const { Component } = wp.element;
const { __ } = wp.i18n;

class ReviewPreview extends Component {
	constructor( props ) {
		super( props );

		this.state = {
			review: null
		};
	}

	componentDidMount() {
		if ( this.props.id ) {
			this.fetchReview();
		}
	}

	componentDidUpdate( prevProps, prevState ) {
		if ( this.props.id !== prevProps.id ) {
			this.fetchReview();
		}
	}

	fetchReview() {
		apiFetch.use( apiFetch.createNonceMiddleware( eddReviews.restNonce ) );
		apiFetch( { url: eddReviews.reviewsApi + '/' + this.props.id } )
			.then( response => {
				const review = response.id ? response : null;

				this.setState( {
					review
				} );
			} )
			.catch( e => {
				console.log( 'fetchReview Error', e );
			} );
	}

	render() {
		if ( ! this.state.review ) {
			return (
				<p>{__( 'Loading review...', 'edd-reviews' )}</p>
			)
		}

		return (
			<div className="edd-review-body edd-review-shortcode-body">
				<div className="edd-review-meta">
					<div className="edd-review-author">
						<strong>{this.state.review.title}</strong>
						<StarRating rating={this.state.review.rating}/>
					</div>
					<div className="edd-review-metadata">
						<p>
							<span className="author">{__( 'By', 'edd-reviews' ) + ' ' + this.state.review.author_name}</span>
							{' ' + __( 'on', 'edd-reviews' ) + ' '}
							{this.state.review.date_formatted}
						</p>
					</div>
				</div>
				<div className="edd-review-content">
					{this.state.review.body}
				</div>
			</div>
		);
	}
}

export default ReviewPreview;
