<?php
/**
 * InitializerInterface.php
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2022, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2.2
 */

namespace EDD\Reviews\Interfaces;

interface InitializerInterface {

	/**
	 * Initializes the class (registers hooks, etc.).
	 *
	 * @since 2.2.2
	 *
	 * @return void
	 */
	public function init();

}
