<?php

namespace EDD\Reviews\Emails\Templates;

defined( 'ABSPATH' ) || exit;

class VendorReviewNotification extends ReviewNotification {

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.2.6
	 * @var string
	 */
	protected $email_id = 'vendor_review_notification';

	/**
	 * The email recipient.
	 *
	 * @since 2.2.6
	 * @var string
	 */
	protected $recipient = 'vendor';

	/**
	 * The email meta.
	 *
	 * @since 2.2.6
	 * @var array
	 */
	protected $meta = array();

	/**
	 * Name of the template.
	 *
	 * @since 2.2.6
	 * @return string
	 */
	public function get_name() {
		return __( 'Vendor Review Notification', 'edd-reviews' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.2.6
	 * @return string
	 */
	public function get_description() {
		return __( 'Email sent to a vendor when a review has been left.', 'edd-reviews' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.2.6
	 * @return string
	 */
	public function defaults(): array {
		return array(
			'subject' => sprintf(
				/* translators: %1$s: Site name, %2$s: Review title */
				__( '[%1$s] New Review: "[%2$s]"', 'edd-reviews' ),
				'{sitename}',
				'{title}'
			),
			'content' => edd_reviews()->settings->get_default_review_notification_email(),
			'status'  => 0,
		);
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 2.2.6
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
			'status',
		);
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_options(): array {
		return array();
	}
}
