<?php

namespace EDD\Reviews\Emails\Types;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Types\Email;

class Request extends Email {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.2.4
	 */
	protected $id = 'review_request';

	/**
	 * The email context.
	 *
	 * @var string
	 * @since 2.2.4
	 */
	protected $context = 'order';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 2.2.4
	 */
	protected $recipient_type = 'customer';

	/**
	 * The order object.
	 *
	 * @var \EDD\Orders\Order
	 */
	protected $order;

	public function __construct( $order ) {
		$this->order = $order;
	}

	/**
	 * Get the email subject.
	 *
	 * @since 2.2.4
	 *
	 * @return string
	 */
	protected function set_email_body_content() {
		$this->raw_body_content = $this->get_template()->content;
	}

	/**
	 * Set the email to address.
	 *
	 * @since 2.2.4
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$this->send_to = $this->order->email;
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.2.4
	 * @return void
	 */
	protected function set_message() {
		$message       = $this->maybe_apply_autop( $this->get_raw_body_content() );
		$this->message = $this->process_tags( $message, $this->order->id, $this->order );
	}
}
