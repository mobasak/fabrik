<?php

namespace EDD\Reviews\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

class VendorFeedback extends EmailTemplate {

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 2.2.4
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 2.2.4
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $email_id = 'review_vendor_feedback';

	/**
	 * The email recipient.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $recipient = 'vendor';

	/**
	 * The email context.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $context = 'fes';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $sender = 'reviews';

	/**
	 * Name of the template.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_name() {
		return __( 'Vendor Feedback', 'edd-reviews' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_description() {
		return __( 'Email sent to a vendor when feedback is posted for their product.', 'edd-reviews' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function defaults(): array {
		return array(
			/* translators: %s: Site title template tag */
			'subject' => sprintf( __( '[%1$s] New Feedback', 'edd-reviews' ), '{sitename}' ),
			'content' => edd_reviews()->fes->get_default_email(),
			'heading' => __( 'New Feedback', 'edd-reviews' ),
			'status'  => 1,
		);
	}

	/**
	 * Gets the preview data for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_preview_data() {
		remove_action( 'pre_get_comments', array( edd_reviews()->fes, 'hide_feedback' ) );
		remove_filter( 'comment_feed_where', array( edd_reviews()->fes, 'hide_feedback_from_comment_feeds' ), 10, 2 );
		remove_filter( 'comments_clauses', array( edd_reviews()->fes, 'hide_feedback_from_comment_feeds_compat' ), 10, 2 );
		$reviews = edd_reviews()->query_reviews(
			array(
				'number'  => 10,
				'post_id' => '',
				'type'    => 'edd_vendor_feedback',
			)
		);

		add_action( 'pre_get_comments', array( edd_reviews()->fes, 'hide_feedback' ) );
		add_filter( 'comment_feed_where', array( edd_reviews()->fes, 'hide_feedback_from_comment_feeds' ), 10, 2 );
		add_filter( 'comments_clauses', array( edd_reviews()->fes, 'hide_feedback_from_comment_feeds_compat' ), 10, 2 );

		if ( empty( $reviews ) ) {
			return false;
		}
		$count  = count( $reviews );
		$review = $reviews[ wp_rand( 0, $count - 1 ) ];

		return array(
			$review->comment_ID,
		);
	}

	/**
	 * Gets the email context as a label.
	 * This is an optional function to allow for more descriptive labels.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_context_label(): string {
		return __( 'Vendor Feedback', 'edd-reviews' );
	}

	/**
	 * Gets the content for the status tooltip, if needed.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	public function get_status_tooltip(): array {
		return array(
			'content'  => __( 'This email is sent to vendors when feedback is posted for their product. It cannot be disabled.', 'edd-reviews' ),
			'dashicon' => 'dashicons-lock',
		);
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
			'heading',
		);
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_options(): array {
		return array(
			'content' => 'edd_reviews_vendor_feedback_email',
			'subject' => 'edd_reviews_vendor_feedback_subject',
			'heading' => 'edd_reviews_vendor_feedback_heading',
		);
	}
}
