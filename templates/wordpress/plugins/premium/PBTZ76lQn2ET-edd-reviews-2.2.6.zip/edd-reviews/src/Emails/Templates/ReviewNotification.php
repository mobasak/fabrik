<?php

namespace EDD\Reviews\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

class ReviewNotification extends EmailTemplate {

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 2.2.4
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 2.2.4
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $email_id = 'review_notification';

	/**
	 * The email recipient.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $recipient = 'admin';

	/**
	 * The email context.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $context = 'review';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $sender = 'reviews';

	/**
	 * The email meta.
	 *
	 * @since 2.2.4
	 * @var array
	 */
	protected $meta = array(
		'recipients' => '',
	);

	/**
	 * Name of the template.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_name() {
		return __( 'Review Notification', 'edd-reviews' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_description() {
		return __( 'Email sent when a review has been left.', 'edd-reviews' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function defaults(): array {
		return array(
			'subject' => sprintf(
				/* translators: %1$s: Site name, %2$s: Review title */
				__( '[%1$s] New Review: "[%2$s]"', 'edd-reviews' ),
				'{sitename}',
				'{title}'
			),
			'content' => edd_reviews()->settings->get_default_review_notification_email(),
			'status'  => 1,
		);
	}

	/**
	 * Gets the preview data for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_preview_data() {
		$reviews = edd_reviews()->query_reviews(
			array(
				'number'  => 10,
				'post_id' => '',
			)
		);
		if ( empty( $reviews ) ) {
			return array( false );
		}
		$count  = count( $reviews );
		$review = $reviews[ wp_rand( 0, $count - 1 ) ];

		return array(
			$review->comment_ID,
		);
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
			'status',
			'recipient',
		);
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_options(): array {
		return array(
			'content'   => 'edd_reviews_settings_emails_notification',
			'subject'   => 'edd_reviews_settings_emails_subject',
			'disabled'  => 'edd_reviews_settings_emails_disable_notifications',
			'recipient' => 'edd_reviews_settings_emails_admin_emails',
		);
	}
}
