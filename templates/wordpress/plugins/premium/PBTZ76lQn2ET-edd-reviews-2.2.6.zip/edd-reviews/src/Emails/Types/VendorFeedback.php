<?php

namespace EDD\Reviews\Emails\Types;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Types\Email;

class VendorFeedback extends Email {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.2.4
	 */
	protected $id = 'review_vendor_feedback';

	/**
	 * The email context.
	 *
	 * @var string
	 * @since 2.2.4
	 */
	protected $context = 'review';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 2.2.4
	 */
	protected $recipient_type = 'vendor';

	/**
	 * The review ID.
	 *
	 * @var int
	 */
	protected $review_id;

	/**
	 * The review object.
	 *
	 * @var \WP_Comment
	 */
	private $review;

	public function __construct( $review_id ) {
		$this->review_id                   = $review_id;
		$review                            = get_comment( $review_id );
		$this->review                      = (array) $review;
		$this->review['id']                = $review_id;
		$this->review['rating']            = get_comment_meta( $review_id, 'edd_rating', true );
		$this->review['item_as_described'] = get_comment_meta( $review_id, 'edd_item_as_described', true );
		$this->review['review_title']      = __( 'Vendor Feedback', 'edd-reviews' );
	}

	/**
	 * Get the email subject.
	 *
	 * @since 2.2.4
	 *
	 * @return string
	 */
	protected function set_email_body_content() {
		$this->raw_body_content = $this->get_template()->content;
	}

	/**
	 * Set the email to address.
	 *
	 * @since 2.2.4
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$this->send_to = get_the_author_meta( 'user_email', get_post_field( 'post_author', $this->review['comment_post_ID'] ) );
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.2.4
	 * @return void
	 */
	protected function set_message() {
		$message       = $this->maybe_apply_autop( $this->get_raw_body_content() );
		$message       = edd_reviews()->email_tags->do_review_tags( $message, $this->review_id, $this->review );
		$this->message = $this->process_tags( $message, $this->review_id, $this->review );
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.2.6
	 * @return void
	 */
	protected function set_subject() {
		$subject       = stripslashes( $this->get_template()->subject );
		$subject       = edd_reviews()->email_tags->do_review_tags( $subject, $this->review_id, $this->review );
		$this->subject = $this->process_tags( $subject, $this->review_id, $this->review );
	}
}
