<?php

namespace EDD\Reviews\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

class Discount extends EmailTemplate {

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 2.2.4
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 2.2.4
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $email_id = 'review_discount';

	/**
	 * The email recipient.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $recipient = 'user';

	/**
	 * The email context.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $context = 'discount';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $sender = 'reviews';

	/**
	 * Name of the template.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_name() {
		return __( 'Reviewer Discount', 'edd-reviews' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_description() {
		return __( 'Email sent to a reviewer to thank them for their review with a discount code.', 'edd-reviews' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Reviewer Discount Code', 'edd-reviews' ),
			'content' => edd_reviews()->settings->get_default_reviewer_discount_email(),
			'status'  => (int) (bool) edd_get_option( 'edd_reviews_reviewer_discount', false ),
		);
	}

	/**
	 * Gets the email context as a label.
	 * This is an optional function to allow for more descriptive labels.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_context_label(): string {
		return __( 'Review is Submitted', 'edd-reviews' );
	}

	/**
	 * Gets the preview data for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_preview_data() {
		$reviews = edd_reviews()->query_reviews(
			array(
				'number'  => 10,
				'post_id' => '',
			)
		);
		if ( empty( $reviews ) ) {
			return array( false );
		}
		$count            = count( $reviews );
		$review           = $reviews[ wp_rand( 0, $count - 1 ) ];
		$args             = get_comment( $review->comment_ID, ARRAY_A );
		$args['discount'] = 'TESTCODE';

		return array(
			$review->comment_ID,
			$args,
		);
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
			'status',
		);
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_options(): array {
		return array(
			'content' => 'edd_reviews_reviewer_discount_email',
			'subject' => 'edd_reviews_reviewer_discount_subject',
		);
	}
}
