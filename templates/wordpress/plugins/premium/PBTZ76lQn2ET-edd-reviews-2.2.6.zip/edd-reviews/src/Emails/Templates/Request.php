<?php

namespace EDD\Reviews\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

class Request extends EmailTemplate {

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 2.2.4
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 2.2.4
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $email_id = 'review_request';

	/**
	 * The email recipient.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $recipient = 'customer';

	/**
	 * The email context.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $context = 'order';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 2.2.4
	 * @var string
	 */
	protected $sender = 'reviews';

	/**
	 * Name of the template.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_name() {
		return __( 'Request a Review', 'edd-reviews' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function get_description() {
		return __( 'Email sent to a customer to ask them to leave a review.', 'edd-reviews' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Leave a review for your recent purchase', 'edd-reviews' ),
			'content' => $this->get_default_content(),
			'status'  => (int) (bool) edd_get_option( 'edd_reviews_request_review_toggle', false ),
		);
	}

	/**
	 * Gets the content for the status tooltip, if needed.
	 *
	 * @since 2.2.6
	 * @return array
	 */
	public function get_status_tooltip(): array {
		$back_date = edd_get_option( 'edd_reviews_request_back_date', false );
		$frequency = edd_get_option( 'edd_reviews_request_review_time_period', false );
		if ( $back_date && $frequency ) {
			return array();
		}

		$content = __( 'This email is not fully enabled.', 'edd-reviews' );
		if ( ! $back_date ) {
			$content .= ' ' . __( 'Please set a start date for the review request email.', 'edd-reviews' );
		} elseif ( ! $frequency ) {
			$content .= ' ' . __( 'Please set a schedule for the review request email.', 'edd-reviews' );
		}

		return array(
			'content'  => $content,
			'dashicon' => 'dashicons-lock',
		);
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
			'status',
		);
	}

	/**
	 * Gets the default email content.
	 *
	 * @since 2.2.4
	 * @return string
	 */
	private function get_default_content() {
		$default_body  = __( 'Dear', 'edd-reviews' ) . ' {name},' . "\n\n";
		$default_body .= sprintf(
			/* translators: %s: Plural label for the product type. */
			__( 'Thank you for your recent purchase. We would appreciate a review to let other customers know about your experience with our %s. Please click on the link(s) below to leave a review.', 'edd-reviews' ),
			strtolower( edd_get_label_plural() )
		) . "\n\n";
		$default_body .= '{review_request}' . "\n\n";
		$default_body .= '{sitename}';

		return $default_body;
	}

	/* Legacy */
	/**
	 * Gets the option names for this email.
	 *
	 * @since 2.2.4
	 * @return array
	 */
	protected function get_options(): array {
		return array(
			'content' => 'edd_reviews_request_review_email',
			'subject' => 'edd_reviews_request_review_subject',
		);
	}
}
