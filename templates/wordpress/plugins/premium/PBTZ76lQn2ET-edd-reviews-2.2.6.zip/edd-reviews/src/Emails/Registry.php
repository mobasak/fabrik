<?php

namespace EDD\Reviews\Emails;

defined( 'ABSPATH' ) || exit;

class Registry {

	/**
	 * Registry constructor.
	 *
	 * @since 2.2.4
	 */
	public function __construct() {
		add_filter( 'edd_email_registered_templates', array( $this, 'register_email_templates' ) );
		add_filter( 'edd_email_registered_types', array( $this, 'register_email_types' ) );
		add_filter( 'edd_email_senders', array( $this, 'register_email_senders' ) );
		add_filter( 'edd_email_contexts', array( $this, 'register_email_contexts' ) );
		add_action( 'edd_email_editor_form', array( $this, 'add_custom_email_settings' ) );
		add_filter( 'edd_email_manager_save_email_id', array( $this, 'save_email_settings' ), 10, 3 );
		add_filter( 'edd_emails_logs_table_object', array( $this, 'update_logs_table_object' ), 10, 2 );
	}

	/**
	 * Registers the email templates.
	 *
	 * @since 2.2.4
	 * @param array $emails
	 * @return array
	 */
	public function register_email_templates( $emails ) {
		$emails['review_notification'] = Templates\ReviewNotification::class;
		$emails['review_discount']     = Templates\Discount::class;
		$emails['review_request']      = Templates\Request::class;

		return $emails;
	}

	/**
	 * Registers the email types.
	 *
	 * @since 2.2.4
	 * @param array $types
	 * @return array
	 */
	public function register_email_types( $types ) {
		$types['review_notification'] = Types\ReviewNotification::class;
		$types['review_discount']     = Types\Discount::class;
		$types['review_request']      = Types\Request::class;

		return $types;
	}

	/**
	 * Registers the email senders.
	 *
	 * @since 2.2.4
	 * @param array $senders
	 * @return array
	 */
	public function register_email_senders( $senders ) {
		$senders['reviews'] = __( 'Reviews', 'edd-reviews' );

		return $senders;
	}

	/**
	 * Registers the email contexts.
	 *
	 * @since 2.2.4
	 * @param array $contexts
	 * @return array
	 */
	public function register_email_contexts( $contexts ) {
		$contexts['review'] = __( 'Review is Submitted', 'edd-reviews' );

		return $contexts;
	}

	/**
	 * Adds the email period field.
	 *
	 * @since 2.2.4
	 * @param \EDD\Emails\Email $email
	 */
	public function add_custom_email_settings( $email ) {
		if ( 'reviews' !== $email->sender ) {
			return;
		}

		if ( 'review_request' === $email->email_id ) {
			$this->add_review_request_period( $email );
		} elseif ( 'review_discount' === $email->email_id ) {
			$this->add_review_discount_setting( $email );
		} elseif ( 'review_notification' === $email->email_id ) {
			$this->add_review_notification_setting( $email );
		}
	}

	/**
	 * Saves the email settings.
	 *
	 * @since 2.2.4
	 * @param bool|string       $email_id
	 * @param \EDD\Emails\Email $email
	 * @param array             $data
	 */
	public function save_email_settings( $email_id, $email, $data ) {
		if ( 'review_discount' === $email->email_id && isset( $data['discount'] ) ) {
			edd_update_option( 'edd_reviews_reviewer_discount_amount', absint( $data['discount'] ) );
		}

		if ( 'review_request' === $email->email_id ) {
			if ( isset( $data['period'] ) ) {
				edd_update_option( 'edd_reviews_request_review_time_period', sanitize_text_field( $data['period'] ) );
			}
			if ( isset( $data['start_date'] ) ) {
				edd_update_option( 'edd_reviews_request_back_date', sanitize_text_field( $data['start_date'] ) );
			}

			wp_clear_scheduled_hook( 'edd_reviews_request_review_scheduled_events' );
			edd_reviews()->request_review->schedule_events();
		}

		if ( 'review_notification' === $email->email_id && isset( $data['moderation'] ) ) {
			edd_update_option( 'edd_reviews_settings_emails_toggle', (int) (bool) $data['moderation'] );
		}

		return $email_id;
	}

	/**
	 * Updates the email logs table object output.
	 *
	 * @since 2.2.4
	 * @param string              $object_id The object ID of the email.
	 * @param EDD\Emails\LogEmail $item      The log item.
	 * @return string
	 */
	public function update_logs_table_object( $object_id, $item ) {
		if ( 'review' !== $item->object_type ) {
			return $object_id;
		}

		return sprintf(
			'<a href="%s">%s</a>',
			edd_get_admin_url(
				array(
					'page' => 'edd-reviews',
					'r'    => absint( $item->object_id ),
					'edit' => 'true',
				)
			),
			/* translators: %s: Review ID */
			sprintf( __( 'Review #%s', 'edd-reviews' ), $item->object_id )
		);
	}

	/**
	 * Adds the review request period field and start date.
	 *
	 * @since 2.2.4
	 * @param \EDD\Emails\Email $email
	 */
	private function add_review_request_period( $email ) {
		$options      = array(
			'now'    => __( 'Immediately', 'edd-reviews' ),
			'6hrs'   => __( '6 Hours Later', 'edd-reviews' ),
			'1day'   => __( 'Next Day', 'edd-reviews' ),
			'3days'  => __( '3 Days Later', 'edd-reviews' ),
			'1week'  => __( '1 Week Later', 'edd-reviews' ),
			'2weeks' => __( '2 Weeks Later', 'edd-reviews' ),
			'1month' => __( '1 Month Later', 'edd-reviews' ),
		);
		$email_period = edd_get_option( 'edd_reviews_request_review_time_period', 'now' );
		?>
		<div class="edd-form-group">
			<label for="edd-notice-period"><?php esc_html_e( 'Schedule Send', 'edd-reviews' ); ?></label>
			<div class="edd-form-group__control">
				<select name="period" id="edd-notice-period">
					<?php foreach ( $options as $period => $label ) : ?>
						<option value="<?php echo esc_attr( $period ); ?>"<?php selected( $period, $email_period ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<p class="description"><?php esc_html_e( 'How long after the order should the email be sent?', 'edd-reviews' ); ?></p>
		</div>
		<div class="edd-form-group">
			<label for="edd-review-start-date"><?php esc_html_e( 'Start Date', 'edd-reviews' ); ?></label>
			<div class="edd-form-group__control">
				<input type="text" name="start_date" id="edd-review-start-date" class="edd_datepicker" value="<?php echo esc_attr( edd_get_option( 'edd_reviews_request_back_date' ) ); ?>" />
				<p class="description"><?php esc_html_e( 'Orders placed prior to this date will not be sent a review request. Leaving this blank will disable review requests.', 'edd-reviews' ); ?></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Adds the discount amount field.
	 *
	 * @since 2.2.4
	 * @param \EDD\Emails\Templates\EmailTemplate $email
	 */
	private function add_review_discount_setting( $email ) {
		if ( 'review_discount' !== $email->email_id ) {
			return;
		}
		?>
		<div class="edd-form-group">
			<label for="edd-reviews-discount"><?php esc_html_e( 'Discount Amount', 'edd-reviews' ); ?></label>
			<div class="edd-form-group__control">
				<input type="number" min="1" max="100" name="discount" placeholder="10" id="edd-reviews-discount" class="small-text" value="<?php echo esc_attr( edd_get_option( 'edd_reviews_reviewer_discount_amount' ) ); ?>" />
			</div>
			<p class="description"><?php esc_html_e( 'The percentage discount amount that will be provided to each reviewer. For example: for 10%, enter 10.', 'edd-reviews' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Adds the moderation setting.
	 *
	 * @since 2.2.4
	 * @param \EDD\Emails\Templates\EmailTemplate $email
	 */
	private function add_review_notification_setting( $email ) {
		if ( 'review_notification' !== $email->email_id ) {
			return;
		}
		?>
		<div class="edd-form-group">
			<label for="edd-reviews-toggle"><?php esc_html_e( 'Send For All Reviews', 'edd-reviews' ); ?></label>
			<div class="edd-form-group__control edd-toggle">
				<input type="hidden" name="moderation" value="0" />
				<input type="checkbox" name="moderation" id="edd-reviews-toggle" value="1" <?php checked( 1, edd_get_option( 'edd_reviews_settings_emails_toggle' ) ); ?> />
				<label for="edd-reviews-toggle"><?php esc_html_e( 'You will always be notified of reviews that require moderation. Enable this to be notified for every review.', 'edd-reviews' ); ?></label>
			</div>
		</div>
		<?php
	}
}
