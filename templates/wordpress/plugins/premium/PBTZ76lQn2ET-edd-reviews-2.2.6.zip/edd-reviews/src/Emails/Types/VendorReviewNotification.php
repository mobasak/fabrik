<?php

namespace EDD\Reviews\Emails\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Vendor Review Notification Email.
 *
 * @since 2.2.6
 */
class VendorReviewNotification extends ReviewNotification {

	/**
	 * The email ID.
	 *
	 * @var string
	 * @since 2.2.6
	 */
	protected $id = 'vendor_review_notification';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 2.2.6
	 */
	protected $recipient_type = 'vendor';

	/**
	 * Set the email to address.
	 *
	 * @since 2.2.6
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$post_author = $this->get_vendor_id();
		if ( $post_author ) {
			$this->send_to = get_the_author_meta( 'user_email', $post_author );
		} else {
			$this->send_to = null;
		}
	}

	/**
	 * Whether the email should be sent.
	 *
	 * @since 2.2.6
	 * @return bool
	 */
	protected function should_send() {
		if ( ! parent::should_send() ) {
			return false;
		}

		return ! empty( $this->get_vendor_id() );
	}

	/**
	 * Get the vendor ID.
	 *
	 * @since 2.2.6
	 * @return int|bool
	 */
	private function get_vendor_id() {
		$post_author = get_post_field( 'post_author', $this->review['comment_post_ID'] );
		if ( EDD_FES()->vendors->user_is_vendor( $post_author ) ) {
			return $post_author;
		}

		return false;
	}
}
