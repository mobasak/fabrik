<?php
/**
 * Voting.php
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2022, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2.2
 */

namespace EDD\Reviews;

use EDD\Reviews\Interfaces\InitializerInterface;
use WP_Comment;

class Voting implements InitializerInterface {

	/**
	 * @inheritDoc
	 */
	public function init() {
		add_action( 'init', array( $this, 'process_non_js_vote' ) );
		add_action( 'wp_ajax_edd_reviews_process_vote', array( $this, 'process_ajax_vote' ) );
		add_action( 'wp_ajax_nopriv_edd_reviews_process_vote', array( $this, 'process_ajax_vote' ) );
	}

	/**
	 * Get the HTML to display the 'helpful' output to the user
	 *
	 * @since 1.3
	 * @access public
	 * @param WP_Comment $review
	 * @return string $output Generated HTML output
	 */
	public function get_comment_helpful_output( $review ) {
		if ( edd_get_option( 'edd_reviews_disable_voting', false ) ) {
			return '';
		}

		if ( $this->is_review_poster( $review ) ) {
			return '';
		}
		ob_start();
		if ( $this->should_show_feedback_message( $review ) ) :
			echo '<div class="edd-review-review-helpful">';
				include edd_reviews()->plugin_path . 'views/voting-success-message.php';
			echo '</div>';
		else :
			include edd_reviews()->plugin_path . 'views/voting-box.php';
		endif;

		return ob_get_clean();
	}

	/**
	 * Whether the feedback message should show.
	 *
	 * @since 2.2.2
	 * @param WP_Comment $review
	 * @return bool
	 */
	private function should_show_feedback_message( $review ) {
		if ( EDD()->session->get( 'wordpress_edd_reviews_voted_' . $review->comment_ID ) ) {
			return true;
		}

		return ! empty( $_GET['edd_reviews_vote'] ) && 'success' === $_GET['edd_reviews_vote'] && ! empty( $_GET['edd_c'] ) && $review->comment_ID == $_GET['edd_c'];
	}

	/**
	 * Conditional whether or not the current logged in user is the poster of
	 * the review being displayed. This function runs throughout the comment
	 * loop and is called for each comment.
	 *
	 * @since 1.2
	 * @access public
	 * @param WP_Comment $comment
	 * @global object    $GLOBALS['comment'] Current comment
	 * @return bool Whether or not the current comment in the loop is by the current user logged in
	 */
	public function is_review_poster( $comment = false ) {
		if ( ! $comment ) {
			$comment = $GLOBALS['comment'];
		}

		$user       = wp_get_current_user();
		$user_email = ( isset( $user->user_email ) ? $user->user_email : null );

		return $comment->comment_author_email === $user_email;
	}

	/**
	 * Display Voting Info
	 *
	 * Example output: 2 of 8 people found this review helpful
	 *
	 * @todo Make the $review parameter required in Reviews 2.3.
	 *
	 * @since 1.0
	 * @access public
	 * @param bool|WP_Comment $review The current comment.
	 * @return void
	 */
	public function display_voting_stats( $review = false ) {

		if ( ! $review instanceof WP_Comment ) {
			if ( false === $review && defined( 'WP_DEBUG' ) && WP_DEBUG && apply_filters( 'edd_deprecated_argument_trigger_error', current_user_can( 'manage_options' ) )) {
				trigger_error(
					'Using display_voting_stats without passing in a review object will not be supported as of Reviews 2.3.',
					E_USER_DEPRECATED
				);
			}
			return;
		}

		$votes = array(
			'yes' => (int) get_comment_meta( $review->comment_ID, 'edd_review_vote_yes', true ),
			'no'  => (int) get_comment_meta( $review->comment_ID, 'edd_review_vote_no', true ),
		);

		if ( ! empty( $votes['yes'] ) && $votes['yes'] >= 1 ) {
			if ( ! is_numeric( $votes['no'] ) ) {
				$votes['no'] = 0;
			}

			$total = $votes['yes'] + $votes['no'];
			?>
			<p class="edd-review-voting-feedback">
				<?php
				/* translators: 1. The number of yes votes 2. The total number of votes. */
				printf( esc_html__( '%1$s of %2$s people found this review helpful.', 'edd-reviews' ), (int) $votes['yes'], (int) $total );
				?>
			</p>
			<?php
		}
	}

	/**
	 * Process Vote from Review
	 *
	 * This function is called if a JavaScript isn't enabled
	 *
	 * @since 1.0
	 * @access public
	 * @return void
	 */
	public function process_non_js_vote() {
		if ( empty( $_GET['edd_c'] ) || ! is_numeric( $_GET['edd_c'] ) || empty( $_GET['edd_review_vote'] ) ) {
			return;
		}
		$review_id = intval( $_GET['edd_c'] );
		$vote      = sanitize_text_field( $_GET['edd_review_vote'] );
		$this->add_comment_vote_meta( $review_id, $vote );

		// Remove the query arguments to prevent multiple votes
		$url = remove_query_arg( array( 'edd_c', 'edd_review_vote' ) );
		$url = add_query_arg(
			array(
				'edd_reviews_vote' => 'success',
				'edd_c'            => urlencode( $review_id ),
			),
			$url
		);
		wp_safe_redirect( $url . '#comment-' . urlencode( $review_id ) );
		die();
	}

	/**
	 * Checks whether an AJAX request has been sent
	 *
	 * @since 1.0
	 * @access public
	 * @return bool Whether or not Reviews AJAX parameters have been passed
	 */
	public function is_ajax_request() {
		return isset( $_POST['edd_reviews_ajax'] ) && ! empty( $_REQUEST['action'] );
	}

	/**
	 * Process Voting for the Reviews via AJAX
	 *
	 * Processes the voting button appended to the bottom of each review by adding
	 * or updating the comment meta via AJAX.
	 *
	 * @since 1.0
	 * @access public
	 *
	 * @return void returns if AJAX check fails
	 */
	public function process_ajax_vote() {
		// Bail if an AJAX request isn't sent
		if ( ! $this->is_ajax_request() ) {
			return;
		}

		check_ajax_referer( 'edd_reviews_voting_nonce', 'security', true );

		if ( ! isset( $_POST['review_vote'] ) ) {
			wp_send_json_error( __( 'Sorry, your vote could not be processed.', 'edd-reviews' ) );
		}
		$review_id = ! empty( $_POST['comment_id'] ) ? (int) $_POST['comment_id'] : false;
		if ( empty( $review_id ) ) {
			wp_send_json_error( __( 'Sorry, your vote could not be processed.', 'edd-reviews' ) );
		}
		$review = get_comment( $review_id );
		if ( ! $review instanceof WP_Comment ) {
			wp_send_json_error( __( 'Sorry, your vote could not be processed.', 'edd-reviews' ) );
		}
		$vote = sanitize_text_field( $_POST['review_vote'] );
		$this->add_comment_vote_meta( $review_id, $vote );

		EDD()->session->set( 'wordpress_edd_reviews_voted_' . $review_id, 'yes' );

		ob_start();
		include edd_reviews()->plugin_path . 'views/voting-success-message.php';
		wp_send_json_success( ob_get_clean() );
	}

	/**
	 * Add Comment Vote
	 *
	 * @since 1.0
	 * @access public
	 *
	 * @param int $comment_id Comment ID
	 * @param string $vote Whether the vote was yes or no
	 * @return void
	 */
	public function add_comment_vote_meta( $comment_id, $vote ) {
		if ( ! in_array( $vote, array( 'yes', 'no' ), true ) ) {
			return;
		}
		$value = get_comment_meta( $comment_id, "edd_review_vote_{$vote}", true );
		$value = absint( $value );
		$value++;

		/**
		 * Delete the comment meta to remove extra rows.
		 * @since 2.2.2
		 * @link https://github.com/awesomemotive/edd-reviews/issues/377
		 * @todo This can possibly be removed in the future.
		 */
		delete_comment_meta( $comment_id, "edd_review_vote_{$vote}" );
		update_comment_meta( $comment_id, "edd_review_vote_{$vote}", $value );
	}
}
