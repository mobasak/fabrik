<?php
/**
 * AssetLoader.php
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2022, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2.2
 */

namespace EDD\Reviews;

use EDD\Reviews\Interfaces\InitializerInterface;

class AssetLoader implements InitializerInterface {

	/**
	 * @inheritDoc
	 */
	public function init() {
		add_action( 'wp_enqueue_scripts', array( $this, 'loadFrontEndCss' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'loadFrontEndJs' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'loadAdminAssets' ) );
	}

	/**
	 * Returns the URL to an asset file.
	 *
	 * @since 2.2.2
	 *
	 * @param string $path Path to the asset, relative to the `assets/` directory.
	 *
	 * @return string
	 */
	private function getAssetUrl( $path ) {
		return edd_reviews()->assets_url . $path;
	}

	/**
	 * Returns the file suffix. Only used for CSS.
	 *
	 * @since 2.2.2
	 *
	 * @return string
	 */
	private function getSuffix() {
		return ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	}

	/**
	 * Loads front-end CSS.
	 *
	 * @since 2.2.2
	 *
	 * @return void
	 */
	public function loadFrontEndCss() {
		/*
		 * `dashicons` needs to be loaded regardless of CSS settings because they
		 * are used to output ratings.
		 * @link https://github.com/easydigitaldownloads/edd-reviews/issues/303
		 */
		wp_enqueue_style( 'dashicons' );

		if ( edd_get_option( 'edd_reviews_disable_css', false ) ) {
			return;
		}

		wp_register_style(
			'edd-reviews',
			$this->getAssetUrl( 'css/edd-reviews' . $this->getSuffix() . '.css' ),
			array( 'dashicons' ),
			edd_reviews()->version
		);

		wp_enqueue_style( 'edd-reviews' );
	}

	/**
	 * Loads the front-end JavaScript.
	 *
	 * @since 2.2.2
	 *
	 * @return void
	 */
	public function loadFrontEndJs() {
		wp_register_script(
			'edd-reviews-js',
			$this->getAssetUrl( 'build/reviews.js' ),
			array( 'jquery' ),
			edd_reviews()->version,
			true
		);

		if ( $this->shouldEnqueueFrontEndJs() ) {
			wp_enqueue_script( 'edd-reviews-js' );
		}

		$edd_reviews_params = array(
			'ajax_url'         => admin_url( 'admin-ajax.php' ),
			'edd_voting_nonce' => wp_create_nonce( 'edd_reviews_voting_nonce' ),
			'thank_you_msg'    => apply_filters( 'edd_reviews_thank_you_for_voting_message', __( 'Thank you for your feedback.', 'edd-reviews' ) ),
			'ajax_loader'      => set_url_scheme( EDD_PLUGIN_URL . 'assets/images/loading.gif', 'relative' ), // Ajax loading image
		);

		wp_localize_script( 'edd-reviews-js', 'edd_reviews_params', apply_filters( 'edd_reviews_js_params', $edd_reviews_params ) );

		/*
		 * Load the WordPress comment_reply JavaScript on singular download pages.
		 */
		global $post;

		if ( is_singular() && $post instanceof \WP_Post && $post->post_type === 'download' && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
	}

	/**
	 * Determines if we should load the front-end JavaScript.
	 *
	 * @since 2.2.2
	 *
	 * @return bool
	 */
	private function shouldEnqueueFrontEndJs() {
		if ( is_singular( 'download' ) ) {
			return true;
		}

		return edd_reviews()->is_fes_installed() &&
		       edd_get_option( 'edd_reviews_vendor_feedback_page', false ) &&
		       is_page( edd_get_option( 'edd_reviews_vendor_feedback_page' ) );
	}

	/**
	 * Loads admin assets.
	 *
	 * @since 2.2.2
	 *
	 * @return void
	 */
	public function loadAdminAssets() {
		wp_register_style(
			'edd-reviews-admin',
			$this->getAssetUrl( 'css/edd-reviews-admin' . $this->getSuffix() . '.css' ),
			array(),
			edd_reviews()->version
		);

		wp_register_script(
			'edd-reviews-admin',
			$this->getAssetUrl( 'build/admin.js' ),
			array( 'jquery', 'wp-ajax-response' ),
			edd_reviews()->version,
			true
		);
		wp_enqueue_script( 'edd-reviews-admin' );

		wp_enqueue_style( 'edd-reviews-admin' );
		wp_enqueue_style( 'wp-color-picker' );

		$edd_reviews_admin_params = array(
			'security' => wp_create_nonce( 'edd-reviews-admin-nonce' ),
		);

		wp_localize_script(
			'edd-reviews-admin',
			'edd_reviews_admin_params',
			apply_filters( 'edd_reviews_admin_params', $edd_reviews_admin_params )
		);
	}

}
