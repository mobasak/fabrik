<?php
/**
 * Request a Review.
 *
 * @package EDD_Reviews
 * @copyright Copyright (c) 2017, Easy Digital Downloads
 * @since 2.1
 */

namespace EDD\Reviews;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Reviews\Interfaces\InitializerInterface;

/**
 * RequestReview Class.
 *
 * @package EDD_Reviews
 * @since 2.1
 */
class RequestReview implements InitializerInterface {

	/**
	 * Constructor Function
	 *
	 * @since 2.1
	 */
	public function init() {
		$this->hooks();
	}

	/**
	 * Adds all the hooks/filters
	 *
	 * Actions are provided to hook on this function, before the hooks and filters
	 * are added and after they are added. The class object is passed via the action.
	 *
	 * @since 2.1
	 * @access public
	 * @return void
	 */
	public function hooks() {
		do_action_ref_array( 'edd_reviews_request_review_before_setup_actions', array( &$this ) );

		/** Actions */
		add_action( 'edd_add_email_tags', array( $this, 'add_email_tag' ) );
		add_action( 'edd_after_payment_actions', array( $this, 'trigger_email' ), 999, 1 );
		add_action( 'wp', array( $this, 'schedule_events' ) );
		add_action( 'edd_reviews_request_review_scheduled_events', array( $this, 'trigger_events' ) );
		add_action( 'updated_option', array( $this, 'clear_events' ), 10, 3 );

		/** Filters */
		add_filter( 'edd_reviews_email_settings', array( $this, 'settings' ) );

		do_action_ref_array( 'edd_reviews_request_review_after_setup_actions', array( &$this ) );
	}

	/**
	 * Register Reviews settings.
	 *
	 * @since  2.1
	 * @access public
	 *
	 * @param array $settings Registered email settings.
	 * @return array $settings New settings.
	 */
	public function settings( $settings ) {
		$new = array(
			array(
				'id'   => 'edd_reviews_request_review_settings',
				'name' => '<h3>' . __( 'Request a Review', 'edd-reviews' ) . '</h3>',
				'type' => 'header',
			),
			array(
				'id'    => 'edd_reviews_request_review_toggle',
				'name'  => __( 'Enable Request a Review', 'edd-reviews' ),
				'check' => __( 'Enable the request a review feature to send an email to customers to leave a review.', 'edd-reviews' ),
				'type'  => function_exists( 'edd_checkbox_toggle_callback' ) ? 'checkbox_toggle' : 'checkbox_description',
			),
			array(
				'id'      => 'edd_reviews_request_review_time_period',
				'name'    => __( 'When to send?', 'edd-reviews' ),
				'desc'    => __( 'How long after the purchase should the email be sent', 'edd-reviews' ),
				'type'    => 'select',
				'options' => array(
					'now'    => __( 'Immediately', 'edd-reviews' ),
					'6hrs'   => __( '6 Hours Later', 'edd-reviews' ),
					'1day'   => __( 'Next Day', 'edd-reviews' ),
					'3days'  => __( '3 Days Later', 'edd-reviews' ),
					'1week'  => __( '1 Week Later', 'edd-reviews' ),
					'2weeks' => __( '2 Weeks Later', 'edd-reviews' ),
					'1month' => __( '1 Month Later', 'edd-reviews' ),
				),
			),
			array(
				'id'          => 'edd_reviews_request_back_date',
				'name'        => __( 'Start Date', 'edd-reviews' ),
				'desc'        => __( 'Orders placed prior to this date will not be sent a review request. Leaving this blank will disable review requests.', 'edd-reviews' ),
				'type'        => 'text',
				'field_class' => 'edd_datepicker',
			),
			array(
				'id'   => 'edd_reviews_request_review_subject',
				'name' => __( 'Review Request Subject', 'edd-reviews' ),
				'desc' => __( 'Enter the subject line for the review request email', 'edd-reviews' ),
				'type' => 'text',
				'size' => 'regular',
				'std'  => '',
			),
			array(
				'id'   => 'edd_reviews_request_review_email',
				'name' => __( 'Email Content', 'edd-reviews' ),
				'desc' => __( 'Enter the text that is sent to the customer requesting a review. HTML is accepted.', 'edd-reviews' ) . '<br />' . edd_get_emails_tags_list(),
				'type' => 'rich_editor',
				'std'  => $this->get_email_body_contents( 0, null ),
			),
		);

		return array_merge( $settings, $new );
	}

	/**
	 * Add {review_request_email_tag} Email Tag.
	 *
	 * @since 2.1
	 * @access public
	 */
	public function add_email_tag() {
		edd_add_email_tag(
			'review_request',
			/* translators: the plural download label */
			sprintf( __( 'Adds links to request a review for all %s.', 'edd-reviews' ), strtolower( edd_get_label_plural() ) ),
			array( $this, 'review_request_email_tag' ),
			__( 'Request a Review', 'edd-reviews' )
		);
	}

	/**
	 * Parse {review_request_email_tag} Email Tag.
	 *
	 * @since 2.1
	 * @access public
	 */
	public function review_request_email_tag( $payment_id ) {
		$order = edd_get_order( $payment_id );
		$list  = '';
		if ( $order->items ) {
			$list = '<ul>';

			foreach ( $order->items as $item ) {
				if ( edd_reviews()->is_review_status( 'closed', $item->product_id ) || edd_reviews()->is_review_status( 'disabled', $item->product_id ) ) {
					continue;
				}

				/**
				 * Filter the link displayed to leave a review.
				 *
				 * @since 2.1
				 */
				$title = apply_filters( 'edd_reviews_request_review_email_title', '<strong><a href="' . edd_reviews()->get_form_link( $item->product_id ) . '">' . get_the_title( $item->product_id ) . '</a></strong>' );

				$list .= '<li>' . $title . '</li>';
			}

			$list .= '</ul>';
		}

		return $list;
	}

	/**
	 * Default email body.
	 *
	 * @access public
	 * @since  2.1
	 * @return string Email body.
	 */
	public function get_email_body_contents() {
		$default_body = __( 'Dear', 'edd-reviews' ) . ' {name},' . "\n\n";
		/* translators: %s: Plural label for the product type */
		$default_body .= sprintf( __( 'Thank you for your recent purchase. We would appreciate a review to let other customers know about your experience with our %s. Please click on the link(s) below to leave a review.', 'edd-reviews' ), strtolower( edd_get_label_plural() ) ) . "\n\n";
		$default_body .= '{review_request}' . "\n\n";
		$default_body .= '{sitename}';

		$email = edd_get_option( 'edd_reviews_request_review_email', false );
		$email = $email ? stripslashes( $email ) : $default_body;

		$email_body = apply_filters( 'edd_email_template_wpautop', true ) ? wpautop( $email ) : $email;

		/**
		 * Filter the email contents.
		 *
		 * @since 2.1
		 *
		 * @param string $email_body Email body.
		 */
		return apply_filters( 'edd_reviews_request_review_email_contents', $email_body );
	}

	/**
	 * Trigger the email to be sent.
	 *
	 * @since 2.1
	 * @access public
	 *
	 * @param  int  $payment_id Payment ID.
	 * @param  bool $deprecated Deprecated in 2.2.3 because it is not used.
	 * @return void
	 */
	public function trigger_email( $payment_id, $deprecated = false ) {
		if ( ! $this->email_is_enabled() ) {
			return;
		}

		$edd_action = filter_input( INPUT_POST, 'edd-action', FILTER_SANITIZE_SPECIAL_CHARS );
		if ( 'edit_payment' === $edd_action ) {
			return;
		}

		if ( ! empty( edd_get_order_meta( $payment_id, '_edd_sl_is_renewal', true ) ) ) {
			return;
		}

		$order       = edd_get_order( $payment_id );
		$should_send = false;

		foreach ( $order->items as $item ) {
			if ( ! edd_reviews()->is_review_status( 'closed', $item->id ) && ! edd_reviews()->is_review_status( 'disabled', $item->id ) ) {
				$should_send = true;
				break;
			}
		}

		if ( ! $should_send ) {
			return;
		}

		$payment_date = $order->date_completed;

		// Fallback to payment created date if `date_completed` does not exist.
		// @link https://github.com/easydigitaldownloads/easy-digital-downloads/issues/7706
		if ( empty( $payment_date ) ) {
			$payment_date = $order->date_created;
		}

		$comparison_time = $this->get_time_period();
		if ( false !== $comparison_time && $payment_date <= $comparison_time ) {
			$this->send_email( $payment_id );
			edd_update_order_meta( $payment_id, 'edd_reviews_request_review', 1 );
		}
	}

	/**
	 * Setup and send the email.
	 *
	 * @since  2.1
	 * @access public
	 *
	 * @param int $payment_id Payment ID.
	 * @return void|bool False if payment not found, void otherwise.
	 */
	public function send_email( $payment_id = 0 ) {
		$payment_id = absint( $payment_id );
		$order      = edd_get_order( $payment_id );
		if ( ! $order ) {
			return false;
		}

		if ( class_exists( '\\EDD\\Emails\\Email' ) ) {
			$email = \EDD\Emails\Registry::get( 'review_request', array( $order ) );
			$email->send();
			return;
		}

		$subject = edd_get_option( 'edd_reviews_request_review_subject', __( 'Leave a review for your recent purchase', 'edd-reviews' ) );
		$subject = apply_filters( 'edd_reviews_request_review_subject', wp_strip_all_tags( $subject ), $payment_id );
		$subject = edd_do_email_tags( $subject, $payment_id );

		$message = $this->get_email_body_contents();
		$message = edd_do_email_tags( $message, $payment_id );

		$emails = EDD()->emails;
		$emails->__set( 'heading', __( 'Leave a Review', 'edd-reviews' ) );

		$emails->send( $order->email, $subject, $message );

		do_action( 'edd_reviews_request_review_send_email', $payment_id, $payment );
	}

	/**
	 * Maybe schedule cron events if the email is enabled and the time period is set.
	 *
	 * @since 2.1
	 * @return void
	 */
	public function schedule_events() {
		if ( wp_next_scheduled( 'edd_reviews_request_review_scheduled_events' ) ) {
			return;
		}

		$frequency = edd_get_option( 'edd_reviews_request_review_time_period', false );
		if ( false === $frequency ) {
			return;
		}

		if ( ! $this->email_is_enabled() ) {
			return;
		}

		$schedule = 'daily';
		if ( '6hrs' === $frequency ) {
			$schedule = 'hourly';
		}

		wp_schedule_event( time(), $schedule, 'edd_reviews_request_review_scheduled_events' );
	}

	/**
	 * Trigger the scheduled events.
	 *
	 * @since 2.1
	 * @access public
	 * @return void
	 */
	public function trigger_events() {
		if ( ! $this->email_is_enabled() ) {
			return;
		}

		$orders = edd_get_orders(
			array(
				'number'     => 999999,
				'date_query' => array(
					'after'  => edd_get_option( 'edd_reviews_request_back_date' ),
					'before' => $this->get_time_period(),
				),
				'meta_query' => array(
					'relation' => 'OR',
					array(
						'key'   => 'edd_reviews_request_review',
						'value' => 0,
					),
					array(
						'key'     => 'edd_reviews_request_review',
						'compare' => 'NOT EXISTS',
					),
				),
				'status'     => 'complete',
			)
		);

		foreach ( $orders as $order ) {
			$this->trigger_email( $order->id );
		}
	}

	/**
	 * Clear the scheduled events.
	 *
	 * @since 2.2.6
	 *
	 * @param string $option_name Option name.
	 * @param mixed  $old_value   Old value.
	 * @param mixed  $new_value   New value.
	 * @return void
	 */
	public function clear_events( $option_name, $old_value, $new_value ) {
		if ( 'edd_settings' !== $option_name ) {
			return;
		}
		if ( class_exists( '\\EDD\\Emails\\Email' ) ) {
			return;
		}

		if ( ( empty( $old_value['edd_reviews_request_review_time_period'] ) || empty( $new_value['edd_reviews_request_review_time_period'] ) ) || ( $old_value['edd_reviews_request_review_time_period'] !== $new_value['edd_reviews_request_review_time_period'] ) ) {
			wp_clear_scheduled_hook( 'edd_reviews_request_review_scheduled_events' );
			$this->schedule_events();
		}
	}

	/**
	 * Check if the email is enabled.
	 *
	 * @since 2.2.6
	 * @return bool True if enabled, false otherwise.
	 */
	private function email_is_enabled() {
		if ( empty( edd_get_option( 'edd_reviews_request_back_date', false ) ) ) {
			return false;
		}

		if ( function_exists( 'edd_get_email' ) ) {
			$email = edd_get_email( 'review_request' );

			return $email && $email->is_enabled();
		}

		return ! empty( edd_get_option( 'edd_reviews_request_review_toggle', false ) );
	}

	/**
	 * Get the time period.
	 *
	 * @since 2.2.6
	 * @return string|bool Time period.
	 */
	private function get_time_period() {
		$time_period = edd_get_option( 'edd_reviews_request_review_time_period', false );

		// In EDD 3.0, the order date is stored in UTC.
		$now = time(); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested

		switch ( $time_period ) {
			case '6hrs':
				$comparison_time = strtotime( '-6 hours', $now );
				break;
			case '1day':
				$comparison_time = strtotime( '-1 day', $now );
				break;
			case '3days':
				$comparison_time = strtotime( '-3 days', $now );
				break;
			case '1week':
				$comparison_time = strtotime( '-7 days', $now );
				break;
			case '2weeks':
				$comparison_time = strtotime( '-14 days', $now );
				break;
			case '1month':
				$comparison_time = strtotime( '-30 days', $now );
				break;
			case 'now':
				$comparison_time = $now;
				break;
			// Unknown/unregistered timeframe.
			default:
				$comparison_time = false;
		}

		return $comparison_time ? date( 'Y-m-d H:i:s', $comparison_time ) : false; // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
	}

	/**
	 * Add cron schedules.
	 *
	 * @since 2.1
	 * @deprecated 2.2.6
	 * @return array $schedules CRON schedules.
	 */
	public function add_schedules( $schedules = array() ) {
		$schedules['6hrs'] = array(
			'interval' => 21600,
			'display'  => __( '6 Hours Later', 'edd-reviews' ),
		);

		$schedules['1day'] = array(
			'interval' => 86400,
			'display'  => __( 'Next Day', 'edd-reviews' ),
		);

		$schedules['3days'] = array(
			'interval' => 259200,
			'display'  => __( 'Three Days Later', 'edd-reviews' ),
		);

		$schedules['1week'] = array(
			'interval' => 604800,
			'display'  => __( 'Next Week', 'edd-reviews' ),
		);

		return $schedules;
	}
}
