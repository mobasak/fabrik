<?php
/**
 * DeprecatedMethodRouter.php
 *
 * Handles rerouting methods that have been deprecated in the main `EDD_Reviews` class
 * to their new home.
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2022, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2.2
 */

namespace EDD\Reviews\Compat;

class DeprecatedMethodRouter {

	/**
	 * A list of deprecated methods, their replacement, and the version they were deprecated in.
	 *
	 * The key is the name of the old method, as it was in `EDD_Reviews`.
	 *
	 * @since 2.2.2
	 *
	 * @return array[]
	 */
	public function getDeprecatedMethods() {
		return array(
			'load_styles'          => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->assetLoader, 'loadFrontEndCss' ),
			),
			'load_scripts'         => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->assetLoader, 'loadFrontEndJs' ),
			),
			'admin_scripts'        => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->assetLoader, 'loadAdminAssets' ),
			),
			'reviews_reply_script' => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->assetLoader, 'loadFrontEndJs' ),
			),
			'register_api_mode'    => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->apiv1, 'register_api_mode' ),
			),
			'api_output'           => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->apiv1, 'api_output' ),
			),
			'query_vars'           => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->apiv1, 'query_vars' ),
			),
			'get_comment_helpful_output' => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->voting, 'get_comment_helpful_output' ),
			),
			'is_review_poster'           => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->voting, 'is_review_poster' ),
			),
			'voting_info' => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->voting, 'display_voting_stats' ),
			),
			'process_vote'               => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->voting, 'process_non_js_vote' ),
			),
			'is_ajax_request'            => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->voting, 'is_ajax_request' ),
			),
			'process_ajax_vote'          => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->voting, 'process_ajax_vote' ),
			),
			'add_comment_vote_meta'      => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->voting, 'add_comment_vote_meta' ),
			),
			'register_reviews_section'   => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->settings, 'register_section' ),
			),
			'register_emails_section'    => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->settings, 'register_section' ),
			),
			'misc_settings'              => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->settings, 'misc_settings' ),
			),
			'settings_emails'            => array(
				'version'     => '2.2.2',
				'replacement' => array( edd_reviews()->settings, 'settings_emails' ),
			),
		);
	}

	/**
	 * Handles re-routing a deprecated method.
	 *
	 * @since 2.2.2
	 *
	 * @param string $method Name of the method, as it was in `EDD_Reviews`.
	 * @param array  $args   Method arguments.
	 *
	 * @return void
	 */
	public function handleDeprecation( $method, $args ) {
		$deprecationInfo = $this->isMethodDeprecated( $method )
			? $this->getDeprecatedMethods()[ $method ]
			: null;

		$deprecatedVersion = isset( $deprecationInfo['version'] ) ? $deprecationInfo['version'] : edd_reviews()->version;
		$replacement       = isset( $deprecationInfo['replacement'] ) ? $deprecationInfo['replacement'] : null;

		_edd_deprecated_function(
			\EDD_Reviews::class . '::' . $method,
			$deprecatedVersion,
			$this->makeReplacementString( $replacement )
		);

		if ( ! empty( $replacement ) ) {
			call_user_func_array(
				$replacement,
				$args
			);
		}
	}

	/**
	 * Determines if the provided method has been deprecated and
	 * is supported via this handler.
	 *
	 * @since 2.2.2
	 *
	 * @param string $method Name of the method.
	 *
	 * @return bool
	 */
	public function isMethodDeprecated( $method ) {
		return array_key_exists( $method, $this->getDeprecatedMethods() );
	}

	/**
	 * Makes a replacement string that can be used in `_edd_deprecated_function()`.
	 *
	 * @param string|null|array $replacement
	 *
	 * @return string|null
	 */
	private function makeReplacementString( $replacement ) {
		if ( is_null( $replacement ) || is_string( $replacement ) ) {
			return $replacement;
		}

		if ( ! is_array( $replacement ) || ! isset( $replacement[0] ) || ! isset( $replacement[1] ) ) {
			return null;
		}

		$replacementString = '';
		if ( is_object( $replacement[0] ) ) {
			$replacementString .= get_class( $replacement[0] ) . '::';
		}

		if ( is_string( $replacement[1] ) ) {
			$replacementString .= $replacement[1];
		}

		return $replacementString;
	}

}
