<?php
/**
 * REST API Endpoint
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2021, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2
 */

namespace EDD\Reviews\API\v1;

abstract class Endpoint {

	public static $namespace = 'edd-reviews/v1';

	/**
	 * Registers the endpoint(s).
	 *
	 * @since 2.2
	 *
	 * @return void
	 */
	abstract public function register();

	/**
	 * Determines whether the current user is able to perform the action.
	 *
	 * @since 2.2
	 *
	 * @return bool|\WP_Error
	 */
	public function permissionsCheck() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new \WP_Error(
				'rest_forbidden',
				__( 'You do not have permission to perform this action.', 'edd-reviews' ),
				array( 'status' => is_user_logged_in() ? 403 : 401 )
			);
		}

		return true;
	}

}
