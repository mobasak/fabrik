<?php
/**
 * Reviews API Endpoint
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2021, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2
 */

namespace EDD\Reviews\API\v1;

class Reviews extends Endpoint {

	/**
	 * Registers the endpoint(s).
	 *
	 * @since 2.2
	 *
	 * @return void
	 */
	public function register() {
		register_rest_route(
			self::$namespace,
			'reviews/product/(?P<product_id>\d+)',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'listProductReviews' ),
				'permission_callback' => array( $this, 'permissionsCheck' ),
				'args'                => array(
					'product_id' => array(
						'required'          => true,
						'validate_callback' => function ( $param, $request, $key ) {
							return 'download' === get_post_type( $param );
						},
						'sanitize_callback' => function ( $param, $request, $key ) {
							return intval( $param );
						}
					)
				)
			)
		);

		register_rest_route(
			self::$namespace,
			'reviews/(?P<id>\d+)',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'getReview' ),
				'permission_callback' => array( $this, 'permissionsCheck' ),
				'args'                => array(
					'id' => array(
						'required'          => true,
						'validate_callback' => function ( $param, $request, $key ) {
							return 'edd_review' === get_comment_type( $param );
						},
						'sanitize_callback' => function ( $param, $request, $key ) {
							return intval( $param );
						}
					)
				)
			)
		);
	}

	/**
	 * Lists reviews for a product.
	 *
	 * @since 2.2
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_REST_Response
	 */
	public function listProductReviews( $request ) {
		global $wpdb;
		$formattedReviews = array();
		$reviews          = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->commentmeta}
			INNER JOIN {$wpdb->comments} ON {$wpdb->commentmeta}.comment_id = {$wpdb->comments}.comment_ID
			WHERE {$wpdb->commentmeta}.meta_key = %s
			AND {$wpdb->comments}.comment_post_ID = %d",
			'edd_review_title',
			$request->get_param( 'product_id' )
		) );

		foreach ( $reviews as $review ) {
			if ( ! empty( $review->comment_id ) ) {
				$formattedReviews[] = array(
					'id'    => $review->comment_id,
					'title' => ! empty( $review->meta_value ) ? $review->meta_value : sprintf( __( 'Review #%d', 'edd-reviews' ), $review->comment_id ),
				);
			}
		}

		return new \WP_REST_Response( array(
			'data' => $formattedReviews,
		) );
	}

	/**
	 * Retrieves an individual review.
	 *
	 * @since 2.2
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_REST_Response
	 */
	public function getReview( $request ) {
		$review = get_comment( $request->get_param( 'id' ) );

		if ( empty( $review ) ) {
			return new \WP_REST_Response( null, 404 );
		}

		return new \WP_REST_Response( array(
			'id'             => $review->comment_ID,
			'date'           => get_comment_date( 'Y-m-d H:i:s', $review->comment_ID ),
			'date_formatted' => get_comment_date( apply_filters( 'edd_reviews_widget_date_format', get_option( 'date_format' ) ), $review->comment_ID ),
			'author_id'      => $review->comment_author,
			'author_name'    => get_comment_author( $review->comment_ID ),
			'title'          => get_comment_meta( $review->comment_ID, 'edd_review_title', true ),
			'rating'         => get_comment_meta( $review->comment_ID, 'edd_rating', true ),
			'body'           => $review->comment_content,
		) );
	}
}
