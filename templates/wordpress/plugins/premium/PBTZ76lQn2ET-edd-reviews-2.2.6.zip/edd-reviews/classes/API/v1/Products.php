<?php
/**
 * Products API Endpoint
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2021, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2
 */

namespace EDD\Reviews\API\v1;

class Products extends Endpoint {

	/**
	 * Registers the endpoint(s).
	 *
	 * @since 2.2
	 *
	 * @return void
	 */
	public function register() {
		register_rest_route(
			self::$namespace,
			'products',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'listProducts' ),
				'permission_callback' => array( $this, 'permissionsCheck' ),
			)
		);
	}

	/**
	 * Lists products that have at least one review.
	 *
	 * @since 2.2
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @return \WP_REST_Response
	 */
	public function listProducts( \WP_REST_Request $request ) {
		global $wpdb;

		$productIdsWithReviews = $wpdb->get_col(
			"SELECT DISTINCT comment_post_ID
			FROM {$wpdb->comments}
			WHERE comment_type = 'edd_review'"
		);

		if ( empty( $productIdsWithReviews ) ) {
			return new \WP_REST_Response( array(
				'data' => array(),
			) );
		}

		$products = get_posts( array(
			'post__in'       => array_map( 'intval', $productIdsWithReviews ),
			'post_type'      => 'download',
			'post_status'    => 'any',
			'posts_per_page' => - 1,
			'orderby'        => 'title',
			'order'          => 'asc',
		) );

		if ( empty( $products ) ) {
			return new \WP_REST_Response( array(
				'data' => array(),
			) );
		}

		$products = array_map( function ( $product ) {
			return array(
				'id'    => $product->ID,
				'title' => $product->post_title,
			);
		}, $products );

		return new \WP_REST_Response( array(
			'data' => $products,
		) );
	}
}
