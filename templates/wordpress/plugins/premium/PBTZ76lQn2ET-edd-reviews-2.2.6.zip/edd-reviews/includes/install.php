<?php

/**
 * This file is loaded by the activation function,
 * if the installation flag has been set.
 */
function edd_reviews_install() {

	flush_rewrite_rules();

	// Create the Vendor Feedback page if it doesn't exist
	$options = get_option( 'edd_settings' );

	if ( ! isset( $options['edd_reviews_vendor_feedback_page'] ) && class_exists( 'EDD_Front_End_Submissions' ) ) {
		$feedback = wp_insert_post(
			array(
				'post_title'     => __( 'Vendor Feedback', 'edd-reviews' ),
				'post_content'   => '[edd_reviews_vendor_feedback]',
				'post_status'    => 'publish',
				'post_author'    => 1,
				'post_type'      => 'page',
				'comment_status' => 'closed',
			)
		);

		$options['edd_reviews_vendor_feedback_page'] = $feedback;
		update_option( 'edd_settings', $options );
	}

	// Initialise upgrade routine
	$version = get_option( 'edd_reviews_version' );

	if ( empty( $version ) ) {
		global $wpdb;
		$has_reviews   = $wpdb->get_var( "SELECT {$wpdb->comments}.comment_ID FROM {$wpdb->commentmeta} LEFT JOIN {$wpdb->comments} ON {$wpdb->commentmeta}.comment_id = {$wpdb->comments}.comment_ID WHERE {$wpdb->comments}.comment_type != 'edd_review' AND {$wpdb->commentmeta}.meta_key = 'edd_review_title' AND 1=1 LIMIT 1" );
		$needs_upgrade = ! empty( $has_reviews );
		if ( ! $needs_upgrade ) {
			edd_set_upgrade_complete( 'reviews_upgrade_20_database' );
			update_option( 'edd_reviews_version', preg_replace( '/[^0-9.].*/', '', edd_reviews()->version ) );
			delete_option( 'edd_doing_upgrade' );
		}
	}
}
