<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<button class="bookly-go-to-cart bookly-js-go-to-cart bookly-round bookly-round-md ladda-button"><span><img width="20" src="<?php echo plugins_url( 'frontend/resources/images/cart.svg', \BooklyCart\Lib\Plugin::getMainFile() ) ?>"/></span>
</button>