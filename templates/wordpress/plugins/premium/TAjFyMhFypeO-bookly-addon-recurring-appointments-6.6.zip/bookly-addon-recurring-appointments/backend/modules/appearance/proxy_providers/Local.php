<?php
namespace BooklyRecurringAppointments\Backend\Modules\Appearance\ProxyProviders;

use Bookly\Backend\Modules\Appearance\Proxy;
use BooklyRecurringAppointments\Lib;

class Local extends Proxy\RecurringAppointments
{
    /**
     * @inheritDoc
     */
    public static function renderInfoMessage()
    {
        self::renderTemplate( 'info_message' );
    }

    /**
     * @inheritDoc
     */
    public static function renderShowStep()
    {
        self::renderTemplate( 'show_repeat_step' );
    }

    /**
     * @inheritDoc
     */
    public static function renderStep( $progress_tracker )
    {
        self::renderTemplate( 'repeat_step', compact( 'progress_tracker' ) );
    }

    /**
     * @inheritDoc
     */
    public static function renderRepeatStepSettings()
    {
        self::renderTemplate( 'repeat_step_settings' );
    }
}