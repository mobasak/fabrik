<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Controls\Inputs;
?>
<div class="bookly-js-repeat-settings bookly-collapse">
    <div class="row">
        <div class='col-md-3 my-2'>
            <?php Inputs::renderCheckBox( __( 'Hide times input', 'bookly' ), null, get_option( 'bookly_recurring_appointments_hide_times_input' ), array( 'id' => 'bookly-js-app-hide-times-input' ) ) ?>
        </div>
    </div>
</div>