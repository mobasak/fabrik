<?php
namespace BooklyRecurringAppointments\Backend\Components\Dialogs\Appointment\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy\RecurringAppointments as RecurringAppointmentsProxy;
use Bookly\Lib\Entities\Payment;
use BooklyPro\Lib\Config;
use BooklyPro\Lib\Utils;

class Local extends RecurringAppointmentsProxy
{
    /**
     * @inheritDoc
     */
    public static function createBackendPayment( BooklyLib\Entities\Series $series, $customer )
    {
        $price = $customer['payment_price'];
        $tax   = $customer['payment_tax'] ?: 0;

        /** @var BooklyLib\Entities\CustomerAppointment[] $ca_list */
        $ca_list = BooklyLib\Entities\CustomerAppointment::query( 'ca' )
            ->leftJoin( 'Appointment', 'a', 'a.id = ca.appointment_id' )
            ->where( 'ca.series_id', $series->getId() )
            ->where( 'ca.customer_id', $customer['id'] )
            ->sortBy( 'a.start_date' )
            ->find();

        $service_id = $ca_list
            ? BooklyLib\Entities\Appointment::find( $ca_list[0]->getAppointmentId() )->getServiceId()
            : null;
        $payment = new Payment();
        $payment
            ->setTax( $customer['payment_tax'] )
            ->setPaid( 0 )
            ->setStatus( Payment::STATUS_PENDING );
        $details = $payment->getDetailsData();

        $service_price = $customer['payment_price'] / count( $ca_list );
        $service_tax = $payment->getTax() / count( $ca_list );

        foreach ( $ca_list as $ca ) {
            $app_details = new BooklyLib\DataHolders\Details\Appointment();
            $app_details->setCa( $ca )
                ->setData( compact( 'service_price', 'service_tax' ) )
                ->setPrice( $service_price );
            $details->addDetails( $app_details );
        }

        $total = $customer['payment_price'];

        if ( get_option( 'bookly_taxes_in_price' ) == 'excluded' ) {
            $total += $payment->getTax();
        }
        $client = BooklyLib\Entities\Customer::find( $customer['id'] );
        $details
            ->setCustomer( $client )
            ->setData( array( 'from_backend' => true ) );
        if ( Config::needCreateWCOrder( $total ) ) {
            $wc_order = Utils\Common::createWCOrder( $service_id, $price, $tax, $client->getWpUserId() );
            $details->setData( array( 'gateway_ref_id' => $wc_order->get_id() ) );

            $payment
                ->setType( Payment::TYPE_WOOCOMMERCE )
                ->setStatus( Payment::STATUS_COMPLETED )
                ->setPaid( $total );
        } else {
            $payment
                ->setType( Payment::TYPE_LOCAL )
                ->setStatus( Payment::STATUS_PENDING )
                ->setPaid( 0 );
        }
        $payment
            ->setTotal( $total )
            ->setTax( $tax )
            ->save();

        foreach ( $ca_list as $ca ) {
            $ca->setPaymentId( $payment->getId() )->save();
        }
    }

    /**
     * @inerhitDoc
     */
    public static function attachBackendPayment( BooklyLib\Entities\Series $series, $customer )
    {
        BooklyLib\Entities\CustomerAppointment::query()
            ->update()
            ->set( 'payment_id', $customer['payment_id'] )
            ->where( 'series_id', $series->getId() )
            ->where( 'customer_id', $customer['id'] )
            ->execute();
    }

    /**
     * @return string[]
     */
    public static function getWeekDays()
    {
        $start_of_week = get_option( 'start_of_week' );
        $weekdays      = array( 'sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat' );

        // Sort days considering start_of_week;
        uksort( $weekdays, function ( $a, $b ) use ( $start_of_week ) {
            $a -= $start_of_week;
            $b -= $start_of_week;
            if ( $a < 0 ) {
                $a += 7;
            }
            if ( $b < 0 ) {
                $b += 7;
            }

            return $a - $b;
        } );

        return $weekdays;
    }
}