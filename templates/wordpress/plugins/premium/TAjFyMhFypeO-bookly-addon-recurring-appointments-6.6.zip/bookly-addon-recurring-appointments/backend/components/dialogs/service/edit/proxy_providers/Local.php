<?php
namespace BooklyRecurringAppointments\Backend\Components\Dialogs\Service\Edit\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Service\Edit\Proxy;

class Local extends Proxy\RecurringAppointments
{
    /**
     * @inheritDoc
     */
    public static function renderSubForm( array $service )
    {
        $frequencies = array( 'daily', 'weekly', 'biweekly', 'monthly' );
        $recurrence_frequencies = explode( ',', $service['recurrence_frequencies'] );

        self::renderTemplate( 'recurring', compact( 'service', 'recurrence_frequencies', 'frequencies' ) );
    }
}