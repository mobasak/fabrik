<?php
namespace BooklyRecurringAppointments\Frontend\Modules\Booking\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Frontend\Modules\Booking\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function enqueueBookingScripts( array $depends )
    {
        self::enqueueScripts( array(
            'alias' => array( 'bookly-moment.min.js' ),
        ) );

        return $depends;
    }

    /**
     * @inheritDoc
     */
    public static function stepOptions( array $options, $step, $userData )
    {
        if ( $step == 'repeat' ) {
            $schedule = array();
            // Available days and times.
            $bounding = BooklyLib\Config::getDateLimits();
            $slots = $userData->getSlots();
            $datetime = date_create( $slots[0][2] );
            $date_min = array(
                (int) $datetime->format( 'Y' ),
                (int) $datetime->format( 'n' ) - 1,
                (int) $datetime->format( 'j' ),
            );
            $repeat_data = $userData->getRepeatData();
            if ( $repeat_data ) {
                $until = BooklyLib\Slots\DatePoint::fromStrInClientTz( $repeat_data['until'] );
                foreach ( $slots as $slot ) {
                    $date = BooklyLib\Slots\DatePoint::fromStr( $slot[2] );
                    if ( $until->lt( $date ) ) {
                        $until = $date->toClientTz();
                    }
                }

                $schedule = Proxy\RecurringAppointments::buildSchedule(
                    clone $userData,
                    $slots[0][2],
                    $until->format( 'Y-m-d' ),
                    $repeat_data['repeat'],
                    $repeat_data['params'],
                    array_map( function( $slot ) { return $slot[2]; }, $slots )
                );
            }

            $options['schedule'] = $schedule;
            $options['repeated'] = (int) $userData->getRepeated();
            $options['repeat_data'] = $userData->getRepeatData();
            $options['short_date_format'] = BooklyLib\Utils\DateTime::convertFormat( 'D, M d', BooklyLib\Utils\DateTime::FORMAT_MOMENT_JS );
            $options['pages_warning_info'] = nl2br( BooklyLib\Utils\Common::getTranslatedOption( 'bookly_l10n_repeat_schedule_help' ) );
            $options['could_be_repeated'] = Proxy\RecurringAppointments::canBeRepeated( true, $userData );
            $options['date_max'] = $bounding['date_max'];
            $options['date_min'] = $date_min;
        }

        return $options;
    }

    /**
     * @inheriDoc
     */
    public static function booklyFormOptions( array $bookly_options )
    {
        if ( get_option( 'bookly_recurring_appointments_enabled' )
            && $bookly_options['skip_steps']['service_part1']
            && $bookly_options['skip_steps']['service_part2']
            && $bookly_options['defaults']['service_id']
        ) {
            $bookly_options['recurrence_enabled'] = (int) BooklyLib\Entities\Service::find( $bookly_options['defaults']['service_id'] )->getRecurrenceEnabled();
        }

        return $bookly_options;
    }
}