<?php
namespace BooklyRecurringAppointments\Frontend\Modules\ModernBookingForm\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Frontend\Modules\ModernBookingForm\Proxy;
use BooklyRecurringAppointments\Backend\Components\Dialogs\Appointment\ProxyProviders\Local;

class Shared extends Proxy\Shared
{
    /**
     * @inerhitDoc
     */
    public static function prepareAppearance( array $bookly_options )
    {
        /** @var \WP_Locale $wp_locale */
        global $wp_locale;

        $weekdays = Local::getWeekDays();
        $weekday_abbrev = array_values( $wp_locale->weekday_abbrev );
        $days = array();
        foreach ( $weekdays as $i => $day ) {
            $days[] = array(
                'value' => $day,
                'label' => $weekday_abbrev[ $i ],
            );
        }

        $bookly_options['l10n']['recurrence_weekly'] = $days;
        $bookly_options['l10n']['recurrence_monthly'] = array(
            array( 'value' => 'day', 'label' => __( 'Specific day', 'bookly' ) ),
            array( 'value' => 'first', 'label' => __( 'First', 'bookly' ) ),
            array( 'value' => 'second', 'label' => __( 'Second', 'bookly' ) ),
            array( 'value' => 'third', 'label' => __( 'Third', 'bookly' ) ),
            array( 'value' => 'fourth', 'label' => __( 'Fourth', 'bookly' ) ),
            array( 'value' => 'last', 'label' => __( 'Last', 'bookly' ) ),
        );
        $bookly_options['l10n']['recurrence_frequencies'] = array(
            'daily' => __( 'Daily', 'bookly' ),
            'weekly' => __( 'Weekly', 'bookly' ),
            'biweekly' => __( 'Biweekly', 'bookly' ),
            'monthly' => __( 'Monthly', 'bookly' ),
        );
        $bookly_options['l10n']['recurrence_repeat'] = __( 'Repeat', 'bookly' );
        $bookly_options['l10n']['recurrence_every'] = __( 'Interval', 'bookly' );
        $bookly_options['l10n']['recurrence_days'] = __( 'day(s)', 'bookly' );
        $bookly_options['l10n']['recurrence_until'] = __( 'Until', 'bookly' );
        $bookly_options['l10n']['recurrence_on'] = __( 'On', 'bookly' );
        $bookly_options['l10n']['recurrence_schedule'] = __( 'Schedule', 'bookly' );
        $bookly_options['l10n']['single_appointment'] = __( 'Single appointment', 'bookly' );
        $bookly_options['l10n']['recurring_appointments'] = __( 'Recurring appointments', 'bookly' );

        $bookly_options['recurring_enabled'] = true;

        return $bookly_options;
    }

    /**
     * @inerhitDoc
     */
    public static function prepareAppearanceData( array $bookly_options )
    {
        $bookly_options['fields']['recurring_enabled'] = __( 'Recurring appointments', 'bookly' );

        return $bookly_options;
    }

    /**
     * @inerhitDoc
     */
    public static function prepareFormOptions( array $bookly_options )
    {
        $bookly_options['recurring_payment_first'] = (int) ( get_option( 'bookly_recurring_appointments_payment' ) === 'first' );

        return $bookly_options;
    }
}