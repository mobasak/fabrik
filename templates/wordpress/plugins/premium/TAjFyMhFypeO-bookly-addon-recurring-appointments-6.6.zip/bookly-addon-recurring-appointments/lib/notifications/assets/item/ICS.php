<?php
namespace BooklyRecurringAppointments\Lib\Notifications\Assets\Item;

use Bookly\Lib as BooklyLib;
use Bookly\Lib\Notifications\Assets\Item\Codes;

class ICS extends BooklyLib\Utils\Ics\Base
{
    /**
     * Constructor.
     *
     * @param Codes $codes
     * @param string $recipient
     */
    public function __construct( Codes $codes, $recipient = 'client' )
    {
        $description_template = $this->getDescriptionTemplate( $recipient );
        $this->data =
            "BEGIN:VCALENDAR\n"
            . "VERSION:2.0\n"
            . "PRODID:-//Bookly\n"
            . "CALSCALE:GREGORIAN\n";

        foreach ( $codes->schedule as $appointment ) {
            $this->empty = false;
            /** @var BooklyLib\DataHolders\Booking\Simple $simple */
            $simple = $appointment['item'];
            $description_codes = BooklyLib\Utils\Codes::getICSCodes( $simple );
            $this->data .= sprintf(
                "BEGIN:VEVENT\n"
                . "ORGANIZER;%s\n"
                . "DTSTAMP:%s\n"
                . "DTSTART:%s\n"
                . "DTEND:%s\n"
                . "SUMMARY:%s\n"
                . "DESCRIPTION:%s\n"
                . "LOCATION:%s\n"
                . "END:VEVENT\n",
                $this->escape( sprintf( 'CN=%s:mailto:%s', $appointment['staff_name'], $appointment['staff_email'] ) ),
                $this->formatDateTime( $simple->getAppointment()->getStartDate() ),
                $this->formatDateTime( $simple->getAppointment()->getStartDate() ),
                $this->formatDateTime( $simple->getAppointment()->getEndDate() ),
                $this->escape( $codes->service_name ),
                $this->escape( BooklyLib\Utils\Codes::replace( $description_template, $description_codes, false ) ),
                $this->escape( $codes->location_name )
            );
        }

        $this->data .= 'END:VCALENDAR';
    }
}