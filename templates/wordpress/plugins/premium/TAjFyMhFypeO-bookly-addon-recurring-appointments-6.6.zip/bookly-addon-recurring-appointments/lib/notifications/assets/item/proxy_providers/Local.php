<?php
namespace BooklyRecurringAppointments\Lib\Notifications\Assets\Item\ProxyProviders;

use Bookly\Lib\Notifications\Assets\Item\Codes;
use Bookly\Lib\Notifications\Assets\Item\Proxy;
use BooklyRecurringAppointments\Lib\Notifications\Assets\Item\ICS;

abstract class Local extends Proxy\RecurringAppointments
{
    /**
     * @inheritDoc
     */
    public static function createICS( Codes $codes, $recipient )
    {
        return new ICS( $codes, $recipient );
    }
}