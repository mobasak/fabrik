<?php
namespace BooklyRecurringAppointments\Lib\ProxyProviders;

use Bookly\Lib as BooklyLib;

class Local extends BooklyLib\Proxy\RecurringAppointments
{
    /**
     * @inheritDoc
     */
    public static function hideChildAppointments( $default, BooklyLib\CartItem $cart_item )
    {
        if (
            $cart_item->getSeriesUniqueId()
            && get_option( 'bookly_recurring_appointments_payment' ) === 'first'
            && ( ! $cart_item->getFirstInSeries() )
        ) {
            return true;
        }

        return $default;
    }

    /**
     * @inerhitDoc
     */
    public static function notifyStaffAndAdmins( $sent, $staff, $notification, $codes, $attachments, $reply_to, $queue = null )
    {
        if ( isset( $codes->schedule ) ) {
            $staff_schedule = array();
            foreach ( $codes->schedule as $event ) {
                if ( ! isset( $event['staff_id'] ) ) {
                    break;
                }
                $staff_id = $event['staff_id'];
                unset( $event['staff_id'] );
                if ( ! isset( $staff_schedule[ $staff_id ] ) ) {
                    $staff_schedule[ $staff_id ] = array();
                }
                $staff_schedule[ $staff_id ][] = $event;
            }

            if ( count( $staff_schedule ) ) {
                foreach ( $staff_schedule as $staff_id => $list ) {
                    $code = clone $codes;
                    $code->prepareForItem( $list[0]['item'], 'staff' );
                    $code->schedule = $list;
                    BooklyLib\Notifications\Booking\BaseSender::sendToStaff( $staff, $notification, $codes, $attachments, $reply_to, $queue );
                    BooklyLib\Notifications\Base\Reminder::sendToAdmins( $notification, $codes, $attachments, $reply_to, $queue );
                    BooklyLib\Notifications\Base\Reminder::sendToCustom( $notification, $codes, $attachments, $reply_to, $queue );
                }
                $sent = true;
            }
        }

        return $sent;
    }
}