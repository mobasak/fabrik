<div class="delete-page-wrapper">
	<span><?php echo __( 'Are you sure you want to remove this coming soon page?', 'thrive-dash' ); ?></span>
	<div class="buttons-wrapper">
		<button class="keep-page enable-state" data-enable="view"><?php echo __( 'Keep this page', 'thrive-dash' ); ?></button>
		<button class="remove-page enable-state" data-enable="search"><?php echo __( 'Remove this page', 'thrive-dash' ); ?></button>
	</div>
</div>