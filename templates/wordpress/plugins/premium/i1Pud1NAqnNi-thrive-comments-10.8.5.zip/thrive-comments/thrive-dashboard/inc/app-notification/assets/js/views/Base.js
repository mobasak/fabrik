/**
 * Created by Russel Hussain on 4/29/2024.
 */

( function ( $ ) {
	module.exports = Backbone.View.extend( {
		render: function () {
			return this;
		}
	} )

} )( jQuery );
