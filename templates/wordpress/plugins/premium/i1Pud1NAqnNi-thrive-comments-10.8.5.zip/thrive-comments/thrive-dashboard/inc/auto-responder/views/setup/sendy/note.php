<div class="tve-sp"></div>
<p><?php echo esc_html__( "Note: we would prefer displaying the list names instead of IDs here, but unfortunately that isn't possible with Sendy.", 'thrive-dash' ) ?></p>
