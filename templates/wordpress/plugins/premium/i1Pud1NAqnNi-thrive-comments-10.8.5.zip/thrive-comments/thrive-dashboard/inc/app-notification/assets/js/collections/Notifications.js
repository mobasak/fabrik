var NotificationModel = require( './../models/Notification' );

module.exports = Backbone.Collection.extend({
	model: NotificationModel,
});

