<div class="update-message notice inline notice-error notice-alt" style="margin: 10px 0 5px;">
	<p><?php echo sprintf( __( 'A new version of %s is available.' ), $plugin->get_name() ); ?>&nbsp;<strong><?php _e( 'Please enter a valid license key to receive this update.' ); ?></strong></p>
</div>
