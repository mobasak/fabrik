=== Easy Digital Downloads - Recently Viewed Items ===
Contributors: easydigitaldownloads, am, mindctrl, johnparris
Tags: Easy Digital Downloads, Recently Viewed Items
Requires at least: 4.2
Tested up to: 6.1
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Increase your sales by showing customers the items they've recently viewed with this extension for Easy Digital Downloads.

== Description ==

Recently Viewed Items for Easy Digital Downloads allows you to show your visitors the items they've previously viewed on your site as they move around your site, much like Amazon does. This is useful for increasing your sales by showing customers the things that interest them most. You can show the recently viewed items on single product pages, on the checkout page, and using a widget anywhere you like.

== Change Log ==

= 1.0.3 =
* Improvement: The extension settings are now registered to a custom tab under the Extensions section.
* Change: The plugin author has been updated to Easy Digital Downloads and the plugin URI has been updated.
* Dev: How the plugin loads has been updated for better dependency management.
* Dev: License handling has been improved.

= 1.0.1 =
* Fixed problem when using custom templates.
* Fixed featured images not showing when using the shortcode.

= 1.0 =
* Initial release *
