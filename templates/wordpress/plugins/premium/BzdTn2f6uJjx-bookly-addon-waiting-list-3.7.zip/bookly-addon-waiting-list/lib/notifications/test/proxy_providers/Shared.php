<?php
namespace BooklyWaitingList\Lib\Notifications\Test\ProxyProviders;

use Bookly\Lib;
use Bookly\Lib\Notifications\Test\Proxy;
use BooklyWaitingList\Lib\Notifications\Test\Sender;

abstract class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function send( $to_email, Lib\Entities\Notification $notification, $codes, $attachments, $reply_to, $send_as, $from )
    {
        Sender::send( $to_email, $notification, $codes, $attachments, $reply_to, $send_as, $from );
    }
}