<?php
namespace BooklyWaitingList\Frontend\Modules\Booking\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Frontend\Modules\Booking\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function renderWaitingListInfoText()
    {
        $info_text = BooklyLib\Utils\Common::getTranslatedOption( 'bookly_l10n_info_time_step_waiting_list' );

        if ( $info_text != '' ) {
            self::renderTemplate( 'info_text', compact( 'info_text' ) );
        }
    }
}