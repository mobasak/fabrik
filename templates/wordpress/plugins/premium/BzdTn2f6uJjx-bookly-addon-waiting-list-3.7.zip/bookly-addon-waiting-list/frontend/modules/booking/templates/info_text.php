<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div class="bookly-box"><?php echo nl2br( $info_text ) ?></div>