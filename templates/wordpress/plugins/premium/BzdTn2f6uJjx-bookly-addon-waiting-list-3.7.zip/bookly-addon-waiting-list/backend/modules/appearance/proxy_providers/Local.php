<?php
namespace BooklyWaitingList\Backend\Modules\Appearance\ProxyProviders;

use Bookly\Backend\Modules\Appearance\Proxy;

class Local extends Proxy\WaitingList
{
     /**
     * @inheritDoc
     */
    public static function renderInfoText()
    {
        self::renderTemplate( 'info_text' );
    }
}