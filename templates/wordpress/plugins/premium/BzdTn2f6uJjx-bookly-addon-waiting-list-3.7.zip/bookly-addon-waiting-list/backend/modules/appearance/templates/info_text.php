<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Editable\Elements;
?>
<div class="bookly-box">
    <?php Elements::renderText( 'bookly_l10n_info_time_step_waiting_list' ) ?>
</div>
