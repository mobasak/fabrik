<?php
namespace BooklyWaitingList\Backend\Modules\Calendar\ProxyProviders;

use Bookly\Backend\Modules\Calendar\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareAppointmentCodesData( array $codes, $appointment_data, $participants )
    {
        $codes['on_waiting_list'] = (int) $appointment_data['on_waiting_list'];

        return $codes;
    }
}