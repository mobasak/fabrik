<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div class="col-lg-6 text-center"><?php esc_html_e( 'Capacity (min and max)', 'bookly' ) ?></div>