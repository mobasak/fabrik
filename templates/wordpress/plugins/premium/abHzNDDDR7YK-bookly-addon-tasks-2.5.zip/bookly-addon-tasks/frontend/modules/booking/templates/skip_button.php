<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Lib as BooklyLib;
?>
<button class="bookly-time-skip bookly-btn bookly-left ladda-button" data-style="zoom-in" data-spinner-size="40">
    <span class="ladda-label"><?php echo BooklyLib\Utils\Common::getTranslatedOption( 'bookly_l10n_button_skip_time_step' ) ?></span>
</button>