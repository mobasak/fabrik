<?php
namespace BooklyTasks\Backend\Components\Dialogs\Appointment\Edit\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy\Shared as AppointmentEditProxy;

class Shared extends AppointmentEditProxy
{
    /**
     * @inheritDoc
     */
    public static function prepareL10n( $l10n )
    {
        $l10n['l10n']['skip_date'] = __( 'Skip time selection', 'bookly' );

        return $l10n;
    }
}