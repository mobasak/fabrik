<?php
namespace BooklyTasks\Backend\Components\Dialogs\Service\Edit\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Service\Edit\Proxy;

class Local extends Proxy\Tasks
{
    /**
     * @inheritDoc
     */
    public static function renderSubForm( array $service )
    {
        self::renderTemplate( 'sub_form', compact( 'service' ) );
    }
}