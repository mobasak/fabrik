<?php
namespace BooklyTasks\Backend\Modules\Appearance\ProxyProviders;

use Bookly\Backend\Modules\Appearance\Proxy\Tasks as TasksProxy;

class Local extends TasksProxy
{
    /**
     * @inheritDoc
     */
    public static function renderShowTimeStep()
    {
        self::renderTemplate( 'show_time_step' );
    }

    /**
     * @inheritDoc
     */
    public static function renderSkipButton()
    {
        self::renderTemplate( 'skip_button' );
    }
}