<?php
namespace BooklyTasks\Backend\Modules\Settings\ProxyProviders;

use Bookly\Backend\Modules\Settings\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function saveSettings( array $alert, $tab, array $params )
    {
        if ( ( $tab == 'calendar' ) && array_key_exists( 'done', $params['status'] ) ) {
            update_option( 'bookly_appointment_status_done_color', $params['status']['done'] );
        }

        return $alert;
    }
}