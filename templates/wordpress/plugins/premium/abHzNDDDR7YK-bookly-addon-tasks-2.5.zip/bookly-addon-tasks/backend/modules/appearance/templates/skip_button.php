<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Editable\Elements;
?>
<div class="bookly-right bookly-js-back-step bookly-btn ml-2">
    <?php Elements::renderString( array( 'bookly_l10n_button_skip_time_step' ) ) ?>
</div>