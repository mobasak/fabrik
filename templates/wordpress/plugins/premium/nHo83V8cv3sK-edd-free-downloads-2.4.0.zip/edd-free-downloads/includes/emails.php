<?php
/**
 * Email Functions
 *
 * @package     EDD\FreeDownloads\Emails
 * @since       2.2.0
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add the {free_downloads_verification_link} tag to the EDD Email tags
 *
 * @since 2.2.0
 * @return void
 */
function edd_free_downloads_register_email_tags() {
	edd_add_email_tag( 'free_downloads_verification_link', __( 'Insert the free downloads confirmation link', 'edd-free-downloads' ), 'edd_free_downloads_get_confirmation_link' );
	edd_add_email_tag( 'free_download_name', __( 'Insert the name of the item delivered via Free Downloads', 'edd-free-downloads' ), 'edd_free_downloads_get_download_name' );

	if ( function_exists( 'edd_is_admin_page' ) && edd_is_admin_page( 'emails' ) ) {
		edd_remove_email_tag( 'free_downloads_verification_link' );
	}
}
add_action( 'edd_add_email_tags', 'edd_free_downloads_register_email_tags', 100 );

/**
 * Retrieve the download confirmation link for a payment ID
 *
 * @since 2.2.0
 * @param int $payment_id
 *
 * @return string
 */
function edd_free_downloads_get_confirmation_link( $payment_id = 0, $order = null ) {
	if ( ! is_numeric( $payment_id ) || empty( $payment_id ) ) {
		return '';
	}

	if ( ! $order instanceof EDD\Orders\Order ) {
		$order = edd_get_order( $payment_id );
	}
	if ( ! $order instanceof EDD\Orders\Order ) {
		return '';
	}

	$token      = wp_hash( $order->payment_key, 'nonce' );
	$base_url   = home_url( 'index.php' );
	$expiration = time() + ( edd_get_option( 'download_link_expiration', 24 ) * HOUR_IN_SECONDS );
	$args       = array(
		'edd_action'      => 'free_download_verify',
		'token'           => $token,
		'key'             => $order->payment_key,
		'ttl'             => $expiration,
		'verify_download' => wp_hash( $order->payment_key . $token . $expiration, 'nonce' ),
	);

	return add_query_arg( $args, $base_url );
}

/**
 * Run the verification process for when a user clicks the link in the verification email.
 *
 * @since 2.2.0
 * @uses edd_free_downloads_complete_download()
 */
function edd_free_download_verify() {
	$payment_key = filter_input( INPUT_GET, 'key', FILTER_SANITIZE_SPECIAL_CHARS );
	$token       = filter_input( INPUT_GET, 'token', FILTER_SANITIZE_SPECIAL_CHARS );
	$order       = ! empty( $payment_key ) ? edd_get_order_by( 'payment_key', $payment_key ) : false;

	// Verify that the token provided matches that of the payment that exists.
	if ( ! $order || ! hash_equals( wp_hash( $order->payment_key, 'nonce' ), $token ) ) {
		wp_die( esc_html__( 'Validation failed.', 'edd-free-downloads' ), esc_html__( 'Validation error', 'edd-free-downloads' ) );
	}

	$expiration = filter_input( INPUT_GET, 'ttl', FILTER_SANITIZE_NUMBER_INT );
	$expired    = time() > $expiration;
	$checksum   = filter_input( INPUT_GET, 'verify_download', FILTER_SANITIZE_SPECIAL_CHARS );
	$challenge  = wp_hash( $payment_key . $token . $expiration, 'nonce' );
	$verified   = hash_equals( $checksum, $challenge );

	$error_message = false;

	if ( ! $verified || $expired ) {
		if ( ! empty( $order ) ) {
			$order_item  = reset( $order->items );
			$download_id = $order_item->product_id;

			if ( $expired ) {
				$error_message = sprintf(
					/* translators: %1$s: download URL, %2$s: download name */
					__( 'Your verification link for <a href="%1$s">%2$s</a> has expired', 'edd-free-downloads' ),
					get_permalink( $download_id ),
					edd_get_download_name( $download_id )
				);
			} else {
				$error_message = sprintf(
					/* translators: %1$s: download URL, %2$s: download name */
					__( 'Error processing download of <a href="%1$s">%2$s</a>', 'edd-free-downloads' ),
					get_permalink( $download_id ),
					edd_get_download_name( $download_id )
				);
			}
		} else {
			$error_message = __( 'Error processing download. Please contact support.', 'edd-free-downloads' );
		}
	}

	if ( ! empty( $error_message ) ) {
		wp_die( $error_message, __( 'Error', 'edd-free-downloads' ), 403 );
	}

	if ( ! in_array( $order->status, array( 'complete', 'publish' ), true ) ) {

		edd_free_download_maybe_unhook_auto_register();

		EDD\FreeDownloads\Checkout\Complete::mark_order_complete( $order->id );

		edd_add_note(
			array(
				'object_id'   => $order->id,
				'object_type' => 'order',
				'content'     => __( 'Free Downloads email verification complete.', 'edd-free-downloads' ),
			)
		);
	}

	edd_free_downloads_complete_download( $order );
}
add_action( 'edd_free_download_verify', 'edd_free_download_verify' );

/**
 * Retrieve the download name for a Free Download 'purchase'.
 *
 * @since 2.2.0
 * @param int $order_id
 *
 * @return string
 */
function edd_free_downloads_get_download_name( $order_id = 0 ) {
	if ( ! is_numeric( $order_id ) || empty( $order_id ) ) {
		return '';
	}

	$order = edd_get_order( $order_id );
	if ( ! $order ) {
		return '';
	}

	$order_item = reset( $order->items );

	return edd_get_download_name( $order_item->product_id, $order_item->price_id );
}

/**
 * Return the setting of the email verification setting.
 *
 * @since 2.2.0
 * @return bool
 */
function edd_free_downloads_verify_email() {
	$verify_email = edd_get_option( 'edd_free_downloads_require_verification', false );
	$verify_email = is_user_logged_in() ? false : $verify_email;

	return (bool) apply_filters( 'edd_free_downloads_require_verification', $verify_email );
}

/**
 * Return the verification message setting.
 *
 * @since 2.2.0
 * @return string
 */
function edd_free_downloads_verify_message() {
	$default_message      = __( 'An email will be sent to the provided address to complete your download.', 'edd-free-downloads' );
	$verification_message = edd_get_option( 'edd_free_downloads_require_verification_message', $default_message );
	return apply_filters( 'edd_free_downloads_verification_message', $verification_message );
}

/**
 * Return the verification email subject setting.
 *
 * @since 2.2.0
 * @return string
 */
function edd_free_downloads_verification_subject() {
	if ( function_exists( 'edd_get_email' ) ) {
		$email                = edd_get_email( 'free_dl_verification' );
		$verification_subject = $email->subject;
	} else {
		$verification_subject = edd_get_option( 'edd_free_downloads_verification_email_subject', __( 'Confirm your free download.', 'edd-free-downloads' ) );
	}

	return apply_filters( 'edd_free_downloads_verification_subject', $verification_subject );
}

/**
 * Return the verification email contents.
 *
 * @since 2.2.0
 * @return string
 */
function edd_free_downloads_verification_email() {
	if ( function_exists( 'edd_get_email' ) ) {
		$email              = edd_get_email( 'free_dl_verification' );
		$verification_email = $email->content;
	} else {
		$default_message    = __( "Please click the following link to complete your download.\n\n" . '{free_downloads_verification_link}', 'edd-free-downloads' );
		$verification_email = edd_get_option( 'edd_free_downloads_verification_email', $default_message );
	}

	return apply_filters( 'edd_free_downloads_verification_email', $verification_email );
}

/**
 * Sends the Free Downloads verification email.
 *
 * @since 2.2.0
 *
 * @param object  $order  EDD_Payment The payment generated for this email.
 * @param string  $to_email The email address to send the payment to.
 *
 * @return bool
 */
function edd_free_downloads_send_verification( $order = null, $to_email = '' ) {
	if ( empty( $order ) || empty( $to_email ) ) {
		return false;
	}

	if ( $order instanceof EDD_Payment ) {
		$order = edd_get_order( $order->ID );
	}

	if ( ! $order instanceof EDD\Orders\Order ) {
		return false;
	}

	if ( ! is_email( $to_email ) ) {
		return false;
	}

	if ( function_exists( 'edd_get_email' ) ) {
		$email = new EDD\FreeDownloads\Emails\Types\Verification( $order->id );

		return $email->send();
	}

	$from_name = edd_get_option( 'from_name', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );
	$from_name = apply_filters( 'edd_free_downloads_verification_from_name', $from_name, $order->id );

	$from_email = edd_get_option( 'from_email', get_bloginfo( 'admin_email' ) );
	$from_email = apply_filters( 'edd_free_downloads_verification_from_address', $from_email, $order->id );

	$subject = edd_free_downloads_verification_subject();
	$subject = apply_filters( 'edd_free_downloads_verification_subject', wp_strip_all_tags( $subject ), $order->id );
	$subject = edd_do_email_tags( $subject, $order->id );

	$headers  = 'From: ' . stripslashes_deep( html_entity_decode( $from_name, ENT_COMPAT, 'UTF-8' ) ) . " <$from_email>\r\n";
	$headers .= 'Reply-To: ' . $from_email . "\r\n";
	$headers .= "Content-Type: text/html; charset=utf-8\r\n";
	$headers  = apply_filters( 'edd_free_downloads_verification_email_headers', $headers, $order->id );

	$message = edd_free_downloads_verification_email();
	$message = make_clickable( edd_do_email_tags( $message, $order->id ) );

	$emails = EDD()->emails;
	$emails->__set( 'from_name', $from_name );
	$emails->__set( 'from_email', $from_email );
	$emails->__set( 'headers', $headers );

	return $emails->send( $to_email, $subject, $message );
}

/**
 * When Free Downloads is about to mark a payment is complete, determine what email settings should be disabled.
 *
 * @since 2.2.0
 *
 * @param  $payment
 * @return void
 */
function edd_free_downloads_maybe_disable_emails( $payment ) {
	$disable_purchase_receipts   = (bool) edd_get_option( 'edd_free_downloads_disable_emails', false );
	$disable_admin_notifications = (bool) edd_get_option( 'edd_free_downloads_disable_admin_emails', false );
	$has_email_management        = function_exists( 'edd_get_email' );

	// Disable purchase receipts
	if ( $disable_purchase_receipts ) {
		if ( function_exists( 'Receiptful' ) ) {
			remove_action( 'edd_complete_purchase', array( Receiptful()->email, 'send_transactional_email' ) );
		}

		if ( ! $has_email_management ) {
			remove_action( 'edd_complete_purchase', 'edd_trigger_purchase_receipt', 999 );

			// Disabling purchase receipt inherently disables admin notices as well.
			if ( ! $disable_admin_notifications ) {
				add_action( 'edd_free_downloads_post_complete_payment', 'edd_admin_email_notice', 10, 1 );
			}
		}
	}

	// Check if admin notices should be sent, in case we are sending purchase confirmations.
	if ( $disable_admin_notifications && ! $has_email_management ) {
		// If not, remove the action.
		remove_action( 'edd_admin_sale_notice', 'edd_admin_email_notice', 10, 2 );
	}
}
add_action( 'edd_free_downloads_pre_complete_payment', 'edd_free_downloads_maybe_disable_emails', 10, 1 );
