<?php
/**
 * Register settings
 *
 * @package     EDD\FreeDownloads\Admin\Settings\Register
 * @since       1.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Add settings section.
 *
 * @since       1.1.2
 * @param       array $sections The existing marketing sections.
 * @return      array The modified marketing sections.
 */
function edd_free_downloads_add_settings_section( $sections ) {
	$sections['free_downloads'] = __( 'Free Downloads', 'edd-free-downloads' );

	return $sections;
}
add_filter( 'edd_settings_sections_marketing', 'edd_free_downloads_add_settings_section' );

/**
 * Add settings
 *
 * @since       1.1.2
 * @param       array $settings The existing plugin settings.
 * @return      array The modified plugin settings
 */
function edd_free_downloads_add_settings( $settings ) {
	$settings_fields = new EDD\FreeDownloads\Admin\Settings();

	return array_merge( $settings, $settings_fields->get() );
}
add_filter( 'edd_settings_marketing', 'edd_free_downloads_add_settings' );

/**
 * Maybe add Auto Register settings
 *
 * If EDD Auto Register is installed, it conflicts with
 * our auto registration functions. Thus, only allow our
 * auto registration option if it isn't installed.
 *
 * @since       1.1.0
 * @param       array $settings The existing settings.
 * @return      array $settings The updated settings
 */
function edd_free_downloads_auto_register_settings( $settings ) {
	$auto_register_settings = array(
		array(
			'id'            => 'edd_free_downloads_bypass_auto_register',
			'name'          => __( 'Bypass Auto Registration', 'edd-free-downloads' ),
			'check'         => __( 'Bypass auto-registration for free downloads.', 'edd-free-downloads' ),
			'type'          => 'checkbox_toggle',
			'tooltip_title' => __( 'Bypass Auto Registration', 'edd-free-downloads' ),
			'tooltip_desc'  => __( 'By default, the Auto Registration plugin registers a new user account when a free download is processed. Enable this to prevent user accounts from being automatically created.', 'edd-free-downloads' ),
			'class'         => \EDD\Checkout\AutoRegister::is_enabled() ? '' : 'edd-hidden',
		),
		array(
			'id'    => 'edd_free_downloads_user_registration',
			'name'  => __( 'User Registration', 'edd-free-downloads' ),
			'check' => __( 'Display a registration form in the download modal for logged-out users.', 'edd-free-downloads' ),
			'type'  => 'checkbox_toggle',
			'class' => edd_get_option( 'edd_free_downloads_bypass_auto_register', false ) ? '' : 'edd-hidden',
		),
	);

	return array_merge( $settings, $auto_register_settings );
}
add_filter( 'edd_free_downloads_fields_settings', 'edd_free_downloads_auto_register_settings' );


/**
 * Add newsletter opt-out checkbox if relevant
 *
 * @since       1.1.0
 * @param       array $settings The existing settings.
 * @return      array $settings The updated settings
 */
function edd_free_downloads_newsletter_settings( $settings ) {
	if ( ! edd_free_downloads_has_newsletter_plugin() ) {
		return $settings;
	}
	$newsletter_settings = array(
		array(
			'id'    => 'edd_free_downloads_newsletter_optin',
			'name'  => __( 'Display Opt-In', 'edd-free-downloads' ),
			'check' => __( 'Display a newsletter opt-in checkbox in the download modal.', 'edd-free-downloads' ),
			'type'  => 'checkbox_toggle',
		),
		array(
			'id'    => 'edd_free_downloads_newsletter_auto_checked',
			'name'  => __( 'Signup Checked by Default', 'edd-free-downloads' ),
			'check' => __( 'Should the newsletter signup checkbox be checked by default for Free Downloads?', 'edd-free-downloads' ),
			'type'  => 'checkbox_toggle',
		),
		array(
			'id'   => 'edd_free_downloads_newsletter_optin_label',
			'name' => __( 'Opt-In Field Label', 'edd-free-downloads' ),
			'desc' => __( 'Specify the text to display for the opt-in field label.', 'edd-free-downloads' ),
			'type' => 'text',
			'std'  => __( 'Subscribe to our newsletter', 'edd-free-downloads' ),
		),
	);

	return array_merge( $settings, $newsletter_settings );
}
add_filter( 'edd_free_downloads_integration_settings', 'edd_free_downloads_newsletter_settings' );

/**
 * Update the docs link for the free downloads section.
 *
 * @since 2.4.0
 * @param string $link The current link.
 * @return string The updated link.
 */
function edd_free_downloads_docs_link( $link ) {
	$page    = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_SPECIAL_CHARS );
	$section = filter_input( INPUT_GET, 'section', FILTER_SANITIZE_SPECIAL_CHARS );

	if ( 'edd-settings' === $page && 'free_downloads' === $section ) {
		return 'https://easydigitaldownloads.com/categories/docs/free-downloads/';
	}

	$email = filter_input( INPUT_GET, 'email', FILTER_SANITIZE_SPECIAL_CHARS );
	if ( 'edd-emails' === $page && 'free_dl_verification' === $email ) {
		return 'https://easydigitaldownloads.com/docs/free-downloads-basic-usage/';
	}

	return $link;
}
add_filter( 'edd_flyout_docs_link', 'edd_free_downloads_docs_link', 15 );
