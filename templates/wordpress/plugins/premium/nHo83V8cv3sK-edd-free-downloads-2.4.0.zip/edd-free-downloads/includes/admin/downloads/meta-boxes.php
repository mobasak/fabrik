<?php
/**
 * Meta boxes
 *
 * @package     EDD\FreeDownloads\Admin\Downloads\MetaBoxes
 * @since       1.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Register meta boxes
 *
 * @since       2.0.0
 * @return      void
 */
function edd_free_downloads_add_download_meta_boxes() {
	if ( class_exists( 'EDD\\Admin\\Downloads\\Editor\\Section' ) ) {
		return;
	}

	add_meta_box( 'free-downloads', __( 'Free Downloads Settings', 'edd-free-downloads' ), 'edd_free_downloads_render_download_meta_box', 'download', 'side', 'default' );
}
add_action( 'add_meta_boxes', 'edd_free_downloads_add_download_meta_boxes' );

function edd_free_downloads_add_section( $sections ) {
	if ( ! class_exists( 'EDD\\Admin\\Downloads\\Editor\\Section' ) ) {
		return $sections;
	}

	$sections['free_downloads'] = EDD\FreeDownloads\Admin\Downloads\Metabox::class;

	return $sections;
}
add_filter( 'edd_download_details_sections', 'edd_free_downloads_add_section' );

/**
 * Render meta box
 *
 * @since 2.0.0
 * @param WP_Post $post The post we are editing
 * @return      void
 */
function edd_free_downloads_render_download_meta_box( $post ) {

	$post_id         = $post->ID;
	$direct_download = edd_get_option( 'edd_free_downloads_direct_download', false ) ? 1 : 0;
	$on_complete     = edd_get_option( 'edd_free_downloads_on_complete', false );
	$on_complete     = ( 'auto-download' === $on_complete ) ? 1 : 0;
	$download_file   = get_post_meta( $post_id, '_edd_free_downloads_file', true );
	$bundle_enable   = get_post_meta( $post_id, '_edd_free_downloads_bundle', false ) ? 1 : 0;
	$notes_title     = get_post_meta( $post_id, '_edd_free_downloads_notes_title', true );
	$notes           = get_post_meta( $post_id, '_edd_free_downloads_notes', true );
	?>
	<div class="edd-form-group">
		<div class="edd-form-group__control">
			<?php
			echo EDD()->html->checkbox(
				array(
					'name'    => '_edd_free_downloads_bypass',
					'current' => get_post_meta( $post_id, '_edd_free_downloads_bypass', true ) ? 1 : 0,
				)
			);
			?>
			<label for="_edd_free_downloads_bypass" class="edd-form-group__label">
				<?php esc_html_e( 'Disable Free Downloads modal', 'edd-free-downloads' ); ?>
				<span alt="f223" class="edd-help-tip dashicons dashicons-editor-help" title="<strong><?php esc_html_e( 'Bypass Modal', 'edd-free-downloads' ); ?></strong>: <?php printf( esc_html__( 'When checked, this will get treated as a normal %s and will require the user to go through the checkout process.', 'edd-free-downloads' ), esc_html( edd_get_label_singular( true ) ) ); ?>"></span>
			</label>
		</div>
	</div>

	<div
		class="edd-form-group edd-free-downloads-bundle-wrap"
		<?php
		if ( ! edd_is_bundled_product( $post_id ) ) {
			echo 'style="display:none;"'; }
		?>
	>
		<div class="edd-form-group__control">
			<?php
			echo EDD()->html->checkbox(
				array(
					'name'    => '_edd_free_downloads_bundle',
					'current' => $bundle_enable,
				)
			);
			?>
			<label for="_edd_free_downloads_bundle" class="edd-form-group__label">
				<?php esc_html_e( 'Enforce use on bundle', 'edd-free-downloads' ); ?>
				<span alt="f223" class="edd-help-tip dashicons dashicons-editor-help" title="<strong><?php _e( 'Use On Bundle', 'edd-free-downloads' ); ?></strong>: <?php printf( esc_html__( 'Free Downloads can\'t reliably determine the value of products in a bundle, so by default it ignores bundles. Check this to enforce use on this bundle and treat all bundled %s as free.', 'edd-free-downloads' ), esc_html( edd_get_label_plural( true ) ) ); ?>"></span>
			</label>
		</div>
	</div>
	<?php
	if ( $direct_download || $on_complete ) {
		?>
		<div class="edd-form-group">
			<label for="_edd_free_downloads_file" class="edd-form-group__label">
				<?php esc_html_e( 'Custom Download File:', 'edd-free-downloads' ); ?>
				<span class="edd-help-tip dashicons dashicons-editor-help" title="<strong><?php esc_html_e( 'Custom Download File', 'edd-free-downloads' ); ?></strong>: <?php printf( esc_html__( 'If this %s includes multiple files, specify an archive file here to use for the Direct Download and Auto Download options.', 'edd-free-downloads' ), esc_html( edd_get_label_singular( true ) ) ); ?>"></span>
			</label>
			<?php
			echo EDD()->html->text(
				array(
					'id'          => '_edd_free_downloads_file',
					'name'        => '_edd_free_downloads_file',
					'class'       => 'widefat',
					'placeholder' => 'http://',
					'value'       => $download_file,
				)
			);
			?>
			<p class="description"><?php esc_html_e( 'Enter a URL for a .zip file. This will be used instead of any files added directly to the download.', 'edd-free-downloads' ); ?></p>
		</div>
		<?php
	}

	if ( edd_get_option( 'edd_free_downloads_show_notes', false ) ) {
		?>
		<div class="edd-form-group">
			<div class="edd-form-group__control">
				<label for="_edd_free_downloads_notes_title" class="edd-form-group__label"><?php esc_html_e( 'Notes Title', 'edd-free-downloads' ); ?></label>
				<?php
				echo EDD()->html->text(
					array(
						'id'    => '_edd_free_downloads_notes_title',
						'name'  => '_edd_free_downloads_notes_title',
						'class' => 'widefat',
						'value' => $notes_title,
					)
				);
				?>
				<p class="description"><?php esc_html_e( 'Enter the title for the notes field, or leave blank to use the global option.', 'edd-free-downloads' ); ?></p>
			</div>
		</div>

		<div class="edd-form-group">
			<div class="edd-form-group__control">
				<label for="_edd_free_downloads_notes" class="edd-form-group__label"><?php esc_html_e( 'Notes', 'edd-free-downloads' ); ?></label>
				<?php
				echo EDD()->html->textarea(
					array(
						'id'    => '_edd_free_downloads_notes',
						'name'  => '_edd_free_downloads_notes',
						'class' => 'widefat',
						'value' => $notes,
					)
				);
				?>
				<p class="description"><?php esc_html_e( 'Enter any notes, or leave blank to use the global option.', 'edd-free-downloads' ); ?></p>
			</div>
		</div>
		<?php
	}

	do_action( 'edd_free_downloads_meta_box_settings_fields', $post_id );

	if ( ! edd_get_option( 'edd_free_downloads_disable_cache', false ) ) {
		echo '<div class="edd-free-downloads-cache-actions">';
		echo '<a href="' . esc_url( wp_nonce_url( add_query_arg( 'edd-action', 'free_downloads_delete_cached_files' ), 'edd_free_downloads_cache_nonce', '_wpnonce' ) ) . '" class="button">' . esc_html__( 'Clear Cached Files', 'edd-free-downloads' ) . '</a>';
		echo '</div>';
	}

	wp_nonce_field( 'edd_free_downloads_metabox', 'edd_free_downloads_meta_box_nonce' );
}


/**
 * Save post meta when the save_post action is called
 *
 * @since       2.0.0
 * @param       int $post_id The ID of the post we are saving
 * @global      object $post The post we are saving
 * @return      void
 */
function edd_free_downloads_meta_box_save( $post_id ) {
	// Don't process if nonce can't be validated
	$nonce = filter_input( INPUT_POST, 'edd_free_downloads_meta_box_nonce', FILTER_SANITIZE_SPECIAL_CHARS );
	if ( ! wp_verify_nonce( $nonce, 'edd_free_downloads_metabox' ) ) {
		return $post_id;
	}

	// Don't process if this is an autosave
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) || isset( $_REQUEST['bulk_edit'] ) ) {
		return $post_id;
	}

	// Don't process if this is a revision
	if ( isset( $post->post_type ) && 'revision' === $post->post_type ) {
		return $post_id;
	}

	// Don't process if the current user shouldn't be editing this product
	if ( ! current_user_can( 'edit_product', $post_id ) ) {
		return $post_id;
	}

	// The default fields that get saved
	$fields = apply_filters(
		'edd_free_downloads_meta_box_fields_save',
		array(
			'_edd_free_downloads_bypass',
			'_edd_free_downloads_bundle',
			'_edd_free_downloads_file',
			'_edd_free_downloads_notes_title',
			'_edd_free_downloads_notes',
		)
	);

	foreach ( $fields as $field ) {
		if ( ! empty( $_POST[ $field ] ) ) {
			if ( is_string( $_POST[ $field ] ) ) {
				$new = esc_attr( $_POST[ $field ] );
			} else {
				$new = $_POST[ $field ];
			}

			$new = apply_filters( 'edd_free_downloads_meta_box_save_' . $field, $new );

			update_post_meta( $post_id, $field, $new );
		} else {
			delete_post_meta( $post_id, $field );
		}
	}
}
add_action( 'save_post', 'edd_free_downloads_meta_box_save' );
