<?php
/**
 * Download Actions
 *
 * @package     EDD\FreeDownloads\Download\Actions
 * @since       2.0.0
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Unhooks Auto Register actions if the current user is not logged in and "bypass auto register" is enabled.
 *
 * @since 2.3.10
 * @return void
 */
function edd_free_download_maybe_unhook_auto_register() {
	if ( is_user_logged_in() ) {
		return;
	}

	add_filter( 'edd_can_create_user_for_order', 'edd_free_downloads_maybe_prevent_user_creation' );
	add_filter( 'edd_auto_register_can_create_user', 'edd_free_downloads_maybe_prevent_user_creation' );
}

/**
 * Process downloads
 *
 * @since       1.0.0
 * @return      void
 */
function edd_free_download_process() {
	$checkout = new EDD\FreeDownloads\Checkout\Process();
	$checkout->process();
}
add_action( 'edd_free_download_process', 'edd_free_download_process' );

/**
 * Do the final processing that delivers the files for a free downloads purchase.
 *
 * @since 2.2.0
 * @param EDD\Orders\Order|EDD_Payment $payment_or_order The order or payment object.
 */
function edd_free_downloads_complete_download( $payment_or_order = null ) {
	$checkout = new EDD\FreeDownloads\Checkout\Complete();
	$checkout->complete( $payment_or_order );
}

/**
 * Process auto download
 *
 * @since       1.0.8
 * @return      void
 */
function edd_free_downloads_process_auto_download() {
	$auto_download = new EDD\FreeDownloads\Downloads\AutoDownload();
	$auto_download->process();
}
add_action( 'edd_free_downloads_process_download', 'edd_free_downloads_process_auto_download' );
