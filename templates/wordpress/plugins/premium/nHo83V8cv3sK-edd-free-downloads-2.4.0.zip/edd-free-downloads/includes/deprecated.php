<?php
/**
 * Deprecated functions
 *
 * @package     EDD\FreeDownloads\Deprecated
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Display an error if EDD isn't active
 *
 * @since       2.1.8
 * @deprecated 2.3.11
 * @return      void
 */
function edd_free_downloads_edd_not_active() {
	echo '<div class="error"><p>' . __( 'Free Downloads requires Easy Digital Downloads! Please install or activate it to continue!', 'edd-free-downloads' ) . '</p></div>';
}
