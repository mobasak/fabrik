<?php
/**
 * Filters
 *
 * @package     EDD\FreeDownloads\Filters
 * @since       2.0.0
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Adds our templates dir to the EDD template stack
 *
 * @since       1.2.5
 * @param       array $paths The existing template stack
 * @return      array $paths The updated template stack
 */
function edd_free_downloads_add_template_stack( $paths ) {
	$paths[55] = EDD_FREE_DOWNLOADS_DIR . 'templates/';

	return $paths;
}
add_filter( 'edd_template_paths', 'edd_free_downloads_add_template_stack' );


/**
 * Add a new query var
 *
 * @since       1.1.0
 * @param       array $vars The current query vars
 * @return      array $vars The new query vars
 */
function edd_free_downloads_query_vars( $vars ) {
	$vars[] = 'download_id';

	return $vars;
}
add_filter( 'query_vars', 'edd_free_downloads_query_vars', -1 );


/**
 * Maybe override straight to checkout
 *
 * @since       1.1.0
 * @param       bool $ret Whether or not to go straight to checkout
 * @global      object $post The WordPress post object
 * @return      bool $ret Whether or not to go straight to checkout
 */
function edd_free_downloads_override_redirect( $ret ) {
	global $post;

	$id = get_the_ID();

	if ( is_single( $id ) && get_post_type( $id ) == 'download' && edd_is_free_download( $id ) ) {
		$ret = false;
	}

	return $ret;
}
add_filter( 'edd_straight_to_checkout', 'edd_free_downloads_override_redirect' );


/**
 * Override the EDD purchase form
 *
 * @since       2.0.0
 * @param       string $purchase_form The HTML for the existing purchase form
 * @param       array $args Arguments passed to the purchase form
 * @return      string $purchase_form Our updated purchase form
 */
function edd_free_downloads_purchase_download_form( $purchase_form, $args ) {

	$download_id = absint( $args['download_id'] );
	if ( ! edd_free_downloads_use_modal( $download_id ) || edd_has_variable_prices( $download_id ) ) {
		return $purchase_form;
	}

	$form = new EDD\FreeDownloads\Downloads\Form( $args );

	return $form->get() ?? $purchase_form;
}
add_filter( 'edd_purchase_download_form', 'edd_free_downloads_purchase_download_form', 10, 2 );

/**
 * If bypass auto register is enabled, prevent EDD from creating a user account.
 *
 * @since 2.4.0
 * @param bool $can_create_user Whether or not a user can be created.
 * @return bool
 */
function edd_free_downloads_maybe_prevent_user_creation( $can_create_user ) {

	// This filter is deprecated in EDD 3.3.0.
	remove_filter( 'edd_auto_register_can_create_user', 'edd_free_downloads_maybe_prevent_user_creation' );

	if ( edd_get_option( 'edd_free_downloads_bypass_auto_register', false ) ) {
		return false;
	}

	return $can_create_user;
}
