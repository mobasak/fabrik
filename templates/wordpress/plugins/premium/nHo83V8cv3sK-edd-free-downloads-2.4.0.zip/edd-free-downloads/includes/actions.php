<?php
/**
 * Actions
 *
 * @package     EDD\FreeDownloads\Actions
 * @since       1.1.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Registers a new rewrite endpoint
 *
 * @since       1.1.0
 * @param       array $rewrite_rules The existing rewrite rules
 * @return      void
 */
function edd_free_downloads_add_endpoint( $rewrite_rules ) {
	add_rewrite_endpoint( 'edd-free-download', EP_ALL );
}
add_action( 'init', 'edd_free_downloads_add_endpoint' );

/**
 * Handle newsletter opt-in
 *
 * @since       1.1.0
 * @return      void
 */
function edd_free_downloads_remove_optin() {
	if ( ! isset( $_POST['edd_free_download_email'] ) ) {
		return;
	}

	if ( edd_get_option( 'edd_free_downloads_newsletter_optin', false ) ) {
		// Build user info array for global opt-in
		$user_info = array(
			'email'      => $_POST['edd_free_download_email'],
			'first_name' => ( isset( $_POST['edd_free_download_fname'] ) ? $_POST['edd_free_download_fname'] : '' ),
			'last_name'  => ( isset( $_POST['edd_free_download_lname'] ) ? $_POST['edd_free_download_lname'] : '' ),
		);

		// MailChimp
		if ( class_exists( 'EDD_MailChimp_List' ) && is_callable( array( 'EDD_MailChimp_List', 'subscribe' ) ) ) {
			$edd_mailchimp = EDD_MailChimp::instance();

			// Running pre MailChimp 3.0
			if ( isset( $_POST['edd_free_download_optin'] ) ) {
				$edd_mailchimp_list = EDD_MailChimp_List::get_default();
				$edd_mailchimp_list->subscribe( $user_info );
			} else {
				remove_action( 'edd_complete_download_purchase', array( $edd_mailchimp, 'completed_download_purchase_signup' ) );
			}
		}

		// GetResponse
		if ( class_exists( 'EDD_GetResponse' ) && is_callable( array( 'EDD_GetResponse', 'instance' ) ) ) {
			if ( isset( $_POST['edd_free_download_optin'] ) ) {
				$lists = get_post_meta( $_POST['edd_free_download_id'], '_edd_getresponse', true );

				// If no lists on the product, retrieve the default list ID
				if ( ! empty( $lists ) ) {

					foreach ( $lists as $list_id ) {
						edd_getresponse()->newsletter->subscribe_email( $user_info, $list_id );
					}
				} else {

					$list_id = edd_get_option( 'edd_getresponse_list', false );
					edd_getresponse()->newsletter->subscribe_email( $user_info, $list_id );

				}
			} else {
				remove_action( 'edd_complete_download_purchase', array( edd_getresponse()->newsletter, 'completed_download_purchase_signup' ) );
			}
		}

		// Aweber
		if ( class_exists( 'EDD_Aweber' ) && is_callable( array( 'EDD_Aweber', 'instance' ) ) ) {
			$edd_aweber = EDD_Aweber::instance();

			if ( isset( $_POST['edd_free_download_optin'] ) ) {
				$edd_aweber->subscribe_email( $user_info );
			} else {
				remove_action( 'edd_complete_download_purchase', array( $edd_aweber, 'completed_download_purchase_signup' ) );
			}
		}

		// MailPoet
		if ( class_exists( 'EDD_MailPoet' ) && is_callable( array( 'EDD_MailPoet', 'instance' ) ) ) {
			$edd_mailpoet = EDD_MailPoet::instance();

			if ( isset( $_POST['edd_free_download_optin'] ) ) {
				$edd_mailpoet->subscribe_email( $user_info );
			} else {
				remove_action( 'edd_complete_download_purchase', array( $edd_mailpoet, 'completed_download_purchase_signup' ) );
			}
		}

		// Sendy
		if ( class_exists( 'EDD_Sendy' ) && is_callable( array( 'EDD_Sendy', 'instance' ) ) ) {
			$edd_sendy = EDD_Sendy::instance();

			if ( isset( $_POST['edd_free_download_optin'] ) ) {
				$edd_sendy->subscribe_email( $user_info );
			} else {
				remove_action( 'edd_complete_download_purchase', array( $edd_sendy, 'completed_download_purchase_signup' ) );
			}
		}

		// Convert Kit
		if ( class_exists( 'EDD_ConvertKit' ) && is_callable( array( 'EDD_ConvertKit', 'instance' ) ) ) {
			$edd_convert_kit = EDD_ConvertKit::instance();

			if ( isset( $_POST['edd_free_download_optin'] ) ) {
				$edd_convert_kit->subscribe_email( $user_info );
			} else {
				remove_action( 'edd_complete_download_purchase', array( $edd_convert_kit, 'completed_download_purchase_signup' ) );
			}
		}

		// ActiveCampaign
		if ( class_exists( 'EDD_ActiveCampaign' ) && is_callable( array( 'EDD_ActiveCampaign', 'instance' ) ) ) {
			if ( isset( $_POST['edd_free_download_optin'] ) ) {

				$lists = get_post_meta( $_POST['edd_free_download_id'], '_edd_activecampaign', true );
				$lists = is_array( $lists ) ? array_map( 'absint', $lists ) : false;

				// If no lists on the product, retrieve the default list ID
				if ( ! empty( $lists ) && is_array( $lists ) ) {

					foreach ( $lists as $list_id ) {
						edd_activecampaign()->subscribe_email( $user_info['email'], $user_info['first_name'], $user_info['last_name'], $list_id );
					}
				} else {

					$list_id = absint( edd_get_option( 'eddactivecampaign_list', 0 ) );

					if ( ! empty( $list_id ) ) {
						edd_activecampaign()->subscribe_email( $user_info['email'], $user_info['first_name'], $user_info['last_name'], $list_id );
					}
				}
			} else {
				remove_action( 'edd_complete_download_purchase', array( edd_activecampaign(), 'completed_download_purchase_signup' ) );
			}
		}
	}
}
add_action( 'edd_update_payment_status', 'edd_free_downloads_remove_optin', -10 );

/**
 * MailChimp 3.0 Integration
 *
 * When the box is checked, set the proper session value so that MailChimp knows if the person should be subscribed
 * or transactional.
 *
 * @since 2.3.4
 *
 * @param int $order_id The order ID that is being processed with Free Downloads.
 */
function edd_free_downloads_mail_chimp_payent_completed( $order_id ) {

	if ( ! class_exists( 'EDD_MailChimp_List' ) ) {
		return;
	}

	$opt_in_meta = edd_get_order_meta( $order_id, 'edd_free_download_optin', true );
	$opted_in    = isset( $_POST['edd_free_download_optin'] ) || $opt_in_meta;

	if ( ! $opted_in ) {
		edd_debug_log( 'Free Downloads - MailChimp value not added to payment meta because edd_free_download_optin was not present.' );
		return;
	}

	edd_debug_log( 'Free Downloads - MailChimp value added to payment because edd_free_download_optin was present.' );
	edd_add_order_meta( $order_id, '_mc_subscribed', 1 );
}
add_action( 'edd_free_downloads_pre_complete_payment', 'edd_free_downloads_mail_chimp_payent_completed', 10, 1 );

/**
 * Upon completion of the free downloads 'purchase', add the proper meta that the user opt'd in to the Active Campaign list.
 *
 * @param int $order_id The order ID that is being processed with Free Downloads.
 *
 * @since 2.3.10
 * @return void
 */
function edd_free_downloads_activecampaign_payment_completed( $order_id ) {
	if ( class_exists( 'EDD_ActiveCampaign' ) && isset( $_POST['edd_free_download_optin'] ) ) {
		edd_add_order_meta( $order_id, 'eddactivecampaign_activecampaign_signup', 1 );
	}
}
add_action( 'edd_free_downloads_pre_complete_payment', 'edd_free_downloads_activecampaign_payment_completed', 10, 1 );

/**
 * Callback function for the Compression Status setting
 *
 * @since       2.0.0
 * @return      void
 */
function edd_free_downloads_zip_status() {
	if ( class_exists( 'ZipArchive' ) ) {
		$html  = '<span class="edd-free-downloads-zip-status-available">' . __( 'Available', 'edd-free-downloads' ) . '</span>';
		$html .= '<span alt="f223" class="edd-help-tip dashicons dashicons-editor-help" title="<strong>' . __( 'Compression Status', 'edd-free-downloads' ) . '</strong>: ' . sprintf( __( 'Great! It looks like you have the ZipArchive class available! That means that we can auto-compress the files for multi-file %s.', 'edd-free-downloads' ), edd_get_label_plural( true ) ) . '"></span>';
	} else {
		$html  = '<span class="edd-free-downloads-zip-status-unavailable">' . __( 'Unavailable', 'edd-free-downloads' ) . '</span>';
		$html .= '<span alt="f223" class="edd-help-tip dashicons dashicons-editor-help" title="<strong>' . __( 'Compression Status', 'edd-free-downloads' ) . '</strong>: ' . sprintf( __( 'Oops! It looks like you don\'t have the ZipArchive class available! If you want us to auto-compress the files for multi-file %s, please make sure that your PHP instance is compiled with ZipArchive support.', 'edd-free-downloads' ), edd_get_label_plural( true ) ) . '"></span>';
	}

	echo $html;
}
add_action( 'edd_free_downloads_zip_status', 'edd_free_downloads_zip_status' );


/**
 * Ensure the cache directory exists
 *
 * @since       2.0.0
 * @return      void
 */
function edd_free_downloads_directory_exists() {
	$upload_dir = wp_upload_dir();
	$upload_dir = $upload_dir['basedir'] . '/edd-free-downloads-cache/';

	// Ensure that the cache directory exists
	if ( ! is_dir( $upload_dir ) ) {
		wp_mkdir_p( $upload_dir );
	}

	// Top level blank index.php
	if ( ! file_exists( $upload_dir . 'index.php' ) ) {
		@file_put_contents( $upload_dir . 'index.php', '<?php' . PHP_EOL . '// Silence is golden.' );
	}

	// Top level .htaccess
	$rules = 'Options -Indexes';
	if ( file_exists( $upload_dir . '.htaccess' ) ) {
		$contents = @file_get_contents( $upload_dir . '.htaccess' );

		if ( $contents !== $rules || ! $contents ) {
			@file_put_contents( $upload_dir . '.htaccess', $rules );
		}
	} else {
		@file_put_contents( $upload_dir . '.htaccess', $rules );
	}
}
add_action( 'admin_init', 'edd_free_downloads_directory_exists' );

/**
 * Display a purge cache button in the settings panel.
 *
 * @since 2.1.0
 */
function edd_free_downloads_display_purge_cache() {
	wp_enqueue_script( 'edd-free-downloads-cache', EDD_FREE_DOWNLOADS_URL . 'assets/js/admin/cache.js', array(), EDD_FREE_DOWNLOADS_VER, true );
	wp_localize_script(
		'edd-free-downloads-cache',
		'edd_free_downloads_cache',
		array(
			'error_message' => __( 'An error occurred while purging the cache.', 'edd-free-downloads' ),
		)
	);
	$timestamp = time();
	?>
	<button
		type="button"
		class="button button-secondary edd-free-downloads-purge-cache"
		data-nonce="<?php echo esc_attr( wp_create_nonce( 'edd_free_downloads_cache_nonce' ) ); ?>"
		data-timestamp="<?php echo esc_attr( $timestamp ); ?>"
		data-token="<?php echo esc_attr( EDD\Utils\Tokenizer::tokenize( $timestamp ) ); ?>"
		>
		<?php esc_html_e( 'Purge Cache', 'edd-free-downloads' ); ?>
	</button>
	<?php
	$tooltip = new EDD\HTML\Tooltip(
		array(
			'title'   => __( 'Purge Cache', 'edd-free-downloads' ),
			'content' => __( 'This will purge all files currently cached by Free Downloads. This does not affect any files hosted locally, it only clears the local copies of remotely hosted files and cached compressed files generated by direct download or auto download.', 'edd-free-downloads' ),
		)
	);
	$tooltip->output();
}
add_action( 'edd_free_downloads_display_purge_cache', 'edd_free_downloads_display_purge_cache' );

/**
 * Purge all cached files.
 *
 * @since 2.1.0
 * @since 2.4.0 The function now runs as an ajax action.
 */
function edd_free_downloads_purge_cache() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'You do not have permission to purge the cache.', 'edd-free-downloads' ) ) );
	}

	$timestamp = filter_input( INPUT_POST, 'timestamp', FILTER_SANITIZE_NUMBER_INT );
	$token     = filter_input( INPUT_POST, 'token', FILTER_SANITIZE_SPECIAL_CHARS );
	if ( ! EDD\Utils\Tokenizer::is_token_valid( $token, $timestamp ) ) {
		wp_send_json_error( array( 'message' => __( 'Invalid token.', 'edd-free-downloads' ) ) );
	}

	$nonce = filter_input( INPUT_POST, 'nonce', FILTER_SANITIZE_SPECIAL_CHARS );
	if ( ! $nonce || ! wp_verify_nonce( $nonce, 'edd_free_downloads_cache_nonce' ) ) {
		wp_send_json_error( array( 'message' => __( 'Nonce verification failed.', 'edd-free-downloads' ) ) );
	}

	$upload_dir = wp_upload_dir();
	$upload_dir = trailingslashit( $upload_dir['basedir'] . '/edd-free-downloads-cache' );

	$files = glob( $upload_dir . '/*' );
	foreach ( $files as $file ) {
		if ( is_file( $file ) && ! strstr( $file, 'index.php' ) ) {
			unlink( $file );
		}
	}

	$download_id = filter_input( INPUT_POST, 'download_id', FILTER_SANITIZE_NUMBER_INT );
	if ( $download_id ) {
		$deleted = edd_free_downloads_delete_cached_files( $download_id );
		if ( true !== $deleted ) {
			wp_send_json_error( array( 'message' => $message ) );
		}
	}

	wp_send_json_success(
		array(
			'message' => __( 'Success', 'edd-free-downloads' ),
		)
	);
}
add_action( 'wp_ajax_edd_free_downloads_purge_cache', 'edd_free_downloads_purge_cache' );

/**
 * Clear cached files for a given download.
 *
 * @since 2.1.0
 * @since 2.4.0 The function now runs as an ajax action.
 */
function edd_free_downloads_delete_cached_files( $download_id = null ) {

	$download_id = filter_input( INPUT_POST, 'download_id', FILTER_SANITIZE_NUMBER_INT );
	if ( ! $download_id ) {
		wp_send_json_error( array( 'message' => __( 'Invalid download ID.', 'edd-free-downloads' ) ) );
	}

	$timestamp = filter_input( INPUT_POST, 'timestamp', FILTER_SANITIZE_NUMBER_INT );
	$token     = filter_input( INPUT_POST, 'token', FILTER_SANITIZE_SPECIAL_CHARS );
	if ( ! EDD\Utils\Tokenizer::is_token_valid( $token, $timestamp ) ) {
		wp_send_json_error( array( 'message' => __( 'Invalid token.', 'edd-free-downloads' ) ) );
	}

	$nonce = filter_input( INPUT_POST, 'nonce', FILTER_SANITIZE_SPECIAL_CHARS );
	if ( ! $nonce || ! wp_verify_nonce( $nonce, 'edd_free_downloads_cache_nonce' ) ) {
		wp_send_json_error( array( 'message' => __( 'Nonce verification failed.', 'edd-free-downloads' ) ) );
	}

	$upload_dir  = wp_upload_dir();
	$upload_dir  = trailingslashit( $upload_dir['basedir'] . '/edd-free-downloads-cache' );
	$download_id = absint( $download_id );

	// Delete cached remote files
	$files = edd_free_downloads_get_files( $download_id );

	foreach ( $files as $file_name => $file_path ) {
		if ( file_exists( $upload_dir . $file_name ) ) {
			unlink( $upload_dir . $file_name );
		}
	}

	// Delete cached zip file
	$zip_name = apply_filters( 'edd_free_downloads_zip_name', strtolower( str_replace( ' ', '-', get_bloginfo( 'name' ) ) ) . '-bundle-' . $download_id . '.zip' );
	$zip_file = $upload_dir . '/' . $zip_name;

	if ( file_exists( $zip_file ) ) {
		unlink( $zip_file );
	}

	wp_send_json_success(
		array(
			'message' => __( 'Success', 'edd-free-downloads' ),
		)
	);
}
add_action( 'wp_ajax_edd_free_downloads_delete_cached_files', 'edd_free_downloads_delete_cached_files' );

/**
 * Get the notes for a given download
 *
 * @since       2.1.0
 * @return      void
 */
function edd_free_downloads_get_notes() {
	if ( ! $_POST['download_id'] ) {
		die( '-1' );
	}

	$download_id = intval( $_POST['download_id'] );
	$download    = get_post( $download_id );

	if ( 'download' != $download->post_type ) {
		die( '-2' );
	}

	$note    = '';
	$title   = '';
	$content = '';

	if ( ! edd_get_option( 'edd_free_downloads_disable_global_notes', false ) ) {
		$title   = edd_get_option( 'edd_free_downloads_notes_title', '' );
		$content = edd_get_option( 'edd_free_downloads_notes', '' );
	}

	if ( $download_title = get_post_meta( $download_id, '_edd_free_downloads_notes_title', true ) ) {
		$title = $download_title;
	}

	if ( $download_note = get_post_meta( $download_id, '_edd_free_downloads_notes', true ) ) {
		$content = $download_note;
	}

	if ( $title !== '' || $content !== '' ) {
		$note = array(
			'title'   => $title,
			'content' => wpautop( stripslashes( $content ) ),
		);

		$note = json_encode( $note );
	}

	echo $note;
	edd_die();
}
add_action( 'wp_ajax_edd_free_downloads_get_notes', 'edd_free_downloads_get_notes' );
add_action( 'wp_ajax_nopriv_edd_free_downloads_get_notes', 'edd_free_downloads_get_notes' );

/**
 * This function and related actions are called via an AJAX
 * request to trigger the modal for Free Downloads.
 *
 * @return string HTML output for the Free Downloads modal
 */
function edd_free_downloads_get_modal() {

	edd_get_template_part( 'download', 'modal' );

	edd_die();
}
add_action( 'wp_ajax_edd_free_downloads_get_modal', 'edd_free_downloads_get_modal' );
add_action( 'wp_ajax_nopriv_edd_free_downloads_get_modal', 'edd_free_downloads_get_modal' );

function edd_free_downloads_get_file_path() {

	$post_id = ! empty( $_GET['download_id'] ) ? intval( $_GET['download_id'] ) : false;

	if ( false !== $post_id ) {

		$download_file = get_post_meta( $post_id, 'edd_download_files', true );
		$download_file = wp_list_pluck( $download_file, 'file' );

		/**
		 * If we have more than one file we will zip them up here
		 * and update the URL appropriately.
		 */
		if ( count( $download_file ) > 1 ) {
			$download_file = edd_free_downloads_compress_files( $download_file );
			$download_file = str_replace( WP_CONTENT_DIR, WP_CONTENT_URL, $download_file );
		} else {
			/**
			 * We are dealing with a single file download
			 * @var [type]
			 */
			if ( isset( $download_file[1] ) ) {
				$download_file = $download_file[1];
			} else {
				/**
				 * Accounting for purchases with no download file
				 */
				$download_file = '';
			}
		}

		/**
		 * Note that wp_send_json also does die()
		 */
		wp_send_json( $download_file );
	}

	edd_die();
}
add_action( 'wp_ajax_edd_free_downloads_get_file_path', 'edd_free_downloads_get_file_path' );
add_action( 'wp_ajax_nopriv_edd_free_downloads_get_file_path', 'edd_free_downloads_get_file_path' );

/**
 * This function creates a wrapper div needed to allow for
 * javascript targeting of the inner modal elements
 */
function edd_free_downloads_add_modal_wrapper() {
	echo '<div class="edd-free-downloads-modal-wrapper edd-free-downloads"><span class="edd-loading"></span><div id="edd-free-downloads-modal" style="display:none"></div></div>';
}
add_action( 'wp_footer', 'edd_free_downloads_add_modal_wrapper' );
