<?php
/**
 * Scripts
 *
 * @package     EDD\FreeDownloads\Scripts
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load scripts
 *
 * @since       1.0.0
 * @return      void
 */
function edd_free_downloads_scripts() {
	EDD\FreeDownloads\Assets\Frontend::enqueue();
}
add_action( 'wp_enqueue_scripts', 'edd_free_downloads_scripts' );

/**
 * Load admin scripts
 *
 * @since       1.3.0
 * @return      void
 */
function edd_free_downloads_admin_scripts() {
	EDD\FreeDownloads\Assets\Admin::enqueue();
}
add_action( 'admin_enqueue_scripts', 'edd_free_downloads_admin_scripts' );
