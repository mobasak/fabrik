<?php
/**
 * Process the download purchase request.
 *
 * @package   EDD\FreeDownloads\Checkout
 * @copyright Copyright (c) 2024, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.4.0
 */

namespace EDD\FreeDownloads\Checkout;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Process class.
 */
class Process {

	/**
	 * The user ID.
	 *
	 * @since 2.4.0
	 * @var int
	 */
	private $user_id = 0;

	/**
	 * The user object.
	 *
	 * @var bool|\WP_User $user Represents the user associated with the checkout process.
	 */
	private $user = false;

	/**
	 * The payment object.
	 *
	 * @since 2.4.0
	 * @var \EDD_Payment
	 */
	private $payment;

	/**
	 * Process the download purchase request.
	 *
	 * @since 2.4.0
	 */
	public function process() {

		$this->check_form();

		edd_free_download_maybe_unhook_auto_register();

		$username                     = false;
		$email                        = $this->get_email();
		$free_downloads_must_register = \EDD\FreeDownloads\Utilities\Registration::user_registration_enabled();
		if ( $free_downloads_must_register ) {
			$username = $this->get_username();
			$password = $this->get_password();
			// If we are registering a user, make sure the required fields are filled out.
			if ( ! $username || ! $password ) {
				$this->process_die( esc_html__( 'The username and password fields are required, please try again.', 'edd-free-downloads' ), true );
			}

			// Make sure the email doesn't already exist.
			if ( email_exists( $email ) ) {
				$this->process_die( esc_html__( 'The specified email has already been used, please log in or try again.', 'edd-free-downloads' ), true );
			}
		}

		$this->user = $this->get_user( $email );
		if ( $this->user ) {
			$this->user_id = $this->user->ID;
		}

		$this->check_terms();

		$download = $this->get_download();

		// Maybe create a log in a new user.
		$require_verification = edd_free_downloads_verify_email();
		if ( $free_downloads_must_register && $username ) {
			$account = array(
				'user_login' => $username,
				'user_pass'  => $password,
				'user_email' => $email,
				'user_first' => $this->get_user_first_name(),
				'user_last'  => $this->get_user_last_name(),
			);

			if ( ! $require_verification ) {
				$this->user_id = edd_register_and_login_new_user( $account );
			} else {
				$this->user_id = wp_insert_user( $account );
			}
		}

		$order = $this->get_order();

		// If verification is not required, go ahead and mark the payment as 'completed'.
		if ( ! $require_verification ) {
			Complete::mark_order_complete( $order->id );
		}

		edd_add_note(
			array(
				'object_id'   => $order->id,
				'object_type' => 'order',
				'content'     => __( 'Purchased through EDD Free Downloads', 'edd-free-downloads' ),
			)
		);
		edd_add_order_meta( $order->id, 'edd_free_downloads_transaction', true );

		edd_empty_cart();
		edd_set_purchase_session(
			array(
				'purchase_key' => $order->payment_key,
			)
		);

		if ( $require_verification ) {
			$email_sent = edd_free_downloads_send_verification( $order, $email );
			if ( $email_sent ) {
				edd_add_note(
					array(
						'object_id'   => $order->id,
						'object_type' => 'order',
						'content'     => sprintf(
							/* translators: %s: email address */
							__( 'Free Downloads verification sent to %s.', 'edd-free-downloads' ),
							$email
						),
					)
				);

				wp_send_json_success(
					array(
						'message' => __( 'Your email has been successfully sent.', 'edd-free-downloads' ),
					)
				);
			} else {
				edd_add_note(
					array(
						'object_id'   => $order->id,
						'object_type' => 'order',
						'content'     => sprintf(
							/* translators: %s: email address */
							__( 'Free Downloads verification failed to send to %s.', 'edd-free-downloads' ),
							$email
						),
					)
				);

				wp_send_json_error(
					array(
						'message' => __( 'Your email failed to send, please try again.', 'edd-free-downloads' ),
					)
				);
			}
		}

		edd_free_downloads_complete_download( $order );
	}

	/**
	 * Check the form data.
	 *
	 * @since 2.4.0
	 */
	private function check_form() {
		if ( ! empty( $_POST['edd_free_download_check'] ) ) {
			$this->process_die( esc_html__( 'Bad spammer, no download!', 'edd-free-downloads' ) );
		}

		if ( ! isset( $_POST['edd_free_download_nonce'] ) || ! wp_verify_nonce( $_POST['edd_free_download_nonce'], 'edd_free_download_nonce' ) ) {
			$this->process_die( esc_html__( 'Cheatin&#8217; huh?', 'edd-free-downloads' ) );
		}

		if ( ! $this->get_email() ) {
			$this->process_die( esc_html__( 'An internal error has occurred, please try again or contact support. Email address not provided.', 'edd-free-downloads' ), true );
		}
	}

	/**
	 * Gets the username from the $_POST data.
	 *
	 * @since 2.4.0
	 * @return string|false
	 */
	private function get_username() {
		$username = ! empty( $_POST['edd_free_download_username'] ) ? trim( $_POST['edd_free_download_username'] ) : false;
		if ( empty( $username ) ) {
			$this->process_die( esc_html__( 'The username field is required, please try again.', 'edd-free-downloads' ), true );
		}

		if ( username_exists( $username ) ) {
			$this->process_die( esc_html__( 'The specified username already exists, please log in or try again.', 'edd-free-downloads' ), true );
		} elseif ( ! edd_validate_username( $username ) ) {
			// Invalid username
			if ( is_multisite() ) {
				$this->process_die( esc_html__( 'Invalid username. Only lowercase letters (a-z) and numbers are allowed.', 'edd-free-downloads' ), true );
			} else {
				$this->process_die( esc_html__( 'Invalid username.', 'edd-free-downloads' ), true );
			}
		}

		return $username;
	}

	/**
	 * Gets the password from the $_POST data.
	 *
	 * @since 2.4.0
	 * @return string|false
	 */
	private function get_password() {
		$password = ! empty( $_POST['edd_free_download_pass'] ) ? trim( $_POST['edd_free_download_pass'] ) : false;
		if ( empty( $password ) ) {
			$this->process_die( esc_html__( 'The password field is required, please try again.', 'edd-free-downloads' ), true );
		}

		$password2 = ! empty( $_POST['edd_free_download_pass2'] ) ? trim( $_POST['edd_free_download_pass2'] ) : false;
		if ( ! $password2 || $password !== $password2 ) {
			$this->process_die( esc_html__( 'Password and password confirmation fields don\'t match, please try again.', 'edd-free-downloads' ), true );
		}

		return $password;
	}

	/**
	 * Gets the email from the $_POST data.
	 *
	 * @since 2.4.0
	 * @return string|false
	 */
	private function get_email() {
		$email = ! empty( $_POST['edd_free_download_email'] ) ? trim( $_POST['edd_free_download_email'] ) : false;

		if ( ! is_email( $email ) || ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
			$this->process_die( esc_html__( 'Please enter a valid email address.', 'edd-free-downloads' ) );
		}

		// No banned emails please!
		if ( edd_is_email_banned( $email ) ) {
			$this->process_die( esc_html__( 'Your email address or domain is not allowed to download content. Please contact support if you feel this is an error.', 'edd-free-downloads' ) );
		}

		return $email;
	}

	/**
	 * Gets the user object.
	 *
	 * @since 2.4.0
	 * @param string $email The email address.
	 * @return \WP_User|false
	 */
	private function get_user( $email ) {
		if ( is_user_logged_in() ) {
			return wp_get_current_user();
		}

		return get_user_by( 'email', $email );
	}

	/**
	 * Retrieves the first name of the user.
	 *
	 * @return string The first name of the user.
	 */
	private function get_user_first_name() {
		if ( ! empty( $_POST['edd_free_download_fname'] ) ) {
			return sanitize_text_field( $_POST['edd_free_download_fname'] );
		}

		return $this->user ? $this->user->first_name : '';
	}

	/**
	 * Retrieves the last name of the user.
	 *
	 * @return string The last name of the user.
	 */
	private function get_user_last_name() {
		if ( ! empty( $_POST['edd_free_download_lname'] ) ) {
			return sanitize_text_field( $_POST['edd_free_download_lname'] );
		}

		return $this->user ? $this->user->last_name : '';
	}

	/**
	 * Gets the download object.
	 *
	 * @since 2.4.0
	 * @return \WP_Post
	 */
	private function get_download() {
		$download_id = filter_input( INPUT_POST, 'edd_free_download_id', FILTER_VALIDATE_INT );
		if ( empty( $download_id ) ) {
			$this->process_die( esc_html__( 'An internal error has occurred, please try again or contact support. $download_id is empty', 'edd-free-downloads' ) );
		}

		$download = get_post( $download_id );
		if ( ! $download instanceof \WP_Post ) {
			$this->process_die( esc_html__( 'An internal error has occurred, please try again or contact support. Download is not a valid object', 'edd-free-downloads' ) );
		}

		if ( 'download' !== $download->post_type ) {
			$this->process_die( esc_html__( 'An internal error has occurred, please try again or contact support. Invalid object type', 'edd-free-downloads' ) );
		}

		// Bail if this isn't a published download (or the current user can't edit it)
		if ( 'publish' !== $download->post_status && ! current_user_can( 'edit_post', $download->ID ) ) {
			$this->process_die( esc_html__( 'An internal error has occurred, please try again or contact support. User does not have access to this download or the download is not available', 'edd-free-downloads' ) );
		}

		return $download;
	}

	/**
	 * Gets the payment object.
	 *
	 * @since 2.4.0
	 * @return \EDD\Orders\Order
	 */
	private function get_order() {
		// Ensure there is not any session data that might cause bad data.
		add_filter( 'edd_fees_get_fees', '__return_empty_array' );

		$email = $this->get_email();
		if ( is_user_logged_in() ) {
			$user = $this->get_user( false );
			if ( $user ) {
				$email = $user->user_email;
			}
		}
		$order_data = array(
			'gateway'      => 'manual',
			'user_info'    => array(
				'id'         => $this->user_id,
				'email'      => $email,
				'first_name' => $this->get_user_first_name(),
				'last_name'  => $this->get_user_last_name(),
			),
			'cart_details' => array(),
		);

		$download  = $this->get_download();
		$price_ids = $this->get_price_ids();
		if ( is_array( $price_ids ) ) {
			foreach ( $price_ids as $price_id ) {
				/**
				 * This logic handles multi-purchase mode with multiple $price_ids selected.
				 *
				 * $price_ids should be an array here.
				 */
				if ( ! edd_is_free_download( $download->ID, $price_id ) ) {
					$this->process_die( __( 'The requested product is not a free product! Please try again or contact support.', 'edd-free-downloads' ) );
				}

				$order_data['cart_details'][] = array(
					'id'         => $download->ID,
					'price_id'   => $price_id,
					'quantity'   => 1,
					'subtotal'   => 0,
					'name'       => edd_get_download_name( $download->ID, $price_id ),
					'amount'     => 0,
					'discount'   => 0,
					'tax'        => 0,
					'price'      => 0,
					'item_price' => 0,
				);
			}
		} elseif ( ! is_array( $price_ids ) && ! empty( $price_ids ) ) {
			/**
			 * This logic deals with variable pricing and accounts for if there is a
			 * free product as well.
			 *
			 * In this situation there is only a single price id though the
			 * variable is still $price_ids.
			 *
			 * $price_ids should be a single integer here.
			 */
			if ( ! edd_is_free_download( $download->ID, $price_ids ) ) {
				$this->process_die( __( 'The requested product is not a free product! Please try again or contact support.', 'edd-free-downloads' ) );
			}

			$order_data['cart_details'][] = array(
				'id'         => $download->ID,
				'price_id'   => $price_ids,
				'quantity'   => 1,
				'subtotal'   => 0,
				'name'       => edd_get_download_name( $download->ID, $price_ids ),
				'amount'     => 0,
				'discount'   => 0,
				'tax'        => 0,
				'price'      => 0,
				'item_price' => 0,
			);
		} else {
			/**
			 * This logic deal with a free download.
			 *
			 * In this situation there is no price id set thus we
			 * will set it to `false` below.
			 */
			if ( ! edd_is_free_download( $download->ID ) ) {
				$this->process_die( __( 'An internal error has occurred, please try again or contact support. Invalid item.', 'edd-free-downloads' ) );
			}

			$order_data['cart_details'][] = array(
				'id'         => $download->ID,
				'price_id'   => null,
				'quantity'   => 1,
				'subtotal'   => 0,
				'name'       => edd_get_download_name( $download->ID ),
				'amount'     => 0,
				'discount'   => 0,
				'tax'        => 0,
				'price'      => 0,
				'item_price' => 0,
			);
		}

		$order_id = edd_build_order( $order_data );

		if ( filter_input( INPUT_POST, 'edd_free_download_optin', FILTER_VALIDATE_BOOLEAN ) ) {
			edd_add_order_meta( $order_id, 'edd_free_download_optin', true );
		}

		return edd_get_order( $order_id );
	}

	/**
	 * Checks if the terms and privacy policy are agreed to if set.
	 *
	 * @since 2.4.0
	 */
	private function check_terms() {
		// If privacy policy is required, verify it's checked.
		if ( edd_get_option( 'edd_free_downloads_display_privacy_policy_agreement', false ) ) {
			$agreed = filter_input( INPUT_POST, 'edd_agree_to_privacy_policy', FILTER_VALIDATE_BOOLEAN );
			if ( ! $agreed ) {
				$agreed = filter_input( INPUT_POST, 'edd_free_download_privacy_agreement', FILTER_VALIDATE_BOOLEAN );
			}
			if ( ! $agreed ) {
				$this->process_die( esc_html__( 'You must agree to the privacy policy to download this content.', 'edd-free-downloads' ) );
			}
		}

		if ( edd_get_option( 'edd_free_downloads_display_terms', false ) && ! filter_input( INPUT_POST, 'edd_agree_to_terms', FILTER_VALIDATE_BOOLEAN ) ) {
			$this->process_die( esc_html__( 'You must agree to the terms and conditions to download this content.', 'edd-free-downloads' ) );
		}
	}

	/**
	 * Gets the price IDs from the $_POST data.
	 *
	 * @since 2.4.0
	 * @return array|string|false
	 */
	private function get_price_ids() {
		$price_ids = isset( $_POST['edd_free_download_price_id'] ) ? array_map( 'intval', $_POST['edd_free_download_price_id'] ) : false;
		if ( ! $price_ids && isset( $_GET['price_ids'] ) ) {
			$price_ids = array_map( 'intval', json_decode( $_GET['price_ids'] ) );
		}

		return $price_ids;
	}

	/**
	 * Process a die message.
	 *
	 * @param string $message The message to display.
	 * @param bool   $show_backlink Whether to show the backlink.
	 */
	private function process_die( $message, $show_backlink = false ) {
		wp_die(
			esc_html( $message ),
			esc_html__( 'Error', 'edd-free-downloads' ),
			array( 'back_link' => (bool) $show_backlink )
		);
	}
}
