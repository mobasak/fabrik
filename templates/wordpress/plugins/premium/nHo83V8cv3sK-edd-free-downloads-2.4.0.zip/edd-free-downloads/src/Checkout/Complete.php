<?php
/**
 * Complete the checkout process.
 *
 * @package   EDD\FreeDownloads\Checkout
 * @copyright Copyright (c) 2024, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.4.0
 */

namespace EDD\FreeDownloads\Checkout;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Complete class.
 */
class Complete {

	/**
	 * Marks an order as complete.
	 *
	 * @since 2.4.0
	 * @param int $order_id The order ID.
	 * @return void
	 */
	public static function mark_order_complete( $order_id ) {
		do_action( 'edd_free_downloads_pre_complete_payment', $order_id );
		edd_update_order_status( $order_id, 'complete' );
		do_action( 'edd_free_downloads_post_complete_payment', $order_id );
	}

	/**
	 * Complete a payment.
	 *
	 * @param \EDD\Orders\Order $order The order object.
	 * @return void
	 */
	public function complete( $order ) {
		if ( empty( $order ) || ! $order instanceof \EDD\Orders\Order ) {
			wp_die( esc_html__( 'Error completing download request', 'edd-free-downloads' ), 403 );
		}

		$redirect_url = $this->get_redirect_url( $order );
		if ( has_filter( 'edd_free_downloads_redirect_url' ) ) {
			$payment      = edd_get_payment( $order->id );
			$redirect_url = apply_filters(
				'edd_free_downloads_redirect_url',
				$redirect_url,
				$payment
			);
		}

		edd_debug_log( 'Free Downloads: Processing download with redirect URL of - ' . $redirect_url );
		if ( edd_doing_ajax() ) {
			wp_send_json_success( array( 'redirect' => $redirect_url ) );
		}

		edd_redirect( $redirect_url );
	}

	/**
	 * Get the redirect URL for the download.
	 *
	 * @param \EDD\Orders\Order $order The order object.
	 * @return string
	 */
	private function get_redirect_url( $order ) {
		$csr_redirect = $this->get_csr_redirect( $order );
		if ( $csr_redirect ) {
			return $csr_redirect;
		}

		$on_complete = $this->get_on_complete( $order );

		edd_debug_log( 'Free Downloads: Processing download with complete handler - ' . $on_complete );

		if ( 'auto-download' === $on_complete ) {
			$redirect_url = add_query_arg(
				array(
					'edd_action' => 'free_downloads_process_download',
					'payment-id' => $order->id,
				)
			);
		} else {
			$redirect_url = Redirect::get_success_redirect_uri( $order, $on_complete );
		}

		$mobile_redirect = $this->get_mobile_redirect( $order->id );
		if ( $mobile_redirect ) {
			return $mobile_redirect;
		}

		return $redirect_url ? $redirect_url : edd_get_success_page_uri();
	}

	/**
	 * Get the on complete action.
	 *
	 * @param \EDD\Orders\Order $order The order object.
	 * @return string
	 */
	private function get_on_complete( $order ) {
		$on_complete = edd_get_option( 'edd_free_downloads_on_complete', 'default' );

		// Determine if we have files to deliver.
		$all_files = array();
		foreach ( $order->items as $order_item ) {
			$download_files = edd_get_download_files( $order_item->product_id, $order_item->price_id );

			if ( ! empty( $download_files ) ) {
				$all_files[] = $download_files;
			}
		}

		/**
		 * This accounts for logged in users when no download file is attached to the purchase.
		 *
		 * Also logic to make sure if the custom redirect option is set
		 */
		edd_debug_log( 'Free Downloads: Processing download, has downloads - ' . var_export( $all_files, true ) );
		if ( empty( $all_files ) && ! in_array( $on_complete, array( 'default', 'redirect' ), true ) ) {
			$on_complete = 'default';
		}

		return $on_complete;
	}

	/**
	 * Get the mobile redirect URL.
	 *
	 * @since 2.4.0
	 * @param int $order_id The order ID.
	 * @return string|false
	 */
	private function get_mobile_redirect( $order_id ) {
		if ( ! wp_is_mobile() ) {
			return false;
		}
		$mobile             = new \Detection\MobileDetect();
		$is_ios             = $mobile->isiOS();
		$mobile_on_complete = edd_get_option( 'edd_free_downloads_mobile_on_complete', 'default' );
		$apple_on_complete  = edd_get_option( 'edd_free_downloads_apple_on_complete', 'default' );

		if ( ( $is_ios && 'default' === $apple_on_complete ) || ( ! $is_ios && 'default' === $mobile_on_complete ) ) {
			return false;
		}

		if ( ( $is_ios && 'confirmation' === $apple_on_complete ) || ( ! $is_ios && 'confirmation' === $mobile_on_complete ) ) {
			return edd_get_success_page_uri();
		}

		if ( ( ! $is_ios && 'auto-download' === $mobile_on_complete ) ) {
			return add_query_arg(
				array(
					'edd_action' => 'free_downloads_process_download',
					'payment-id' => $order_id,
				)
			);
		}

		if ( ( $is_ios && 'redirect' === $apple_on_complete ) || ( ! $is_ios && 'redirect' === $mobile_on_complete ) ) {
			$success_page = edd_get_success_page_uri();

			return $is_ios ? edd_get_option( 'edd_free_downloads_apple_redirect', $success_page ) : edd_get_option( 'edd_free_downloads_mobile_redirect', $success_page );
		}

		return false;
	}

	/**
	 * Maybe update the redirect URL for the download for Conditional Success Redirects.
	 *
	 * @since 2.4.0
	 * @param \EDD\Orders\Order $order The order object.
	 * @return string|false
	 */
	private function get_csr_redirect( $order ) {
		if ( ! function_exists( 'edd_csr_is_redirect_active' ) ) {
			return false;
		}

		$order_item  = reset( $order->items );
		$redirect_id = edd_csr_get_redirect_id( $order_item->product_id );
		if ( edd_csr_is_redirect_active( $redirect_id ) ) {
			return get_permalink( edd_csr_get_redirect_page_id( $redirect_id ) );
		}

		return false;
	}
}
