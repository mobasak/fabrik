<?php
/**
 * Redirect class.
 *
 * @since 2.3.15
 * @package EDD\FreeDownloads\Checkout
 */

namespace EDD\FreeDownloads\Checkout;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Redirect class.
 */
class Redirect {

	/**
	 * Get the redirect URL for a successful purchase.
	 *
	 * @param \EDD\Orders\Order $order       The order object.
	 * @param string            $on_complete Completion type.
	 * @return string
	 */
	public static function get_success_redirect_uri( $order, $on_complete ) {
		if ( $order instanceof \EDD_Payment ) {
			$order = edd_get_order( $order->ID );
		}
		if ( 'redirect' === $on_complete ) {
			$custom_url = edd_get_option( 'edd_free_downloads_redirect', false );
			if ( $custom_url ) {
				return add_query_arg( 'payment_key', $order->payment_key, $custom_url );
			}
		}

		$purchase_session = edd_get_purchase_session();
		if ( ! empty( $purchase_session['purchase_key'] ) && hash_equals( $order->payment_key, $purchase_session['purchase_key'] ) ) {
			return add_query_arg( 'payment_key', $order->payment_key, edd_get_success_page_uri() );
		}

		return edd_get_receipt_page_uri( $order->id );
	}
}
