<?php
/**
 * Registration utility class.
 *
 * @package   EDD\FreeDownloads\Utilities
 * @copyright Copyright (c) 2024, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.4.0
 */

namespace EDD\FreeDownloads\Utilities;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Registration class.
 *
 * @since 2.4.0
 */
class Registration {

	/**
	 * Checks if free downloads must handle user registration.
	 *
	 * @since 2.4.0
	 * @return bool
	 */
	public static function user_registration_enabled() {
		if ( is_user_logged_in() ) {
			return false;
		}

		$user_registration = edd_get_option( 'edd_free_downloads_user_registration', false );
		if ( $user_registration && ! edd_get_option( 'edd_free_downloads_bypass_auto_register', false ) ) {
			return false;
		}

		return $user_registration;
	}
}
