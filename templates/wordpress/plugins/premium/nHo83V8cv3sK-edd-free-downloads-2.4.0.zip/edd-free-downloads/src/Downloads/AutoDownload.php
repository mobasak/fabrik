<?php
/**
 * Auto download class.
 *
 * @package   EDD\FreeDownloads\Downloads
 * @copyright Copyright (c) 2024, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.4.0
 */

namespace EDD\FreeDownloads\Downloads;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Auto download class.
 *
 * @since 2.4.0
 */
class AutoDownload {

	/**
	 * Array of download files.
	 *
	 * @since 2.4.0
	 * @var array
	 */
	private $download_files = array();

	/**
	 * The order object.
	 *
	 * @since 2.4.0
	 * @var bool|\EDD\Orders\Order
	 */
	private $order = false;

	/**
	 * The download ID.
	 *
	 * @since 2.4.0
	 * @var int
	 */
	private $download_id;

	/**
	 * The order ID.
	 *
	 * @since 2.4.0
	 * @var int
	 */
	private $order_id;

	/**
	 * Processes the download.
	 *
	 * @since 2.4.0
	 */
	public function process() {
		$this->download_id = filter_input( INPUT_GET, 'download_id', FILTER_SANITIZE_NUMBER_INT );
		$this->order_id    = filter_input( INPUT_GET, 'payment-id', FILTER_SANITIZE_NUMBER_INT );
		if ( ! $this->order_id && ! $this->download_id ) {
			return;
		}

		if ( $this->order_id ) {
			$this->get_download_files_for_order();
		} else {
			$this->find_or_create_order();
		}

		if ( $this->can_auto_download() ) {
			$this->do_auto_download();

			return;
		}

		if ( ! $this->order ) {
			return;
		}

		$this->complete( edd_get_option( 'edd_free_downloads_on_complete', 'default' ) );
	}

	/**
	 * Gets the download files for an order.
	 *
	 * @since 2.4.0
	 */
	private function get_download_files_for_order() {
		$order = edd_get_order( $this->order_id );
		if ( ! $order || empty( $order->get_items() ) ) {
			return;
		}

		$download_files = array();
		foreach ( $order->get_items() as $key => $item ) {
			$this->download_id = $item->product_id;
			$download_files    = array_merge( $download_files, $this->get_download_files( $item->product_id, $item->price_id ) );
		}

		$this->download_files = array_merge( $this->download_files, $download_files );
	}

	/**
	 * Finds or creates an order.
	 *
	 * @since 2.4.0
	 */
	private function find_or_create_order() {

		$price_ids = null;
		if ( isset( $_GET['price_ids'] ) ) {
			$price_ids = explode( ',', trim( sanitize_text_field( $_GET['price_ids'] ) ) );
		} elseif ( edd_has_variable_prices( $this->download_id ) ) {
			$price_ids = edd_get_default_variable_price( $this->download_id );
		}

		if ( is_array( $price_ids ) && ! empty( $price_ids ) ) {
			foreach ( $price_ids as $cart_id => $price_id ) {
				if ( ! edd_is_free_download( $this->download_id, $price_id ) ) {
					wp_die( __( 'The requested product is not a free product! Please try again or contact support.', 'edd-free-downloads' ), __( 'Error', 'edd-free-downloads' ) );
				}
			}
		} elseif ( ! is_array( $price_ids ) && ! empty( $price_ids ) && ! edd_is_free_download( $this->download_id, $price_ids ) ) {
			wp_die( __( 'The requested product is not a free product! Please try again or contact support.', 'edd-free-downloads' ), __( 'Error', 'edd-free-downloads' ) );
		} elseif ( ! edd_is_free_download( $this->download_id ) ) {
			wp_die( esc_html__( 'An internal error has occurred, please try again or contact support. Invalid item.', 'edd-free-downloads' ), __( 'Error', 'edd-free-downloads' ) );
		}

		$this->maybe_create_order( $this->download_id, $price_ids );

		$this->download_files = array_merge( $this->download_files, $this->get_download_files( $this->download_id, $price_ids ) );
	}

	/**
	 * Gets the download files.
	 *
	 * @since 2.4.0
	 *
	 * @param int            $download_id The download ID.
	 * @param int|null|array $price_id    The price ID or array of price IDs.
	 *
	 * @return array
	 */
	private function get_download_files( $download_id, $price_id = null ) {
		$archive_url = get_post_meta( $download_id, '_edd_free_downloads_file', true );

		if ( ! empty( $archive_url ) ) {
			return array( basename( $archive_url ) => $archive_url );
		}

		if ( ! is_null( $price_id ) ) {
			if ( is_array( $price_id ) ) {
				$download_files = array();
				foreach ( $price_id as $p_id ) {
					$download_files = array_merge( $download_files, edd_free_downloads_get_files( $download_id, $p_id ) );
				}

				return $download_files;
			}

			return edd_free_downloads_get_files( $download_id, $price_id );
		}

		return edd_free_downloads_get_files( $download_id );
	}

	/**
	 * Maybe creates an order, if it is needed, for a logged in user.
	 *
	 * @since 2.4.0
	 *
	 * @param int        $download_id The download ID.
	 * @param null|array $price_ids   The price IDs.
	 */
	private function maybe_create_order( $download_id, $price_ids = null ) {
		if ( ! is_user_logged_in() ) {
			return;
		}

		/**
		 * Getting our logged in user info
		 *
		 * This do_action is needed to correctly get currently logged in user.
		 */
		do_action( 'edd_pre_process_purchase' );

		$user_id  = get_current_user_id();
		$user     = get_userdata( $user_id );
		$customer = new \EDD_Customer( $user_id, true );

		// Allow extensions to require a new payment record be made every time.
		$require_new_payment = apply_filters( 'edd_free_downloads_require_new_payment', false, $download_id, $user_id, $customer );

		// If multi-purchase mode is enabled and used, require a new payment.
		if ( ! empty( $price_ids ) && count( $price_ids ) > 1 ) {
			$require_new_payment = true;
		}

		$has_purchased = false;
		if ( false === $require_new_payment ) {
			$has_purchased_price_ids = empty( $price_ids ) ? null : $price_ids;
			$has_purchased           = edd_has_user_purchased( $user_id, $download_id, $has_purchased_price_ids );
		}

		// If the user is already logged in, has purchased this item before and a new record isn't required, look it up.
		if ( false === $require_new_payment && true === $has_purchased ) {
			$orders = edd_get_orders(
				array(
					'user_id'    => $user_id,
					'number'     => 1,
					'fields'     => 'id',
					'product_id' => $download_id,
				)
			);
			if ( ! empty( $orders ) ) {
				$this->order_id = reset( $orders );
				$this->order    = edd_get_order( $this->order_id );
			}
		}

		if ( empty( $customer->id ) ) {
			$customer->create(
				array(
					'email'   => $user->data->user_email,
					'user_id' => $user_id,
					'name'    => trim( $user->first_name . ' ' . $user->last_name ),
				)
			);
		}

		$order_data = array(
			'gateway'      => 'manual',
			'user_info'    => array(
				'id'         => $user_id,
				'email'      => $user->data->user_email,
				'first_name' => $user->first_name,
				'last_name'  => $user->last_name,
			),
			'cart_details' => array(),
		);

		if ( is_array( $price_ids ) && ! empty( $price_ids ) ) {
			foreach ( $price_ids as $price_id ) {
				$order_data['cart_details'][] = array(
					'id'         => $download_id,
					'price_id'   => $price_id,
					'quantity'   => 1,
					'subtotal'   => 0,
					'name'       => edd_get_download_name( $download_id, $price_id ),
					'amount'     => 0,
					'discount'   => 0,
					'tax'        => 0,
					'price'      => 0,
					'item_price' => 0,
				);
			}
		} else {
			$order_data['cart_details'][] = array(
				'id'         => $download_id,
				'price_id'   => null,
				'quantity'   => 1,
				'subtotal'   => 0,
				'name'       => edd_get_download_name( $download_id ),
				'amount'     => 0,
				'discount'   => 0,
				'tax'        => 0,
				'price'      => 0,
				'item_price' => 0,
			);
		}
		$this->order_id = edd_build_order( $order_data );

		\EDD\FreeDownloads\Checkout\Complete::mark_order_complete( $this->order_id );

		$this->order = edd_get_order( $this->order_id );

		edd_add_note(
			array(
				'object_id'   => $this->order->id,
				'object_type' => 'order',
				'content'     => __( 'Purchased through EDD Free Downloads', 'edd-free-downloads' ),
			)
		);
	}

	/**
	 * Auto download the file.
	 *
	 * @since 2.4.0
	 */
	private function do_auto_download() {
		if ( empty( $this->download_files ) ) {
			$this->complete( 'default' );
			return;
		}

		if ( count( $this->download_files ) > 1 ) {
			$download_url = edd_free_downloads_compress_files( $this->download_files, $this->download_id );
			$download_url = str_replace( WP_CONTENT_DIR, WP_CONTENT_URL, $download_url );

			// Prevent errors with edd_free_downloads_download_file()
			$hosted = 'multi';
		} else {

			$download_url = array_values( $this->download_files );
			$download_url = $download_url[0]['file'] ?? $download_url[0];

			$hosted = edd_free_downloads_get_host( $download_url );
			if ( 'local' !== $hosted ) {
				$download_url = edd_free_downloads_fetch_remote_file( $download_url, $hosted );
				$download_url = str_replace( WP_CONTENT_DIR, WP_CONTENT_URL, $download_url );
			}
		}

		/**
		 * If the user submitted information and a payment was created, log the file download.
		 *
		 * If the Direct Download option is enabled, and the user clicks the direct download link, no payment is created
		 * and we should bypass this attempt to log the file download as the necessary information is not present.
		 */
		if ( ! empty( $this->order ) ) {
			/**
			 * Looping through files to create report logs
			 */
			foreach ( $this->download_files as $download_file ) {
				if ( empty( $download_file['download_id'] ) ) {
					continue;
				}
				edd_record_download_in_log(
					$download_file['download_id'],
					$download_file['file_id'],
					array(),
					edd_get_ip(),
					$this->order->id
				);
			}
		}

		edd_free_downloads_download_file( $download_url, $hosted );
	}

	/**
	 * Completes the download process.
	 *
	 * @since 2.4.0
	 * @param string $on_complete The on complete action.
	 */
	private function complete( $on_complete ) {
		if ( ! empty( $this->order ) ) {
			$redirect_url = \EDD\FreeDownloads\Checkout\Redirect::get_success_redirect_uri( $this->order, $on_complete );
		} else {
			$redirect_url = remove_query_arg( array( 'edd_action', 'download_id', 'payment-id' ) );
		}

		wp_safe_redirect( $redirect_url );
		exit;
	}

	/**
	 * Checks if the download can be automatically downloaded, because either:
	 * - The on complete action is set to auto-download.
	 * - The direct download option is enabled and the email verification is disabled.
	 *
	 * @since 2.4.0
	 * @return bool
	 */
	private function can_auto_download() {
		if ( 'auto-download' === edd_get_option( 'edd_free_downloads_on_complete', 'default' ) ) {
			return true;
		}

		return edd_get_option( 'edd_free_downloads_direct_download', false ) && ! edd_free_downloads_verify_email();
	}
}
