<?php

namespace EDD\FreeDownloads\Downloads;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use EDD\FreeDownloads\Assets\Frontend;

class Form {

	/**
	 * The arguments passed to the form.
	 *
	 * @since 2.3.11
	 * @var array
	 */
	private $args;

	/**
	 * Form constructor.
	 *
	 * @param string $purchase_form The purchase form.
	 * @param array  $args          The arguments passed to the form.
	 */
	public function __construct( $args ) {
		$this->args = $args;
	}

	/**
	 * Get the purchase form.
	 *
	 * @since 2.3.11
	 * @return string
	 */
	public function get() {

		$download_id    = absint( $this->args['download_id'] );
		$form_id        = "edd_purchase_{$download_id}";
		$download_label = $this->get_download_label();
		$button_style   = ( array_key_exists( 'style', $this->args ) && isset( $this->args['style'] ) ) ? $this->args['style'] : edd_get_option( 'button_style', 'button' );
		$button_color   = ( array_key_exists( 'color', $this->args ) && isset( $this->args['color'] ) ) ? $this->args['color'] : edd_get_option( 'checkout_color', 'blue' );
		$button_class   = ( array_key_exists( 'class', $this->args ) && isset( $this->args['class'] ) ) ? $this->args['class'] : '';

		// If the user is not logged in, or if the user must be logged in to download, show the purchase form.
		if ( ! is_user_logged_in() || ! edd_get_option( 'edd_free_downloads_bypass_logged_in', false ) ) {

			$download_class = implode( ' ', array_filter( array( $button_style, $button_color, $button_class, 'edd-submit edd-free-download edd-free-download-single' ) ) );
			$href           = '#edd-free-download-modal';

			/**
			 * Output buffer is needed here to allow for do_action to work as expected
			 */
			ob_start();
			Frontend::enqueue( true );
			?>

			<form id="<?php echo esc_attr( $form_id ); ?>" class="edd_download_purchase_form">
				<?php do_action( 'edd_purchase_link_top', $download_id, $this->args ); ?>
				<div class="edd_free_downloads_form_class">
					<?php
					if ( edd_is_ajax_enabled() ) {
						echo apply_filters(
							'edd_free_downloads_button_override',
							sprintf(
								'<a class="%1$s" href="' . $href . '" data-download-id="%3$s">%2$s</a>',
								$download_class,
								$download_label,
								$download_id
							),
							$download_id
						);
					} else {
						echo apply_filters(
							'edd_free_downloads_button_override',
							sprintf(
								'<input type="submit" class="edd-no-js %1$s" name="edd_purchase_download" value="%2$s" href="' . $href . '" data-download-id="%3$s" />',
								$download_class,
								$download_label,
								$download_id
							),
							$download_id
						);
					}
					?>
				</div>
				<?php do_action( 'edd_purchase_link_end', $download_id, $this->args ); ?>
			</form>

			<?php

			return ob_get_clean();
		}

		$download_class = implode( ' ', array_filter( array( edd_get_option( 'button_style', 'button' ), edd_get_option( 'checkout_color', 'blue' ), 'edd-submit' ) ) );

		/**
		 * Output buffer is needed here to allow for do_action to work as expected
		 */
		ob_start();
		Frontend::enqueue( true );
		?>
		<div class="edd_download_purchase_form">
		<?php do_action( 'edd_purchase_link_top', $download_id, $this->args ); ?>
			<div class="edd_free_downloads_form_class">
			<?php
			echo apply_filters(
				'edd_free_downloads_button_override',
				sprintf(
					'<a href="#" class="edd-free-downloads-direct-download-link %1$s" data-download-id="%3$s">%2$s</a>',
					$download_class,
					$download_label,
					$download_id
				),
				$download_id
			);
			?>
			</div>
			<?php do_action( 'edd_purchase_link_end', $download_id, $this->args ); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Get the download button label.
	 *
	 * @since 2.3.11
	 * @return string
	 */
	private function get_download_label() {
		$download_label = edd_get_option( 'edd_free_downloads_button_label', __( 'Download Now', 'edd-free-downloads' ) );

		// If the text argument is empty, return the default download label.
		if ( empty( $this->args['text'] ) ) {
			return $download_label;
		}

		$current_label = $this->args['text'];

		/**
		 * If the current label has price - purchase, we need to remove the price part and return the purchase part.
		 */
		if ( false !== strpos( $current_label, '&nbsp;&ndash;&nbsp;' ) ) {
			$text = explode( '&nbsp;&ndash;&nbsp;', $current_label );
			if ( ! empty( $text[1] ) ) {
				unset( $text[0] );
				$current_label = implode( '&nbsp;&ndash;&nbsp;', $text );
			}
		}
		$add_to_cart_label = edd_get_option( 'add_to_cart_text', __( 'Add to Cart', 'easy-digital-downloads' ) );
		$checkout_label    = edd_get_option( 'checkout_label', __( 'Purchase', 'easy-digital-downloads' ) );
		$buy_now_label     = edd_get_option( 'buy_now_text', __( 'Buy Now', 'easy-digital-downloads' ) );

		// If the current label is not one of the default labels, return the current label.
		if ( ! in_array( $current_label, array( $add_to_cart_label, $checkout_label, $buy_now_label ), true ) ) {
			return $current_label;
		}

		return $download_label;
	}
}
