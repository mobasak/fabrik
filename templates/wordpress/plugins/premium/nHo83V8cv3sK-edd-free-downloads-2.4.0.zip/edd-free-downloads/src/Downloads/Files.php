<?php

namespace EDD\FreeDownloads\Downloads;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Files {

	/**
	 * Get the files for a download.
	 *
	 * @param int $download_id Download ID.
	 * @param int $price_id    Price ID.
	 * @return array
	 */
	public static function get( $download_id, $price_id = null ) {
		$archive_url = self::get_archive_url( $download_id );

		if ( false !== $archive_url ) {
			return $archive_url;
		}

		if ( is_array( $price_id ) && ! empty( $price_id ) && ! edd_is_bundled_product( $download_id ) ) {
			$download_files = array();
			foreach ( $price_id as $pid ) {
				$download_files = array_merge( $download_files, edd_free_downloads_get_files( $download_id, $pid ) );
			}

			return $download_files;
		}

		return edd_free_downloads_get_files( $download_id, $price_id );
	}

	/**
	 * Get the archive URL for a download.
	 *
	 * @param int $download_id Download ID.
	 * @return array|bool
	 */
	private static function get_archive_url( $download_id ) {
		$archive_url = get_post_meta( $download_id, '_edd_free_downloads_file', true );
		if ( empty( $archive_url ) ) {
			return false;
		}

		$file_type = wp_check_filetype( $archive_url );
		if ( empty( $file_type['type'] ) ) {
			return array();
		}

		$download_file = array(
			'file'        => $archive_url,
			'download_id' => $download_id,
			'file_id'     => 0,
		);

		return array( basename( $archive_url ) => $download_file );
	}
}
