<?php
/**
 * Class to handle fetching remote files.
 *
 * @package     EDD\FreeDownloads\Downloads
 * @copyright   Copyright (c) 2024, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.4.0
 */

namespace EDD\FreeDownloads\Downloads;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

/**
 * Remote files class.
 */
class RemoteFiles {

	/**
	 * Fetch a file from a remote location.
	 *
	 * @since 2.4.0
	 * @param string $file_path            The file path.
	 * @param string $hosted               The file host.
	 * @param bool   $force_local_download Whether to force a local download.
	 * @return string|false
	 */
	public static function fetch( $file_path, $hosted, $force_local_download = false ) {

		if ( 'amazon' === $hosted && defined( 'EDD_AS3_VERSION' ) ) {
			return self::handle_amazon( $file_path );
		}

		if ( 'dropbox' === $hosted ) {
			return self::handle_dropbox( $file_path );
		}

		$local_cache_disabled = edd_get_option( 'edd_free_downloads_disable_cache', false );
		if ( false === $force_local_download && filter_var( $local_cache_disabled, FILTER_VALIDATE_BOOLEAN ) ) {
			return self::force_external_download( $file_path );
		}

		$local_file_name = basename( $file_path );
		$wp_upload_dir   = wp_upload_dir();
		$local_file_path = $wp_upload_dir['basedir'] . '/edd-free-downloads-cache/';
		$local_file      = $local_file_path . remove_query_arg( 'dl', $local_file_name );

		if ( ! file_exists( $local_file ) ) {
			// Remote files must be downloaded to the local machine!
			$args = array(
				'timeout' => 300,
			);

			$response = wp_remote_get( $file_path, $args );
			if ( is_wp_error( $response ) ) {
				return false;
			}
			$new_file = wp_remote_retrieve_body( $response );
			if ( ! $new_file ) {
				return false;
			}

			file_put_contents( $local_file_path . urldecode( remove_query_arg( 'dl', $local_file_name ) ), $new_file );
		}

		return $local_file;
	}

	/**
	 * Handle Amazon S3 files.
	 *
	 * @since 2.4.0
	 * @param string $file_path The file path.
	 * @return string
	 */
	private static function handle_amazon( $file_path ) {
		if ( false !== strpos( $file_path, 'AWSAccessKeyId' ) ) {
			if ( $url = parse_url( $file_path ) ) {
				$file_path = ltrim( $url['path'], '/' );
			}
		}

		if ( function_exists( 'edd_amazon_s3' ) ) {
			return edd_amazon_s3()->get_s3_url( $file_path, 25 );
		}

		return isset( $GLOBALS['edd_s3'] ) ? $GLOBALS['edd_s3']->get_s3_url( $file_path, 25 ) : false;
	}

	/**
	 * Handle Dropbox files.
	 *
	 * @since 2.4.0
	 * @param string $file_path The file path.
	 * @return string|false
	 */
	private static function handle_dropbox( $file_path ) {
		if ( class_exists( '\\EDDDropboxFileStore' ) ) {
			add_filter( 'edd_file_download_method', 'edd_free_downloads_set_download_method' );
			add_filter( 'edd_symlink_file_downloads', 'edd_free_downloads_disable_symlink' );

			$dfs = new \EDDDropboxFileStore();
			$dfs->dbfsInit();

			return $dfs->getDownloadURL( $file_path );
		}

		return false;
	}

	/**
	 * Given an External URL, change any query string parameters to force a download instead of view a file.
	 *
	 * @since 2.4.0
	 * @param string $url The file download URL.
	 * @return string
	 */
	private static function force_external_download( $url ) {
		// Account for Dropbox's ?dl=0/1 values.
		if ( false !== strpos( $url, 'dropbox.com' ) && strpos( $url, 'dl=0' ) ) {
			return str_replace( 'dl=0', 'dl=1', $url );
		}

		return $url;
	}
}
