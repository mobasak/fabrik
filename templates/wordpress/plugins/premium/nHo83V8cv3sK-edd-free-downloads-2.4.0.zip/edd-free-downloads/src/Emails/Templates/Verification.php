<?php

namespace EDD\FreeDownloads\Emails\Templates;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;
use EDD\Emails\Templates\Previews\Data;

class Verification extends EmailTemplate {

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 2.3.12
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 2.3.12
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Unique identifier for this template.
	 *
	 * @since 2.3.12
	 * @var string
	 */
	protected $email_id = 'free_dl_verification';

	/**
	 * The email recipient.
	 *
	 * @since 2.3.12
	 * @var string
	 */
	protected $recipient = 'customer';

	/**
	 * The email context.
	 *
	 * @since 2.3.12
	 * @var string
	 */
	protected $context = 'order';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 2.3.12
	 * @var string
	 */
	protected $sender = 'free-downloads';

	/**
	 * The required tag.
	 *
	 * @since 2.3.12
	 * @var string
	 */
	protected $required_tag = 'free_downloads_verification_link';

	/**
	 * Gets the email template name.
	 *
	 * @since 2.3.12
	 * @return string
	 */
	public function get_name() {
		return __( 'Free Downloads Verification', 'edd-free-downloads' );
	}

	/**
	 * Gets the email template description.
	 *
	 * @since 2.3.12
	 * @return string
	 */
	public function get_description() {
		return __( 'Enter in the content of the email you want to send to verify email addresses.', 'edd-free-downloads' );
	}

	/**
	 * Gets the default email settings.
	 *
	 * @since 2.3.12
	 * @return array
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Confirm your free download.', 'edd-free-downloads' ),
			'content' => sprintf(
				/* translators: %s: The verification link tag which is replaced in the email content. */
				__( "Please click the following link to complete your download.\n\n%s", 'edd-free-downloads' ),
				'{free_downloads_verification_link}'
			),
			'status'  => $this->are_base_requirements_met(),
		);
	}

	/**
	 * Gets the content for the status tooltip, if needed.
	 *
	 * @since 2.3.12
	 * @return array
	 */
	public function get_status_tooltip(): array {
		if ( $this->can_edit( 'status' ) ) {
			return array();
		}

		return array(
			'content'  => __( 'This email status is based on the \'Require Email Verification\' setting.', 'edd-free-downloads' ),
			'dashicon' => 'dashicons-lock',
		);
	}

	/**
	 * Gets the required tag parameters for the email editor.
	 *
	 * @since 2.3.12
	 * @return array
	 */
	public function get_required_tag_parameters() {
		return array(
			'label'       => __( 'Verification URL', 'easy-digital-downloads' ),
			'description' => __( 'Insert the free downloads confirmation link.', 'edd-free-downloads' ),
		);
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 2.3.12
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
		);
	}

	/**
	 * Gets the preview data for this email.
	 *
	 * @since 2.3.12
	 * @return array
	 */
	protected function get_preview_data() {
		return array(
			Data::get_complete_order_id(),
		);
	}

	/**
	 * This email cannot be activated if Auto Register is active.
	 *
	 * @since 2.3.12
	 * @return bool
	 */
	public function are_base_requirements_met(): bool {
		return (bool) edd_get_option( 'edd_free_downloads_require_verification', false );
	}

	/**
	 * Whether the email is enabled.
	 *
	 * @since 2.3.12
	 * @return bool
	 */
	protected function is_enabled(): bool {
		return $this->are_base_requirements_met();
	}

	/**
	 * Legacy
	 */
	protected function get_options(): array {
		return array(
			'subject' => 'edd_free_downloads_verification_email_subject',
			'content' => 'edd_free_downloads_verification_email',
		);
	}
}
