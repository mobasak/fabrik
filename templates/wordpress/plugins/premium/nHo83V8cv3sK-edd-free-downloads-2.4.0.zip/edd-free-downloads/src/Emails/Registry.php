<?php
/**
 * Emails registry class.
 *
 * @package   EDD\FreeDownloads\Emails
 * @copyright Copyright (c) 2024, Sandhills Development, LLC
 * @license   https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since     2.3.12
 */

namespace EDD\FreeDownloads\Emails;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

class Registry {

	/**
	 * Registry constructor.
	 *
	 * @since 2.3.12
	 */
	public function __construct() {
		add_filter( 'edd_email_registered_templates', array( $this, 'register_templates' ) );
		add_filter( 'edd_email_registered_types', array( $this, 'register_types' ) );
		add_filter( 'edd_email_senders', array( $this, 'register_sender' ) );
		add_filter( 'edd_disable_order_receipt', array( $this, 'maybe_disable_order_receipt' ), 10, 2 );
		add_filter( 'edd_disable_admin_order_notice', array( $this, 'maybe_disable_order_receipt' ), 10, 2 );
	}

	/**
	 * Register email templates.
	 *
	 * @since 2.3.12
	 * @param array $emails
	 * @return array
	 */
	public function register_templates( $emails ) {
		$emails['free_dl_verification'] = Templates\Verification::class;

		return $emails;
	}

	/**
	 * Register email types.
	 *
	 * @since 2.3.12
	 * @param array $types
	 * @return array
	 */
	public function register_types( $types ) {
		$types['free_dl_verification'] = Types\Verification::class;

		return $types;
	}

	/**
	 * Register email senders.
	 *
	 * @since 2.3.12
	 * @param array $senders
	 * @return array
	 */
	public function register_sender( $senders ) {
		$senders['free-downloads'] = __( 'Free Downloads', 'edd-free-downloads' );

		return $senders;
	}

	/**
	 * Maybe disable the order receipt.
	 *
	 * @since 2.3.12
	 *
	 * @param bool                    $should_disable Whether the email should be disabled.
	 * @param \EDD\Emails\Types\Email $email          The email object.
	 * @return bool
	 */
	public function maybe_disable_order_receipt( $should_disable, $email ) {
		if ( ! function_exists( 'edd_get_email' ) ) {
			return $should_disable;
		}
		$option = 'edd_free_downloads_disable_emails';
		if ( 'admin' === $email->recipient_type ) {
			$option = 'edd_free_downloads_disable_admin_emails';
		}
		if ( ! edd_get_option( $option, false ) ) {
			return $should_disable;
		}

		$order = $email->order;
		if ( $should_disable || empty( $order ) ) {
			return $should_disable;
		}

		$free_download = $this->is_free_download_transaction( $order );
		if ( ! empty( $free_download ) ) {
			return true;
		}

		return $should_disable;
	}

	/**
	 * Check if the order is a free download.
	 *
	 * @since 2.3.12
	 *
	 * @param \EDD\Orders\Order $order The order object.
	 * @return bool
	 */
	private function is_free_download_transaction( $order ) {
		if ( ! empty( edd_get_order_meta( $order->id, 'edd_free_downloads_transaction', true ) ) ) {
			return true;
		}

		if ( 0.00 === (float) $order->total ) {
			return true;
		}

		return false;
	}
}
