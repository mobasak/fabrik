<?php

namespace EDD\FreeDownloads\Emails\Types;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Types\Email;

class Verification extends Email {

	/**
	 * Email ID.
	 *
	 * @since 2.3.12
	 * @var string
	 */
	public $id = 'free_dl_verification';

	/**
	 * The email context.
	 *
	 * @since 2.3.12
	 * @var string
	 */
	protected $context = 'order';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 2.3.12
	 */
	protected $recipient_type = 'customer';

	/**
	 * The order object.
	 *
	 * @var \EDD\Orders\Order
	 * @since 2.3.12
	 */
	protected $order;

	/**
	 * UserDeposit constructor.
	 *
	 * @param int $order_id The order ID.
	 */
	public function __construct( $order_id ) {
		$this->email_object_id = $order_id;
		$this->order           = edd_get_order( $order_id );
	}

	/**
	 * Set the email to address.
	 *
	 * @since 2.3.12
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$this->send_to = $this->order->email;
	}

	/**
	 * Set the email subject.
	 *
	 * @since 2.3.12
	 * @return void
	 */
	protected function set_subject() {
		$subject = apply_filters( 'edd_free_downloads_verification_subject', wp_strip_all_tags( $this->get_email()->subject ), $this->order->id );
		$subject = edd_do_email_tags( $subject, $this->order->id, $this->order, 'order' );

		$this->subject = $subject;
	}

	/**
	 * Set the email message.
	 *
	 * @since 2.3.12
	 * @return void
	 */
	protected function set_message() {
		$message = $this->maybe_apply_autop( $this->get_raw_body_content() );
		$message = edd_do_email_tags( $message, $this->order->id, $this->order, 'order' );

		$this->message = $message;
	}
}
