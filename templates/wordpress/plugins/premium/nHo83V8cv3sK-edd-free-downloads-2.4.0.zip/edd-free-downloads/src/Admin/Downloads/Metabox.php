<?php
/**
 * EDD\FreeDownloads\Admin\Downloads\Metabox class
 *
 * @package     EDD\FreeDownloads\Admin\Downloads
 * @copyright   Copyright (c) 2024, Sandhills Development, LLC
 * @license     https://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       2.4.0
 */

namespace EDD\FreeDownloads\Admin\Downloads;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use EDD\Admin\Downloads\Editor\Section;

/**
 * Metabox class.
 */
class Metabox extends Section {

	/**
	 * Section ID.
	 *
	 * @since 2.4.0
	 * @var string
	 */
	protected $id = 'free_downloads';

	/**
	 * Section priority.
	 *
	 * @since 2.4.0
	 * @var int
	 */
	protected $priority = 60;

	/**
	 * Section icon.
	 *
	 * @since 2.4.0
	 * @var string
	 */
	protected $icon = 'awards';

	/**
	 * Get the section label.
	 *
	 * @since 2.4.0
	 * @return string
	 */
	public function get_label() {
		return __( 'Free Downloads', 'edd-free-downloads' );
	}

	/**
	 * Render the section.
	 *
	 * @since 2.4.0
	 * @return void
	 */
	public function render() {
		wp_enqueue_script( 'edd-free-downloads-metabox', EDD_FREE_DOWNLOADS_URL . 'assets/js/admin/metabox.js', array(), EDD_FREE_DOWNLOADS_VER, true );
		$download = $this->item;
		?>
		<div class="edd-form-group">
			<div class="edd-form-group__control">
				<?php
				$checkbox = new \EDD\HTML\CheckboxToggle(
					array(
						'name'    => '_edd_free_downloads_bypass',
						'current' => get_post_meta( $download->ID, '_edd_free_downloads_bypass', true ) ? 1 : 0,
						'label'   => __( 'Disable Free Downloads modal', 'edd-free-downloads' ),
						'tooltip' => array(
							'title'   => __( 'Bypass Modal', 'edd-free-downloads' ),
							'content' => sprintf(
								/* translators: %s: singular download label */
								__( 'When checked, this will get treated as a normal %s and will require the user to go through the checkout process.', 'edd-free-downloads' ),
								edd_get_label_singular( true )
							),
						),
					)
				);
				$checkbox->output();
				?>
			</div>
		</div>

		<div class="edd-form-group edd-free-downloads-bundle-wrap" data-edd-supports-product-type="bundle">
			<div class="edd-form-group__control">
				<?php
				$bundle_enable = get_post_meta( $download->ID, '_edd_free_downloads_bundle', false ) ? 1 : 0;
				$checkbox      = new \EDD\HTML\CheckboxToggle(
					array(
						'name'    => '_edd_free_downloads_bundle',
						'current' => $bundle_enable,
						'label'   => __( 'Enforce use on bundle', 'edd-free-downloads' ),
						'tooltip' => array(
							'title'   => __( 'Use On Bundle', 'edd-free-downloads' ),
							'content' => sprintf(
								/* translators: %s: plural download label */
								__( 'Free Downloads can\'t reliably determine the value of products in a bundle, so by default it ignores bundles. Check this to enforce use on this bundle and treat all bundled %s as free.', 'edd-free-downloads' ),
								edd_get_label_plural( true )
							),
						),
					)
				);
				$checkbox->output();
				?>
			</div>
		</div>
		<?php
		$direct_download = edd_get_option( 'edd_free_downloads_direct_download', false ) ? 1 : 0;
		$on_complete     = edd_get_option( 'edd_free_downloads_on_complete', false );
		$on_complete     = ( 'auto-download' === $on_complete ) ? 1 : 0;
		$download_file   = '';
		if ( $direct_download || $on_complete ) {
			?>
			<div class="edd-form-group">
				<label for="_edd_free_downloads_file" class="edd-form-group__label">
					<?php esc_html_e( 'Custom Download File:', 'edd-free-downloads' ); ?>
					<span class="edd-help-tip dashicons dashicons-editor-help" title="<strong><?php esc_html_e( 'Custom Download File', 'edd-free-downloads' ); ?></strong>: <?php printf( esc_html__( 'If this %s includes multiple files, specify an archive file here to use for the Direct Download and Auto Download options.', 'edd-free-downloads' ), esc_html( edd_get_label_singular( true ) ) ); ?>"></span>
				</label>
				<?php
				$download_file = get_post_meta( $download->ID, '_edd_free_downloads_file', true );
				$text          = new \EDD\HTML\Text(
					array(
						'id'          => '_edd_free_downloads_file',
						'name'        => '_edd_free_downloads_file',
						'class'       => 'widefat',
						'placeholder' => 'http://',
						'value'       => $download_file,
					)
				);
				$text->output();
				?>
				<p class="edd-form-group__help description"><?php esc_html_e( 'Enter a URL for a .zip file. This will be used instead of any files added directly to the download.', 'edd-free-downloads' ); ?></p>
			</div>
			<?php
		}

		if ( edd_get_option( 'edd_free_downloads_show_notes', false ) ) {
			?>
			<div class="edd-form-group">
				<div class="edd-form-group__control">
					<label for="_edd_free_downloads_notes_title" class="edd-form-group__label"><?php esc_html_e( 'Notes Title', 'edd-free-downloads' ); ?></label>
					<?php
					$text = new \EDD\HTML\Text(
						array(
							'id'    => '_edd_free_downloads_notes_title',
							'name'  => '_edd_free_downloads_notes_title',
							'class' => 'widefat',
							'value' => get_post_meta( $download->ID, '_edd_free_downloads_notes_title', true ),
						)
					);
					$text->output();
					?>
					<p class="edd-form-group__help description"><?php esc_html_e( 'Enter the title for the notes field, or leave blank to use the global option.', 'edd-free-downloads' ); ?></p>
				</div>
			</div>

			<div class="edd-form-group">
				<div class="edd-form-group__control">
					<label for="_edd_free_downloads_notes" class="edd-form-group__label"><?php esc_html_e( 'Notes', 'edd-free-downloads' ); ?></label>
					<?php
					$textarea = new \EDD\HTML\Textarea(
						array(
							'id'    => '_edd_free_downloads_notes',
							'name'  => '_edd_free_downloads_notes',
							'class' => 'widefat',
							'value' => get_post_meta( $download->ID, '_edd_free_downloads_notes', true ),
						)
					);
					$textarea->output();
					?>
					<p class="edd-form-group__help description"><?php esc_html_e( 'Enter any notes, or leave blank to use the global option.', 'edd-free-downloads' ); ?></p>
				</div>
			</div>
			<?php
		}

		do_action( 'edd_free_downloads_meta_box_settings_fields', $download->ID );
		wp_nonce_field( 'edd_free_downloads_metabox', 'edd_free_downloads_meta_box_nonce' );

		if ( edd_get_option( 'edd_free_downloads_disable_cache', false ) || ( empty( $download->get_files() ) && ! $download_file ) ) {
			return;
		}

		wp_enqueue_script( 'edd-free-downloads-cache', EDD_FREE_DOWNLOADS_URL . 'assets/js/admin/cache.js', array(), EDD_FREE_DOWNLOADS_VER, true );
		$timestamp = time();
		?>
		<div class="edd-free-downloads__cache-actions">
			<button
				type="button"
				class="button button-secondary edd-free-downloads-purge-cache"
				data-nonce="<?php echo esc_attr( wp_create_nonce( 'edd_free_downloads_cache_nonce' ) ); ?>"
				data-timestamp="<?php echo esc_attr( $timestamp ); ?>"
				data-token="<?php echo esc_attr( \EDD\Utils\Tokenizer::tokenize( $timestamp ) ); ?>"
				>
				<?php esc_html_e( 'Clear Cached Files', 'edd-free-downloads' ); ?>
			</button>
		</div>
		<?php
	}
}
