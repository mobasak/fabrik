<?php

namespace EDD\FreeDownloads\Admin;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

class Settings {

	/**
	 * The type of checkbox.
	 *
	 * @var string
	 * @since 2.3.14
	 */
	private $checkbox_type;

	/**
	 * Settings constructor.
	 *
	 * @since 2.3.14
	 */
	public function __construct() {
		$this->checkbox_type = $this->get_checkbox_type();
	}

	/**
	 * Get the settings.
	 *
	 * @since 2.3.14
	 * @return array
	 */
	public function get() {
		return array(
			'free_downloads' => array_merge(
				$this->get_general_settings(),
				$this->get_fields_settings(),
				$this->get_processing_settings(),
				$this->get_cache_settings(),
				$this->get_integration_settings()
			),
		);
	}

	/**
	 * Get the general settings.
	 *
	 * @since 2.3.14
	 * @return array The general settings.
	 */
	private function get_general_settings() {
		$display_settings = array(
			array(
				'id'            => 'edd_free_downloads_general_settings',
				'name'          => '<h3>' . __( 'General Settings', 'edd-free-downloads' ) . '</h3>',
				'desc'          => '',
				'type'          => 'header',
				'tooltip_title' => __( 'General Settings', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'The settings below determine how the free download process works and how the relevant components appear on your site.', 'edd-free-downloads' ),
			),
			array(
				'id'   => 'edd_free_downloads_button_label',
				'name' => __( 'Button Label', 'edd-free-downloads' ),
				'desc' => __( 'Specify the text for the button shown in download lists and product pages.', 'edd-free-downloads' ),
				'type' => 'text',
				'std'  => __( 'Download Now', 'edd-free-downloads' ),
			),
			array(
				'id'   => 'edd_free_downloads_modal_button_label',
				'name' => __( 'Modal Button Label', 'edd-free-downloads' ),
				'desc' => __( 'Specify the text for the button shown in the Free Downloads modal.', 'edd-free-downloads' ),
				'type' => 'text',
				'std'  => __( 'Download Now', 'edd-free-downloads' ),
			),
			array(
				'id'            => 'edd_free_downloads_close_button',
				'name'          => __( 'Display Close Button', 'edd-free-downloads' ),
				'check'         => __( 'Display a close button on the modal.', 'edd-free-downloads' ),
				'type'          => $this->checkbox_type,
				'tooltip_title' => __( 'Displaying A Close Button', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'By default, Free Downloads does not display a close button on the modal. In this state, users must click on the background to close the modal.', 'edd-free-downloads' ),
			),
			array(
				'id'    => 'edd_free_downloads_bypass_logged_in',
				'name'  => __( 'Bypass If Logged In', 'edd-free-downloads' ),
				'check' => __( 'Bypass the modal if a user is logged in.', 'edd-free-downloads' ),
				'type'  => $this->checkbox_type,
			),
			array(
				'id'            => 'free_downloads_enqueue',
				'name'          => __( 'Script Handling', 'edd-free-downloads' ),
				'check'         => __( 'Enqueue the Free Downloads JavaScript on all pages.', 'edd-free-downloads' ),
				'type'          => $this->checkbox_type,
				'tooltip_title' => __( 'Script Handling', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'To improve performance, the Free Downloads JavaScript is only loaded when needed. If you are adding custom free download links to your site outside of the included shortcodes or page content, you will need to enable this setting.', 'edd-free-downloads' ),
			),
		);

		$privacy_policy_page          = get_option( 'wp_page_for_privacy_policy', 0 );
		$privacy_policy_page_settings = edd_get_admin_url(
			array(
				'page' => 'edd-settings',
				'tab'  => 'privacy',
			)
		);
		$disabled                     = empty( $privacy_policy_page );
		$description                  = $disabled ?
			/* translators: %s: URL to the Privacy Policy settings */
			sprintf( __( 'To enable this option, you need to <a href="%s">select a Privacy Policy page</a>.', 'edd-free-downloads' ), $privacy_policy_page_settings ) :
			/* translators: %s: URL to the Privacy Policy settings */
			sprintf( __( 'Provide the user with a checkbox to agree to the privacy policy and show a link to the privacy policy page <a href="%s">defined in the Easy Digital Downloads settings</a>.', 'edd-free-downloads' ), $privacy_policy_page_settings );

		$display_settings[] = array(
			'id'      => 'edd_free_downloads_display_privacy_policy_agreement',
			'name'    => __( 'Agree to Privacy Policy', 'edd-free-downloads' ),
			'check'   => $description,
			'type'    => $this->checkbox_type,
			'options' => array(
				'disabled' => $disabled,
			),
		);
		$display_settings[] = array(
			'id'    => 'edd_free_downloads_display_terms',
			'name'  => __( 'Agree to Terms', 'edd-free-downloads' ),
			'desc'  => __( 'Display a checkbox for users to agree to your terms of service.', 'edd-free-downloads' ),
			'type'  => $this->checkbox_type,
			'check' => __( 'Show Terms for Free Downloads', 'edd-free-downloads' ),
			'class' => edd_get_option( 'agree_text' ) ? '' : 'edd-hidden',
		);

		return apply_filters( 'edd_free_downloads_general_settings', $display_settings );
	}

	/**
	 * Get the fields settings.
	 *
	 * @since 2.3.14
	 * @return array The fields settings.
	 */
	private function get_fields_settings() {
		$fields_settings = array(
			array(
				'id'            => 'edd_free_downloads_fields_settings',
				'name'          => '<h3>' . __( 'Fields Settings', 'edd-free-downloads' ) . '</h3>',
				'desc'          => '',
				'type'          => 'header',
				'tooltip_title' => __( 'Fields Settings', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'The fields below define what fields are shown in the download modal and how the system interacts with them.', 'edd-free-downloads' ),
			),
			array(
				'id'    => 'edd_free_downloads_get_name',
				'name'  => __( 'Collect Name', 'edd-free-downloads' ),
				'check' => __( 'Show a name field in the download modal.', 'edd-free-downloads' ),
				'type'  => $this->checkbox_type,
			),
			array(
				'id'    => 'edd_free_downloads_require_name',
				'name'  => __( 'Require Name', 'edd-free-downloads' ),
				'check' => __( 'Make the first and last name fields required.', 'edd-free-downloads' ),
				'type'  => $this->checkbox_type,
				'class' => edd_get_option( 'edd_free_downloads_get_name' ) ? '' : 'edd-hidden',
			),
			array(
				'id'            => 'edd_free_downloads_show_notes',
				'name'          => __( 'Show Notes Field', 'edd-free-downloads' ),
				'check'         => __( 'Enable the notes field in the download modal.', 'edd-free-downloads' ),
				'type'          => $this->checkbox_type,
				'tooltip_title' => __( 'The Notes Field', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'Enabling this option allows you to display notes in the modal.', 'edd-free-downloads' ),
			),
			array(
				'id'    => 'edd_free_downloads_disable_global_notes',
				'name'  => __( 'Disable Global Notes', 'edd-free-downloads' ),
				'check' => __( 'Disable global notes and only use notes defined per-product.', 'edd-free-downloads' ),
				'type'  => $this->checkbox_type,
				'class' => edd_get_option( 'edd_free_downloads_show_notes' ) ? '' : 'edd-hidden',
			),
			array(
				'id'    => 'edd_free_downloads_notes_title',
				'name'  => __( 'Notes Field Title', 'edd-free-downloads' ),
				'desc'  => __( 'Enter the title to display for the notes field, or leave blank for none.', 'edd-free-downloads' ),
				'type'  => 'text',
				'std'   => __( 'Notes', 'edd-free-downloads' ),
				'class' => edd_get_option( 'edd_free_downloads_show_notes' ) ? '' : 'edd-hidden',
			),
			array(
				'id'    => 'edd_free_downloads_notes',
				'name'  => __( 'Notes', 'edd-free-downloads' ),
				'desc'  => __( 'Enter any notes to display in the Free Downloads modal.', 'edd-free-downloads' ),
				'type'  => 'rich_editor',
				'class' => edd_get_option( 'edd_free_downloads_show_notes' ) ? '' : 'edd-hidden',
			),
		);

		return apply_filters( 'edd_free_downloads_fields_settings', $fields_settings );
	}

	/**
	 * Get the processing settings.
	 *
	 * @since 2.3.14
	 * @return array The processing settings.
	 */
	private function get_processing_settings() {
		$processing_settings = array(
			array(
				'id'            => 'edd_free_downloads_processing_settings',
				'name'          => '<h3>' . __( 'Processing Settings', 'edd-free-downloads' ) . '</h3>',
				'desc'          => '',
				'type'          => 'header',
				'tooltip_title' => __( 'Processing Settings', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'The fields below define how Free Downloads handles downloads after a user has filled out the modal fields.', 'edd-free-downloads' ),
			),
			array(
				'id'    => 'edd_free_downloads_require_verification',
				'name'  => __( 'Require Email Verification', 'edd-free-downloads' ),
				'check' => __( 'Requires users to receive an email and follow a link in order to complete their download.', 'edd-free-downloads' ),
				'type'  => $this->checkbox_type,
			),
			array(
				'id'          => 'edd_free_downloads_require_verification_message',
				'name'        => __( 'Email Verification Message', 'edd-free-downloads' ),
				'desc'        => __( 'Define the message to show to visitors letting them know they will receive an email to verify their download.', 'edd-free-downloads' ),
				'type'        => 'text',
				'std'         => __( 'An email will be sent to the provided address to complete your download.', 'edd-free-downloads' ),
				'allow_blank' => false,
				'class'       => edd_get_option( 'edd_free_downloads_require_verification' ) ? '' : 'edd-hidden',
			),
			'edd_free_downloads_verification_email_subject' => array(
				'id'          => 'edd_free_downloads_verification_email_subject',
				'name'        => __( 'Verification Email Subject', 'edd-free-downloads' ),
				'desc'        => __( 'The subject line for the email sent to the user.', 'edd-free-downloads' ),
				'type'        => 'text',
				'std'         => __( 'Confirm your free download.', 'edd-free-downloads' ),
				'allow_blank' => false,
				'class'       => edd_get_option( 'edd_free_downloads_require_verification' ) ? '' : 'edd-hidden',
			),
			'edd_free_downloads_verification_email' => array(
				'id'          => 'edd_free_downloads_verification_email',
				'name'        => __( 'Verification Email', 'edd-free-downloads' ),
				'desc'        => __( 'Enter in the content of the email you want to send to verify email addresses.', 'edd-free-downloads' ) . '<br/>' . edd_get_emails_tags_list(),
				'type'        => 'rich_editor',
				'std'         => sprintf(
					/* translators: %s: The verification link tag which is replaced in the email content. */
					__( "Please click the following link to complete your download.\n\n%s", 'edd-free-downloads' ),
					'{free_downloads_verification_link}'
				),
				'allow_blank' => false,
				'class'       => edd_get_option( 'edd_free_downloads_require_verification' ) ? '' : 'edd-hidden',
			),
			array(
				'id'            => 'edd_free_downloads_on_complete',
				'name'          => __( 'On-Complete Handler', 'edd-free-downloads' ),
				'desc'          => __( 'Specify what to do once the user has filled out the download form.', 'edd-free-downloads' ),
				'type'          => 'select',
				'tooltip_title' => __( 'On-Complete Handler', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'Free Downloads can do a number of things when a download is processed:', 'edd-free-downloads' ) .
					'<p><strong>' . __( 'Display Purchase Confirmation:', 'edd-free-downloads' ) . '</strong> ' . __( 'This is the default behavior of EDD. Users will be redirected to the same Purchase Confirmation page they would see when completing a purchase.', 'edd-free-downloads' ) . '</p>' .
					'<p><strong>' . __( 'Auto Download:', 'edd-free-downloads' ) . '</strong> ' . __( 'The system will close the download modal, and automatically download the relevant file(s).', 'edd-free-downloads' ) . '</p>' .
					'<p><strong>' . __( 'Custom Redirect:', 'edd-free-downloads' ) . '</strong> ' . __( 'Rather than redirecting to the Purchase Confirmation page, this allows you to define a custom redirection URL.', 'edd-free-downloads' ) . '</p>',
				'std'           => 'default',
				'options'       => array(
					'default'       => __( 'Display Purchase Confirmation', 'edd-free-downloads' ),
					'auto-download' => __( 'Auto Download', 'edd-free-downloads' ),
					'redirect'      => __( 'Custom Redirect', 'edd-free-downloads' ),
				),
			),
			array(
				'id'            => 'edd_free_downloads_redirect',
				'name'          => __( 'Redirect URL', 'edd-free-downloads' ),
				'desc'          => __( 'Enter a URL to redirect to on completion.', 'edd-free-downloads' ),
				'type'          => 'text',
				'tooltip_title' => __( 'Redirect URL', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'If no URL is set, users will be automatically redirected to the Purchase Confirmation page.', 'edd-free-downloads' ),
				'class'         => 'redirect' === edd_get_option( 'edd_free_downloads_on_complete' ) ? '' : 'edd-hidden',
			),
			array(
				'id'            => 'edd_free_downloads_mobile_on_complete',
				'name'          => __( 'Mobile On-Complete Handler', 'edd-free-downloads' ),
				'desc'          => __( 'Specify what to do once the user has filled out the download form.', 'edd-free-downloads' ),
				'type'          => 'select',
				'tooltip_title' => __( 'Mobile On-Complete Handler', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'Specify an alternate method of handling completion on mobile devices.', 'edd-free-downloads' ),
				'std'           => 'default',
				'options'       => array(
					'default'       => __( 'Use Main On-Complete Handler', 'edd-free-downloads' ),
					'confirmation'  => __( 'Display Purchase Confirmation', 'edd-free-downloads' ),
					'auto-download' => __( 'Auto Download', 'edd-free-downloads' ),
					'redirect'      => __( 'Custom Redirect', 'edd-free-downloads' ),
				),
			),
			array(
				'id'            => 'edd_free_downloads_mobile_redirect',
				'name'          => __( 'Mobile Redirect URL', 'edd-free-downloads' ),
				'desc'          => __( 'Enter a URL to redirect to on completion for mobile devices.', 'edd-free-downloads' ),
				'type'          => 'text',
				'tooltip_title' => __( 'Mobile Redirect URL', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'If no URL is set, users will be automatically redirected to the Purchase Confirmation page.', 'edd-free-downloads' ),
				'class'         => 'redirect' === edd_get_option( 'edd_free_downloads_mobile_on_complete' ) ? '' : 'edd-hidden',
			),
			array(
				'id'            => 'edd_free_downloads_apple_on_complete',
				'name'          => __( 'Apple On-Complete Handler', 'edd-free-downloads' ),
				'desc'          => __( 'Apple does not allow automatic downloads. Specify an alternative for Apple devices.', 'edd-free-downloads' ),
				'type'          => 'select',
				'tooltip_title' => __( 'Apple On-Complete Handler', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'Specify an alternate method of handling completion on Apple mobile devices.', 'edd-free-downloads' ),
				'std'           => 'default',
				'options'       => array(
					'default'      => __( 'Use Main On-Complete Handler', 'edd-free-downloads' ),
					'confirmation' => __( 'Display Purchase Confirmation', 'edd-free-downloads' ),
					'redirect'     => __( 'Custom Redirect', 'edd-free-downloads' ),
				),
			),
			array(
				'id'            => 'edd_free_downloads_apple_redirect',
				'name'          => __( 'Apple Redirect URL', 'edd-free-downloads' ),
				'desc'          => __( 'Enter a URL to redirect to on completion for Apple devices.', 'edd-free-downloads' ),
				'type'          => 'text',
				'tooltip_title' => __( 'Apple Redirect URL', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'If no URL is set, users will be automatically redirected to the Purchase Confirmation page.', 'edd-free-downloads' ),
				'class'         => 'redirect' === edd_get_option( 'edd_free_downloads_apple_on_complete' ) ? '' : 'edd-hidden',
			),
			array(
				'id'    => 'edd_free_downloads_disable_emails',
				'name'  => __( 'Disable purchase confirmation emails', 'edd-free-downloads' ),
				'check' => __( 'Disable the purchase confirmation emails which are sent to customers after they purchase a free product.', 'edd-free-downloads' ),
				'type'  => $this->checkbox_type,
			),
			array(
				'id'    => 'edd_free_downloads_disable_admin_emails',
				'name'  => __( 'Disable admin sales notifications', 'edd-free-downloads' ),
				'check' => $this->get_admin_notice_description(),
				'type'  => $this->checkbox_type,
			),
			array(
				'id'    => 'edd_free_downloads_direct_download',
				'name'  => __( 'Direct Download', 'edd-free-downloads' ),
				'check' => __( 'Allow users to download files without entering their info.', 'edd-free-downloads' ),
				'type'  => $this->checkbox_type,
			),
			array(
				'id'    => 'edd_free_downloads_direct_download_label',
				'name'  => __( 'Direct Download Label', 'edd-free-downloads' ),
				'desc'  => __( 'Enter the text to display for the direct download link', 'edd-free-downloads' ),
				'type'  => 'text',
				'std'   => __( 'No thanks, proceed to download', 'edd-free-downloads' ),
				'class' => edd_get_option( 'edd_free_downloads_direct_download' ) ? '' : 'edd-hidden',
			),
			array(
				'id'   => 'free_downloads_zip_status',
				'name' => __( 'Compression Status', 'edd-free-downloads' ),
				'desc' => '',
				'type' => 'hook',
			),
		);
		if ( function_exists( 'edd_get_email' ) ) {
			unset( $processing_settings['edd_free_downloads_verification_email_subject'] );
			unset( $processing_settings['edd_free_downloads_verification_email'] );
		}

		return apply_filters( 'edd_free_downloads_processing_settings', $processing_settings );
	}

	/**
	 * Retrieves the description for the admin notice.
	 *
	 * @since 2.3.14
	 * @return string The description for the admin notice.
	 */
	private function get_admin_notice_description() {
		if ( function_exists( 'edd_get_email' ) ) {
			return sprintf(
				/* translators: %s: URL to the Admin Sale Notification email */
				__( 'Disable the default <a href="%s">Admin Sale Notification</a> for orders processed by Free Downloads.', 'edd-free-downloads' ),
				edd_get_admin_url(
					array(
						'page'  => 'edd-emails',
						'email' => 'admin_order_notice',
					)
				)
			);
		}

		return sprintf(
			/* translators: %s: URL to the Sale Notification Emails setting */
			__( 'Disable the default sales notifications which get sent to the email addresses in the <a href="%s">Sale Notification Emails</a> setting.', 'edd-free-downloads' ),
			edd_get_admin_url(
				array(
					'page'    => 'edd-settings',
					'tab'     => 'emails',
					'section' => 'sale_notifications',
				)
			)
		);
	}

	/**
	 * Gets the cache settings.
	 *
	 * @since 2.3.14
	 * @return array The cache settings.
	 */
	private function get_cache_settings() {
		$cache_settings = array(
			array(
				'id'            => 'edd_free_downloads_cache_settings',
				'name'          => '<h3>' . __( 'Cache Settings', 'edd-free-downloads' ) . '</h3>',
				'desc'          => '',
				'type'          => 'header',
				'tooltip_title' => __( 'Cache Settings', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'The fields below define how Free Downloads handles file caching. Free Downloads caches files which are stored remotely while compressing them if direct download or auto download are enabled.', 'edd-free-downloads' ),
			),
			array(
				'id'            => 'edd_free_downloads_disable_cache',
				'name'          => __( 'Disable Cache', 'edd-free-downloads' ),
				'check'         => __( 'Disable caching remote files entirely.', 'edd-free-downloads' ),
				'type'          => $this->checkbox_type,
				'tooltip_title' => __( 'Disable Cache', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'Free Downloads caches remote files to prevent long download times while compressing multi-file downloads. If you prefer not to use this feature, check this option.', 'edd-free-downloads' ),
			),
			array(
				'id'            => 'edd_free_downloads_purge_cache_timeout',
				'name'          => __( 'Cache Timeout', 'edd-free-downloads' ),
				'desc'          => __( 'Enter the length of the cache timeout, in hours.', 'edd-free-downloads' ),
				'type'          => 'text',
				'size'          => 'small',
				'std'           => '1',
				'allow_blank'   => false,
				'tooltip_title' => __( 'Cache Timeout', 'edd-free-downloads' ),
				'tooltip_desc'  => __( 'If a cached file is requested, Free Downloads will see when it was created. If that time is greater than this cache timeout, the file will be recreated.', 'edd-free-downloads' ),
				'class'         => edd_get_option( 'edd_free_downloads_disable_cache' ) ? 'edd-hidden' : '',
			),
			array(
				'id'    => 'free_downloads_display_purge_cache',
				'name'  => __( 'Purge Cache', 'edd-free-downloads' ),
				'desc'  => '',
				'type'  => 'hook',
				'class' => edd_get_option( 'edd_free_downloads_disable_cache' ) ? 'edd-hidden' : '',
			),
		);

		return apply_filters( 'edd_free_downloads_cache_settings', $cache_settings );
	}

	/**
	 * Gets the integration settings.
	 *
	 * @since 2.3.14
	 * @return array The integration settings.
	 */
	private function get_integration_settings() {
		$integration_settings = apply_filters( 'edd_free_downloads_integration_settings', array() );

		if ( count( $integration_settings ) > 0 ) {
			$integration_header = array(
				array(
					'id'            => 'edd_free_downloads_integrations_settings',
					'name'          => '<h3>' . __( 'Integration Settings', 'edd-free-downloads' ) . '</h3>',
					'desc'          => '',
					'type'          => 'header',
					'tooltip_title' => __( 'Integration Settings', 'edd-free-downloads' ),
					'tooltip_desc'  => __( 'The fields below define how Free Downloads integrates with other plugins you have installed.', 'edd-free-downloads' ),
				),
			);

			$integration_settings = array_merge( $integration_header, $integration_settings );
		}

		return $integration_settings;
	}

	/**
	 * Get the checkbox type.
	 *
	 * @since 2.3.14
	 * @return string
	 */
	private function get_checkbox_type() {
		return function_exists( 'edd_checkbox_toggle_callback' ) ? 'checkbox_toggle' : 'checkbox_description';
	}
}
