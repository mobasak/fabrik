<?php

namespace EDD\FreeDownloads\Assets;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

class Admin {

	/**
	 * Enqueue scripts and styles.
	 *
	 * @since 2.3.14
	 * @return void
	 */
	public static function enqueue() {
		if ( ! self::can_enqueue() ) {
			return;
		}

		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		wp_register_style( 'edd-free-downloads', EDD_FREE_DOWNLOADS_URL . 'assets/css/admin.css', array(), EDD_FREE_DOWNLOADS_VER );
		wp_enqueue_style( 'edd-free-downloads' );

		wp_register_script( 'edd-free-downloads', EDD_FREE_DOWNLOADS_URL . 'assets/js/admin' . $suffix . '.js', array( 'jquery' ), EDD_FREE_DOWNLOADS_VER, true );
		wp_enqueue_script( 'edd-free-downloads' );
	}

	/**
	 * Determine if the script can be enqueued.
	 *
	 * @since 2.3.14
	 * @return bool
	 */
	private static function can_enqueue() {
		if ( ! function_exists( 'edd_is_admin_page' ) ) {
			return false;
		}

		if ( edd_is_admin_page( 'download', 'edit' ) || edd_is_admin_page( 'download', 'new' ) || edd_is_admin_page( 'settings', 'marketing' ) ) {
			return true;
		}

		return false;
	}
}
