<?php

namespace EDD\FreeDownloads\Assets;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

class Frontend {

	public static function enqueue( $force = false ) {
		if ( ! self::can_enqueue( $force ) ) {
			return;
		}

		$suffix = self::get_suffix();

		wp_register_style( 'edd-free-downloads', EDD_FREE_DOWNLOADS_URL . 'assets/css/edd-free-downloads.css', array(), EDD_FREE_DOWNLOADS_VER );
		wp_enqueue_style( 'edd-free-downloads' );

		wp_register_script( 'edd-free-downloads', EDD_FREE_DOWNLOADS_URL . 'assets/js/edd-free-downloads' . $suffix . '.js', array( 'jquery' ), EDD_FREE_DOWNLOADS_VER, true );
		wp_enqueue_script( 'edd-free-downloads' );

		wp_localize_script(
			'edd-free-downloads',
			'edd_free_downloads_vars',
			self::get_localization_args()
		);
	}

	/**
	 * Enqueue the variable script.
	 *
	 * @since 2.3.15
	 */
	public static function enqueue_variable() {
		if ( wp_script_is( 'edd-free-downloads-variable', 'enqueued' ) ) {
			return;
		}

		self::enqueue( true );
		wp_enqueue_script( 'edd-free-downloads-variable', EDD_FREE_DOWNLOADS_URL . 'assets/js/edd-free-downloads-variable' . self::get_suffix() . '.js', array( 'edd-free-downloads' ), EDD_FREE_DOWNLOADS_VER, true );
	}

	/**
	 * Determine if the script can be enqueued.
	 *
	 * @since 2.3.14
	 * @param bool $force Whether to force the script to be enqueued.
	 * @return bool
	 */
	private static function can_enqueue( $force = false ) {
		if ( wp_script_is( 'edd-free-downloads', 'enqueued' ) ) {
			return false;
		}

		if ( $force || edd_get_option( 'free_downloads_enqueue', false ) ) {
			return true;
		}

		if ( is_singular( 'download' ) && edd_is_free_download( get_the_ID() ) ) {
			return true;
		}

		// If the content includes #edd-free-download-modal, enqueue the script.
		if ( false !== strpos( get_the_content(), '#edd-free-download-modal' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Get localization arguments for the script.
	 *
	 * @since 2.3.14
	 * @return array
	 */
	private static function get_localization_args() {
		$close_button            = edd_get_option( 'edd_free_downloads_close_button', false );
		$close_button            = ( $close_button ? 'box' : 'overlay' );
		$download_label          = edd_get_option( 'edd_free_downloads_button_label', __( 'Download Now', 'edd-free-downloads' ) );
		$guest_checkout_disabled = edd_no_guest_checkout();
		$on_complete_handler     = edd_get_option( 'edd_free_downloads_on_complete', 'default' );
		$user_registration       = \EDD\FreeDownloads\Utilities\Registration::user_registration_enabled();

		return array(
			'close_button'            => $close_button,
			'user_registration'       => $user_registration ? 'true' : 'false',
			'require_name'            => edd_get_option( 'edd_free_downloads_require_name', false ) ? 'true' : 'false',
			'download_loading'        => __( 'Please Wait... ', 'edd-free-downloads' ),
			'download_label'          => $download_label,
			'modal_download_label'    => edd_get_option( 'edd_free_downloads_modal_button_label', __( 'Download Now', 'edd-free-downloads' ) ),
			'has_ajax'                => edd_is_ajax_enabled(),
			'ajaxurl'                 => edd_get_ajax_url(),
			'mobile_url'              => esc_url( add_query_arg( array( 'edd-free-download' => 'true' ) ) ),
			'form_class'              => apply_filters( 'edd_free_downloads_form_class', 'edd_purchase_submit_wrapper' ),
			'bypass_logged_in'        => edd_get_option( 'edd_free_downloads_bypass_logged_in', false ) && is_user_logged_in() ? 'true' : 'false',
			'is_download'             => ( is_singular( 'download' ) ? 'true' : 'false' ),
			'edd_is_mobile'           => wp_is_mobile(),
			'success_page'            => edd_get_success_page_uri(),
			'guest_checkout_disabled' => $guest_checkout_disabled,
			'email_verification'      => edd_free_downloads_verify_email(),
			'on_complete_handler'     => $on_complete_handler,
			'on_complete_delay'       => apply_filters( 'edd_free_downloads_on_complete_handler_delay', 2000 ),
		);
	}

	/**
	 * Get the suffix for the scripts.
	 *
	 * @since 2.3.15
	 * @return string
	 */
	private static function get_suffix() {
		return ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	}
}
