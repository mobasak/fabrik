jQuery( document.body ).ready( function ( $ ) {
	'use strict';

	const forms = $( '.edd-has-free-variable-price' ).closest( 'form' );
	if ( !forms ) {
		return;
	}

	forms.each( function () {

		var classes = forms.find( '.edd-add-to-cart' ).attr( 'class' );
		if ( !classes ) {
			return;
		}

		classes = classes.replace( 'edd-add-to-cart', '' );

		const href = '#edd-free-download-modal';

		var wrapperPrefix, linkPrefix, linkSuffix, wrapperSuffix;
		if ( edd_free_downloads_vars.has_ajax === '1' ) {
			wrapperPrefix = '<div class="edd-free-downloads-variable-wrapper">';
			linkPrefix = '<a class="edd-free-downloads-variable edd-free-download ' + classes + '" href="' + href + '" data-download-id=""><span>';
			linkSuffix = '</span></a>';
			wrapperSuffix = '</div>';
		} else {
			wrapperPrefix = '';
			linkPrefix = '<input type="submit" class="edd-free-downloads-variable edd-free-download ' + classes + '" name="edd_purchase_download" value="';
			linkSuffix = '" href="' + href + '" data-download-id="" />';
			wrapperSuffix = '';
		}

		$( '.edd_purchase_submit_wrapper' ).each( function ( i ) {
			if ( $( '.edd_purchase_submit_wrapper' ).eq( i ).find( '.edd-add-to-cart' ).data( 'variable-price' ) === 'yes' ) {
				var download_id = $( this ).closest( 'form' ).attr( 'id' ).replace( 'edd_purchase_', '' );

				if ( edd_free_downloads_vars.bypass_logged_in === 'true' ) {
					$( this ).after( wrapperPrefix + '<a href="#" class="edd-free-downloads-direct-download-link ' + classes + '" data-download-id="' + download_id + '">' + edd_free_downloads_vars.download_label + '</a>' + wrapperSuffix );
				} else {
					$( this ).after( wrapperPrefix + linkPrefix + edd_free_downloads_vars.download_label + linkSuffix + wrapperSuffix );
				}

				$( this ).parent().find( '.edd-free-downloads-variable' ).attr( 'data-download-id', download_id );

				if ( $( this ).parent().find( 'input[name="edd_options[price_id][]"]:checked' ).attr( 'data-price' ) === '0.00' ) {
					$( this ).css( 'display', 'none' );
					$( this ).parent().find( '.edd-free-downloads-variable-wrapper' ).css( 'display', 'block' );
				} else {
					if ( $( this ).parent().find( 'input[name="edd_options[price_id][]"]:checked' ).attr( 'data-price' ) === '0.00' ) {
						$( this ).css( 'display', 'none' );
						$( this ).parent().find( '.edd-free-downloads-variable-wrapper' ).css( 'display', 'block' );
					} else {
						$( this ).css( 'display', 'block' );
						$( this ).parent().find( '.edd-free-downloads-variable-wrapper' ).css( 'display', 'none' );
					}
				}
			}
		} );

	} );

	$( '.edd-has-free-variable-price' ).on( 'change', 'input[name="edd_options[price_id][]"]', function () {
		const purchaseForm = $( this ).closest( '.edd_download_purchase_form' );
		var total = 0;
		var checked = 0;
		var price_ids = [];
		var dlUrl = purchaseForm.find( 'a.edd-free-downloads-variable' ).attr( 'href' );
		var dlId = purchaseForm.find( '.edd_purchase_submit_wrapper' ).find( '.edd-add-to-cart' ).attr( 'data-download-id' );

		dlUrl = edd_free_downloads_append_query_string( dlUrl, 'download_id', dlId );

		$( this ).closest( 'ul' ).find( 'input[name="edd_options[price_id][]"]' ).each( function () {
			if ( $( this ).is( ':checked' ) ) {
				total += parseFloat( $( this ).attr( 'data-price' ) );
				checked += 1;
				price_ids.push( parseInt( $( this ).val() ) );
			}
		} );

		if ( checked !== 0 ) {
			if ( total === 0 ) {
				var price_id_string = JSON.stringify( price_ids );
				dlUrl = edd_free_downloads_append_query_string( dlUrl, 'price_ids', price_id_string );

				purchaseForm.find( 'a.edd-free-downloads-variable' ).attr( 'href', dlUrl );

				purchaseForm.find( '.edd_purchase_submit_wrapper' ).css( 'display', 'none' );
				purchaseForm.find( '.edd-free-downloads-variable-wrapper' ).css( 'display', 'block' );
			} else {
				purchaseForm.find( '.edd_purchase_submit_wrapper' ).css( 'display', 'block' );
				purchaseForm.find( '.edd-free-downloads-variable-wrapper' ).css( 'display', 'none' );

				purchaseForm.find( 'a.edd-free-downloads-variable' ).attr( 'href', dlUrl );
			}
		} else {
			purchaseForm.find( '.edd_purchase_submit_wrapper' ).css( 'display', 'block' );
			purchaseForm.find( '.edd-free-downloads-variable-wrapper' ).css( 'display', 'none' );

			purchaseForm.find( 'a.edd-free-downloads-variable' ).attr( 'href', dlUrl );
		}
	} );

	$( document.body ).on( 'click', '.edd-free-downloads-variable', function ( e ) {
		e.preventDefault();
	} );
} );

function edd_free_downloads_append_query_string ( uri, key, value ) {

	var re = new RegExp( "([?&])" + key + "=.*?(&|$)", "i" );
	if ( typeof uri != "undefined" ) {
		var separator = uri.indexOf( '?' ) !== -1 ? "&" : "?";
	}

	if ( typeof uri != "undefined" && uri.match( re ) ) {
		return uri.replace( re, '$1' + key + "=" + value + '$2' );
	}

	return uri + separator + key + "=" + value;
}
