const freeDownloadsNavItem = document.getElementById( 'edd_download_editor__free_downloads-nav-item' ),
	mainPrice = document.getElementById( 'edd_price' ),
	variablePricing = document.getElementById( 'edd_variable_pricing' );

if ( freeDownloadsNavItem ) {
	checkDownload();

	variablePricing.addEventListener( 'change', function () {
		checkDownload();
	} );
}

function checkDownload () {
	if ( variablePricing && !variablePricing.checked ) {
		if ( mainPrice ) {
			mainPrice.addEventListener( 'change', function () {
				toggleFreeDownloadFields( parseFloat( mainPrice.value ) === 0 );
			} );

			toggleFreeDownloadFields( parseFloat( mainPrice.value ) === 0 );
		}
	} else if ( variablePricing.checked ) {
		document.addEventListener( 'change', function ( event ) {
			if ( event.target.classList.contains( 'edd-price-field' ) && event.target.name.indexOf( 'edd_variable_prices' ) !== -1 ) {
				toggleFreeDownloadFields( isVariationFree() );
			}
		} );

		toggleFreeDownloadFields( isVariationFree() );
	}
}

function toggleFreeDownloadFields ( isFreeDownload ) {
	if ( isFreeDownload ) {
		freeDownloadsNavItem.classList.remove( 'edd-hidden' );
	} else {
		freeDownloadsNavItem.classList.add( 'edd-hidden' );
	}
}

function isVariationFree () {
	const priceFields = document.querySelectorAll( '.edd-section-content__fields--standard .edd-price-field' );
	for ( let i = 0; i < priceFields.length; i++ ) {
		const priceField = priceFields[ i ];
		if ( priceField.name.indexOf( 'edd_variable_prices' ) !== -1 ) {
			const priceValue = parseFloat( priceField.value );
			if ( priceValue === 0 ) {
				return true;
			}
		}
	}
	return false;
}
