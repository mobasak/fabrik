const deleteButton = document.querySelector( '.edd-free-downloads-purge-cache' );

if ( deleteButton ) {
	deleteButton.addEventListener( 'click', function ( event ) {
		event.preventDefault();
		const button = event.target;
		button.disabled = true;
		button.classList.add( 'updating-message' );

		const data = new FormData();
		let action = 'edd_free_downloads_purge_cache';
		data.append( 'timestamp', button.dataset.timestamp );
		data.append( 'token', button.dataset.token );
		data.append( 'nonce', button.dataset.nonce );
		if ( edd_vars.post_id ) {
			action = 'edd_free_downloads_delete_cached_files';
			data.append( 'download_id', edd_vars.post_id );
		}
		data.append( 'action', action );

		fetch( ajaxurl, {
			method: 'POST',
			body: data,
		} ).then( function ( response ) {
			if ( ! response.ok ) {
				throw new Error( 'Network response was not ok' );
			}
			return response.json();
		} ).then( function ( data ) {
			if ( data.success ) {
				button.classList.remove( 'updating-message' );
				button.classList.add( 'updated-message' );
				button.innerHTML = data.data.message;
			} else {
				button.classList.remove( 'updating-message' );
				button.classList.add( 'error-message' );
				button.innerHTML = data.data.message;
			}
		} ).catch( function ( error ) {
			button.classList.remove( 'updating-message' );
			button.classList.add( 'error-message' );
			button.innerHTML = edd_free_downloads_cache.error_message;
			console.log( error );
		} );
	} );
}
