/*global jQuery, document, edd_free_downloads_vars*/
/*jslint newcap: true*/
jQuery( document.body ).ready( function ( $ ) {
	'use strict';

	var body = $( document.body );
	/**
	 * This function controls the closing of the modal by either
	 * clicking the close 'x', outside the modal, or pressing the escape key.
	 */
	function eddFreeDownloadCloseModal () {
		$( '.edd-free-downloads-modal-wrapper .edd-loading' ).hide();
		$( '.edd-free-downloads-modal-wrapper' ).removeClass( 'edd-free-downloads-modal--active' );
		$( '#edd-free-downloads-modal' ).html( '' );
		$( 'body' ).removeClass( 'edd-frozen' );
	}

	/**
	 * The user clicked the download button from the shortcode output.
	 * We will use an ajax call to populate the modal.
	 */
	body.on( 'click', 'a.edd-free-download', function ( e ) {
		e.preventDefault();

		var edd_download_id = $( this ).data( 'download-id' );
		var price_ids = [];
		var variable_prices = $( this ).parent().parent().find( 'input[name="edd_options[price_id][]"]' );
		if ( variable_prices.length > 0 ) {
			variable_prices.each( function () {
				$( this ).parent().parent().find( 'input[name="edd_options[price_id][]"]' ).each( function () {
					if ( $( this ).prop( 'checked' ) || $( this ).attr( 'type' ) === 'hidden' ) {
						price_ids.push( $( this ).val().toString() );
					}
				} );
			} );
		}

		var modal_wrapper = $( '.edd-free-downloads-modal-wrapper' );
		modal_wrapper.addClass( 'edd-free-downloads-modal--active' );
		$( '.edd-free-downloads-modal-wrapper .edd-loading' ).show();

		$.ajax( {
			url: edd_free_downloads_vars.ajaxurl,
			type: 'GET',
			data: {
				'action': 'edd_free_downloads_get_modal',
				'download_id': edd_download_id,
				'price_ids': price_ids,
				'edd_is_mobile': edd_free_downloads_vars.edd_is_mobile,
				'require_name': edd_free_downloads_vars.require_name,
				'success_page': edd_free_downloads_vars.success_page,
			},
			success: function ( returned_data ) {

				var modal_container = $( '#edd-free-downloads-modal' );

				// remove the .edd-hidden class from the modal
				modal_container.prepend( returned_data ).fadeIn( 250 );

				$( '.edd-free-downloads-modal-wrapper .edd-loading' ).hide();


				$( '.edd-free-downloads-modal-wrapper .edd-free-downloads-modal-close' ).on( 'click', function () {
					eddFreeDownloadCloseModal();
				} );

				$( '#edd-free-downloads-modal' ).on( 'click', 'a.edd-free-downloads-direct-download-link', function ( e ) {
					e.preventDefault();
					edd_fd_process_direct_download_link( $( this ) );
				} );

				/**
				 * Stopping propagation here allows the user to click on the modal without closing it
				 */
				$( '#edd-free-downloads-modal' ).on( 'click', function ( e ) {
					e.stopPropagation();
				} );

				/**
				 * If the user clicks outside the modal we remove it here
				 * and hide the wrapper again
				 */
				$( '#edd-free-downloads-modal' ).parent( '.edd-free-downloads-modal-wrapper' ).on( 'click', function () {
					eddFreeDownloadCloseModal();
				} );

				/**
				 * If the user is focused on the email field and presses enter
				 * this will "click" the download botton
				 */
				body.on( 'keypress', '.edd-free-download-field', function ( e ) {
					if ( e.which === 13 ) {
						$( '.edd-free-download-submit' ).click();
						return false;
					}
				} );

				/**
				 * If the user is focused on the close element and presses enter or spacebar,
				 * this will "click" the close botton
				 */
				body.on( 'keypress', '.edd-free-downloads-modal-close', function ( e ) {
					if ( e.which === 13 || e.which === 32 ) {
						$( '.edd-free-downloads-modal-close' ).click();
						return false;
					}
				} );

				/**
				 * Allowing for pressing escape key to close modal
				 */
				body.on( 'keyup', function ( e ) {
					if ( 27 === e.keyCode ) {
						eddFreeDownloadCloseModal();
					}
				} );

				// Set up the download button's click listener and resulting ajax call
				edd_fd_set_up_download_click_listener();

			} // End success.

		} ); // End AJAX call.

	} );

	body.on( 'click', 'a.edd-free-downloads-direct-download-link', function ( e ) {
		e.preventDefault();
		edd_fd_process_direct_download_link( $( this ) );
	} );

	/**
	 * This function sets up the jQuery listener for the click on the Download Now button, and carries out the subsequent actions.
	 */
	function edd_fd_set_up_download_click_listener () {

		var free_downloads_form_element = $( '#edd_free_download_form' );

		/**
		 * Caching `body` as it is used on key presses and clicks below.
		 * Setting closeButtonDOM to allow for an empty value by default.
		 */
		var closeButtonDOM = '';

		body.addClass( 'edd-frozen' );

		free_downloads_form_element.find( 'input' ).first().trigger( 'focus' );

		free_downloads_form_element.on( 'click', '.edd-free-download-submit', function ( e ) {

			// Clear existing errors.
			$( '.edd-free-download-errors' ).css( 'display', 'none' );
			$( '#edd-free-download-error-processing' ).empty().css( 'display', 'none' );

			var has_error = 0;
			/**
			 * Making sure we have a valid email address
			 */
			var email = free_downloads_form_element.find( 'input[name="edd_free_download_email"]' );

			var regex = /^((([A-Za-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([A-Za-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([A-Za-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([A-Za-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([A-Za-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([A-Za-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([A-Za-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([A-Za-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([A-Za-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([A-Za-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/;

			if ( email.val() === '' ) {

				$( '.edd-free-download-errors' ).show();
				$( '#edd-free-download-error-email-required' ).css( 'display', 'block' );

				has_error++;
				e.preventDefault();

			} else {
				$( '#edd-free-download-error-email-required' ).css( 'display', 'none' );

				if ( !regex.test( email.val() ) ) {
					$( '.edd-free-download-errors' ).show();
					$( '#edd-free-download-error-email-invalid' ).css( 'display', 'block' );

					has_error++;
					e.preventDefault();
				} else {
					$( '#edd-free-download-error-email-invalid' ).css( 'display', 'none' );
				}
			}
			/**
			 * End email check
			 */

			/**
			 * First and Last name check if the option is set
			 */
			if ( 'true' === edd_free_downloads_vars.require_name ) {

				var fname = $( '#edd_free_download_form input[name="edd_free_download_fname"]' );
				var lname = $( '#edd_free_download_form input[name="edd_free_download_lname"]' );

				if ( '' === fname.val() ) {
					$( '.edd-free-download-errors' ).show();
					$( '#edd-free-download-error-fname-required' ).css( 'display', 'block' );

					has_error++;
					e.preventDefault();
				} else {
					$( '#edd-free-download-error-fname-required' ).css( 'display', 'none' );
				} // End checking first name

				if ( '' === lname.val() ) {
					$( '.edd-free-download-errors' ).show();
					$( '#edd-free-download-error-lname-required' ).css( 'display', 'block' );

					has_error++;
					e.preventDefault();
				} else {
					$( '#edd-free-download-error-lname-required' ).css( 'display', 'none' );
				} // End checking last name

			} // End true check on required_name

			/**
			 * If edd_free_downloads_vars.optional_fields is empty then
			 * a user registration is NOT required
			 */
			if ( 'true' === edd_free_downloads_vars.user_registration ) {
				var username, password, password2, registration_required;

				username = $( 'input[name="edd_free_download_username"]' );
				password = $( 'input[name="edd_free_download_pass"]' );
				password2 = $( 'input[name="edd_free_download_pass2"]' );
				registration_required = edd_free_downloads_vars.guest_checkout_disabled === '1';

				if ( username.val() === '' && registration_required ) {

					$( '#edd-free-download-error-username-required' ).css( 'display', 'block' );

					has_error++;

				}

				if ( password.val() === '' && ( registration_required || '' !== username.val() ) ) {

					$( '#edd-free-download-error-password-required' ).css( 'display', 'block' );

					has_error++;

				}

				if ( password2.val() === '' && ( registration_required || '' !== username.val() ) ) {

					$( '#edd-free-download-error-password2-required' ).css( 'display', 'block' );

					has_error++;

				}

				if ( password.val() !== '' && password2.val() !== '' ) {

					if ( password.val() !== password2.val() && ( registration_required || '' !== username.val() ) ) {

						$( '#edd-free-download-error-password-unmatch' ).css( 'display', 'block' );

						has_error++;

					} else {
						$( '#edd-free-download-error-password-unmatch' ).css( 'display', 'none' );
					}
				}
			}

			// If the privacy policy checkbox is shown, and not checked.
			if ( $( '#edd-agree-to-privacy-policy' ).length && !$( '#edd-agree-to-privacy-policy' ).is( ':checked' ) ) {
				has_error++;
				$( '#edd-free-download-error-privacy-policy' ).css( 'display', 'block' );
			} else {
				$( '#edd-free-download-error-privacy-policy' ).css( 'display', 'none' );
			}

			if ( has_error === 0 ) {

				var original_submit_html = $( '.edd-free-download-submit span' ).html();
				$( '.edd-free-download-submit span' ).html( edd_free_downloads_vars.download_loading );
				$( '.edd-free-download-submit span' ).append( '<i class="edd-icon-spinner edd-icon-spin"></i>' );
				$( '.edd-free-download-submit' ).attr( 'disabled', 'disabled' );

				if ( edd_free_downloads_vars.email_verification === '1' ) {
					e.preventDefault();
					var data = $( '#edd_free_download_form' ).serialize();

					$.ajax( {
						url: edd_free_downloads_vars.ajaxurl,
						type: 'POST',
						data: data,
						success: function ( response ) {
							let message = response;
							if ( response.data && response.data.message.length ) {
								message = response.data.message;
							}
							if ( response.success ) {
								$( '.edd-free-downloads-verification-message' ).html( message ).fadeIn();
								$( '.edd-free-downloads-verification-message-wrapper' ).removeClass( 'edd-alert-info' ).addClass( 'edd-alert-success', 250 );
								$( '.edd-free-download-submit' ).hide();
								$( '.edd-free-download-cancel' ).hide();
							} else {
								$( '.edd-free-download-errors' ).css( 'display', 'block' );
								$( '#edd-free-download-error-processing' ).html( message ).css( 'display', 'block' );
								$( '.edd-free-download-submit' ).removeAttr( 'disabled' );
								$( '.edd-free-download-submit span' ).html( original_submit_html );
							}
						}
					} );
				} else {
					$( '#edd_free_download_form' ).submit();

					// If the on complete handler is set to "default" or "redirect", don't close the Modal. Otherwise, close it. This prevents it from failing to submit the form.
					if ( 'default' != edd_free_downloads_vars.on_complete_handler && 'redirect' != edd_free_downloads_vars.on_complete_handler ) {
						setTimeout( function () {
							eddFreeDownloadCloseModal();
						}, edd_free_downloads_vars.on_complete_delay );
					}
				}
			} else {
				$( '.edd-free-download-errors' ).css( 'display', 'block' );
				$( '.edd-free-download-submit' ).removeAttr( 'disabled' );
				e.preventDefault();
			}

		} ); // End validation checks

		// Show/hide the terms and conditions (copied from EDD core).
		free_downloads_form_element.find( '.edd_terms_links' ).on( 'click', function ( e ) {
			e.preventDefault();

			const terms = $( this ).parent();

			terms.prev( '.edd-terms' ).slideToggle();
			terms.find( '.edd_terms_links' ).toggle();
		} );
	}

	function edd_fd_process_direct_download_link ( target ) {

		var price_ids = [];
		var download_id = target.parent().parent().find( 'input[name="edd_free_download_id"]' ).val();

		if ( !download_id ) {
			download_id = target.parent().parent().find( '.edd-free-download' ).data( 'download-id' );
		}

		if ( !download_id ) {
			download_id = target.data( 'download-id' );
		}

		if ( target.parent().parent().find( 'input[name="edd_free_download_price_id[]"]' ).length > 0 ) {
			target.parent().parent().find( 'input[name="edd_free_download_price_id[]"]' ).each( function () {
				price_ids.push( $( this ).val().toString() );
			} );
		} else if ( target.parent().parent().find( 'input[name="edd_options[price_id][]"]:checked' ).length > 0 ) {
			target.parent().parent().find( 'input[name="edd_options[price_id][]"]:checked' ).each( function () {
				price_ids.push( $( this ).val().toString() );
			} );
		}

		var redirect = window.location.href;

		if ( redirect.indexOf( '?' ) !== -1 ) {
			redirect = redirect + '&';
		} else {
			redirect = redirect + '?';
		}

		eddFreeDownloadCloseModal();

		redirect = redirect + 'edd_action=free_downloads_process_download&download_id=' + download_id;
		if ( price_ids.length > 0 ) {
			redirect = redirect + '&price_ids=' + price_ids;
		}

		window.location = redirect;
	}
} );
