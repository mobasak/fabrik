<?php
// Silence is golden.
// 