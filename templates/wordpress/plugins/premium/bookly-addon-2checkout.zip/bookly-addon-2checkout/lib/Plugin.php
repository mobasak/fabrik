<?php
namespace Bookly2checkout\Lib;

use Bookly\Lib as BooklyLib;
use Bookly2checkout\Backend;
use Bookly2checkout\Frontend;

/**
 * Class Plugin
 * @package Bookly2checkout\Lib
 */
abstract class Plugin extends BooklyLib\Base\Plugin
{
    protected static $prefix;
    protected static $title;
    protected static $version;
    protected static $slug;
    protected static $directory;
    protected static $main_file;
    protected static $basename;
    protected static $text_domain;
    protected static $root_namespace;
    protected static $embedded;

    /**
     * @inheritDoc
     */
    protected static function init()
    {
        // Init proxy.
        Backend\Modules\Payments\ProxyProviders\Shared::init();
        Backend\Modules\Settings\ProxyProviders\Shared::init();

        if ( get_option( 'bookly_2checkout_enabled' ) ) {
            Backend\Modules\Appearance\ProxyProviders\Shared::init();
            Frontend\Modules\Booking\ProxyProviders\Shared::init();
        }
        ProxyProviders\Shared::init();
    }
}