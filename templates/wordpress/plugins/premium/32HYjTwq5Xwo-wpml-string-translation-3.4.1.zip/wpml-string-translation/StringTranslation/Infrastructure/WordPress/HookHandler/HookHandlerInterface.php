<?php
namespace WPML\StringTranslation\Infrastructure\WordPress\HookHandler;

interface HookHandlerInterface {
	public function load();
}