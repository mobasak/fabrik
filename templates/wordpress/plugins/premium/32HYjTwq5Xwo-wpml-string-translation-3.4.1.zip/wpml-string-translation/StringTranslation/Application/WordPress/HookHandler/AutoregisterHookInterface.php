<?php

namespace WPML\StringTranslation\Application\WordPress\HookHandler;

interface AutoregisterHookInterface {
}