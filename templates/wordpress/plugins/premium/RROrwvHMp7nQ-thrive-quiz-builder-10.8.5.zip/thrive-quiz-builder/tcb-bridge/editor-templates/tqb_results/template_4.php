<div class="thrv_wrapper tve-tqb-page-type tqb-result-template-4 tve_editor_main_content" style="<?php echo esc_attr( $main_content_style ); ?>">
	<div class="tqb-cb1 thrv_wrapper thrv_contentbox_shortcode thrv-content-box tve-draggable tve-droppable">
		<div class="tve-content-box-background"></div>
		<div class="tve-cb tve_empty_dropzone">
			<div class="tqb-hp1 thrv_wrapper thrv_heading thrv_text_element tve-draggable tve-droppable">
				<h2>Thank You</h2>
			</div>
			<div class="thrv_wrapper thrv_heading thrv_text_element tve-draggable tve-droppable">
				<h2>Thank you for filling out our survey!</h2>
			</div>
			<div class="tqb-p1 thrv_wrapper thrv_text_element tve-draggable tve-droppable tve_empty_dropzone">
				<p class="tve-droppable">
					The answers you've given will help us to understand how we can improve
				</p>
			</div>
		</div>
	</div>
</div>
