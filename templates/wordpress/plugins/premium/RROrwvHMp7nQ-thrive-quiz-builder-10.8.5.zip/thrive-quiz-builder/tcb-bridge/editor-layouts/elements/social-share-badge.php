<div class="tqb-social-share-badge-container tcb-no-url thrv_wrapper thrv_social tcb-elem-placeholder tcb-no-clone">
		<span class="tcb-inline-placeholder-action">
		<?php echo esc_html__( 'Insert Social Share Badge', 'thrive-quiz-builder' ); ?>
	</span>
</div>
