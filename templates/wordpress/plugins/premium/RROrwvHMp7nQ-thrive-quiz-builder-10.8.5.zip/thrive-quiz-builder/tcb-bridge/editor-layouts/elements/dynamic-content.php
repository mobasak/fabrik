<div class="thrv_wrapper tve_center tqb-dynamic-content-container tve_empty_dropzone tcb-no-clone tcb-elem-placeholder">
	<?php echo Thrive_Quiz_Builder::STATES_DYNAMIC_CONTENT_PATTERN; ?>
	<div class="tve_content_inner tqb-content-inner">
		<?php echo Thrive_Quiz_Builder::STATES_DYNAMIC_CONTENT_DEFAULT; ?>
	</div>
	<?php echo Thrive_Quiz_Builder::STATES_DYNAMIC_CONTENT_PATTERN; ?>
</div>
