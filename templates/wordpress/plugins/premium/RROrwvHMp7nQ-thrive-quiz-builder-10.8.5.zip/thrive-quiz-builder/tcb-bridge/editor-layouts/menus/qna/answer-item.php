<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden
}
?>

<div id="tve-answer_item-component" class="tve-component" data-view="answerItem">

</div>