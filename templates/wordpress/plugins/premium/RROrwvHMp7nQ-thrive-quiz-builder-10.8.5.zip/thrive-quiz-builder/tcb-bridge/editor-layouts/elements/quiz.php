<div class="thrv_wrapper tcb-row-empty tcb-elem-placeholder thrive-quiz-builder-shortcode">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'quiz', false, 'editor' ) ?>
		<?php echo esc_html__( 'Select a Quiz', 'thrive-quiz-builder' ) ?>
	</span>
</div>
