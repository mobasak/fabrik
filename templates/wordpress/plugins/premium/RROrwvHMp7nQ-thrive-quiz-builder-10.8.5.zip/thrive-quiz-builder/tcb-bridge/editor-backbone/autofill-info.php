<div class="tqb-notification">

	<?php
	echo sprintf( esc_html__( 'The hidden field will be automatically populated with the result that the user obtains in the quiz', 'thrive-quiz-builder' ) );
	?>

	<a href="https://thrivethemes.com/tkb_item/how-to-send-the-quiz-result-to-your-autoresponder-in-a-custom-field//"
	   target="_blank">
		<?php echo sprintf( esc_html__( 'Learn More', 'thrive-quiz-builder' ) ); ?>
	</a>

</div>
