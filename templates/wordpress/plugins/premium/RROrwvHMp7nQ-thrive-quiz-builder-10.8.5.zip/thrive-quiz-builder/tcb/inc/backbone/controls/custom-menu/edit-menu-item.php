<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 5/23/2018
 * Time: 2:25 PM
 */
?>
<div class="tcb-flex space-between pb-10">
	<div class="label"><?php echo esc_html__( 'Insert / edit hyperlink', 'thrive-cb' ); ?></div>
</div>

<div class="control-grid no-space full-width pb-5">
	<input type="text" class="tcb-menu-item-text change target input" data-fn-change="changed" data-fn-input="labelChanged" value="" autocomplete="off">
</div>
<div class="tcb-button-link-container">
	<div class="btn-link mt-10"></div>
</div>
<div class="tcb-menu-display-container mt-10">
	<hr>
	<div class="tcb-menu-display mt-5"></div>
</div>
