<template>
	<!-- eslint-disable -->
	<div class="tap-suite-row p-15 tap-fw tap-flex--between tap-rubik">
		<div class="tap-suite-name">
			<h4>See what extras you can get for free:</h4>
		</div>
		<div class="tap-suite-basic tap-flex">
			Basic Automator
		</div>
		<div class="tap-suite-connected tap-flex">
			Connected Automator
			<div class="tap-free">
				FREE
			</div>
		</div>
	</div>
	<div class="tap-suite-row p-15 tap-fw tap-flex--between">
		<div class="tap-suite-name">
			<icon icon-name="tap-wordpress-logo"/>
			Wordpress triggers and actions
		</div>
		<div class="tap-suite-basic tap-flex">
			<icon icon-name="tap-filled-check"/>
		</div>
		<div class="tap-suite-connected tap-flex">
			<icon icon-name="tap-filled-check"/>
		</div>
	</div>
	<div class="tap-suite-row p-15 tap-fw tap-flex--between">
		<div class="tap-suite-name">
			<img src="@/../images/mailing-integrations.webp" alt="Mailing integrations">
			Enable new automations for popular email services and CRMs
		</div>
		<div class="tap-suite-basic tap-flex">
			<icon icon-name="tap-cross"/>
		</div>
		<div class="tap-suite-connected tap-flex">
			<icon icon-name="tap-filled-check"/>
		</div>
	</div>
	<div class="tap-suite-row p-15 tap-fw tap-flex--between">
		<div class="tap-suite-name">
			<img src="@/../images/woo-logo.webp" alt="WooCommerce logo">
			Create WooCommerce automations with new triggers and actions
		</div>
		<div class="tap-suite-basic tap-flex">
			<icon icon-name="tap-cross"/>
		</div>
		<div class="tap-suite-connected tap-flex">
			<icon icon-name="tap-filled-check"/>
		</div>
	</div>
	<div class="tap-suite-row p-15 tap-fw tap-flex--between">
		<div class="tap-suite-name">
			<img src="@/../images/external-integrations.webp" alt="External integrations">
			Connect Thrive Automator to a growing library of popular apps
		</div>
		<div class="tap-suite-basic tap-flex">
			<icon icon-name="tap-cross"/>
		</div>
		<div class="tap-suite-connected tap-flex">
			<icon icon-name="tap-filled-check"/>
		</div>
	</div>
	<!-- eslint-enable -->
</template>

<script>
export default {
	name: "SuiteComparison"
}
</script>
