<?php
namespace BooklyInvoices\Backend\Modules\Payments\ProxyProviders;

use Bookly\Backend\Modules\Payments\Proxy;
use Bookly\Lib as BooklyLib;

abstract class Local extends Proxy\Invoices
{
    /**
     * @inheritDoc
     */
    public static function renderDownloadButton()
    {
        self::renderTemplate( 'download_button' );
    }
}