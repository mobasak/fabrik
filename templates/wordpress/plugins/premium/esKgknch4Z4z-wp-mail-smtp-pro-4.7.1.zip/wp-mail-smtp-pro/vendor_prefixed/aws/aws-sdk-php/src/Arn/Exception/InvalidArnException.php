<?php

namespace WPMailSMTP\Vendor\Aws\Arn\Exception;

/**
 * Represents a failed attempt to construct an Arn
 */
class InvalidArnException extends \RuntimeException
{
}
