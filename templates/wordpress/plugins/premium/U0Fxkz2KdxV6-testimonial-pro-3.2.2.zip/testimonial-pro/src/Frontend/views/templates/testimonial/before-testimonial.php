<?php
/**
 * Before Testimonial.
 *
 * This template can be overridden by copying it to yourtheme/testimonial-pro/templates/testimonial/before-testimonial.php
 *
 * @package    Testimonial_Pro
 * @subpackage Testimonial_Pro/Frontend
 */

?>
<div class="sp-testimonial-pro-item <?php echo esc_attr( $layout_class ); ?>">
<div class="sp-testimonial-pro">
