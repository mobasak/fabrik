<?php
/**
 * Validation message.
 *
 * This template can be overridden by copying it to yourtheme/testimonial-pro/templates/form/validation-msg.php
 *
 * @package    Testimonial_Pro
 * @subpackage Testimonial_Pro/Frontend
 */

?>
<div class="sp-tpro-form-validation-msg"><?php echo stripslashes( $validation_msg ); ?></div>
