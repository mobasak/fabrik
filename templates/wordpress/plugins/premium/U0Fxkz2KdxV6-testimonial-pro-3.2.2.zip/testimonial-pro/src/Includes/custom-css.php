<?php
$custom_css = trim( html_entity_decode( $setting_options['custom_css'] ) );
