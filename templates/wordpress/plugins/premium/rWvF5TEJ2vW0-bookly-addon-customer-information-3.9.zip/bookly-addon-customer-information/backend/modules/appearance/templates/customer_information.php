<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div class="bookly-box bookly-js-customer-information bookly-table">
    <div class="bookly-form-group">
        <label for="bookly-customer-information"><?php esc_html_e( 'Customer Information', 'bookly' ) ?></label>
        <div class="bookly-form-field">
            <input class="bookly-form-element" id="bookly-customer-information" type="text"/>
            <div><?php esc_html_e( 'Customer Information description', 'bookly' ) ?></div>
        </div>
    </div>
</div>