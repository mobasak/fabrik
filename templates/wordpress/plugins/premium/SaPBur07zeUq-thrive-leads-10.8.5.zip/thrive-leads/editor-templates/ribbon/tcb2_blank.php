<div class="thrv-ribbon tve_no_drag tve_no_icons thrv_wrapper tve_editor_main_content tve_empty_dropzone">
	<div class="thrv_wrapper thrv-page-section tve-draggable tve-droppable" data-css="tve-u-15da1cf38b4">
		<div class="tve-page-section-out"></div>
		<div class="tve-page-section-in tve_empty_dropzone" data-css="tve-u-15d98f73307"></div>
	</div>
	<div class="thrv_wrapper thrv_icon tcb-icon-display tve_evt_manager_listen tve_et_click tve_ea_thrive_leads_form_close tve-draggable tve-droppable" data-css="tve-u-15d98fe03d1"
		 data-tcb-events="__TCB_EVENT_[{&quot;a&quot;:&quot;thrive_leads_form_close&quot;,&quot;t&quot;:&quot;click&quot;}]_TNEVE_BCT__">
		<svg class="tcb-icon" viewBox="0 0 30 32" data-name="close">
			<path d="M0.655 2.801l1.257-1.257 27.655 27.655-1.257 1.257-27.655-27.655z"></path>
			<path d="M28.31 1.543l1.257 1.257-27.655 27.655-1.257-1.257 27.655-27.655z"></path>
		</svg>
	</div>
</div>