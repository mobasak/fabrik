<h2><?php echo esc_html__( 'No updates available.', 'thrive-leads' ); ?> </h2>
<a href="<?php echo admin_url( 'admin.php?page=thrive_leads_dashboard' ); ?>"><?php echo esc_html__( 'Back to Thrive Leads Dashboard', 'thrive-cb' ); ?></a>
