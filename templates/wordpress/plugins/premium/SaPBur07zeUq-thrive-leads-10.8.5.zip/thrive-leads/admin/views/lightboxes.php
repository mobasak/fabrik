<?php
/**
 *  should contain all lightboxes needed throughout the admin part
 */
?>