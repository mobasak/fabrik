<?php
namespace BooklyPackages\Backend\Modules\Appointments\ProxyProviders;

use Bookly\Backend\Modules\Calendar\Proxy;
use BooklyPackages\Backend\Components;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function renderAddOnsComponents()
    {
        Components\Dialogs\Schedule\Dialog::render();
    }
}