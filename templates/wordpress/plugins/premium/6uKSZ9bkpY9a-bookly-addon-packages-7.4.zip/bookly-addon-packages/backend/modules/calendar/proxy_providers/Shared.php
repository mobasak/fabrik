<?php
namespace BooklyPackages\Backend\Modules\Calendar\ProxyProviders;

use Bookly\Backend\Modules\Appointments\Proxy;
use BooklyPackages\Backend\Components;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function renderAddOnsComponents()
    {
        Components\Dialogs\Schedule\Dialog::render();
    }
}