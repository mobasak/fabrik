<?php
namespace BooklyPackages\Backend\Components\Dialogs\Staff\Edit\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

class Local extends Proxy\Packages
{
    /**
     * @inheritDoc
     */
    public static function renderStaffServicesTip()
    {
        self::renderTemplate( 'modal' );
    }
}