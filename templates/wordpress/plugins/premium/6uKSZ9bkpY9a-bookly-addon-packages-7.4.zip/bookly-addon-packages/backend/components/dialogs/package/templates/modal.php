<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Dialogs\Appointment\AttachPayment\Proxy as AttachPaymentProxy;
use Bookly\Backend\Components\Dialogs;

?>
<?php AttachPaymentProxy\Pro::renderAttachPaymentDialog() ?>
<?php Dialogs\Payment\Dialog::render() ?>
