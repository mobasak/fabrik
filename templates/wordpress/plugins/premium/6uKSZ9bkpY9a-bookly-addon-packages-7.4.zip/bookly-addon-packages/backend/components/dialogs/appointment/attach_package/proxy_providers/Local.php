<?php
namespace BooklyPackages\Backend\Components\Dialogs\Appointment\AttachPackage\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Appointment\AttachPackage\Proxy;
use BooklyPackages\Backend\Components\Dialogs\Appointment\AttachPackage\Dialog;

class Local extends Proxy\Packages
{
    /**
     * @inheritDoc
     */
    public static function renderAttachPackageDialog()
    {
        Dialog::render();
    }
}