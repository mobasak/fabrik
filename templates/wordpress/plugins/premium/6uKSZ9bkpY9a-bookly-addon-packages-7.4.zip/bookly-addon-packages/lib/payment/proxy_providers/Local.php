<?php
namespace BooklyPackages\Lib\Payment\ProxyProviders;

use Bookly\Lib\Payment\Proxy;
use Bookly\Lib\Entities;
use BooklyPackages\Lib\Entities\Package;
use Bookly\Lib\DataHolders;

class Local extends Proxy\Packages
{
    /**
     * @inheritDoc
     */
    public static function deleteCascade( Entities\Payment $payment )
    {
        foreach ( Package::query()->where( 'payment_id', $payment->getId() )->find() as $package ) {
            $package->delete();
        }
    }
}