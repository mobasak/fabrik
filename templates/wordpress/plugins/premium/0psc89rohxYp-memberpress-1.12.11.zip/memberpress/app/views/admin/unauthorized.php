<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>

<h2><?php esc_html_e('Nope', 'memberpress'); ?></h2>

