<?php

foreach ($subs as $sub) {
    echo esc_html($sub->subscr_id) . "\n";
}
