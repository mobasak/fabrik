<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
}

/**
 * This is just a front-end Controller adapter for MeprNotifications.
 *
 * @deprecated 1.11.36
 */
class MeprNotificationsCtrl extends MeprBaseCtrl
{
    /**
     * Loads WordPress hooks for the class.
     *
     * @deprecated 1.11.36
     */
    public function load_hooks()
    {
    }
}
