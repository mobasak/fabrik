<?php

/**
 * Silence will fall.
 */
