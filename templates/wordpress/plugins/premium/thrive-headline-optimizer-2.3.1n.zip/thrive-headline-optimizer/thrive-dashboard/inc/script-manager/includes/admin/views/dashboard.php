<?php

/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-dashboard
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
 include( TVD_SM_Constants::path( 'includes/admin/views/templates' ) . '/header.phtml' ); ?>
<div id="tvd-sm-breadcrumbs-wrapper"></div>
<div id="tvd-sm-wrapper">
	<div id="tvd-sm-container">
	</div>
</div>
