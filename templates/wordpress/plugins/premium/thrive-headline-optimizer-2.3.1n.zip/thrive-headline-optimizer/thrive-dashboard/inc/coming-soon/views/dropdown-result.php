<div class='select2-result-page clearfix'>
	<div class='select2-result-page__title'><#= pageTitle #></div>
</div>