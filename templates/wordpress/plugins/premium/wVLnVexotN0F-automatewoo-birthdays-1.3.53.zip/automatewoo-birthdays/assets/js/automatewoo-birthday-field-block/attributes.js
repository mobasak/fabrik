/**
 * External dependencies
 */
import { getSetting } from '@woocommerce/settings';
import { __ } from '@wordpress/i18n';

const { birthdayFieldDescription } = getSetting(
	'automatewoo_birthday_field_data',
	''
);

export default {
	description: {
		type: 'string',
		default: birthdayFieldDescription,
	},
	shouldCollectYear: {
		type: 'boolean',
		default: false,
	},
	title: {
		type: 'string',
		default: __( 'Birthday (Optional)', 'automatewoo-birthdays' ),
	},
};
