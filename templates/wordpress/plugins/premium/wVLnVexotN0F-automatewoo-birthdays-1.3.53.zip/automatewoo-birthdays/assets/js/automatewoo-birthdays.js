/* global awBirthdaysParams, wc_checkout_params */
/* eslint camelcase: [ "error", { ignoreGlobals: true } ] */

/**
 * Toggle the visibility of the birthday field in the classic `[woocommerce_checkout]` form.
 */
addEventListener( 'DOMContentLoaded', () => {
	if (
		typeof wc_checkout_params === 'undefined' ||
		typeof awBirthdaysParams === 'undefined'
	) {
		return false;
	}

	const $ = document.querySelector.bind( document );
	const createAccountCheckbox = $( 'input#createaccount' );

	function toggleBirthdayFieldVisibility() {
		$( '.automatewoo-birthday-section' ).setAttribute(
			'aria-hidden',
			createAccountCheckbox.checked ? 'false' : 'true'
		);
	}

	// Set up only for non-logged in users, who are about to create their account if they can.
	if (
		awBirthdaysParams.is_logged_in !== '1' &&
		wc_checkout_params.option_guest_checkout === 'yes' &&
		createAccountCheckbox
	) {
		toggleBirthdayFieldVisibility();
		createAccountCheckbox.addEventListener(
			'change',
			toggleBirthdayFieldVisibility
		);
	}
} );
