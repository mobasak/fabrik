/**
 * External dependencies
 */
import {
	useBlockProps,
	RichText,
	InspectorControls,
} from '@wordpress/block-editor';
import {
	SelectControl,
	Flex,
	FlexItem,
	PanelBody,
	CheckboxControl,
} from '@wordpress/components';
import { getSetting } from '@woocommerce/settings';
import { useEffect } from '@wordpress/element';
import { __ } from '@wordpress/i18n';

const { collectYear } = getSetting( 'automatewoo_birthday_field_data' );

export const Edit = ( {
	attributes: { title, description, shouldCollectYear },
	setAttributes,
} ) => {
	const blockProps = useBlockProps();

	useEffect( () => {
		if ( shouldCollectYear !== collectYear ) {
			setAttributes( {
				shouldCollectYear: collectYear,
			} );
		}
	}, [] ); // eslint-disable-line react-hooks/exhaustive-deps

	return (
		<div { ...blockProps }>
			<>
				<InspectorControls key="setting">
					<PanelBody
						title={ __( 'Settings', 'automatewoo-birthdays' ) }
					>
						<CheckboxControl
							label="Collect year of birth"
							help={ __(
								'Since the year of birth is not required for most birthday features collecting it is optional. If disabled, customers will not enter the year of their birth. Only the month and day will be stored.',
								'automatewoo-birthdays'
							) }
							checked={ shouldCollectYear }
							onChange={ ( value ) =>
								setAttributes( { shouldCollectYear: value } )
							}
						/>
					</PanelBody>
				</InspectorControls>
				<RichText
					value={ title }
					onChange={ ( value ) => setAttributes( { title: value } ) }
				/>
				<Flex justify="flex-start">
					{ shouldCollectYear && (
						<FlexItem isBlock={ true }>
							<SelectControl
								options={ [
									{
										label: __(
											'Year',
											'automatewoo-birthdays'
										),
										value: '',
									},
								] }
							/>
						</FlexItem>
					) }

					<FlexItem isBlock={ true }>
						<SelectControl
							options={ [
								{
									label: __(
										'Month',
										'automatewoo-birthdays'
									),
									value: '',
								},
							] }
						/>
					</FlexItem>
					<FlexItem isBlock={ true }>
						<SelectControl
							options={ [
								{
									label: __( 'Day', 'automatewoo-birthdays' ),
									value: '',
								},
							] }
						/>
					</FlexItem>
				</Flex>
				<RichText
					value={ description }
					onChange={ ( value ) =>
						setAttributes( { description: value } )
					}
				/>
			</>
		</div>
	);
};

export const Save = () => {
	return <div { ...useBlockProps.save() } />;
};
