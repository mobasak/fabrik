/**
 * External dependencies
 */
import { useState, useEffect } from '@wordpress/element';
import { useSelect } from '@wordpress/data';
import { getSetting } from '@woocommerce/settings';
import { Flex, FlexItem, SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

const {
	renderField,
	collectYear,
	userYear,
	userDay,
	userMonth,
	localizedMonths,
} = getSetting( 'automatewoo_birthday_field_data' );

/**
 * The component that gets rendered on frontend.
 *
 * @param {Object} props                         Incoming props.
 * @param {string} [props.description]           The field description appearing below the inputs
 * @param {string} [props.title]                 The field title appearing above the inputs.
 * @param {Object} [props.checkoutExtensionData] Passed from Checkout block, used to append data.
 */
const Block = ( { description, title, checkoutExtensionData } ) => {
	const { customerId, shouldCreateAccount } = useSelect( ( select ) => {
		const store = select( 'wc/store/checkout' );
		return {
			customerId: store.getCustomerId(),
			shouldCreateAccount: store.getShouldCreateAccount(),
		};
	} );

	/**
	 * The field is shown if the user is a guest and clicks on "Create account"
	 * or is a logged in customer without his birthday set.
	 */
	const showBirthdayField =
		( customerId || shouldCreateAccount ) && renderField;

	const [ year, setYear ] = useState( userYear );
	const [ day, setDay ] = useState( userDay );
	const [ month, setMonth ] = useState( userMonth );

	const { setExtensionData } = checkoutExtensionData;
	useEffect( () => {
		setExtensionData( 'automatewoo_birthday_field', 'userBirthday', {
			year,
			month,
			day,
		} );
	}, [ year, day, month, setExtensionData ] );

	const currentYear = new Date().getFullYear();

	const getMonths = () => {
		return localizedMonths.map( ( el, index ) => {
			return {
				value: String( index + 1 ).padStart( 2, '0' ),
				label: el,
			};
		} );
	};

	const getDays = () => {
		return Array.from( { length: 30 } ).map( ( el, index ) => {
			const dayNum = String( index + 1 ).padStart( 2, '0' );
			return {
				value: dayNum,
				label: dayNum,
			};
		} );
	};

	const getYears = () => {
		return Array.from( { length: 120 } ).map( ( el, index ) => {
			const optionYear = currentYear - index;
			return {
				value: optionYear,
				label: optionYear,
			};
		} );
	};

	return (
		<div
			className="automatewoo-birthday-field-block automatewoo-birthday-section automatewoo-birthday-section--checkout form-row form-row-wide"
			aria-hidden={ showBirthdayField ? 'false' : 'true' }
		>
			<div className="automatewoo-birthday-section__collapsible">
				<p className="wc-block-components-checkout-step__description">
					{ title }
				</p>
				<Flex justify="flex-start">
					{ collectYear && (
						<FlexItem isBlock={ true }>
							<SelectControl
								aria-label={ __(
									'Birthday Year',
									'automatewoo-birthdays'
								) }
								className="components-base-control wc-block-components-combobox-control components-combobox-control"
								value={ year }
								onChange={ setYear }
								options={ [
									{
										label: __(
											'- Year -',
											'automatewoo-birthdays'
										),
										value: '',
									},
									...getYears(),
								] }
							/>
						</FlexItem>
					) }
					<FlexItem isBlock={ true }>
						<SelectControl
							aria-label={ __(
								'Birthday Month',
								'automatewoo-birthdays'
							) }
							className="components-base-control wc-block-components-combobox-control components-combobox-control"
							value={ month }
							onChange={ setMonth }
							options={ [
								{
									label: __(
										'- Month -',
										'automatewoo-birthdays'
									),
									value: '',
								},
								...getMonths(),
							] }
						/>
					</FlexItem>
					<FlexItem isBlock={ true }>
						<SelectControl
							aria-label={ __(
								'Birthday Day',
								'automatewoo-birthdays'
							) }
							className="components-base-control wc-block-components-combobox-control components-combobox-control"
							value={ day }
							onChange={ setDay }
							options={ [
								{
									label: __(
										'- Day -',
										'automatewoo-birthdays'
									),
									value: '',
								},
								...getDays(),
							] }
						/>
					</FlexItem>
				</Flex>
				<p className="wc-block-components-checkout-step__description">
					{ description }
				</p>
			</div>
		</div>
	);
};

export default Block;
