# Hooks Reference

A list of hooks, e.g. `actions` and `filters`, that are defined or used in this project.

## automatewoo/birthdays/after_init

**Type**: action

**Used in**:

- [birthdays-addon.php#L53](https://github.com/woocommerce/automatewoo-birthdays/blob/227db6d2b46267604805678c8fa75a0cad4b50de/includes/birthdays-addon.php#L53)

## automatewoo/birthdays/checkout_field_placement

**Type**: filter

**Used in**:

- [frontend.php#L90](https://github.com/woocommerce/automatewoo-birthdays/blob/227db6d2b46267604805678c8fa75a0cad4b50de/includes/frontend.php#L90)

## automatewoo/birthdays/storage_format/full

**Type**: filter

**Used in**:

- [birthdays-addon.php#L159](https://github.com/woocommerce/automatewoo-birthdays/blob/227db6d2b46267604805678c8fa75a0cad4b50de/includes/birthdays-addon.php#L159)

## automatewoo/birthdays/storage_format/month_day

**Type**: filter

**Used in**:

- [birthdays-addon.php#L168](https://github.com/woocommerce/automatewoo-birthdays/blob/227db6d2b46267604805678c8fa75a0cad4b50de/includes/birthdays-addon.php#L168)

## automatewoo/birthdays/use_us_format

**Type**: filter

**Used in**:

- [frontend.php#L129](https://github.com/woocommerce/automatewoo-birthdays/blob/227db6d2b46267604805678c8fa75a0cad4b50de/includes/frontend.php#L129)

