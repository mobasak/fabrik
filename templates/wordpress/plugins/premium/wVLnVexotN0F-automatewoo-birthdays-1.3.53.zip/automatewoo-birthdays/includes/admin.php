<?php

namespace AutomateWoo\Birthdays;

defined( 'ABSPATH' ) || exit;

/**
 * Plugin Admin class.
 *
 * @package AutomateWoo\Birthdays
 */
class Admin {

	/**
	 * Init plugin admin area.
	 */
	public static function init() {
		/**
		 * Class name (for IDE).
		 *
		 * @var $self Admin
		 */
		$self = __CLASS__;

		add_filter( 'automatewoo/settings/tabs', [ $self, 'register_settings_tab' ] );
		add_action( 'current_screen', [ $self, 'conditional_includes' ] );

		add_filter( 'plugin_action_links_' . plugin_basename( AW_Birthdays()->file ), [ $self, 'plugin_action_links' ] );
	}

	/**
	 * Include admin files conditionally.
	 *
	 * @param \WP_Screen $screen
	 */
	public static function conditional_includes( $screen ) {
		switch ( $screen->id ) {
			case 'users':
			case 'user':
			case 'profile':
			case 'user-edit':
				new Admin_Edit_User();
				break;
		}
	}

	/**
	 * Register plugin settings tab.
	 *
	 * @param array $tabs
	 *
	 * @return array
	 */
	public static function register_settings_tab( $tabs ) {
		$tabs[] = AW_Birthdays()->path( '/includes/settings-tab.php' );
		return $tabs;
	}

	/**
	 * Output admin view.
	 *
	 * @param string $view
	 * @param array  $args
	 */
	public static function output_view( $view, $args = [] ) {
		if ( $args && is_array( $args ) ) {
			// phpcs:disable WordPress.PHP.DontExtract.extract_extract
			extract( $args );
			// phpcs:enable
		}

		$path = AW_Birthdays()->path( '/includes/views/' . $view );

		if ( file_exists( $path ) ) {

			// Exclusion reason: The $path is protected by AW_Birthdays()->path and also only being called by us
			// internally without reaching user input.
			// nosemgrep: audit.php.lang.security.file.inclusion-arg
			include $path;
		}
	}

	/**
	 * Return a page URL based on page type.
	 *
	 * @param string $page
	 * @return string
	 */
	public static function page_url( $page ) {
		switch ( $page ) {
			case 'settings':
				return admin_url( 'admin.php?page=automatewoo-settings&tab=birthdays' );

			case 'documentation':
				return 'https://woocommerce.com/document/automatewoo/getting-started-with-birthdays/?utm_source=wordpress&utm_medium=all-plugins-page&utm_campaign=doc-link&utm_content=automatewoo-birthdays';

		}

		return '';
	}

	/**
	 * Show action links on the plugin screen.
	 *
	 * @since 1.3.26
	 *
	 * @param  mixed $links Plugin Action links
	 * @return array
	 */
	public static function plugin_action_links( $links ) {
		$action_links = [
			'settings'      => '<a href="' . esc_url( self::page_url( 'settings' ) ) . '" title="' . esc_attr( __( 'View AutomateWoo Referral Settings', 'automatewoo-birthdays' ) ) . '">' . esc_html__( 'Settings', 'automatewoo-birthdays' ) . '</a>',
			'documentation' => '<a href="' . esc_url( self::page_url( 'documentation' ) ) . '" title="' . esc_attr( __( 'View AutomateWoo Referral Documentation', 'automatewoo-birthdays' ) ) . '">' . esc_html__( 'Documentation', 'automatewoo-birthdays' ) . '</a>',
		];

		return array_merge( $action_links, $links );
	}
}
