<?php

namespace AutomateWoo\Birthdays;

use AutomateWoo\Customer_Factory;
use AutomateWoo\Integrations;
use Automattic\WooCommerce\Blocks\Integrations\IntegrationRegistry;
use Automattic\WooCommerce\StoreApi\Routes\V1\Checkout;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CheckoutSchema;
use WP_Post;

defined( 'ABSPATH' ) || exit;

/**
 * Class Blocks_Integration
 * Used for register the different hooks in order to activate the AW Birthdays block
 * as well as extending the checkout API in order to get the User Birthday.
 *
 * @since 1.3.29
 */
class Blocks_Integration {

	/**
	 * @var string Name of the block
	 */
	private string $block_name = 'automatewoo-birthdays/birthday-field';

	/**
	 * @var array The user birthday
	 */
	private array $current_user_birthday;

	/**
	 * WooCommerce_Blocks_Integration constructor.
	 */
	public function __construct() {
		add_action( 'init', [ $this, 'register_blocks' ] );
		add_action( 'rest_after_insert_page', [ $this, 'maybe_update_settings' ], 10, 1 );
		add_action( 'woocommerce_blocks_checkout_block_registration', [ $this, 'register_checkout_frontend_blocks' ] );
		add_filter( '__experimental_woocommerce_blocks_add_data_attributes_to_block', [ $this, 'add_attributes_to_frontend_blocks' ], 10, 1 );
		if ( Integrations::is_woocommerce_blocks_active( '7.2.0' ) ) {
			add_action( 'woocommerce_store_api_checkout_update_order_from_request', [ $this, 'process_checkout_block_user_birthday' ], 10, 2 );
		} else {
			add_action( 'woocommerce_blocks_checkout_update_order_from_request', [ $this, 'process_checkout_block_user_birthday' ], 10, 2 );
		}

		add_action( 'woocommerce_created_customer', [ $this, 'process_checkout_block_guest_birthday' ], 10, 2 );

		self::extend_store_api();
	}

	/**
	 * Register blocks.
	 */
	public function register_blocks() {
		$asset_file_path = AW_Birthdays()->path( '/build/automatewoo-birthday-field-block.asset.php' );

		if ( file_exists( $asset_file_path ) && false === \WP_Block_Type_Registry::get_instance()->is_registered( $this->block_name ) ) {
			register_block_type( AW_Birthdays()->path( '/assets/js/automatewoo-birthday-field-block' ) );
		}
	}

	/**
	 * Load blocks in frontend with Checkout.
	 *
	 * @param IntegrationRegistry $integration_registry
	 */
	public function register_checkout_frontend_blocks( $integration_registry ) {
		$birthdays_block = new Birthday_Field_Block();

		if ( ! $integration_registry->is_registered( $birthdays_block->get_name() ) ) {
			$integration_registry->register( $birthdays_block );
		}
	}

	/**
	 * This allows dynamic (JS) blocks to access attributes in the frontend.
	 *
	 * @param string[] $allowed_blocks
	 */
	public function add_attributes_to_frontend_blocks( $allowed_blocks ) {
		$allowed_blocks[] = $this->block_name;
		return $allowed_blocks;
	}

	/**
	 * Add schema Store API to support posted data.
	 */
	public function extend_store_api() {
		$args = [
			'endpoint'        => CheckoutSchema::IDENTIFIER,
			'namespace'       => 'automatewoo_birthday_field',
			'schema_callback' => function () {
				return [
					'userBirthday' => [
						'description' => __( 'User birthday.', 'automatewoo-birthdays' ),
						'type'        => 'object',
						'properties'  => [
							'year'  => [
								'description' => esc_html__( 'User birthday year.', 'automatewoo-birthdays' ),
								'type'        => 'string',
							],
							'month' => [
								'description' => esc_html__( 'User birthday month.', 'automatewoo-birthdays' ),
								'type'        => 'string',
							],
							'day'   => [
								'description' => esc_html__( 'User birthday month.', 'automatewoo-birthdays' ),
								'type'        => 'string',
							],
						],
					],
				];
			},
		];

		if ( function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			woocommerce_store_api_register_endpoint_data( $args );
		}
	}

	/**
	 * Save the user birthday for registered customers in checkout block.
	 *
	 * @param \WC_Order        $order The order to process
	 * @param \WP_REST_Request $request The request payload (including User Birthday)
	 * @throws \Exception In case Frontend::save_birthday_field() throws an exception.
	 */
	public function process_checkout_block_user_birthday( $order, $request ) {
		if ( ! $order ) {
			return;
		}

		$params = $request->get_json_params();

		if ( ! isset( $params['extensions']['automatewoo_birthday_field'] ) ) {
			return;
		}

		$birthday = $params['extensions']['automatewoo_birthday_field']['userBirthday'] ?? [
			'year'  => '',
			'month' => '',
			'day'   => '',
		];
		$customer = Customer_Factory::get_by_order( $order, false );

		if ( $customer && $customer->get_user_id() ) {
			Frontend::save_birthday_field( $customer->get_user_id(), $birthday );
		} else {
			// In case the customer is a guest, we save the birthday in the new customer data for blocks.

			$this->current_user_birthday = $birthday;
			add_filter( 'woocommerce_new_customer_data', [ $this, 'alter_woocommerce_new_customer_data' ] );
		}
	}

	/**
	 * Save birthday for created customers in checkout block.
	 *
	 * @param integer $customer_id New customer (user) ID.
	 * @param array   $new_customer_data Array of customer (user) data.
	 * @throws \Exception In case Frontend::save_birthday_field() throws an exception.
	 */
	public function process_checkout_block_guest_birthday( $customer_id, $new_customer_data ) {
		if ( ! $customer_id ) {
			return;
		}

		$birthday = $new_customer_data['birthday'] ?? [
			'year'  => '',
			'month' => '',
			'day'   => '',
		];

		Frontend::save_birthday_field( $customer_id, $birthday );
	}

	/**
	 * Alters $new_user_data variable in Checkout Blocks
	 *
	 * @see Checkout::create_customer_account
	 * @param array $new_user_data User data provided in Checkout Block
	 * @return array The altered $new_user_data
	 */
	public function alter_woocommerce_new_customer_data( $new_user_data ) {
		if ( ! $this->current_user_birthday ) {
			return $new_user_data;
		}

		$new_user_data['birthday'] = $this->current_user_birthday;
		return $new_user_data;
	}

	/**
	 * If the `automatewoo-birthdays/birthday-field` block is in the post content then extract
	 * the block and update the `require_year_of_birth` setting based on block attributes
	 *
	 * @param WP_Post $post The WordPress Post object to check for the AutomateWoo Birthdays Block
	 *
	 * @since 1.3.37
	 *
	 * @return void
	 */
	public function maybe_update_settings( $post ): void {
		if ( has_block( $this->block_name, $post->post_content ) ) {
			$blocks = parse_blocks( $post->post_content );

			// Extract the `woocommerce/checkout` block and inner `automatewoo-birthdays/birthday-field` block
			$checkout_block     = $this->extract_block( 'woocommerce/checkout', $blocks );
			$aw_birthdays_block = $this->extract_block( $this->block_name, $checkout_block['innerBlocks'] ?? [] );

			if ( $aw_birthdays_block ) {
				update_option(
					'aw_birthdays_require_year_of_birth',
					! isset( $aw_birthdays_block['attrs']['shouldCollectYear'] ) ? 'no' : 'yes'
				);
			}
		}
	}

	/**
	 * Recursively search through all blocks and innerBlocks to find a specific block by name
	 *
	 * @param string $block_name Name of the Block to search for
	 * @param array  $blocks     Block to check
	 *
	 * @since 1.3.37
	 *
	 * @return array|bool False if not found or the matching block
	 */
	public function extract_block( $block_name, $blocks ) {
		foreach ( $blocks as $block ) {
			if ( $block_name === $block['blockName'] ) {
				return $block;
			}

			$match = $this->extract_block( $block_name, $block['innerBlocks'] );
			if ( $match ) {
				return $match;
			}
		}

		return false;
	}
}
