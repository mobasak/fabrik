<?php

namespace AutomateWoo\Birthdays;

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;

defined( 'ABSPATH' ) || exit;

/**
 * This class extends IntegrationInterface and is in charge of loading the assets and script data for the block.
 *
 * @since 1.3.29
 */
class Birthday_Field_Block implements IntegrationInterface {

	/**
	 * The name of the integration.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'automatewoo_birthday_field';
	}

	/**
	 * When called invokes any initialization/setup for the integration.
	 */
	public function initialize() {
		$script_asset = AW_Birthdays()->url( '/build/automatewoo-birthday-field-block-frontend.js' );
		$asset_path   = AW_Birthdays()->path( '/build/automatewoo-birthday-field-block-frontend.asset.php' );

		$asset_info = file_exists( $asset_path )
			? require $asset_path
			: [
				'dependencies' => [],
				'version'      => AW_Birthdays()->version,
			];

		wp_register_script(
			'automatewoo-birthday-field-block',
			$script_asset,
			$asset_info['dependencies'],
			$asset_info['version'],
			true
		);

		wp_enqueue_style( 'automatewoo-birthdays', AW_Birthdays()->url( '/build/automatewoo-birthdays.css' ), [], AW_Birthdays()->version );

		wp_set_script_translations(
			'automatewoo-birthday-field-block',
			'automatewoo-birthdays',
			AW_Birthdays()->path( '/languages' ),
		);
	}

	/**
	 * Returns an array of script handles to enqueue in the frontend context.
	 *
	 * @return string[]
	 */
	public function get_script_handles() {
		return [ 'automatewoo-birthday-field-block' ];
	}

	/**
	 * Returns an array of script handles to enqueue in the editor context.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles() {
		return [];
	}

	/**
	 * An array of key, value pairs of data made available to the block on the client side.
	 * Accessible via getSetting("automatewoo_birthday_field_data") in the frontend.
	 *
	 * @return array
	 */
	public function get_script_data() {
		$user_birthday = AW_Birthdays()->get_user_birthday( $this->get_user_id() );

		return [
			'renderField'              => ! $user_birthday,
			'birthdayFieldDescription' => AW_Birthdays()->options()->birthday_field_description(),
			'collectYear'              => AW_Birthdays()->options()->require_year_of_birth(),
			'userYear'                 => $user_birthday['year'] ?? '',
			'userMonth'                => $user_birthday['month'] ?? '',
			'userDay'                  => $user_birthday['day'] ?? '',
			'localizedMonths'          => $this->get_localized_months(),
		];
	}

	/**
	 * Get the current user ID
	 *
	 * @return int The current user's ID, or 0 if no user is logged in.
	 */
	public function get_user_id() {
		return get_current_user_id();
	}

	/**
	 * Get the localized month names using WP Locale
	 *
	 * @return array|string[] The localized months
	 */
	public function get_localized_months() {
		global $wp_locale;

		return array_map(
			function ( $month ) use ( $wp_locale ) {
				return $wp_locale->get_month( str_pad( $month, 2, '0', STR_PAD_LEFT ) );
			},
			range( 1, 12 )
		);
	}
}
