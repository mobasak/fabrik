<?php
namespace BooklyCompoundServices\Lib;

use Bookly\Lib as BooklyLib;

/**
 * Class Installer
 * @package BooklyCompoundServices\Lib
 */
class Installer extends Base\Installer
{
}