<?php
namespace BooklyCompoundServices\Lib;

/**
 * Class Updater
 * @package BooklyCompoundServices\Lib
 */
class Updater extends \Bookly\Lib\Base\Updater
{
    function update_1_3()
    {
        delete_option( 'bookly_compound_services_enabled' );
    }
}