/**
 * Internal dependencies
 */
import './register-report';
