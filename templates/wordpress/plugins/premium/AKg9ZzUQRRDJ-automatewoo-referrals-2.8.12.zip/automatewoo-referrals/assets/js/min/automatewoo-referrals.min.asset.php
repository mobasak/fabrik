<?php return array('dependencies' => array(), 'version' => '0167ea3d41f9d43172d6');
