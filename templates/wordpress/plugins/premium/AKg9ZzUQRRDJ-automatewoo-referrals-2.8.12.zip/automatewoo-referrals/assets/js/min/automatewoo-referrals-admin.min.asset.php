<?php return array('dependencies' => array(), 'version' => '522a54e6e91bff0306d5');
