<?php
// phpcs:ignoreFile

defined( 'ABSPATH' ) || exit;
