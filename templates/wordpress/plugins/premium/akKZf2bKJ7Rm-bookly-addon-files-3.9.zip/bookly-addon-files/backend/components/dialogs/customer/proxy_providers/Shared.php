<?php
namespace BooklyFiles\Backend\Components\Dialogs\Customer\ProxyProviders;

use Bookly\Backend\Components\Dialogs\Customer\Edit\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareL10n( $localize )
    {
        $localize['l10n']['incorrect_file_type'] = __( 'File\'s extension is not allowed', 'bookly' );
        $localize['l10n']['download'] = __( 'Download', 'bookly' );
        $localize['l10n']['areYouSure'] = __( 'Are you sure?', 'bookly' );

        return $localize;
    }
}