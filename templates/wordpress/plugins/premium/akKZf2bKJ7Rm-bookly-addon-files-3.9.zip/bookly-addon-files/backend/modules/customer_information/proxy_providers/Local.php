<?php
namespace BooklyFiles\Backend\Modules\CustomerInformation\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Lib\Proxy;

class Local extends Proxy\Files
{
    /**
     * @inheritDoc
     */
    public static function renderCustomerInformationTemplate( $description_html )
    {
        self::renderTemplate( 'file', compact( 'description_html' ) );
    }
}