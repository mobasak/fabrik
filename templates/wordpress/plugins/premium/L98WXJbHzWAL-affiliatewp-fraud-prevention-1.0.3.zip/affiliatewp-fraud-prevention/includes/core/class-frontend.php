<?php
/**
 * Fraud Prevention Frontend
 *
 * @package     AffiliateWP Fraud Prevention
 * @subpackage  Core
 * @copyright   Copyright (c) 2022, Awesome Motive Inc
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 */

namespace AffiliateWP_Fraud_Prevention\Core;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

#[\AllowDynamicProperties]

class Frontend {

	/**
	 * Get things started.
	 *
	 * @access public
	 * @since  1.0
	 **/
	public function __construct() {
		add_filter( 'affwp_is_customer_email_affiliate_email', array( $this, 'check_self_referral' ), 20 );
		add_filter( 'affwp_tracking_is_valid_affiliate', array( $this, 'maybe_override_tracking' ), 20, 2 );

		add_filter( 'affwp_tracking_skip_track_visit', array( $this, 'check_referring_site' ), 10, 4 );

		add_filter( 'affwp_insert_pending_referral', array( $this, 'flag_referral' ), 10, 6 );
		add_filter( 'affwp_pre_insert_visit_data', array( $this, 'flag_visit' ) );

	}

	/**
	 * Check if self referrals should be allowed.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $is_affiliate_email Whether the email is the affiliate email.
	 * @return bool.
	 */
	public function check_self_referral( $is_affiliate_email ) {

		if ( function_exists( 'affiliatewp_allow_own_referrals' ) ) {
			return $is_affiliate_email;
		}

		if ( $is_affiliate_email && 'reject' !== affiliate_wp()->settings->get( 'fraud_prevention_self_referrals', 'reject' ) ) {

			if ( 'flag' === affiliate_wp()->settings->get( 'fraud_prevention_self_referrals', 'reject' ) ) {
				add_action( 'affwp_fraud_prevention_flag_self_referral', '__return_true' );
			}

			return false;
		}

		return $is_affiliate_email;
	}

	/**
	 * Filters whether the current tracked affiliate is valid.
	 *
	 * @since 1.0
	 *
	 * @param bool $ret          Whether the current affiliate is valid.
	 * @param int  $affiliate_id Tracked affiliate ID.
	 * @return bool Whether the current tracked affiliate is valid.
	 */
	public function maybe_override_tracking( $ret, $affiliate_id ) {

		if ( function_exists( 'affiliatewp_allow_own_referrals' ) ) {
			return $ret;
		}

		if ( 'active' === affwp_get_affiliate_status( $affiliate_id ) && 'reject' !== affiliate_wp()->settings->get( 'fraud_prevention_self_referrals', 'reject' ) ) {
			return true;
		}

		return $ret;
	}

	/**
	 * Filters whether the referring site for the tracked visit is valid.
	 *
	 * @since 1.0
	 *
	 * @param bool   $skip_visit         Whether to skip tracking a visit.
	 * @param int    $affiliate_id       Affiliate ID.
	 * @param bool   $is_valid_affiliate Whether the affiliate is valid.
	 * @param string $referrer           Visit referrer.
	 * @return bool Whether the referrer for the tracked visit is valid.
	 */
	public function check_referring_site( $skip_visit, $affiliate_id, $is_valid_affiliate, $referrer ) {

		if ( ! affiliate_wp()->settings->get( 'allow_affiliate_registration' ) ) {
			return $skip_visit;
		}

		if ( empty( $referrer ) ) {
			return $skip_visit;
		}

		$check_referring_site = affiliate_wp()->settings->get( 'fraud_prevention_referring_sites', 'allow' );

		if ( 'allow' === $check_referring_site ) {
			return $skip_visit;
		}

		$websites = $this->get_affiliate_websites( $affiliate_id );

		if ( empty( $websites ) ) {
			return $skip_visit;
		}

		$parse_referrer = wp_parse_url( $referrer );

		$is_valid_referring_url = false;

		foreach ( $websites as $website ) {

			$parse_affiliate_website_url = wp_parse_url( $website );

			$valid_referring_site = stripos( trim( $parse_referrer['host'] ), trim( $parse_affiliate_website_url['host'] ) ) !== false;

			if ( true === $valid_referring_site ) {
				$is_valid_referring_url = true;
				break;
			}
		}

		if ( $is_valid_referring_url ) {
			return $skip_visit;
		}

		if ( 'flag' === $check_referring_site ) {
			add_action( 'affwp_fraud_prevention_flag_referring_site', '__return_true' );

			return false;
		}

		affiliate_wp()->utils->log( sprintf( '"%s" is not a valid referring URL for affiliate #%d. A visit was not recorded.', $referrer, $affiliate_id ) );

		return true;
	}

	/**
	 * Add a flag to a referral before it is created.
	 *
	 * @since 1.0
	 *
	 * @param array  $args         Arguments sent to referrals->add() to insert a pending referral.
	 * @param float  $amount       Calculated referral amount.
	 * @param string $reference    Referral reference (usually the order or entry number).
	 * @param string $description  Referral description.
	 * @param int    $affiliate_id Affiliate ID.
	 * @param int    $visit_id     Visit ID.
	 * @return array
	 */
	public function flag_referral( $args, $amount, $reference, $description, $affiliate_id, $visit_id ) {

		$visit = false;
		if ( ! empty( $visit_id ) ) {
			$visit = affwp_get_visit( $visit_id );
		}

		// Apply flag to referral if visit is flagged.
		if ( empty( $data['flag'] ) && $visit && empty( $visit->referral_id ) && ! empty( $visit->flag ) ) {
			$args['flag'] = $visit->flag;
		}

		// Check conversion rate.
		if ( ( 'flag' === affiliate_wp()->settings->get( 'fraud_prevention_conversion_rate', 'allow' ) ) && 10 <= $this->get_affiliate_referrals_count( $affiliate_id ) ) {
			$conversion_rate     = $this->calculate_conversion_rate( $affiliate_id );
			$min_conversion_rate = affiliate_wp()->settings->get( 'fraud_prevention_min_conversion_rate', 2 );
			$max_conversion_rate = affiliate_wp()->settings->get( 'fraud_prevention_max_conversion_rate', 20 );

			if ( $conversion_rate < $min_conversion_rate || $conversion_rate > $max_conversion_rate ) {
				$args['flag'] = 'conversion_rate';
			}
		}

		// Add self_referral flag.
		if ( has_action( 'affwp_fraud_prevention_flag_self_referral' ) ) {
			$args['flag'] = 'self_referral';
		}

		// Always flag the visit for a referral if the referral is flagged.
		if ( $visit && ! empty( $args['flag'] ) && empty( $visit->flag ) ) {
			affiliate_wp()->visits->update( $visit->visit_id, array( 'flag' => $args['flag'] ) );
		}

		return $args;
	}

	/**
	 * Add a flag to a visit before it is created.
	 *
	 * @since 1.0
	 *
	 * @param array $data Data to be inserted for a new visit.
	 * @return array
	 */
	public function flag_visit( $data ) {

		// Add referring_site flag.
		if ( has_action( 'affwp_fraud_prevention_flag_referring_site' ) ) {
			$data['flag'] = 'referring_site';
		}

		return $data;
	}

	/**
	 * Calculate the conversion rate for an affiliate.
	 *
	 * @since 1.0
	 *
	 * @param int $affiliate_id Affiliate ID.
	 * @return float
	 */
	public function calculate_conversion_rate( $affiliate_id ) {

		$visits_count = affiliate_wp()->visits->get_visits( array( 'affiliate_id' => $affiliate_id ), true );

		$conversion_rate = ( $this->get_affiliate_referrals_count( $affiliate_id ) / $visits_count ) * 100;

		return round( $conversion_rate, 2 );
	}

	/**
	 * Get the referrals count for an affiliate.
	 *
	 * @since 1.0
	 *
	 * @param int $affiliate_id Affiliate ID.
	 * @return int
	 */
	private function get_affiliate_referrals_count( $affiliate_id ) {
		$referrals_args = array(
			'affiliate_id' => $affiliate_id,
			'status'       => array( 'paid', 'unpaid' ),
		);

		return affiliate_wp()->referrals->get_referrals( $referrals_args, true );
	}

	/**
	 * Get all the websites submitted by an affiliate.
	 *
	 * @since 1.0
	 *
	 * @param int $affiliate_id Affiliate ID.
	 * @return array
	 */
	private function get_affiliate_websites( $affiliate_id ) {

		$websites = array();

		$user = get_user_by( 'ID', affwp_get_affiliate_user_id( $affiliate_id ) );

		if ( $user && ! empty( $user->user_url ) ) {
			$websites[] = $user->user_url;
		}

		$custom_fields = affwp_get_custom_registration_fields( $affiliate_id, true );

		if ( ! empty( $custom_fields ) ) {
			foreach ( $custom_fields as $custom_field ) {
				if ( 'website' === $custom_field['type'] ) {
					$websites[] = $custom_field['meta_value'];
				}
			}
		}

		return $websites;
	}
}
