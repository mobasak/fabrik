=== AutomatorWP - WhatsApp ===
Contributors: automatorwp, rubengc, eneribs, dioni00, tinocalvo
Tags: whatsapp, automatorwp, marketing, automation
Requires at least: 4.4
Tested up to: 6.8
Stable tag: 1.0.0
License: GNU AGPLv3
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Connect AutomatorWP with WhatsApp

== Description ==

[WhatsApp](https://business.whatsapp.com/ "WhatsApp") allows you to reach your customers worldwide and offer them engaging experiences at scale. Showcase your products and services, boost sales, and build relationships.

= Anonymous Triggers =

* Message received.

= Actions =

* Send message to phone number.
* Send message template to phone number.

= Tags =

* Message tags to access to the message information (phone number, content, datetime, etc.).

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.0.0 =

* Initial release.
