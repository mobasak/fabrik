(function( $ ) {

    var prefix = 'automatorwp-whatsapp-';
    var _prefix = 'automatorwp_whatsapp_';

    // On click authorize button
    $('body').on('click', '.automatorwp_settings #' + _prefix + 'authorize', function(e) {
        e.preventDefault();

        var button = $(this);
        var wrapper = button.parent();

        var token = $('#' + _prefix + 'token').val();
        var phone_id = $('#' + _prefix + 'phone_id').val();
        var business_id = $('#' + _prefix + 'business_id').val();
        var webhook_verification_id = $('#' + _prefix + 'webhook_verification_id').val();

        // Check if response div exists
        var response_wrap = wrapper.find('#' + _prefix + 'response');

        if( ! response_wrap.length ) {
            wrapper.append( '<div id="' + _prefix + 'response" style="display: none; margin-top: 10px;"></div>' );
            response_wrap = wrapper.find('#' + _prefix + 'response');
        }

        // Show error message if not correctly configured
        if( token.length === 0 || phone_id.length === 0 || business_id.length === 0 || webhook_verification_id.length === 0 ) {
            response_wrap.addClass( 'automatorwp-notice-error' );
            response_wrap.html( 'All fields are required to connect with WhatsApp' );
            response_wrap.slideDown('fast');
            return;
        }

        response_wrap.slideUp('fast');
        response_wrap.attr('class', '');

        // Show spinner
        wrapper.append('<span class="spinner is-active" style="float: none;"></span>');

        // Disable button
        button.prop('disabled', true);

        $.post(
            ajaxurl,
            {
                action: 'automatorwp_whatsapp_authorize',
                nonce: automatorwp_whatsapp.nonce,
                token: token,
                phone_id: phone_id,
                business_id: business_id,
                webhook_verification_id: webhook_verification_id,
            },
            function( response ) {

                // Add class automatorwp-notice-success on successful unlock, if not will add the class automatorwp-notice-error
                response_wrap.addClass( 'automatorwp-notice-' + ( response.success === true ? 'success' : 'error' ) );
                response_wrap.html( ( response.data.message !== undefined ? response.data.message : response.data ) );
                response_wrap.slideDown('fast');

                // Hide spinner
                wrapper.find('.spinner').remove();

                // Redirect on success
                if( response.success === true && response.data.redirect_url !== undefined ) {
                    window.location = response.data.redirect_url;
                    return;
                }
                

                // Enable button
                button.prop('disabled', false);

            }
        );
    
    });

    // On click refresh button
    $('body').on('click', '.automatorwp_settings #' + _prefix + 'refresh', function(e) {
        e.preventDefault();

        var button = $(this);
        var wrapper = button.parent();

        var webhook = $('#' + _prefix + 'webhook').val();

        // Check if response div exists
        var response_wrap = wrapper.find('#' + _prefix + 'response');

        if( ! response_wrap.length ) {
            wrapper.append( '<div id="' + _prefix + 'response" style="display: none; margin-top: 10px;"></div>' );
            response_wrap = wrapper.find('#' + _prefix + 'response');
        }

        response_wrap.slideUp('fast');
        response_wrap.attr('class', '');

        // Show spinner
        $('<span class="spinner is-active" style="float: none;"></span>').insertAfter( button );

        // Disable button
        button.prop('disabled', true);

        $.post(
            ajaxurl,
            {
                action: 'automatorwp_whatsapp_refresh',
                nonce: automatorwp_whatsapp.nonce,
                webhook: webhook,
            },
            function( response ) {

                // Add class automatorwp-notice-success on successful unlock, if not will add the class automatorwp-notice-error
                response_wrap.addClass( 'automatorwp-notice-' + ( response.success === true ? 'success' : 'error' ) );
                response_wrap.html( ( response.data.message !== undefined ? response.data.message : response.data ) );
                response_wrap.slideDown('fast');

                // Hide spinner
                wrapper.find('.spinner').remove();

                // Redirect on success
                if( response.success === true && response.data.redirect_url !== undefined ) {
                    window.location = response.data.redirect_url;
                    return;
                }


                // Enable button
                button.prop('disabled', false);

            }
        );

    });

    // View webhook on triggers
    $('body').on('click', '.automatorwp-view-webhook', function(e) {
        e.preventDefault();

        $(this).parent().next().slideDown('fast');

    });
        


})( jQuery );