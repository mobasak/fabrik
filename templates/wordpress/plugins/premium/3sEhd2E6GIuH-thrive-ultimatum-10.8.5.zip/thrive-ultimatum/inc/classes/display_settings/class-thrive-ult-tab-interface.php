<?php

/**
 * Interface TabInterface
 * Any class that implements this interface has to have options to be displayed
 */
interface Thrive_Ult_Tab_Interface {
	public function getOptions();
}
