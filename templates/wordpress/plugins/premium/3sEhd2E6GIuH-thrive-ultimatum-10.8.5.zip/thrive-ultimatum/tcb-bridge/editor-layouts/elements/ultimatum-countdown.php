<div class="thrv_wrapper tcb-row-empty tcb-elem-placeholder thrive_ultimatum_shortcode">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'ultimatum', false, 'editor' ) ?>
		<?php echo __( 'Insert Ultimatum Countdown', 'thrive-ult') ?>
	</span>
</div>
