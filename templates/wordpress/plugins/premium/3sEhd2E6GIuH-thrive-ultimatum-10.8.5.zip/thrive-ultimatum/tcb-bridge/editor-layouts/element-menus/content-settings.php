<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>

<button class="tcb-settings-modal-open-button click" data-fn="tve_ult_save_template">
	<?php echo __( 'Save Template', 'thrive-ult' ); ?>
	<?php tcb_icon( 'go-to' ); ?>
</button>
