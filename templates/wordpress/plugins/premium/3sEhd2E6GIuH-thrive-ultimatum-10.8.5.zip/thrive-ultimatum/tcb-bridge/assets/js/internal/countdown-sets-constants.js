module.exports = {
	tvu_set_01:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'background': '',
					'border-color': '',
				}
		},
	tvu_set_02:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'background': '',
					'border-color': '',
				}
		},
	tvu_set_03:
		{
			'.tve_countdown_1 .tve_t_part [class*="part-"]':
				{
					'color': '',
				}
		},
	tvu_set_05:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'background': '',
					'border-color': '',
				}
		},
	tvu_set_09:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'background': '',
					'border-color': '',
				}
		},
	tvu_set_10:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'background': '',
					'border-color': '',
				}
		},
	tvu_set_11:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'background': '',
					'border-color': '',
				}
		},
	tvu_set_12:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'background': '',
					'border-color': '',
				}
		},
	tvu_set_18:
		{
			'.tve_countdown_3 .tve_t_part .part-1':
				{
					'color': ''
				},
			'.tve_countdown_3 .tve_t_part .part-2':
				{
					'color': ''
				}
		},
	tvu_set_22:
		{
			'.tve_countdown_3 .sc_timer_content':
				{
					'background': ''
				}
		},
	tvu_set_20:
		{
			'.tve_countdown_3 .tve_t_part':
				{
					'background-color': '',
					'border-color': ''
				},
			'.tve_countdown_3 .tve_t_part::before':
				{
					'border-color': ''
				},
			'.tve_countdown_3 .tve_t_part::after':
				{
					'border-color': ''
				}
		},
	tvu_set_23:
		{
			'.tve_countdown_3 .sc_timer_content':
				{
					'border-color': ''
				},
			'.tve_countdown_3 .tve_t_part::before':
				{
					'border-color': '',
				},
			'.tve_countdown_3 .tve_t_part::after':
				{
					'border-color': '',
				}
		},
	tvu_set_24:
		{
			'.tve_countdown_1 .t-digits':
				{
					'border-color': '',
				},
		},
	tvu_set_25:
		{
			'.tve_countdown_3 .tve_t_part::after':
				{
					'background': '',
					'border-color': ''
				}
		},
	tvu_set_26:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'background': '',
				}
		},
	tvu_set_27:
		{
			'.tve_countdown_2 .tve_t_part':
				{
					'border-color': '',
				}
		},
	tvu_set_28:
		{
			'.tve_countdown_2 .t-digits':
				{
					'border-color': '',
				}
		}
};