<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include class for social connect
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-social-connect.php';

/**
 * Include class for User
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-user.php';

/**
 * Include class for Logger
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php';

/**
 * Disable WordPress notices on settings page
 *
 * @return void
 */
function socplugRemoveNoticeFromSettingsPage() {
	$screen = get_current_screen();
	if (
		'toplevel_page_socplugAdminSettingsPage' === $screen->id
		|| 'toplevel_page_socplugAdminLicensePage' === $screen->id
		|| 'social-connect_page_socplugAdminLicensePage' === $screen->id
		|| 'social-connect_page_socplugAdminLogsPage' === $screen->id
	) {
		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
	}
}
add_action( 'admin_head', 'socplugRemoveNoticeFromSettingsPage', 1 );

/**
 * Get Iconmoon Icon by type
 *
 * @param string $type The type of the icon.
 *
 * @return string The icon.
 */
function socplugGetIconmoonIcon( $type ) {
	$icon = '';
	switch ( $type ) {
		case 'google':
			$icon = '<span class="icon-icon-google"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span></span>';
			break;
		case 'facebook':
			$icon = '<span class="icon-icon-meta"></span>';
			break;
		case 'configure':
			$icon = '<span class="icon-icon-configure"></span>';
			break;
		case 'info':
			$icon = '<span class="icon-icon-info"></span>';
			break;
		default:
			break;
	}

	return $icon;
}

/**
 * Get settings SVG icon
 *
 * @return string
 */
function socplugGetSettingsSvgIcon() {
	return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="3" y="6" width="18" height="2" rx="1" fill="#C5C5C5" fill-opacity="0.5"/>
                <rect x="3" y="11" width="18" height="2" rx="1" fill="#C5C5C5" fill-opacity="0.5"/>
                <rect x="3" y="16" width="18" height="2" rx="1" fill="#C5C5C5" fill-opacity="0.5"/>
                <circle class="cr-1" cx="8" cy="7" r="2" fill="#BBBBBB"/>
                <circle class="cr-2" cx="16" cy="12" r="2" fill="#BBBBBB"/>
                <circle class="cr-3" cx="8" cy="17" r="2" fill="#BBBBBB"/>
            </svg>';
}

/**
 * Allow SVG tags in the context of the post
 *
 * @param array  $tags The tags.
 * @param string $context The context.
 *
 * @return array
 */
function socplugAllowSvgTags( $tags, $context ) {
	if ( 'post' === $context ) {
		$tags['svg']      = array(
			'width'   => true,
			'height'  => true,
			'viewBox' => true,
			'fill'    => true,
			'xmlns'   => true,
		);
		$tags['rect']     = array(
			'x'            => true,
			'y'            => true,
			'width'        => true,
			'height'       => true,
			'rx'           => true,
			'fill'         => true,
			'fill-opacity' => true,
		);
		$tags['circle']   = array(
			'class' => true,
			'cx'    => true,
			'cy'    => true,
			'r'     => true,
			'fill'  => true,
		);
		$tags['input']    = array(
			'type'        => true,
			'name'        => true,
			'value'       => true,
			'id'          => true,
			'class'       => true,
			'placeholder' => true,
			'checked'     => true,
			'disabled'    => true,
			'readonly'    => true,
			'min'         => true,
			'max'         => true,
			'step'        => true,
		);
		$tags['select']   = array(
			'name'        => true,
			'id'          => true,
			'class'       => true,
			'placeholder' => true,
			'selected'    => true,
			'disabled'    => true,
			'required'    => true,
			'multiple'    => true,
		);
		$tags['option']   = array(
			'value'    => true,
			'selected' => true,
			'disabled' => true,
			'class'    => true,
			'id'       => true,
			'name'     => true,
			'type'     => true,
		);
		$tags['textarea'] = array(
			'placeholder' => true,
			'rows'        => true,
			'class'       => true,
			'name'        => true,
			'id'          => true,
		);
	}

	return $tags;
}
add_filter( 'wp_kses_allowed_html', 'socplugAllowSvgTags', 10, 2 );


/**
 * Get buttons
 *
 * @param array  $priority The priority of the buttons.
 * @param string $style The style of the buttons.
 * @param string $redirect The redirect URL.
 *
 * @return string
 */
function socplugGetButtons( $priority, $style, $redirect = '', $add_discount = false ) {
	$html = '';
	/**
	 * Get all providers
	 */
	$social_connect = new SC_Social_Connect();
	$providers      = $social_connect->getActiveProviders();

	if ( empty( $priority ) || empty( $providers ) || ! is_array( $providers ) ) {
		return $html;
	}

	/**
	 * Add buttons based on priority and active providers
	 */
	foreach ( $priority as $network_name ) {
		/**
		 * Check if network is active
		 */
		if ( ! isset( $providers[ ucfirst( $network_name ) ] ) ) {
			continue;
		}

		$html .= socplugGetNetworkLoginBtn( ucfirst( $network_name ), $style, $redirect, $add_discount );
	}

	return $html;
}

/**
 * Show admin bar
 *
 * @param bool $show_admin_bar The show admin bar.
 *
 * @return bool
 */
function socplugShowAdminBar( $show_admin_bar ) {
	if ( ! is_user_logged_in() ) {
		return $show_admin_bar;
	}

	$main_show_admin_bar = get_option( 'socplug_main_show_admin_bar' );

	if ( current_user_can( 'read' ) && ! class_exists( 'WooCommerce' ) ) {
		$show_admin_bar = ( 'true' === $main_show_admin_bar );
	}

	return $show_admin_bar;
}
add_filter( 'show_admin_bar', 'socplugShowAdminBar', 100, 1 );

/**
 * Add field to user setting, to display meta login id
 *
 * @param object $user The user object.
 */
function socplugShowMetaLoginId( $user ): void {
	/**
	 * Check if display option is enabled. Admin can see the meta login id
	 */
	$facebook_meta_settings = get_option( 'socplug_settings_facebook' );

	if (
		! is_admin()
		&& ( empty( $facebook_meta_settings ) || 'true' !== $facebook_meta_settings['privacy'] )
	) {
		return;
	}

	/**
	 * Display meta login id
	 */
	$meta_login_id = get_user_meta( $user->ID, '_socplug_social_id_Facebook', true );
	?>
	<h2><?php esc_html_e( 'Social Connect Meta', 'social-connect-pys' ); ?></h2>
	<table class="form-table">
		<tr>
			<th>
				<label for="_socplug_social_id_Facebook">
					<?php esc_html_e( 'Meta Login ID', 'social-connect-pys' ); ?>
				</label>
			</th>
			<td>
				<input type="text" name="_socplug_social_id_Facebook" id="_socplug_social_id_Facebook"
					value="<?php echo esc_attr( $meta_login_id ); ?>" class="regular-text" readonly />
			</td>
		</tr>
	</table>
	<?php
}

add_action( 'show_user_profile', 'socplugShowMetaLoginId' );
add_action( 'edit_user_profile', 'socplugShowMetaLoginId' );

/**
 * Add field to user setting, to display Social discounts used counter
 *
 * @param object $user The user object.
 */
function socplugShowSocialDiscount( $user ): void {
	$meta_login_id = get_user_meta( $user->ID, '_socplug_social_discount_used', true );
	?>
	<h2><?php esc_html_e( 'Social Discounts', 'social-connect-pys' ); ?></h2>
	<table class="form-table">
		<tr>
			<th>
				<label for="_socplug_social_discount_used">
					<?php esc_html_e( 'Social discounts are used', 'social-connect-pys' ); ?>
				</label>
			</th>
			<td>
				<input type="text" name="_socplug_social_discount_used" id="_socplug_social_discount_used"
					value="<?php echo esc_attr( $meta_login_id ); ?>" class="regular-text" readonly />
			</td>
		</tr>
	</table>
	<?php
}

add_action( 'show_user_profile', 'socplugShowSocialDiscount' );
add_action( 'edit_user_profile', 'socplugShowSocialDiscount' );


/**
 * For old versions of php (< 5.6) that don't support hash_equals function
 */
if ( ! function_exists( 'hash_equals' ) ) {

	/**
	 * Hash equals
	 *
	 * @param string $safe_string The safe string.
	 * @param string $user_string The user string.
	 *
	 * @return bool
	 */
	function hash_equals( $safe_string, $user_string ): bool {
		$safe_len = strlen( $safe_string );
		$user_len = strlen( $user_string );

		if ( $user_len !== $safe_len ) {
			return false;
		}

		$result = 0;

		for ( $i = 0; $i < $user_len; ++$i ) {
			$result |= ( ord( $safe_string[ $i ] ) ^ ord( $user_string[ $i ] ) );
		}

		return 0 === $result;
	}
}

/**
 * Replace usercodes (e.g. [first_name]) in the text strings
 *
 * @param string $text The text to replace the usercodes in.
 * @param int    $id The user ID.
 *
 * @return string The text with the usercodes replaced.
 */
function socplugUsercodesReplace( $text, $id = 0 ): string {
	if ( 0 === $id ) {
		$id = get_current_user_id();
	}

	$user_data = get_userdata( $id );

	$first_name = $user_data->first_name ?? '';
	$last_name  = $user_data->last_name ?? '';
	$user_email = $user_data->user_email ?? '';
	$full_name  = $user_data->display_name ?? '';

	$codes = array(
		'[first_name]' => ! empty( $first_name ) ? $first_name : ( ! empty( $last_name ) ? $last_name : ( ! empty( $full_name ) ? $full_name : $user_email ) ),
		'[last_name]'  => ! empty( $last_name ) ? $last_name : ( ! empty( $first_name ) ? $first_name : ( ! empty( $full_name ) ? $full_name : $user_email ) ),
		'[user_email]' => $user_email,
		'[full_name]'  => ! empty( $full_name ) ? $full_name : ( ! empty( $first_name ) ? $first_name : ( ! empty( $last_name ) ? $last_name : $user_email ) ),
	);

	return strtr( $text, $codes );
}

/**
 * Get date range
 *
 * @param string $first The first date.
 * @param string $last The last date.
 * @param string $step The step.
 * @param string $output_format The output format.
 *
 * @return array The date range.
 */
function socplugDateRange( $first, $last, $step = '+1 day', $output_format = 'd.m.Y' ): array {
	$dates   = array();
	$current = strtotime( $first );
	$last    = strtotime( $last );
	while ( $current <= $last ) {
		$dates[] = gmdate( $output_format, $current );
		$current = strtotime( $step, $current );
	}

	return $dates;
}

/**
 * Output social accounts menu in the WordPress profile page
 *
 * @param object $user The user object.
 */
function socplugSocialAccountsMenuInWp( $user ) {
	$social_connect = new SC_Social_Connect();
	$connectmore    = $social_connect->getConnectMoreOptions();

	/**
	 * Check if connectmore is enabled and show_wp is true
	 */
	if ( empty( $connectmore ) || 'true' !== $connectmore['enabled'] || 'true' !== $connectmore['show_wp'] ) {
		return;
	}

	if ( isset( $user->ID ) ) {
		$_SESSION['connectmore_user_id'] = $user->ID;
	}

	/**
	 * Get connect more shortcode
	 *
	 * @var string
	 */
	echo do_shortcode( '[social-connect-more]' );
}

add_action( 'show_user_profile', 'socplugSocialAccountsMenuInWp', 100, 1 );
add_action( 'edit_user_profile', 'socplugSocialAccountsMenuInWp', 100, 1 );

/**
 * Redirect after auth
 *
 * @return void
 */
function socplugRedirectAfterAuth() {
	$url          = socplugDetermineRedirectUrl();
	$redirect_url = esc_url_raw( $url );

	if ( filter_var( $redirect_url, FILTER_VALIDATE_URL ) ) {
		wp_redirect( $redirect_url );
		exit;
	} else {
		wp_safe_redirect( home_url() );
		exit;
	}
}

/**
 * Determine redirect url
 *
 * @return string The redirect url.
 */
function socplugDetermineRedirectUrl() {
	$defaultUrl = admin_url();
	$moved_from = '';

	if ( isset( $_COOKIE['socplug_moved_from'] ) && ! empty( $_COOKIE['socplug_moved_from'] ) ) {
		$moved_from = $_COOKIE['socplug_moved_from'];
	}

	if ( ! $moved_from ) {
		return $defaultUrl;
	}

	setcookie( 'socplug_moved_from', '', time() - 3600, '/' );

	if ( str_contains( $moved_from, 'pre-checkout' ) ) {
		return get_permalink( wc_get_page_id( 'checkout' ) );
	}

	return $moved_from;
}

/**
 * Check if we configurate provider well
 *
 * @return array
 */
function socplugCheckProviderConfig() {
	$result = array(
		'close' => false,
	);

	if ( get_transient( 'check_provider_config' ) ) {
		$check_provider_config_send_query = get_transient( 'check_provider_config_send_query' );

		if ( $check_provider_config_send_query ) {
			delete_transient( 'check_provider_config' );
			delete_transient( 'check_provider_config_send_query' );
			$result['close'] = true;
		} else {
			set_transient( 'check_provider_config_send_query', true, 180 );
		}
	}

	return $result;
}

/**
 * Check if all fields are filled
 *
 * @return void
 */
function socplugCheckPluginVersion(): void {

	$current_version = get_option( 'socplug_version' );

	if ( PYS_SOCIAL_CONNECT_VERSION === $current_version ) {
		return;
	}

	/**
	 * Check all fields are filled
	 * Get default settings from json file
	 */
	$default_settings = json_decode( file_get_contents( PYS_SOCIAL_CONNECT_PATH . '/includes/default-settings.json' ), true );

	/**
	 * Check if all fields
	 */
	foreach ( $default_settings as $option_key => $default_value ) {
		if ( in_array( $option_key, array( 'socplug_version' ), true ) ) {
			continue;
		}

		/**
		 * Get current saved option value
		 */
		$current_value = get_option( $option_key, false );

		if ( false === $current_value ) {
			/**
			 * Add option if not exists
			 */
			add_option( $option_key, $default_value );
		} elseif ( is_array( $default_value ) && is_array( $current_value ) ) {
			/**
			 * Check if all fields are filled
			 */
			if ( is_array( $default_value ) && is_array( $current_value ) ) {
				$merged = wp_parse_args( $current_value, $default_value );
				if ( $merged !== $current_value ) {
					update_option( $option_key, $merged );
				}
			}
		}
	}

	update_option( 'socplug_version', PYS_SOCIAL_CONNECT_VERSION );

	/**
	 * Flush rewrite rules
	 */
	flush_rewrite_rules();
}

add_action( 'admin_init', 'socplugCheckPluginVersion' );

/**
 * Initialize changelog functionality
 */
function socplug_init_changelog() {
	require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-socplug-changelog.php';
	new Socplug_Changelog();
}
add_action( 'plugins_loaded', 'socplug_init_changelog' );
