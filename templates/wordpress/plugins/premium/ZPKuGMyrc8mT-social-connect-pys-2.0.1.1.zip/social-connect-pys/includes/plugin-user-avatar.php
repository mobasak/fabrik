<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Replace default avatar with social avatar if user has it
 */
add_filter( 'get_avatar', 'socplugGetAvatar', 10, 3 );
function socplugGetAvatar( $avatar, $id_or_email, $size ) {
	/**
	 * Get user by id or email
	 */
	$user = '';
	if ( is_numeric( $id_or_email ) ) {
		$user = get_user_by( 'id', $id_or_email );
	} elseif ( is_string( $id_or_email ) ) {
		$user = get_user_by( 'email', $id_or_email );
	} elseif ( is_object( $id_or_email ) ) {
		if ( ! empty( $id_or_email->user_id ) ) {
			$user = get_user_by( 'id', $id_or_email->user_id );
		}
	}

	/**
	 * Check if user is exists
	 */
	if ( ! $user || empty( $user ) || empty( $user->ID ) ) {
		return $avatar;
	}

	/**
	 * Check if user has avatar from social connect plugin
	 */
	$user        = new SC_User( $user->ID );
	$user_avatar = $user->getSocplugAvatar();

	if ( ! $user_avatar ) {
		/**
		 * Return base avatar
		 */
		return $avatar;
	}

	/**
	 * Return social avatar
	 */
	return '<img src="' . esc_url( $user_avatar ) . '" class="avatar socplug-avatar avatar-' . esc_attr( $size ) . ' photo" height="' . esc_attr( $size ) . '" width="' . esc_attr( $size ) . '" />';
}

/**
 * Import user avatar after login from social connect
 */
function socplugImportAvatar( $image_url, $user_id, $provider ) {
	/**
	 * Base folder for avatars
	 */
	$upload_dir  = wp_upload_dir();
	$avatars_dir = $upload_dir['basedir'] . '/' . PYS_SOCIAL_CONNECT_AVATARS_DIR;
	$avatars_url = $upload_dir['baseurl'] . '/' . PYS_SOCIAL_CONNECT_AVATARS_DIR;

	/**
	 * Check if base folder exists
	 */
	if ( ! file_exists( $avatars_dir ) ) {
		wp_mkdir_p( $avatars_dir );
	}

	/**
	 * File name
	 */
	$filename    = 'socplug-user-avatar-' . $provider . '-' . $user_id . '.png';
	$upload_file = $avatars_dir . '/' . $filename;

	/**
	 * Check if file exists
	 */
	if ( file_exists( $upload_file ) ) {
		SC_Logger::record( 'system', 'Upload user avatar: File exists', 'error' );
	} else {
		/**
		 * Get image from social provider
		 */
		$response = wp_remote_get( $image_url );

		/**
		 * Check if image is not found
		 */
		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			SC_Logger::record( 'system', 'Upload user avatar: Failed to download avatar from: ' . $image_url, 'error' );
			SC_Logger::record( 'system', 'Upload user avatar: User ID: ' . $user_id, 'error' );
			SC_Logger::record( 'system', 'Upload user avatar: Provider: ' . $provider, 'error' );

			return;
		}

		/**
		 * Get image type from response
		 */
		$file_type = wp_remote_retrieve_header( $response, 'content-type' );

		/**
		 * Check if image type is valid
		 */
		if ( ! in_array( $file_type, array( 'image/jpeg', 'image/png', 'image/gif' ) ) ) {
			SC_Logger::record( 'system', 'Upload user avatar: Invalid image type from: ' . $image_url, 'error' );
			SC_Logger::record( 'system', 'Upload user avatar: User ID: ' . $user_id, 'error' );
			SC_Logger::record( 'system', 'Upload user avatar: Provider: ' . $provider, 'error' );

			return;
		}

		/**
		 * Save image to upload folder
		 */
		$file_saved = file_put_contents( $upload_file, wp_remote_retrieve_body( $response ) );
		if ( ! $file_saved ) {
			SC_Logger::record( 'system', 'Upload user avatar: Failed to save avatar', 'error' );
			SC_Logger::record( 'system', 'Upload user avatar: User ID: ' . $user_id, 'error' );
			SC_Logger::record( 'system', 'Upload user avatar: Provider: ' . $provider, 'error' );

			return;
		}

		/**
		 * Form URL of saved image
		 */
		$file_url = $avatars_url . '/' . $filename;

		/**
		 * Save URL of avatar to user meta
		 */
		update_user_meta( $user_id, '_socplug_avatar_' . $provider, $file_url );
	}
}
