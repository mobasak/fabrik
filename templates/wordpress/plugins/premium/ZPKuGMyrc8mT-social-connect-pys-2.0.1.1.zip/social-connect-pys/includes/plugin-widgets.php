<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include widgets
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/widgets/main.php';
