<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Check if session is started
 */
if ( ! session_id() ) {
	session_start();
}

$validate_config = socplugCheckProviderConfig();

if ( $validate_config['close'] ) {
	echo '<script>window.close();</script>';
	exit();
}

/**
 * Initialize logger
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php';

/**
 * Check transient
 */
$redirect_after_auth = isset( $_COOKIE['socplug_redirect_after_auth'] ) ? true : false;

if ( $redirect_after_auth ) {
	setcookie( 'socplug_redirect_after_auth', false, time() - 3600, '/' );
	socplugRedirectAfterAuth();
	exit();
}

/**
 * Check if provider is set
 */
if ( ! isset( $_GET['provider'] ) ) {
	SC_Logger::record( 'system', 'Provider is not set, while trying to login', 'error' );
	return;
}

if ( isset( $_GET['moved_from'] ) ) {
	setcookie( 'socplug_moved_from', $_GET['moved_from'], time() + 300, '/' );
}

/**
 * Check if add discount is set
 */
if ( isset( $_GET['ds'] ) && 'true' === $_GET['ds'] ) {
	setcookie( 'socplug_add_discount', true, time() + 300, '/' );
}


/*
 * Check if provider is exists, and if it's active
 */
$social_connect   = new SC_Social_Connect();
$active_providers = $social_connect->getActiveProviders();
$provider         = $_GET['provider'];

if ( empty( $active_providers ) || ! is_array( $active_providers ) || ! isset( $active_providers[ $provider ] ) ) {
	SC_Logger::record( 'system', 'We have no active providers for login', 'error' );
	return;
}

/**
 * Init authentication and set provider
 */
$authentication           = new SC_Authentication();
$authentication->provider = $provider;

/**
 * Authenticate process
 */
$authentication->authenticateProcess();

/* check if we're not accessing a preview of a post, since previews are usually opened in a JS popup, so it would cause side-effects */

?>
<script>
if (window.opener != null) {
	let parentWindow = window.opener;
	parentWindow.location = window.location.href.split('#')[0];
	window.close();
}
</script>
