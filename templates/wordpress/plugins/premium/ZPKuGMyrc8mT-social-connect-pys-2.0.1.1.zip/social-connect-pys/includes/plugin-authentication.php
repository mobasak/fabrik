<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include HybridAuth
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/vendor/autoload.php';
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-authentication.php';

/**
 * Logout from all social networks
 */
function socplugLogoutFromAllProviders(): void {
	$authentication = new SC_Authentication();
	$authentication->logoutProviders();
}
add_action( 'wp_logout', 'socplugLogoutFromAllProviders' );

/**
 * Add rewrite rule for social connect auth
 */
add_action(
	'init',
	function () {
		add_rewrite_rule( '^socplug/auth/?$', 'index.php?socplug_auth=1', 'top' );
	}
);

add_filter(
	'query_vars',
	function ( $vars ) {
		$vars[] = 'socplug_auth';
		$vars[] = 'provider';
		return $vars;
	}
);

add_action(
	'template_redirect',
	function () {
		if ( get_query_var( 'socplug_auth' ) ) {
			$provider = get_query_var( 'provider', '' );
			if ( ! $provider ) {
				SC_Logger::record( 'system', 'Provider is not set, while trying to login via social connect', 'error' );
				wp_die( 'Provider is not specified!' );
			}

			require_once __DIR__ . '/socplug-auth-handler.php';
			exit;
		}
	}
);
