<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include shortcode for deleting social connect link from account and clear user metadata
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/shortcodes/sh-remove-social-links.php';

/**
 * Include shortcode for deleting the account from the WordPress system along with the data
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/shortcodes/sh-remove-account.php';

/**
 * Include shortcode Connect More
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/shortcodes/sh-connect-more.php';

/**
 * Include shortcode Social login
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/shortcodes/sh-social-login.php';

/**
 * Include shortcode Social Connect Main
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/shortcodes/sh-social-connect-main.php';


/**
 * Verify deleting form submit
 *
 * @param array $verify_rules The rules to verify.
 *
 * @return string The message.
 */
function socplugVerifyDeletingFormSubmit( $verify_rules ): string {
	/**
	 * Check if nonce is valid
	 */
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['remove_social_data_nonce'] ) ), 'remove_social_data' ) ) {
		return '<p class="socplug_center">' . __( 'Verification failed.', 'social-connect-pys' ) . '</p>';
	}

	$form_type = sanitize_text_field( wp_unslash( $_POST['form_type'] ) );
	$user_id   = get_current_user_id();

	/**
	 * Check if user has admin capabilities or admin role
	 */
	$capabilities_check = socplugCheckUserCapabilitiesToDelete( $verify_rules );

	if ( $capabilities_check ) {
		return '<p class="socplug_center">' . $capabilities_check . '</p>';
	}

	/**
	 * Do different actions based on form type
	 */
	if ( 'remove_social_links' === $form_type ) {
		/**
		 * Delete Social Connect Data from user
		 */
		socplugDeleteSocialConnectDataFromUser( $user_id );

		/**
		 * Logout all providers and clear session data
		 */
		socplugLogoutFromAllProviders();

		$message = __( 'Your Social Data has been deleted', 'social-connect-pys' );
	} else {
		/**
		 * Delete user
		 */
		require_once ABSPATH . 'wp-admin/includes/user.php';
		wp_delete_user( $user_id );

		/**
		 * Logout user
		 */
		wp_logout();
		$message = __( 'Your account has been deleted', 'social-connect-pys' );
	}

	return '<p class="socplug_center">' . $message . '</p>';
}

/**
 * Check if user has admin capabilities or admin role
 *
 * @param array $verify_rules The rules to verify.
 *
 * @return string The message.
 */
function socplugCheckUserCapabilitiesToDelete( $verify_rules ): string {

	$verify_rules = array_fill_keys( $verify_rules, true );

	if ( isset( $verify_rules['admin'] ) && current_user_can( 'manage_options' ) ) {
		return __( 'You cannot delete your account as you have the admin capabilities.', 'social-connect-pys' );
	}

	/**
	 * Check if it only 1 user on the site
	 */
	if ( isset( $verify_rules['one_user'] ) && count( get_users() ) === 1 ) {
		return __( 'You are the only user on this site. Please create another user before deleting your account.', 'social-connect-pys' );
	}

	return false;
}

/**
 * Get form html
 *
 * @param array $data The data to get the form html.
 *
 * @return string The form html.
 */
function socplugGetDeleteForm( $data ): string {
	$html = '<div class="socplug_remove_data">';
	if ( ! empty( $data['form_title'] ) ) {
		$html .= '<p>' . $data['form_title'] . '</p>';
	}

	$html .= '<form method="post" action="#" name="socplug_social_data_remove" id="socplug_social_data_remove">';
	$html .= '<input type="hidden" name="remove_social_data_nonce" value="' . wp_create_nonce('remove_social_data') . '" />';
	$html .= '<input type="hidden" name="form_type" id="form_type" value="' . $data['form_type'] . '" />';
	$text  = ! empty( $data['button_text'] ) ? $data['button_text'] : __( 'Delete my account', 'social-connect-pys' );
	$html .= '<button type="submit" name="socplug_social_data_remove" data-confirmation="' . $data['confirmation'] . '" data-confirmation-text="' . $data['confirmation_text'] . '" value="1">' . $text . '</button>';
	$html .= '</form>';
	$html .= '</div>';

	return $html;
}

/**
 * Delete social connect data from user
 */
function socplugDeleteSocialConnectDataFromUser( $id ): void {
	$user_meta_keys = array(
		'_socplug_social_id_Facebook',
		'_socplug_social_user_Facebook',
		'_socplug_social_user_Google',
		'_socplug_social_lastlogin_Facebook',
		'_socplug_social_lastlogin_Google',
		'_socplug_avatar_Facebook',
		'_socplug_avatar_Google',
		'_socplug_social_discount_used',
		'_socplug_reg_timestamp',
		'_socplug_social_providers',
	);

	foreach ( $user_meta_keys as $key ) {
		delete_user_meta( $id, $key );
	}
}

/**
 * Disconnect providers ajax
 */

add_action( 'wp_ajax_socplugDisconnectProviderAjax', 'socplugDisconnectProviderAjax' );
add_action( 'wp_ajax_nopriv_socplugDisconnectProviderAjax', 'socplugDisconnectProviderAjax' );

function socplugDisconnectProviderAjax() {
	$provider = $_POST['provider'] ?? '';
	$user     = new SC_User();

	/**
	 * Check if provider is not empty
	 */
	if ( empty( $provider ) ) {
		wp_send_json_error( __( 'Provider is not set', 'social-connect-pys' ) );
	}

	/**
	 * Check if we have user, and this provider is connected to this user
	 */
	if ( ! $user->getUserConnectedProviders() ) {
		wp_send_json_error( __( 'User is not connected', 'social-connect-pys' ) );
	}

	/**
	 * Check if provider is connected to user
	 */
	if ( ! $user->isProviderConnected( $provider ) ) {
		wp_send_json_error( __( 'Provider is not connected', 'social-connect-pys' ) );
	}

	/**
	 * All data is valid, disconnect provider
	 */

	$auth   = new SC_Authentication();
	$result = $auth->logoutProviders( array( $provider ) );

	if ( ! empty( $result ) ) {

		/**
		 * Delete user meta data for each disabled provider
		 */
		foreach ( $result as $provider ) {
			delete_user_meta( $user->userId, '_socplug_social_id_' . $provider );
			delete_user_meta( $user->userId, '_socplug_social_lastlogin_' . $provider );
			delete_user_meta( $user->userId, '_socplug_social_user_' . $provider );
			delete_user_meta( $user->userId, '_socplug_avatar_' . $provider );

			/**
			 * Delete disabled provider from active social providers
			 */
			$user_providers = $user->getUserConnectedProviders();
			if ( ! empty( $user_providers ) && in_array( $provider, $user_providers ) ) {
				$providers = array_diff( $user_providers, array( $provider ) );
				update_user_meta( $user->userId, '_socplug_social_providers', $providers );
			}
		}
	}

	wp_send_json_success( array( $result ) );
}
