<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	array(
		'version'      => '2.0.1',
		'release_date' => '10 April 2025',
		'changes'      => array(
			'Added logging mechanism.',
			'Changed coupon activation logic on authorization.',
			'Fixed bug on pre-checkout page, related to redirect.',
		),
	),
	array(
		'version'      => '2.0.0',
		'release_date' => '4 April 2025',
		'changes'      => array(
			'Initial plugin release with social login functionality.',
		),
	),
);
