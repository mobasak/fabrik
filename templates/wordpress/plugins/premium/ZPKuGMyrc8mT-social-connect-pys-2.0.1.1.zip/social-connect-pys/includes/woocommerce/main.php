<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include coupons features
 */
require_once 'coupons.php';

/**
 * Update user meta, when order is placed
 *
 * @param int $order_id The order ID.
 */
function socplugPurchasesStats( $order_id ): void {
	$order       = new WC_Order( $order_id );
	$customer_id = $order->get_user_id();
	$customer    = get_user_by( 'ID', $customer_id );

	if ( ! $customer ) {
		return;
	}

	/**
	 * Get user providers, which is ordered
	 */
	$providers = get_user_meta( $customer->ID, '_socplug_social_providers' );

	if ( empty( $providers ) ) {
		return;
	}
	$providers = json_encode( $providers );

	/**
	 * Update order meta
	 */
	add_post_meta( $order_id, 'socplug_user_networks', $providers );
}
add_action( 'woocommerce_order_status_completed', 'socplugPurchasesStats', 10, 1 );

/**
 * Remove intermediate page title
 *
 * @param string $title The title.
 * @param int    $id    The ID.
 *
 * @return string The title.
 */
function socplugRemovePrecheckoutTitle( $title, $id ) {
	$intermediate_page    = get_page_by_path( 'pre-checkout' );
	$intermediate_page_id = $intermediate_page->ID;

	/**
	 * Compare pages id
	 */

	if ( $id !== $intermediate_page_id ) {
		return $title;
	}

	return false;
}

/**
 * Display social block on WooCommerce pages
 *
 * @return void
 */
function socplugWooDisplaySocialLogin(): void {
	if ( is_user_logged_in() ) {
		return;
	}

	$social_connect = new SC_Social_Connect();
	$options        = $social_connect->getWooCouponOptions();

	if ( ! isset( $options ) ) {
		return;
	}

	/**
	 * Handle intermediate page display
	 */
	if ( 'true' === $options['enable'] && '0' !== $options['coupon_id'] && 'intermediate_page' === $options['type'] ) {
		socplugSetupIntermediatePage( $options );
	}

	/**
	 * Handle checkout displays
	 */
	if ( 'true' === $options['enable'] && '0' !== $options['coupon_id'] && 'checkout_top' === $options['type'] ) {
		add_action( 'woocommerce_before_checkout_form', 'socplugWooDisplaySocial', 5, 0 );
		socplugAddCustomAssets( array( 'social-connect-wc' ), array( 'social-connect-login-buttons' ) );
	} elseif ( 'true' === $options['enable'] && '0' !== $options['coupon_id'] && 'checkout_inside' === $options['type'] ) {
		add_action( 'woocommerce_checkout_before_customer_details', 'socplugWooDisplaySocial', 10, 0 );
		socplugAddCustomAssets( array( 'social-connect-wc' ), array( 'social-connect-login-buttons' ) );
	}

	/**
	 * Handle single product page display
	 */
	socplugHandleSingleProductDisplay( $options );

	/**
	 * Handle cart page display
	 */
	socplugHandleCartPageDisplay( $options );

	/**
	 * Handle checkout page display
	 */
	if ( 'true' !== $options['enable'] || '0' === $options['coupon_id'] ) {
		socplugSetupCheckoutPage( $options );
	}
}

add_action( 'init', 'socplugWooDisplaySocialLogin' );

/**
 * Setup checkout page
 *
 * @param array $options The options.
 *
 * @return void
 */
function socplugSetupCheckoutPage( $options ): void {
	if ( 'true' !== $options['show_on_checkout_page'] ) {
		return;
	}

	$hooks = array(
		'top'    => 'woocommerce_before_checkout_form',
		'bottom' => 'woocommerce_after_checkout_form',
	);

	$hook = $options['show_on_checkout_page_display'];

	if ( isset( $hooks[ $hook ] ) ) {
		add_action( $hooks[ $hook ], 'socplugWooDisplaySocial', 5, 0 );
		socplugAddCustomAssets( array( 'social-connect-wc' ), array( 'social-connect-login-buttons' ) );
	}
}

/**
 * Setup intermediate page
 *
 * @param array $options The options.
 *
 * @return void
 */
function socplugSetupIntermediatePage( $options ): void {
	add_filter( 'woocommerce_get_checkout_url', 'socplugWooChangeCheckoutUrl' );

	if ( 'true' === $options['hide_title'] ) {
		add_filter( 'the_title', 'socplugRemovePrecheckoutTitle', 10, 2 );
	}

	/**
	 * Check if intermediate page exists
	 */
	$intermediate_page = get_page_by_path( 'pre-checkout' );
	if ( null === $intermediate_page ) {
		wp_insert_post(
			array(
				'post_name'    => 'pre-checkout',
				'post_title'   => 'Intermediate Page',
				'post_content' => 'Intermediate Page Content',
				'post_status'  => 'publish',
				'post_type'    => 'page',
			)
		);
	}

	socplugAddCustomAssets( array( 'social-connect-wc' ), array( 'social-connect-login-buttons' ) );
}

/**
 * Handle single product page display
 *
 * @param array $options The options.
 *
 * @return void
 */
function socplugHandleSingleProductDisplay( $options ): void {
	if ( 'true' !== $options['show_on_single_product_page'] || defined( 'ELEMENTOR_VERSION' ) ) {
		return;
	}

	$hooks = array(
		'top_summary'               => 'woocommerce_before_single_product_summary',
		'before_add_to_cart_button' => 'woocommerce_before_add_to_cart_button',
		'after_add_to_cart_button'  => 'woocommerce_after_add_to_cart_button',
		'after_product_meta'        => 'woocommerce_product_meta_end',
	);

	$hook = $options['show_on_single_product_page_display'];

	if ( isset( $hooks[ $hook ] ) ) {
		add_action( $hooks[ $hook ], 'socplugWooDisplaySocial', 5, 0 );
		socplugAddCustomAssets( array( 'social-connect-wc' ), array( 'social-connect-login-buttons' ) );
	}
}

/**
 * Handle cart page display
 *
 * @param array $options The options.
 *
 * @return void
 */
function socplugHandleCartPageDisplay( $options ): void {
	if ( 'true' !== $options['show_on_cart_page'] ) {
		return;
	}

	$hooks = array(
		'top'    => 'woocommerce_before_cart',
		'bottom' => 'woocommerce_after_cart_table',
	);

	$hook = $options['show_on_cart_page_display'];

	if ( isset( $hooks[ $hook ] ) ) {
		add_action( $hooks[ $hook ], 'socplugWooDisplaySocial', 5, 0 );
		socplugAddCustomAssets( array( 'social-connect-wc' ), array( 'social-connect-login-buttons' ) );
	}
}

/**
 * Display social block on WooCommerce pages
 *
 * @param bool $echo_content Whether to echo the output.
 *
 * @return string The HTML output.
 */
function socplugWooDisplaySocial( $echo_content = true ) {
	/**
	 * If user logged in, return
	 */
	if ( is_user_logged_in() ) {
		return '';
	}

	$add_discount = false;

	if ( is_checkout() || is_page( 'pre-checkout' ) ) {
		$add_discount = true;
	}

	$social_connect = new SC_Social_Connect();
	$options        = $social_connect->getWooCouponOptions();
	$main_buttons   = $social_connect->getMainButtonsOptions();
	$type           = $options['type'];

	$box_data = socplugWooDisplaySocialGetData( $options );

	if ( $box_data['break'] ) {
		return '';
	}

	$text = $box_data['text'];

	/**
	 * Seach XX% in text and replace with discount percentage
	 */
	$text = $social_connect->generateSocialCouponDiscountText( $text );

	/**
	 * Generate content
	 */
	$html  = '<div class="social-connect-wc">';
	$html .= '<h4>' . stripslashes( $text ) . '</h4>';
	$html .= '<div class="social-connect-wc-buttons">';
	$html .= '<div class="social-connect-wc-buttons-wrapper">';
	$html .= socplugGetButtons( $main_buttons['order'], $main_buttons['style'], '', $add_discount );
	$html .= '</div>';
	$html .= '</div>';
	if ( 'intermediate_page' === $type && is_page( 'pre-checkout' ) ) {
		$html .= '<p class="social-connect-wc-skip"><a href="' . esc_url( wc_get_checkout_url() ) . '">' . stripslashes( $options['intermediate_page_skip_link'] ) . '</a></p>';
	}

	$html .= '</div>';
	if ( $echo_content ) {
		echo wp_kses_post( $html );
	}

	return $html;
}

/**
 * Get data for social block
 *
 * @param array $options The options of the social block.
 *
 * @return array The data of the social block.
 */
function socplugWooDisplaySocialGetData( $options ): array {
	$type      = $options['type'];
	$enable    = $options['enable'];
	$coupon_id = $options['coupon_id'];
	$data      = array(
		'text'  => '',
		'break' => true,
	);

	if ( is_page( 'pre-checkout' )
		&& 'true' === $enable
		&& '0' !== $coupon_id ) {
		/**
		 * Is pre-checkout page
		 */
		if ( ! empty( $options['intermediate_page_text'] ) ) {
			$data['text']  = $options['intermediate_page_text'];
			$data['break'] = false;
		} elseif ( ! empty( $options['text_before_login'] ) ) {
			$data['text']  = $options['text_before_login'];
			$data['break'] = false;
		}
	} elseif ( is_checkout() ) {
		/**
		 * Is checkout page
		 */
		if ( 'true' === $enable && '0' !== $coupon_id ) {
			if ( ! empty( $options[ $type . '_text' ] ) ) {
				$data['text']  = $options[ $type . '_text' ];
				$data['break'] = false;
			} elseif ( ! empty( $options['text_before_login'] ) ) {
				$data['text']  = $options['text_before_login'];
				$data['break'] = false;
			}
		} elseif ( 'true' === $options['show_on_checkout_page'] && ! empty( $options['show_on_checkout_page_text'] ) ) {
			$data['text']  = $options['show_on_checkout_page_text'];
			$data['break'] = false;
		}
	} elseif ( is_cart() && ! empty( $options['show_on_cart_page_text'] ) ) {
		/**
		 * Is cart page
		 */
		$data['text']  = $options['show_on_cart_page_text'];
		$data['break'] = false;
	} elseif ( is_product() && ! empty( $options['show_on_single_product_page_text'] ) ) {
		/**
		 * Is single product page
		 */
		$data['text']  = $options['show_on_single_product_page_text'];
		$data['break'] = false;
	}

	return $data;
}

/**
 * Change checkout url
 *
 * @param string $checkout_url The checkout url.
 *
 * @return string The checkout url.
 */
function socplugWooChangeCheckoutUrl( $checkout_url ) {
	if ( ! is_cart() ) {
		return $checkout_url;
	}

	$intermediate_page    = get_page_by_path( 'pre-checkout' );
	$intermediate_page_id = $intermediate_page->ID;
	return get_permalink( $intermediate_page_id );
}

/**
 * Add social buttons to-checkout page
 *
 * @param string $content The content of the page.
 *
 * @return string The content of the page.
 */
function socplugWooPreCheckoutContent( $content ) {

	if ( ! is_page( 'pre-checkout' ) ) {
		return $content;
	}

	return socplugWooDisplaySocial( false );
}
add_action( 'the_content', 'socplugWooPreCheckoutContent' );

/**
 * Output social accounts menu in the woocommerce myaccount page
 *
 * @return void
 */
function socplugSocialAccountsMenuInWc() {
	$social_connect = new SC_Social_Connect();
	$connectmore    = $social_connect->getConnectMoreOptions();

	/**
	 * Check if connectmore is enabled and show_wp is true
	 */
	if (
		empty( $connectmore )
		|| 'true' !== $connectmore['enabled']
		|| 'true' !== $connectmore['show_wc']
		|| ! class_exists( 'WooCommerce' )
		|| ! is_account_page()
		|| ! is_user_logged_in()
	) {
		return;
	}

	/**
	 * Get connect more shortcode
	 */
	echo do_shortcode( '[social-connect-more]' );
}
add_action( 'woocommerce_after_my_account', 'socplugSocialAccountsMenuInWc' );
