<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php'; // Ensure logger is included

/**
 * Apply social coupon discount
 *
 * @return void
 */
function socplugWooApplySocialCouponDiscount(): void {
	$social_connect = new SC_Social_Connect();
	$options        = $social_connect->getWooCouponOptions();
	$user           = new SC_User();

	if ( ! isset( $_COOKIE['socplug_add_discount'] ) || '1' !== $_COOKIE['socplug_add_discount'] ) {
		return;
	}

	if (
		( ! isset( $options['enable'] )
			&& 'true' !== $options['enable'] )
		|| ! $user->userHasConnected
		|| empty( $options['coupon_id'] )
		|| '0' === $options['coupon_id']
	) {
		return;
	}

	$coupon_data = $social_connect->getSocialCouponData();
	if ( ! $coupon_data ) {
		return;
	}

	$coupon_code           = $coupon_data->get_code();
	$limit_discount_number = $options['limit'] ?? 1;
	$used_discount         = $user->getUserSocialDiscountData();

	if ( $used_discount >= $limit_discount_number ) {
		return;
	}

	global $woocommerce;

	$order_placed = ( isset( $_GET['key'] ) && str_contains( $_GET['key'], 'wc_order' ) );

	if (
		! $order_placed
		&& $woocommerce->cart->get_cart_contents_count() !== 0
		&& ! $woocommerce->cart->has_discount( $coupon_code )
		&& ! WC()->session->get( 'social_coupon_removed' )
	) {
		$woocommerce->cart->add_discount( $coupon_code );
		$text = $social_connect->generateSocialCouponDiscountText( $options['text_after_login'] );
		setcookie( 'socplug_add_discount', '0', 0, '/' );

		/**
		 * Save notice to session
		 */
		WC()->session->set( 'social_coupon_notice', $text );
		WC()->session->set( 'social_coupon_notice_show', 2 );
	}
}
add_action( 'woocommerce_cart_updated', 'socplugWooApplySocialCouponDiscount' );

/**
 * Show social coupon notice
 *
 * @return void
 */
function socplugShowSocialCouponNotice() {

	if ( ! is_user_logged_in() && ! class_exists( 'WooCommerce' ) ) {
		return;
	}

	if ( ! WC() || ! WC()->session ) {
		return;
	}

	try {
		$notice = WC()->session->get( 'social_coupon_notice' );

		if ( empty( $notice ) ) {
			return;
		}

		wc_add_notice( $notice, 'success' );

		WC()->session->__unset( 'social_coupon_notice' );

	} catch ( Exception $e ) {
		/**
		 * Error handling
		 */
		SC_Logger::record( 'system', 'socplugShowSocialCouponNotice: Error', 'error' );
		SC_Logger::record( 'system', $e->getMessage(), 'error' );
		return;
	}
}

add_action( 'wp_footer', 'socplugShowSocialCouponNotice' );
add_action( 'woocommerce_before_cart', 'socplugShowSocialCouponNotice' );

/**
 * Remove social coupon
 * Save to session and dont apply it again to order
 *
 * @param string $coupon_code The coupon code.
 *
 * @return void
 */
function onCouponRemoved( $coupon_code ) {
	$social_connect     = new SC_Social_Connect();
	$social_coupon_data = $social_connect->getSocialCouponData();

	if ( ! $social_coupon_data ) {
		return;
	}

	$social_coupon_code = $social_coupon_data->get_code();

	if ( strtolower( $coupon_code ) !== strtolower( $social_coupon_code ) ) {
		return;
	}

	/**
	 * Save to session
	 */
	WC()->session->set( 'social_coupon_removed', true );
}
add_action( 'woocommerce_removed_coupon', 'onCouponRemoved', 10, 1 );

/**
 * Update user meta, when order is placed
 *
 * @param int $order_id The order ID.
 *
 * @return void
 */
function socplugWooCustomCheckCouponAfterOrder( $order_id ): void {
	/**
	 * Check if user is logged in and connected with social account and coupon is enabled
	 */
	$social_connect = new SC_Social_Connect();
	$user           = new SC_User();
	$options        = $social_connect->getWooCouponOptions();

	if (
		'true' !== $options['enable']
		|| ! $user->userHasConnected
		|| empty( $options['coupon_id'] )
		|| '0' === $options['coupon_id']
	) {
		return;
	}

	/**
	 * Get order details
	 */
	$order = wc_get_order( $order_id );

	/**
	 * Get applied coupon
	 */
	$coupons = $order->get_coupon_codes();

	/**
	 * Social coupon data
	 */
	$coupon_data = $social_connect->getSocialCouponData();

	if ( empty( $coupons ) || ! $coupon_data ) {
		return;
	}

	$coupon_code = $coupon_data->get_code();

	/**
	 * Check if Social discount is applied
	 */
	foreach ( $coupons as $coupon ) {
		if ( strtolower( $coupon ) !== strtolower( $coupon_code ) ) {
			continue;
		}

		/**
		 * Update user meta
		 */
		$social_discount_uses = $user->getUserSocialDiscountData();
		$social_discount_uses = (int) $social_discount_uses + 1;
		$user->setUserSocialDiscountData( $social_discount_uses );

		return;
	}
}

add_action( 'woocommerce_checkout_order_processed', 'socplugWooCustomCheckCouponAfterOrder', 10, 1 );


/**
 * Block Social coupon for non-authenticated users
 *
 * @param bool   $is_valid The is valid.
 * @param object $coupon   The coupon.
 *
 * @return bool The is valid.
 */
function socplugBlockSocialCouponeForNonLoggedUsers( $is_valid, $coupon ) {
	/**
	 * Get base options
	 */
	$social_connect = new SC_Social_Connect();
	$user           = new SC_User();
	$options        = $social_connect->getWooCouponOptions();

	/**
	 * Check if social coupon data exists
	 */
	$social_coupon_data = $social_connect->getSocialCouponData();
	if ( ! $social_coupon_data ) {
		return $is_valid;
	}

	/**
	 * Check if coupon is social coupon and enabled
	 */
	if (
		'true' !== $options['enable']
		|| empty( $options['coupon_id'] )
		|| strtolower( $coupon->get_code() ) !== strtolower( $social_coupon_data->get_code() )
	) {
		return $is_valid;
	}

	/**
	 * Check if user is logged in and have active provider
	 */
	if ( ! $user->userHasConnected ) {
		wc_add_notice( 'You need to be logged via social network to use this coupon', 'error' );
		return false;
	}

	/**
	 * User logged in and have active provider, need check if they don't reach limit
	 */
	$social_discount_uses = $user->getUserSocialDiscountData();

	if ( $social_discount_uses >= $options['limit'] ) {
		wc_add_notice( 'You have already reached the limit of using this discount', 'error' );
		return false;
	}

	/**
	 * User is logged in and have active provider, so apply coupon
	 */
	return $is_valid;
}

add_filter( 'woocommerce_coupon_is_valid', 'socplugBlockSocialCouponeForNonLoggedUsers', 10, 2 );
