<?php

if (!defined('ABSPATH')) {
    exit;
}

class Social_Connect_Main_Widget extends WP_Widget
{
    /**
     * Sets up the widget name and description.
     */
    public function __construct()
    {
        parent::__construct(
            'social_connect_widget',
            __('Social Connect Widget', 'social-connect-pys'),
            ['description' => __('A widget to display social widget', 'social-connect-pys')],
        );
    }

    /**
     * Outputs the content of the widget on the front end.
     */
    public function widget($args, $instance)
    {
        if (shortcode_exists('social-connect-main')) {
            echo do_shortcode('[social-connect-main]');
        }
    }
}


function socplugRegisterSocialConnectMainWidget()
{
    register_widget('Social_Connect_Main_Widget');
}
add_action('widgets_init', 'socplugRegisterSocialConnectMainWidget');
