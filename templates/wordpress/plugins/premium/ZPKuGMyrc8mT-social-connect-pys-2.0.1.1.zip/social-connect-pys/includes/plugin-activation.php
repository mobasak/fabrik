<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *  Plugin version and default settings on initial activation
 */
register_activation_hook( __FILE__, 'socplugActivation' );
add_action( 'admin_init', 'socplugActivation' );

/**
 * Activation function
 *
 * @return void
 */
function socplugActivation() {
	$social_connect = new SC_Social_Connect();
	$social_connect->onPluginActivation();
}
