<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SC_Elementor_Social_Login extends \Elementor\Widget_Base {

	public function get_name(): string {
		return 'social_login_form';
	}

	public function get_title(): string {
		return esc_html__( 'Social Login Form', 'social-connect-pys' );
	}

	public function get_icon(): string {
		return 'eicon-social-icons';
	}

	public function get_categories(): array {
		return array( 'social-connect' );
	}

	public function get_keywords(): array {
		return array( 'social connect', 'pixel your site' );
	}

	public function get_custom_help_url(): string {
		return 'https://pixelyoursite.com';
	}

	protected function register_controls(): void {

		/**
		 * Content section
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'social-connect-pys' ),
			)
		);

		$this->add_control(
			'heading',
			array(
				'label'     => esc_html__( 'Heading', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::TEXTAREA,
				'default'   => __( 'Login to the website', 'social-connect-pys' ),
				'separator' => 'before',
			)
		);

		$this->add_control(
			'social_login_subheading',
			array(
				'label'     => esc_html__( 'Social login subheading', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::TEXTAREA,
				'default'   => __( 'With your favorite social service', 'social-connect-pys' ),
				'separator' => 'before',
			)
		);

		$this->add_control(
			'base_login_subheading',
			array(
				'label'     => esc_html__( 'Credintials login subheading', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::TEXTAREA,
				'default'   => __( 'With your credentials', 'social-connect-pys' ),
				'separator' => 'before',
			)
		);

		$this->end_controls_section();

		/**
		 * Redirect Rules
		 */
		$this->start_controls_section(
			'section_redirect_rules',
			array(
				'label' => esc_html__( 'Redirect Rules', 'social-connect-pys' ),
			)
		);

		$this->add_control(
			'redirect_rules',
			array(
				'label'   => esc_html__( 'Redirect Rules', 'social-connect-pys' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array(
					'none'    => esc_html__( 'None', 'social-connect-pys' ),
					'account' => esc_html__( 'Account', 'social-connect-pys' ),
					'custom'  => esc_html__( 'Custom Url', 'social-connect-pys' ),
				),
				'default' => 'none',
			)
		);

		$this->add_control(
			'custom_url',
			array(
				'label'     => esc_html__( 'Custom Url', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::URL,
				'dynamic'   => array(
					'active' => true,
				),
				'condition' => array(
					'redirect_rules' => 'custom',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Display options
		 */
		$this->start_controls_section(
			'display_options',
			array(
				'label' => esc_html__( 'Display Options', 'social-connect-pys' ),
			)
		);

		$this->add_control(
			'form_layout',
			array(
				'label'       => esc_html__( 'Form Layout', 'social-connect-pys' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'vertical'   => esc_html__( 'Vertical', 'social-connect-pys' ),
					'horizontal' => esc_html__( 'Horizontal', 'social-connect-pys' ),
				),
				'default'     => 'vertical',
			)
		);

		$this->add_control(
			'buttons_design',
			array(
				'label'       => esc_html__( 'Buttons Design', 'social-connect-pys' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'options'     => array(
					'base'                  => __( 'Square color', 'social-connect-pys' ),
					'monochrome'            => __( 'Square monochrome', 'social-connect-pys' ),
					'circle'                => __( 'Circle color', 'social-connect-pys' ),
					'circle_monochrome'     => __( 'Circle monochrome', 'social-connect-pys' ),
					'big'                   => __( 'Square color (big)', 'social-connect-pys' ),
					'big_monochrome'        => __( 'Square monochrome (big)', 'social-connect-pys' ),
					'circle_big'            => __( 'Circle color (big)', 'social-connect-pys' ),
					'circle_big_monochrome' => __( 'Circle monochrome (big)', 'social-connect-pys' ),
					'full'                  => __( 'Wide color', 'social-connect-pys' ),
					'short'                 => __( 'Wide color (no text)', 'social-connect-pys' ),
				),
				'default'     => 'base',
			)
		);

		$this->add_control(
			'buttons_order',
			array(
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Select order of networks', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'facebook_google' => __( 'Facebook - Google', 'social-connect-pys' ),
					'google_facebook' => __( 'Google - Facebook', 'social-connect-pys' ),
				),
				'default'     => 'facebook_google',
			)
		);

		$this->add_control(
			'form_show',
			array(
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Show or hide form for logged in users', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'show' => __( 'Show', 'social-connect-pys' ),
					'hide' => __( 'Hide', 'social-connect-pys' ),
				),
				'default'     => 'hide',
			)
		);

		$this->end_controls_section();

		/**
		 * Preview Settings
		 */
		$this->start_controls_section(
			'socplug_preview_settings',
			array(
				'label' => esc_html__( 'Preview Settings', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'socplug_preview_as',
			array(
				'type'        => \Elementor\Controls_Manager::CHOOSE,
				'label'       => esc_html__( 'Preview widget in different user status', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'not_logged'              => array(
						'title' => esc_html__( 'Not logged in', 'social-connect-pys' ),
						'icon'  => 'eicon-person',
					),
					'logged_in_not_connected' => array(
						'title' => esc_html__( 'Logged in (not connected)', 'social-connect-pys' ),
						'icon'  => 'eicon-person',
					),
					'logged_in_connected'     => array(
						'title' => esc_html__( 'Logged in (connected)', 'social-connect-pys' ),
						'icon'  => 'eicon-person',
					),
				),
				'default'     => 'not_logged',
				'toggle'      => true,
				'description' => esc_html__( 'Select the preview type (Not logged in, Logged in and not connected, Logged in and connected)', 'social-connect-pys' ),
			)
		);

		$this->end_controls_section();

		/**
		 * Styles section
		 */
		$this->start_controls_section(
			'socplug_styles_section',
			array(
				'label' => esc_html__( 'Section Styles', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'section_background_color',
			array(
				'label'     => esc_html__( 'Section Background Color', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style.socplug-login-form' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .dynamic-style.socplug-login-form .divider-text' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'section_border_type',
			array(
				'label'     => esc_html__( 'Border Type', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'options'   => array(
					'none'   => __( 'None', 'social-connect-pys' ),
					'solid'  => __( 'Solid', 'social-connect-pys' ),
					'dashed' => __( 'Dashed', 'social-connect-pys' ),
					'dotted' => __( 'Dotted', 'social-connect-pys' ),
					'double' => __( 'Double', 'social-connect-pys' ),
					'groove' => __( 'Groove', 'social-connect-pys' ),
					'ridge'  => __( 'Ridge', 'social-connect-pys' ),
					'inset'  => __( 'Inset', 'social-connect-pys' ),
					'outset' => __( 'Outset', 'social-connect-pys' ),
				),
				'default'   => 'none',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style.socplug-login-form' => 'border-style: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'section_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#BAC7D5',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style.socplug-login-form' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'section_border_size',
			array(
				'label'     => esc_html__( 'Border Size', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => '0',
				'min'       => '0',
				'max'       => '20',
				'step'      => '1',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style.socplug-login-form' => 'border-width: {{VALUE}}px;',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Typography section
		 */
		$this->start_controls_section(
			'section_typography',
			array(
				'label' => esc_html__( 'Typography', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Heading typography
		 */
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'socplug_heading_typography',
				'label'    => esc_html__( 'Heading', 'social-connect-pys' ),
				'selector' => '{{WRAPPER}} .dynamic-style .socplug-login-form-heading h2',
			)
		);

		/**
		 * Heading color
		 */
		$this->add_control(
			'socplug_heading_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Heading color', 'social-connect-pys' ),
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style .socplug-login-form-heading h2' => 'color: {{VALUE}};',
				),
			)
		);

		/**
		 * Content typography
		 */
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'socplug_subheading_typography',
				'label'    => esc_html__( 'Subheading', 'social-connect-pys' ),
				'selector' => '{{WRAPPER}} .dynamic-style h3',
			)
		);

		/**
		 * Content color
		 */
		$this->add_control(
			'socplug_content_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Content color', 'social-connect-pys' ),
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style h3' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Buttons styles
		 */
		$this->start_controls_section(
			'section_buttons_styles',
			array(
				'label' => esc_html__( 'Buttons Styles', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'buttons_border_type',
			array(
				'label'     => esc_html__( 'Border Type', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'options'   => array(
					'none'   => __( 'None', 'social-connect-pys' ),
					'solid'  => __( 'Solid', 'social-connect-pys' ),
					'dashed' => __( 'Dashed', 'social-connect-pys' ),
					'dotted' => __( 'Dotted', 'social-connect-pys' ),
					'double' => __( 'Double', 'social-connect-pys' ),
					'groove' => __( 'Groove', 'social-connect-pys' ),
					'ridge'  => __( 'Ridge', 'social-connect-pys' ),
					'inset'  => __( 'Inset', 'social-connect-pys' ),
					'outset' => __( 'Outset', 'social-connect-pys' ),
				),
				'default'   => 'solid',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style .network-login-btn' => 'border-style: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buttons_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#BAC7D5',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style .network-login-btn' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buttons_border_size',
			array(
				'label'     => esc_html__( 'Border Size', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'default'   => '1',
				'min'       => '0',
				'max'       => '20',
				'step'      => '1',
				'selectors' => array(
					'{{WRAPPER}} .dynamic-style .network-login-btn' => 'border-width: {{VALUE}}px;',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		/**
		 * Check if builder mode
		 */
		$builder = false;

		if ( \Elementor\Plugin::instance()->editor->is_edit_mode() ) {
			$builder = true;

			if ( 'hide' === $settings['form_show']
			&& 'not_logged' !== $settings['socplug_preview_as'] ) {
				return;
			}
		}

		/**
		 * Dont show widget if user is logged in, except builder mode
		 */
		if ( ! $builder && is_user_logged_in() && 'hide' === $settings['form_show'] ) {
			return;
		}

		/**
		 * Form layout
		 */
		$form_layout             = $settings['form_layout'];
		$heading                 = $settings['heading'];
		$social_login_subheading = $settings['social_login_subheading'];
		$base_login_subheading   = $settings['base_login_subheading'];

		/**
		 * Redirect
		 */
		$redirect_to = '';
		if ( 'custom' === $settings['redirect_rules'] && ! empty( $settings['custom_url']['url'] ) ) {
			$redirect_to = $settings['custom_url']['url'];
		} elseif ( 'account' === $settings['redirect_rules'] ) {
			$redirect_to = get_edit_user_link();
		}

		/**
		 * Echo widget template
		 */
		echo '<div class="socplug-login-form dynamic-style form-layout-' . esc_attr( $form_layout ) . '">';

		/**
		 * Form heading
		 */
		echo '<div class="socplug-login-form-heading">';
		if ( ! empty( $heading ) ) {
			echo '<h2>' . esc_html( $heading ) . '</h2>';
		}
		if ( ! empty( $social_login_subheading ) ) {
			echo '<h3>' . esc_html( $social_login_subheading ) . '</h3>';
		}
		echo '</div>';

		/**
		 * Form content
		 */
		echo '<div class="socplug-login-form-content">';

		/**
		 * Remember me for vertical layout
		 */
		echo '<div class="socplug-login-form-remember socplug-login-form-remember-vertical">';
		echo socplugGetFormElCheckbox(
			array(
				'name'     => 'socplug_remember_me_vertical',
				'class'    => 'socplug-login-form-remember-checkbox',
				'id'       => 'socplug_remember_me_vertical',
				'label'    => __( 'Remember me', 'social-connect-pys' ),
				'selected' => 'true',
			)
		);
		echo '</div>';

		/**
		 * Social buttons
		 */
		echo '<div class="socplug-login-form-social">';
		if ( ! empty( $social_login_subheading ) ) {
			echo '<h3>' . esc_html( $social_login_subheading ) . '</h3>';
		}

		/**
		 * Social buttons
		 */
		$button_style = $settings['buttons_design'];
		$button_order = $settings['buttons_order'];
		$button_order = explode( '_', $button_order );

		echo '<div class="socplug-login-form-social-buttons">';
		echo socplugGetButtons( $button_order, $button_style, $redirect_to );
		echo '</div>';

		echo '</div>';

		/**
		 * Divider
		 */
		echo '<div class="socplug-login-form-divider">';
		/**
		 * Vertical divider
		 */
		echo '<span class="socplug-login-form-divider-vertical"><span class="divider-text">' . __( 'or continue with', 'social-connect-pys' ) . '</span></span>';

		/**
		 * Horizontal divider
		 */
		echo '<span class="socplug-login-form-divider-horizontal"><span class="divider-text">' . __( 'or', 'social-connect-pys' ) . '</span></span>';
		echo '</div>';

		/**
		 * Base login form
		 */
		echo '<div class="socplug-login-form-login">';
		if ( ! empty( $base_login_subheading ) ) {
			echo '<h3>' . esc_html( $base_login_subheading ) . '</h3>';
		}

		echo '<div class="socplug-login-form-base">';
		$form = wp_login_form(
			array(
				'echo'              => false,
				'redirect'          => $redirect_to,
				'form_id'           => 'socplug-login-form',
				'label_username'    => __( '', 'social-connect-pys' ),
				'label_password'    => __( '', 'social-connect-pys' ),
				'label_remember'    => __( 'Remember Me', 'social-connect-pys' ),
				'label_log_in'      => __( 'Log In', 'social-connect-pys' ),
				'id_username'       => 'user_login',
				'id_password'       => 'user_pass',
				'id_remember'       => 'rememberme',
				'id_submit'         => 'wp-submit',
				'remember'          => true,
				'value_remember'    => true,
				'required_username' => true,
				'required_password' => true,
			)
		);

		/**
		 * Add autocomplete to form fields
		 */
		$form = str_replace(
			'<input type="text"',
			'<input type="text" autocomplete="username"',
			$form
		);

		$form = str_replace(
			'<input type="password"',
			'<input type="password" autocomplete="current-password"',
			$form
		);

		echo $form;
		echo '</div>';

		/**
		 * Remember me for horizontal layout
		 */
		echo '<div class="socplug-login-form-remember socplug-login-form-remember-horizontal">';
		echo socplugGetFormElCheckbox(
			array(
				'name'     => 'socplug_remember_me_horizontal',
				'class'    => 'socplug-login-form-remember-checkbox',
				'id'       => 'socplug_remember_me_horizontal',
				'label'    => __( 'Remember me', 'social-connect-pys' ),
				'selected' => 'true',
			)
		);
		echo '</div>';

		/**
		 * End form content
		 */
		echo '</div>';

		/**
		 * End widget template
		 */
		echo '</div>';

		socplugAddCustomAssets( array( 'social-connect-login-form' ), array( 'social-connect-login-form', 'social-connect-login-buttons' ) );
	}
}
