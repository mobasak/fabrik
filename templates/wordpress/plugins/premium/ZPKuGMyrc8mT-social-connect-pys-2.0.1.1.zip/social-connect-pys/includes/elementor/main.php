<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Check if elementor is installed
 */
if ( class_exists( 'Elementor\Plugin' ) ) {
	socplugRegisterElementorCustomWidgets();
}

/**
 * Register Elementor custom widgets
 *
 * @return void
 */
function socplugRegisterElementorCustomWidgets(): void {
	/**
	 * Register Category
	 */
	add_action( 'elementor/elements/categories_registered', 'socplugAddElementorWidgetCategories' );

	/**
	 * Register Main Social Connect widget
	 */
	add_action( 'elementor/widgets/register', 'socplugRegisterElementorSocialWidget' );
	add_action( 'elementor/frontend/after_enqueue_styles', 'socplugWidgetEnqueueStyles' );
	add_action( 'elementor/editor/after_enqueue_styles', 'socplugWidgetEnqueueStyles' );

	/**
	 * Register Login buttons widget
	 */
	add_action( 'elementor/widgets/register', 'socplugRegisterElementorLoginButtonsWidget' );
	add_action( 'elementor/frontend/after_enqueue_styles', 'socplugLoginsButtonsWidgetEnqueueStyles' );
	add_action( 'elementor/editor/after_enqueue_styles', 'socplugLoginsButtonsWidgetEnqueueStyles' );

	/**
	 * Register Login Form widget
	 */
	add_action( 'elementor/widgets/register', 'socplugRegisterElementorLoginFormWidget' );
	add_action( 'elementor/frontend/after_enqueue_styles', 'socplugLoginFormWidgetEnqueueStyles' );
	add_action( 'elementor/editor/after_enqueue_styles', 'socplugLoginFormWidgetEnqueueStyles' );
}

/**
 * Register Main Social Connect widget
 *
 * @param object $widgets_manager The widgets manager.
 * @return void
 */
function socplugRegisterElementorSocialWidget( $widgets_manager ): void {
	require_once PYS_SOCIAL_CONNECT_PATH . '/includes/elementor/widgets/class-sc-elementor-social-connect.php';
	$widgets_manager->register( new \SC_Elementor_Social_Connect() );
}

/**
 * Enqueue styles for Main Social Connect widget
 *
 * @return void
 */
function socplugWidgetEnqueueStyles() {
	socplugAddCustomAssets( array( 'social-connect-main' ) );
}


/**
 * Register Login buttons widget
 *
 * @param object $widgets_manager The widgets manager.
 * @return void
 */
function socplugRegisterElementorLoginButtonsWidget( $widgets_manager ): void {
	require_once PYS_SOCIAL_CONNECT_PATH . '/includes/elementor/widgets/class-sc-elementor-social-buttons.php';
	$widgets_manager->register( new \SC_Elementor_Social_Buttons() );
}

/**
 * Enqueue styles for Login buttons widget
 *
 * @return void
 */
function socplugLoginsButtonsWidgetEnqueueStyles() {
	socplugAddCustomAssets( array( 'social-connect-wc' ) );
}

/**
 * Register Elementor Custom Category
 *
 * @param object $elements_manager The elements manager.
 * @return void
 */
function socplugAddElementorWidgetCategories( $elements_manager ): void {
	$elements_manager->add_category(
		'social-connect',
		array(
			'title' => esc_html__( 'Social Connect', 'social-connect-pys' ),
			'icon'  => 'fa fa-plug',
		)
	);
}

/**
 * Register Login Form widget
 *
 * @param object $widgets_manager The widgets manager.
 * @return void
 */
function socplugRegisterElementorLoginFormWidget( $widgets_manager ): void {
	require_once PYS_SOCIAL_CONNECT_PATH . '/includes/elementor/widgets/class-sc-elementor-social-login.php';
	$widgets_manager->register( new \SC_Elementor_Social_Login() );
}

/**
 * Enqueue styles for Login Form widget
 *
 * @return void
 */
function socplugLoginFormWidgetEnqueueStyles() {
	socplugAddCustomAssets(
		array( 'social-connect-login-form' ),
		array( 'social-connect-login-form', 'social-connect-login-buttons' )
	);
}
