<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Social Connect Widget
 *
 * @since 1.0.0
 */
class SC_Elementor_Social_Connect extends \Elementor\Widget_Base {


	public function get_name(): string {
		return 'social_connect_widget';
	}

	public function get_title(): string {
		return esc_html__( 'Social Connect', 'social-connect-pys' );
	}

	public function get_icon(): string {
		return 'eicon-social-icons';
	}

	public function get_categories(): array {
		return array( 'social-connect' );
	}

	public function get_keywords(): array {
		return array( 'social connect', 'pixel your site' );
	}

	public function get_custom_help_url(): string {
		return 'https://pixelyoursite.com';
	}

	protected function register_controls(): void {
		/**
		 * Content Section
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		/**
		 * Widget Title
		 */
		$this->add_control(
			'socplug_widget_title',
			array(
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label'       => esc_html__( 'Widget Title', 'social-connect-pys' ),
				'label_block' => true,
				'default'     => esc_html__( 'Connect with us', 'social-connect-pys' ),
				'placeholder' => esc_html__( 'Enter widget title', 'social-connect-pys' ),
			)
		);

		/**
		 * Show or hide widget title
		 */
		$this->add_control(
			'socplug_widget_hide_title',
			array(
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'label'   => esc_html__( 'Hide widget title', 'social-connect-pys' ),
				'default' => 'no',
			)
		);

		/**
		 * Unconnected user title
		 */
		$this->add_control(
			'socplug_widget_unconnected_user_title',
			array(
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label'       => esc_html__( 'Unconnected user title', 'social-connect-pys' ),
				'label_block' => true,
				'default'     => esc_html__( 'Login with your social account', 'social-connect-pys' ),
			)
		);

		/**
		 * Connected user title
		 */
		$this->add_control(
			'socplug_widget_connected_users_title',
			array(
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label'       => esc_html__( 'Connected user title', 'social-connect-pys' ),
				'label_block' => true,
				'default'     => esc_html__( 'Hey, [first_name]', 'social-connect-pys' ),
				'placeholder' => esc_html__( 'Hey, [first_name]', 'social-connect-pys' ),
				'description' => esc_html__( 'Personalize the message by using special tags like [first_name], [last_name], [user_email] and [full_name] for a more relatable message', 'social-connect-pys' ),
			)
		);

		/**
		 * Account link text
		 */
		$this->add_control(
			'socplug_widget_account_link_text',
			array(
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label'       => esc_html__( 'Account link text', 'social-connect-pys' ),
				'label_block' => true,
				'default'     => esc_html__( 'Go to your account', 'social-connect-pys' ),
				'placeholder' => esc_html__( 'Go to your account', 'social-connect-pys' ),
			)
		);

		$this->end_controls_section();

		/**
		 * Redirect rules
		 */
		$this->start_controls_section(
			'redirect_rules',
			array(
				'label' => esc_html__( 'Redirect Rules', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'socplug_redirect_rules',
			array(
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Redirect Rules', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'account'    => esc_html__( 'Redirect to WordPress account', 'social-connect-pys' ),
					'custom_url' => esc_html__( 'Redirect to Custom Url', 'social-connect-pys' ),
					'samepage'   => esc_html__( 'Stay on the same page', 'social-connect-pys' ),
				),
				'default'     => 'samepage',
			)
		);

		$this->add_control(
			'socplug_redirect_url',
			array(
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label'       => esc_html__( 'Redirect URL', 'social-connect-pys' ),
				'label_block' => true,
				'default'     => '',
				'condition'   => array(
					'socplug_redirect_rules' => 'custom_url',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Buttons Design
		 */
		$this->start_controls_section(
			'socplug_buttons_design_section',
			array(
				'label' => esc_html__( 'Buttons Design', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		/**
		 * Control Icon Design
		 */
		$this->add_control(
			'socplug_icon_design',
			array(
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Select icon design', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'base'                  => __( 'Square color', 'social-connect-pys' ),
					'monochrome'            => __( 'Square monochrome', 'social-connect-pys' ),
					'circle'                => __( 'Circle color', 'social-connect-pys' ),
					'circle_monochrome'     => __( 'Circle monochrome', 'social-connect-pys' ),
					'big'                   => __( 'Square color (big)', 'social-connect-pys' ),
					'big_monochrome'        => __( 'Square monochrome (big)', 'social-connect-pys' ),
					'circle_big'            => __( 'Circle color (big)', 'social-connect-pys' ),
					'circle_big_monochrome' => __( 'Circle monochrome (big)', 'social-connect-pys' ),
					'full'                  => __( 'Wide color', 'social-connect-pys' ),
					'short'                 => __( 'Wide color (no text)', 'social-connect-pys' ),
				),
				'default'     => 'base',
			)
		);

		/**
		 * Control Order network
		 */
		$this->add_control(
			'socplug_networks_order',
			array(
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Select order of networks', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'facebook_google' => __( 'Facebook - Google', 'social-connect-pys' ),
					'google_facebook' => __( 'Google - Facebook', 'social-connect-pys' ),
				),
				'default'     => 'facebook_google',
			)
		);

		$this->end_controls_section();

		/**
		 * Profile Settings
		 */
		$this->start_controls_section(
			'socplug_profile_settings_section',
			array(
				'label' => esc_html__( 'Profile Settings', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		/**
		 * Show profile picture
		 */
		$this->add_control(
			'socplug_show_profile_picture',
			array(
				'type'    => \Elementor\Controls_Manager::SWITCHER,
				'label'   => esc_html__( 'Show profile picture', 'social-connect-pys' ),
				'default' => 'yes',
			)
		);

		$this->end_controls_section();

		/**
		 * Preview Settings
		 */
		$this->start_controls_section(
			'socplug_preview_settings',
			array(
				'label' => esc_html__( 'Preview Settings', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'socplug_preview_as',
			array(
				'type'        => \Elementor\Controls_Manager::CHOOSE,
				'label'       => esc_html__( 'Preview widget in different user status', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'not_logged'              => array(
						'title' => esc_html__( 'Not logged in', 'social-connect-pys' ),
						'icon'  => 'eicon-person',
					),
					'logged_in_not_connected' => array(
						'title' => esc_html__( 'Logged in (not connected)', 'social-connect-pys' ),
						'icon'  => 'eicon-person',
					),
					'logged_in_connected'     => array(
						'title' => esc_html__( 'Logged in (connected)', 'social-connect-pys' ),
						'icon'  => 'eicon-person',
					),
				),
				'default'     => 'not_logged',
				'toggle'      => true,
				'description' => esc_html__( 'Select the preview type (Not logged in, Logged in and not connected, Logged in and connected)', 'social-connect-pys' ),
			)
		);

		$this->end_controls_section();

		/**
		 * Styles section
		 */
		$this->start_controls_section(
			'socplug_styles_section',
			array(
				'label' => esc_html__( 'Section Styles', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Section background color
		 */
		$this->add_control(
			'socplug_section_background_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Section background color', 'social-connect-pys' ),
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-main' => 'background-color: {{VALUE}};',
				),
			)
		);

		/**
		 * Border type
		 */
		$this->add_control(
			'socplug_section_border_type',
			array(
				'type'      => \Elementor\Controls_Manager::SELECT,
				'label'     => esc_html__( 'Border type', 'social-connect-pys' ),
				'default'   => 'solid',
				'options'   => array(
					'solid'  => __( 'Solid', 'social-connect-pys' ),
					'dashed' => __( 'Dashed', 'social-connect-pys' ),
					'dotted' => __( 'Dotted', 'social-connect-pys' ),
					'double' => __( 'Double', 'social-connect-pys' ),
					'groove' => __( 'Groove', 'social-connect-pys' ),
					'ridge'  => __( 'Ridge', 'social-connect-pys' ),
					'inset'  => __( 'Inset', 'social-connect-pys' ),
					'outset' => __( 'Outset', 'social-connect-pys' ),
				),
				'selectors' => array(
					'{{WRAPPER}} .social-connect-main' => 'border-style: {{VALUE}};',
				),
			)
		);

		/**
		 * Border color
		 */
		$this->add_control(
			'socplug_section_border_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Border color', 'social-connect-pys' ),
				'default'   => '#BAC7D5',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-main' => 'border-color: {{VALUE}};',
				),
			)
		);

		/**
		 * Border size
		 */
		$this->add_control(
			'socplug_section_border_size',
			array(
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'label'     => esc_html__( 'Border size', 'social-connect-pys' ),
				'default'   => array(
					'size' => 1,
				),
				'selectors' => array(
					'{{WRAPPER}} .social-connect-main' => 'border-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		/**
		 * Section padding
		 */
		$this->add_control(
			'socplug_section_padding',
			array(
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'label'      => esc_html__( 'Section padding', 'social-connect-pys' ),
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .social-connect-main' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Typography section
		 */
		$this->start_controls_section(
			'socplug_typography_section',
			array(
				'label' => esc_html__( 'Typography', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Heading typography
		 */
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'socplug_heading_typography',
				'label'    => esc_html__( 'Heading', 'social-connect-pys' ),
				'selector' => '{{WRAPPER}} .social-connect-main-heading',
			)
		);

		/**
		 * Heading color
		 */
		$this->add_control(
			'socplug_heading_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Heading color', 'social-connect-pys' ),
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-main-heading' => 'color: {{VALUE}};',
				),
			)
		);

		/**
		 * Content typography
		 */
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'socplug_subheading_typography',
				'label'    => esc_html__( 'Subheading', 'social-connect-pys' ),
				'selector' => '{{WRAPPER}} .social-connect-main-subheading',
			)
		);

		/**
		 * Content color
		 */
		$this->add_control(
			'socplug_content_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Content color', 'social-connect-pys' ),
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-main-subheading' => 'color: {{VALUE}};',
				),
			)
		);

		/**
		 * Account link typography
		 */
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'socplug_account_link_typography',
				'label'    => esc_html__( 'Account link', 'social-connect-pys' ),
				'selector' => '{{WRAPPER}} .social-connect-main-account-link a',
			)
		);

		/**
		 * Account link color
		 */
		$this->add_control(
			'socplug_account_link_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Account link color', 'social-connect-pys' ),
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-main-account-link a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Button styles
		 */
		$this->start_controls_section(
			'socplug_button_styles_section',
			array(
				'label' => esc_html__( 'Button Styles', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Button border type
		 */
		$this->add_control(
			'socplug_button_border_type',
			array(
				'type'      => \Elementor\Controls_Manager::SELECT,
				'label'     => esc_html__( 'Button border type', 'social-connect-pys' ),
				'default'   => 'solid',
				'options'   => array(
					'solid'  => __( 'Solid', 'social-connect-pys' ),
					'dashed' => __( 'Dashed', 'social-connect-pys' ),
					'dotted' => __( 'Dotted', 'social-connect-pys' ),
					'double' => __( 'Double', 'social-connect-pys' ),
					'groove' => __( 'Groove', 'social-connect-pys' ),
					'ridge'  => __( 'Ridge', 'social-connect-pys' ),
					'inset'  => __( 'Inset', 'social-connect-pys' ),
					'outset' => __( 'Outset', 'social-connect-pys' ),
				),
				'selectors' => array(
					'{{WRAPPER}} .network-login-btn' => 'border-style: {{VALUE}};',
				),
			)
		);

		/**
		 * Button border color
		 */
		$this->add_control(
			'socplug_button_border_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Button border color', 'social-connect-pys' ),
				'default'   => '#BAC7D5',
				'selectors' => array(
					'{{WRAPPER}} .network-login-btn' => 'border-color: {{VALUE}};',
				),
			)
		);

		/**
		 * Button border size
		 */
		$this->add_control(
			'socplug_button_border_size',
			array(
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'label'     => esc_html__( 'Button border size', 'social-connect-pys' ),
				'default'   => array(
					'size' => 1,
				),
				'selectors' => array(
					'{{WRAPPER}} .network-login-btn' => 'border-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		/**
		 * Button border radius
		 */
		$this->add_control(
			'socplug_button_border_radius',
			array(
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'label'     => esc_html__( 'Button border radius', 'social-connect-pys' ),
				'default'   => array(
					'size' => 0,
				),
				'selectors' => array(
					'{{WRAPPER}} .network-login-btn' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		/**
		 * Button padding
		 */
		$this->add_control(
			'socplug_button_padding',
			array(
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'label'      => esc_html__( 'Button padding', 'social-connect-pys' ),
				'size_units' => array( 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .network-login-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'default'    => array(
					'top'    => 0,
					'right'  => 0,
					'bottom' => 0,
					'left'   => 0,
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$user     = new SC_User();
		$show_as  = '';

		if ( \Elementor\Plugin::instance()->editor->is_edit_mode() && ! empty( $settings['socplug_preview_as'] ) ) {
			$show_as = $settings['socplug_preview_as'];

			if ( 'logged_in_connected' === $show_as ) {
				$user->userHasConnected = true;
			} elseif ( 'logged_in_not_connected' === $show_as || 'not_logged' === $show_as ) {
				$user->userHasConnected = false;
			}

			if ( 'not_logged' === $show_as ) {
				$user->userd = 0;
			}
		}

		if ( ! $user->userHasConnected && $user->userId !== 0 ) {
			return;
		}

		/**
		 * Widget Title
		 */
		$widget_title = $settings['socplug_widget_title'];

		/**
		 * If user is connected, add class 'user-connected'
		 */
		$classes = $user->userHasConnected ? ' user-connected' : '';

		/**
		 * If title is empty or hide, add class 'no-title'
		 */
		$classes .= empty( $widget_title ) || 'true' === $settings['socplug_widget_hide_title'] ? ' no-title' : '';

		/**
		 * Redirect rules
		 */
		$redirect_rules = $settings['socplug_redirect_rules'];
		$redirect       = '';

		if ( 'custom_url' === $redirect_rules && ! empty( $settings['socplug_redirect_url'] ) ) {
			$redirect = $settings['socplug_redirect_url'];
		} elseif ( 'account' === $redirect_rules ) {
			$redirect = admin_url( 'profile.php' );
		}

		/**
		 * Echo widget template
		 */
		echo '<div class="social-connect-main dynamic-style ' . esc_attr( $classes ) . '">';
		echo '<div class="social-connect-main-wrapper">';
		echo '<div class="social-connect-main-header">';

		/**
		 * Heading
		 */
		if (
			( $user->userId === 0 && ! empty( $widget_title ) )
			||
			( $user->userId !== 0 && ! empty( $widget_title ) && $settings['socplug_widget_hide_title'] !== 'yes' )
		) {
			echo '<h2 class="social-connect-main-heading">' . esc_textarea( $widget_title ) . '</h2>';
		}

		/**
		 * Profile picture
		 */
		if ( $user->userHasConnected && 'yes' === $settings['socplug_show_profile_picture'] ) {
			$user_avatar = $user->getSocplugAvatar();
			if ( $user_avatar ) {
				echo '<img src="' . esc_url( $user_avatar ) . '" alt="User Avatar" height="53" width="53" class="social-connect-main-avatar">';
			}
		}

		/**
		 * Subheading
		 */
		$widget_subtitle = '';

		if ( ! empty( $settings['socplug_widget_connected_users_title'] ) && $user->userHasConnected ) {
			$widget_subtitle = socplugUsercodesReplace( $settings['socplug_widget_connected_users_title'] );
		} elseif ( ! empty( $settings['socplug_widget_unconnected_user_title'] ) && ! $user->userHasConnected ) {
			$widget_subtitle = $settings['socplug_widget_unconnected_user_title'];
		}

		if ( ! empty( $widget_subtitle ) ) {
			echo '<h3 class="social-connect-main-subheading">' . esc_textarea( $widget_subtitle ) . '</h3>';
		}

		echo '</div>';

		if ( $user->userHasConnected ) {
			/**
			 * Link to account
			 */
			echo '<div class="social-connect-main-account-link">';
			echo '<a href="' . esc_url( admin_url( 'profile.php' ) ) . '">' . esc_textarea( $settings['socplug_widget_account_link_text'] ) . '</a>';
			echo '</div>';
		} else {
			/**
			 * Buttons
			 */
			$networks_order = explode( '_', $settings['socplug_networks_order'] );
			echo '<div class="social-connect-main-buttons">';
			echo wp_kses_post( socplugGetButtons( $networks_order, $settings['socplug_icon_design'], $redirect ) );
			echo '</div>';
		}

		echo '</div>';

		/**
		 * End widget template
		 */
		echo '</div>';
	}
}
