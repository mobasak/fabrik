<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SC_Elementor_Social_Buttons extends \Elementor\Widget_Base {


	public function get_name(): string {
		return 'social_login_buttons';
	}

	public function get_title(): string {
		return esc_html__( 'Social Login Buttons', 'social-connect-pys' );
	}

	public function get_icon(): string {
		return 'eicon-social-icons';
	}

	public function get_categories(): array {
		return array( 'social-connect' );
	}

	public function get_keywords(): array {
		return array( 'social connect', 'pixel your site' );
	}

	public function get_custom_help_url(): string {
		return 'https://pixelyoursite.com';
	}

	protected function register_controls(): void {

		/**
		 * Content Section
		 */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		/**
		 * Control Text Above Buttons
		 */
		$this->add_control(
			'socplug_text_above_buttons',
			array(
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'label'       => esc_html__( 'Text above buttons', 'social-connect-pys' ),
				'label_block' => true,
				'default'     => esc_html__( 'Continue with your social network for a smoother experience', 'social-connect-pys' ),
				'placeholder' => esc_html__( 'Continue with your social network for a smoother experience', 'social-connect-pys' ),
			)
		);

		/**
		 * Control Icon Design
		 */
		$this->add_control(
			'socplug_icon_design',
			array(
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Select icon design', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'base'                  => __( 'Square color', 'social-connect-pys' ),
					'monochrome'            => __( 'Square monochrome', 'social-connect-pys' ),
					'circle'                => __( 'Circle color', 'social-connect-pys' ),
					'circle_monochrome'     => __( 'Circle monochrome', 'social-connect-pys' ),
					'big'                   => __( 'Square color (big)', 'social-connect-pys' ),
					'big_monochrome'        => __( 'Square monochrome (big)', 'social-connect-pys' ),
					'circle_big'            => __( 'Circle color (big)', 'social-connect-pys' ),
					'circle_big_monochrome' => __( 'Circle monochrome (big)', 'social-connect-pys' ),
					'full'                  => __( 'Wide color', 'social-connect-pys' ),
					'short'                 => __( 'Wide color (no text)', 'social-connect-pys' ),
				),
				'default'     => 'base',
			)
		);

		/**
		 * Control Order network
		 */
		$this->add_control(
			'socplug_networks_order',
			array(
				'type'        => \Elementor\Controls_Manager::SELECT,
				'label'       => esc_html__( 'Select order of networks', 'social-connect-pys' ),
				'label_block' => true,
				'options'     => array(
					'facebook_google' => __( 'Facebook - Google', 'social-connect-pys' ),
					'google_facebook' => __( 'Google - Facebook', 'social-connect-pys' ),
				),
				'default'     => 'facebook_google',
			)
		);

		$this->end_controls_section();

		/**
		 * Typography Section
		 */
		$this->start_controls_section(
			'typography_section',
			array(
				'label' => esc_html__( 'Typography', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'label'    => esc_html__( 'Text above buttons typography', 'social-connect-pys' ),
				'name'     => 'socplug_text_above_buttons_typography',
				'selector' => '{{WRAPPER}} .social-connect-wc h4',
			)
		);

		$this->add_control(
			'socplug_text_above_buttons_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Text above buttons color', 'social-connect-pys' ),
				'default'   => '#2f2f2f',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-wc h4' => 'color: {{VALUE}}',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Section styles
		 */
		$this->start_controls_section(
			'section_style',
			array(
				'label' => esc_html__( 'Section Styles', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Text align
		 */
		$this->add_control(
			'socplug_text_align',
			array(
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'label'     => esc_html__( 'Text Align', 'social-connect-pys' ),
				'options'   => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'social-connect-pys' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'social-connect-pys' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'social-connect-pys' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'center',
				'toggle'    => true,
				'selectors' => array(
					'{{WRAPPER}} .social-connect-wc' => 'text-align: {{VALUE}};',
				),
			)
		);

		/**
		 * Section Background Color
		 */
		$this->add_control(
			'socplug_bg_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Background color', 'social-connect-pys' ),
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-wc' => 'background-color: {{VALUE}};',
				),
			)
		);

		/**
		 * Section Border type / size / color
		 */
		$this->add_control(
			'socplug_border_type',
			array(
				'label'     => esc_html__( 'Border Type', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'options'   => array(
					'none'   => esc_html__( 'None', 'social-connect-pys' ),
					'solid'  => esc_html__( 'Solid', 'social-connect-pys' ),
					'dashed' => esc_html__( 'Dashed', 'social-connect-pys' ),
					'dotted' => esc_html__( 'Dotted', 'social-connect-pys' ),
					'double' => esc_html__( 'Double', 'social-connect-pys' ),
				),
				'default'   => 'none',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-wc' => 'border-style: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'socplug_border_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Border Color', 'social-connect-pys' ),
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .social-connect-wc' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'socplug_border_width',
			array(
				'label'      => esc_html__( 'Border Width', 'social-connect-pys' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .social-connect-wc' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Buttons styles
		 */
		$this->start_controls_section(
			'buttons_style',
			array(
				'label' => esc_html__( 'Buttons Styles', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Buttons background color
		 */
		$this->add_control(
			'socplug_buttons_bg_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Buttons background color', 'social-connect-pys' ),
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .network-login-btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		/**
		 * Buttons border type
		 */
		$this->add_control(
			'socplug_buttons_border_type',
			array(
				'label'     => esc_html__( 'Buttons border type', 'social-connect-pys' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'options'   => array(
					'none'   => esc_html__( 'None', 'social-connect-pys' ),
					'solid'  => esc_html__( 'Solid', 'social-connect-pys' ),
					'dashed' => esc_html__( 'Dashed', 'social-connect-pys' ),
					'dotted' => esc_html__( 'Dotted', 'social-connect-pys' ),
					'double' => esc_html__( 'Double', 'social-connect-pys' ),
				),
				'default'   => 'solid',
				'selectors' => array(
					'{{WRAPPER}} .network-login-btn' => 'border-style: {{VALUE}};',
				),
			)
		);

		/**
		 * Buttons border color
		 */
		$this->add_control(
			'socplug_buttons_border_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Buttons border color', 'social-connect-pys' ),
				'default'   => '#f0f0f1',
				'selectors' => array(
					'{{WRAPPER}} .network-login-btn' => 'border-color: {{VALUE}};',
				),
			)
		);

		/**
		 * Buttons border width
		 */
		$this->add_responsive_control(
			'socplug_buttons_border_width',
			array(
				'label'      => esc_html__( 'Buttons border width', 'social-connect-pys' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .network-login-btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'default'    => array(
					'top'    => '1px',
					'right'  => '1px',
					'bottom' => '1px',
					'left'   => '1px',
				),
			)
		);

		/**
		 * Buttons border radius
		 */
		$this->add_control(
			'socplug_buttons_border_radius',
			array(
				'label'      => esc_html__( 'Buttons border radius', 'social-connect-pys' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .network-login-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'default'    => array(
					'top'    => '0px',
					'right'  => '0px',
					'bottom' => '0px',
					'left'   => '0px',
				),
			)
		);

		/**
		 * Buttons padding
		 */
		$this->add_responsive_control(
			'socplug_buttons_padding',
			array(
				'label'      => esc_html__( 'Buttons padding', 'social-connect-pys' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .network-login-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'default'    => array(
					'top'    => '8px',
					'right'  => '8px',
					'bottom' => '8px',
					'left'   => '8px',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Buttons text styles
		 */
		$this->start_controls_section(
			'buttons_text_style',
			array(
				'label' => esc_html__( 'Buttons Text Styles', 'social-connect-pys' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		/**
		 * Buttons text typography
		 */
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'label'    => esc_html__( 'Buttons typography', 'social-connect-pys' ),
				'name'     => 'socplug_buttons_typography',
				'selector' => '{{WRAPPER}} .network-login-btn span.full-text , {{WRAPPER}} .network-login-btn span.short-text',
			)
		);

		/**
		 * Buttons text color
		 */
		$this->add_control(
			'socplug_buttons_color',
			array(
				'type'      => \Elementor\Controls_Manager::COLOR,
				'label'     => esc_html__( 'Buttons color', 'social-connect-pys' ),
				'default'   => '#252a31',
				'selectors' => array(
					'{{WRAPPER}} .network-login-btn span.full-text , {{WRAPPER}} .network-login-btn span.short-text' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		/**
		 * Check if builder mode
		 */
		$builder = false;
		$user    = new SC_User();

		if ( \Elementor\Plugin::instance()->editor->is_edit_mode() ) {
			$builder = true;
		}

		/**
		 * Dont show widget if user is logged in, except builder mode
		 */
		if ( ! $builder && is_user_logged_in() && $user->userHasConnected ) {
			return;
		}

		$settings = $this->get_settings_for_display();

		/**
		 * Widget Title
		 */
		$text_above_buttons = $settings['socplug_text_above_buttons'];

		/**
		 * Networks order
		 */
		$networks_order = $settings['socplug_networks_order'];
		$networks_order = explode( '_', $networks_order );

		/**
		 * Echo widget template
		 */
		echo '<div class="social-connect-wc">';

		if ( ! empty( $text_above_buttons ) ) {
			echo wp_kses_post( '<h4>' . $text_above_buttons . '</h4>' );
		}

		/**
		 * Buttons
		 */
		echo '<div class="social-connect-wc-buttons">';
		echo '<div class="social-connect-wc-buttons-wrapper">';
		echo wp_kses_post( socplugGetButtons( $networks_order, $settings['socplug_icon_design'] ) );
		echo '</div>';
		echo '</div>';

		/**
		 * End widget template
		 */
		echo '</div>';

		socplugAddCustomAssets( array( 'social-connect-wc' ), array() );
	}
}
