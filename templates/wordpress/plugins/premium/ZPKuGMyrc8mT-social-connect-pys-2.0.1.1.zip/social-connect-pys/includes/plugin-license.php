<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Include license class
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-plugin-license.php';

/**
 * Include updater class
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-plugin-updater.php';

/**
 * Add cron event to check the license
 */
if ( ! wp_next_scheduled( 'social_connect_license_check_event' ) ) {
	wp_schedule_event( time(), 'daily', 'social_connect_license_check_event' );
}

/**
 * Hooks to check license
 */
add_action( 'social_connect_license_check_event', 'socialConnectLicenseCheckDaily', 0 );
function socialConnectLicenseCheckDaily() {
	$license = new SC_Plugin_License();
	$license->cronCheckLicense();
}

/**
 * Update Plugin
 */
add_action( 'admin_init', 'socplugUpdatePlugin', 0 );
function socplugUpdatePlugin() {
	$license      = new SC_Plugin_License();
	$license_data = $license->getLicenseData();

	if ( ! empty( $license_data['license_key'] ) && 'valid' === $license_data['license_status'] ) {
		$updater = new SC_Plugin_Updater(
			PYS_SOCIAL_CONNECT_STORE_URL,
			PYS_SOCIAL_CONNECT_PLUGIN_FILE,
			array(
				'version'   => PYS_SOCIAL_CONNECT_VERSION,
				'license'   => $license_data['license_key'],
				'item_name' => PYS_SOCIAL_CONNECT_ITEM_NAME,
				'author'    => 'PixelYourSite',
			)
		);
		$updater->init();
	}
}

/**
 * Deactivate license ajax action
 */
add_action( 'wp_ajax_socplugDeactivateLicenseAjax', 'socplugDeactivateLicenseAjax' );
add_action( 'wp_ajax_nopriv_socplugDeactivateLicenseAjax', 'socplugDeactivateLicenseAjax' );
function socplugDeactivateLicenseAjax() {
	$license = new SC_Plugin_License();

	/**
	 * Check if license key is set
	 */
	$license_key = $license->getLicenseData();
	if ( empty( $license_key['license_key'] ) ) {
		wp_send_json_success(
			array(
				'success' => false,
				'message' => 'License key not found',
			)
		);
	}

	/**
	 * Try to deactivate license
	 */
	$deactivate_status = $license->deactivateLicense();
	if ( ! empty( $deactivate_status['success'] ) && $deactivate_status['success'] ) {
		wp_send_json_success( $deactivate_status );
	}

	/**
	 * Return error
	 */
	wp_send_json_error( $deactivate_status );
}

/**
 * Activate license ajax action
 */
add_action( 'wp_ajax_socplugActivateLicenseAjax', 'socplugActivateLicenseAjax' );
add_action( 'wp_ajax_nopriv_socplugActivateLicenseAjax', 'socplugActivateLicenseAjax' );
function socplugActivateLicenseAjax() {

	$license_key = $_POST['license_key'] ?? '';
	if ( empty( $license_key ) ) {
		wp_send_json_error( 'License key not found' );
	}

	$license         = new SC_Plugin_License();
	$activate_status = $license->activateLicense( $license_key );

	/**
	 * Check results
	 */
	if ( ! empty( $activate_status['success'] ) && $activate_status['success'] ) {
		wp_send_json_success( $activate_status );
	}

	wp_send_json_error( $activate_status );
}
