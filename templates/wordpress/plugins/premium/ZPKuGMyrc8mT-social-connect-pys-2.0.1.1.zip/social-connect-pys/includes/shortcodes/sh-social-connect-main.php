<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_shortcode( 'social-connect-main', 'socialConnectMainShortcode' );

function socialConnectMainShortcode() {
	$options = get_option( 'socplug_widget' );
	$user    = new SC_User();
	$user_id = $user->userId;
	$classes = '';

	/**
	 * Check if user is authenticated and not connected then hide the widget
	 * Except if the user not admin
	 */
	if ( 0 !== $user_id && ! $user->userHasConnected && ! current_user_can( 'manage_options' ) ) {
		return '';
	}

	/**
	 * If user is connected, add class 'user-connected'
	 */
	$classes .= $user->userHasConnected ? ' user-connected' : '';

	/**
	 * If title is empty or hide, add class 'no-title'
	 */
	$classes .= empty( $options['title'] ) || $options['title_hide'] == 'true' ? ' no-title' : '';

	$html  = '<div class="social-connect-main dynamic-style ' . $classes . '">';
	$html .= '<div class="social-connect-main-wrapper">';
	$html .= '<div class="social-connect-main-header">';

	/**
	 * Redirect rules
	 */
	$redirect_rules = $options['redirect_rules'] ?? 'samepage';
	$redirect       = '';

	if ( 'custom_url' === $redirect_rules && ! empty( $options['custom_url'] ) ) {
		$redirect = $options['custom_url'];
	} elseif ( 'account' === $redirect_rules ) {
		$redirect = admin_url( 'profile.php' );
	}

	/**
	 * Heading
	 */
	if ( ! empty( $options['title'] ) && ( $user_id == 0 || ( $user_id !== 0 && $options['title_hide'] == 'false' ) ) ) {
		$html .= '<h2 class="social-connect-main-heading">' . esc_textarea( $options['title'] ) . '</h2>';
	}

	if ( $user->userHasConnected && $options['profile_picture'] == 'true' ) {
		$user_avatar = $user->getSocplugAvatar();
		if ( $user_avatar ) {
			$html .= '<img src="' . $user_avatar . '" alt="User Avatar" height="53" width="53" class="social-connect-main-avatar">';
		}
	}

	/**
	 * Subheading
	 */
	if ( $user_id == 0 && ! empty( $options['text_loggedout'] ) ) {
		$html .= '<h3 class="social-connect-main-subheading">' . esc_textarea( $options['text_loggedout'] ) . '</h3>';
	} elseif ( $user_id !== 0 && ! empty( $options['text_loggedin'] ) ) {
		$text  = socplugUsercodesReplace( $options['text_loggedin'] );
		$html .= '<h3 class="social-connect-main-subheading">' . esc_textarea( $text ) . '</h3>';
	}

	$html .= '</div>';

	if ( $user->userHasConnected ) {
		/**
		 * Link to account
		 */
		$html .= '<div class="social-connect-main-account-link">';
		$html .= '<a href="' . admin_url( 'profile.php' ) . '">' . esc_textarea( $options['text_accountlink'] ) . '</a>';
		$html .= '</div>';
	} else {
		/**
		 * Buttons
		 */
		$html .= '<div class="social-connect-main-buttons">';
		$html .= socplugGetButtons( $options['network_priority'], $options['buttons_style'], $redirect );
		
		$html .= '</div>';
	}

	$html .= '</div>';

	/**
	 * Generate dynamic style for the widget
	 */
	$html .= socplugGenerateDynamicStyleMainWidget( $options );
	$html .= '</div>';

	/**
	 * Enqueue scripts
	 */
	socplugAddCustomAssets( array( 'social-connect-main' ), array( 'social-connect-login-buttons' ) );

	return $html;
}

/**
 * Generate dynamic style for the widget
 */
function socplugGenerateDynamicStyleMainWidget( $options ) {
	$style = '<style>';

	/**
	 * Section
	 */
	$style .= '.dynamic-style.social-connect-main {';
	if ( ! empty( $options['background'] ) ) {
		$style .= 'background-color: ' . $options['background'] . ';';
	}
	$style .= 'border-width: ' . $options['border_size'] . 'px;';
	$style .= 'border-style: ' . $options['border_type'] . ';';
	$style .= 'border-color: ' . $options['border_color'] . ';';
	$style .= '}';

	/**
	 * Heading
	 */
	$style .= '.dynamic-style .social-connect-main-heading {';
	if ( ! empty( $options['main_font_color'] ) ) {
		$style .= 'color: ' . $options['main_font_color'] . ';';
	}
	if ( ! empty( $options['main_font_size'] ) ) {
		$style .= 'font-size: ' . $options['main_font_size'] . 'px;';
	}
	$style .= '}';

	/**
	 * Subheading and text
	 */
	$style .= '.dynamic-style .social-connect-main-subheading, .dynamic-style .social-connect-main {';
	if ( ! empty( $options['font_color'] ) ) {
		$style .= 'color: ' . $options['font_color'] . ';';
	}
	if ( ! empty( $options['font_size'] ) ) {
		$style .= 'font-size: ' . $options['font_size'] . 'px;';
	}
	$style .= '}';

	/**
	 * Buttons
	 */
	$style .= '.dynamic-style .network-login-btn {';
	$style .= 'border-width: ' . $options['icon_border_size'] . 'px;';
	$style .= 'border-style: ' . $options['icon_border_type'] . ';';
	$style .= 'border-color: ' . $options['icon_border_color'] . ';';
	$style .= '}';

	$style .= '</style>';

	return $style;
}
