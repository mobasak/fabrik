<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Social login shortcode
 *
 * @param array $atts The attributes of the shortcode.
 *
 * @return string The html of the social login form.
 */
function socplugLoginFormShortcode( $atts ) {
	/**
	 * Get session variable page_now
	 */
	$session_page_now = isset( $_SESSION['page_now'] )
	? sanitize_text_field( wp_unslash( $_SESSION['page_now'] ) )
	: false;

	/**
	 * Check if user is logged
	 */
	if ( is_user_logged_in() && ! $session_page_now ) {
		return '';
	}

	/**
	 * Get options
	 */
	$social_connect       = new SC_Social_Connect();
	$login_form_options   = $social_connect->getLoginFormOptions();
	$main_buttons_options = $social_connect->getMainButtonsOptions();

	$redirect_to = '';

	/**
	 * Set base redirect rules
	 */
	if ( isset( $atts['redirect'] ) && ! empty( $atts['redirect'] ) ) {
		$redirect_to = get_admin_url();

		if ( 'account' === $atts['redirect'] ) {
			$redirect_to = get_edit_user_link();
		}

		if ( 'custom' === $atts['redirect'] && ! empty( $login_form_options['custom_url'] ) ) {
			$redirect_to = $login_form_options['custom_url'];
		}
	}

	/**
	 * Check redirect rules in attributes
	 */
	$form_layout = $login_form_options['buttons_display'];

	/**
	 * Start building html
	 */
	$html = '<div class="socplug-login-form dynamic-style form-layout-' . $form_layout . '">';

	/**
	 * Form heading
	 */
	$html .= '<div class="socplug-login-form-heading">';
	$html .= '<h2>' . __( 'Login to the website', 'social-connect-pys' ) . '</h2>';
	$html .= '<h3>' . __( 'With your favorite social service', 'social-connect-pys' ) . '</h3>';
	$html .= '</div>';

	/**
	 * Form content
	 */
	$html .= '<div class="socplug-login-form-content">';

	/**
	 * Remember me for vertical layout
	 */
	$html .= '<div class="socplug-login-form-remember socplug-login-form-remember-vertical">';
	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_remember_me_vertical',
			'class'    => 'socplug-login-form-remember-checkbox',
			'id'       => 'socplug_remember_me_vertical',
			'label'    => __( 'Remember me', 'social-connect-pys' ),
			'selected' => 'true',
		)
	);
	$html .= '</div>';

	/**
	 * Social buttons
	 */
	$html .= '<div class="socplug-login-form-social">';
	$html .= '<h3>' . __( 'With your favorite social service', 'social-connect-pys' ) . '</h3>';

	/**
	 * Social buttons
	 */
	$html .= '<div class="socplug-login-form-social-buttons">';
	$html .= socplugGetButtons( $main_buttons_options['order'], $login_form_options['buttons_style'], $redirect_to );
	$html .= '</div>';

	$html .= '</div>';

	/**
	 * Divider
	 */
	$html .= '<div class="socplug-login-form-divider">';
	/**
	 * Vertical divider
	 */
	$html .= '<span class="socplug-login-form-divider-vertical"><span class="divider-text">' . __( 'or continue with', 'social-connect-pys' ) . '</span></span>';

	/**
	 * Horizontal divider
	 */
	$html .= '<span class="socplug-login-form-divider-horizontal"><span class="divider-text">' . __( 'or', 'social-connect-pys' ) . '</span></span>';
	$html .= '</div>';

	/**
	 * Base login form
	 */
	$html .= '<div class="socplug-login-form-login">';
	$html .= '<h3>' . __( 'With your credentials', 'social-connect-pys' ) . '</h3>';

	$html .= '<div class="socplug-login-form-base">';
	$html .= wp_login_form(
		array(
			'echo'              => false,
			'redirect'          => $redirect_to,
			'form_id'           => 'socplug-login-form',
			'label_username'    => __( '', 'social-connect-pys' ),
			'label_password'    => __( '', 'social-connect-pys' ),
			'label_remember'    => __( 'Remember Me', 'social-connect-pys' ),
			'label_log_in'      => __( 'Log In', 'social-connect-pys' ),
			'id_username'       => 'user_login',
			'id_password'       => 'user_pass',
			'id_remember'       => 'rememberme',
			'id_submit'         => 'wp-submit',
			'remember'          => true,
			'value_remember'    => true,
			'required_username' => true,
			'required_password' => true,
		)
	);
	$html .= '</div>';

	/**
	 * Remember me for horizontal layout
	 */
	$html .= '<div class="socplug-login-form-remember socplug-login-form-remember-horizontal">';
	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_remember_me_horizontal',
			'class'    => 'socplug-login-form-remember-checkbox',
			'id'       => 'socplug_remember_me_horizontal',
			'label'    => __( 'Remember me', 'social-connect-pys' ),
			'selected' => 'true',
		)
	);
	$html .= '</div>';

	$html .= '</div>';

	$html .= '</div>';

	/**
	 * Generate Dynamic styles
	 */
	$html .= socplugGenerateDynamicStylesLoginForm( $login_form_options );

	$html .= '</div>';

	socplugAddCustomAssets( array( 'social-connect-login-form' ), array( 'social-connect-login-form', 'social-connect-login-buttons' ) );

	return $html;
}

/**
 * Add nonce field to the custom login form
 */
add_filter(
	'login_form_bottom',
	function ( $content, $args ) {
		if ( $args['form_id'] === 'socplug-login-form' ) {
			$content .= wp_nonce_field( 'socplug_login_action', '_socplug_nonce', true, false );
		}
		return $content;
	},
	10,
	2
);
add_shortcode( 'social-login', 'socplugLoginFormShortcode' );


/**
 * Handle login form submit
 */
add_action( 'wp_ajax_socplugLoginFormSubmit', 'socplugLoginFormSubmit' );
add_action( 'wp_ajax_nopriv_socplugLoginFormSubmit', 'socplugLoginFormSubmit' );
function socplugLoginFormSubmit() {
	$data = $_POST;

	if ( ! isset( $data['_socplug_nonce'] ) || ! wp_verify_nonce( $data['_socplug_nonce'], 'socplug_login_action' ) ) {
		wp_send_json_error( array( 'message' => 'Invalid request. Please try later.' ) );
	}

	/**
	 * Get email and password
	 */
	$email    = isset( $data['log'] ) ? $data['log'] : '';
	$password = isset( $data['pwd'] ) ? $data['pwd'] : '';

	if ( empty( $password ) || empty( $email ) ) {
		wp_send_json_error( array( 'message' => 'Email or password is empty' ) );
	}

	/**
	 * Check email format
	 */
	$email = sanitize_email( $email );
	if ( empty( $email ) || ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => 'Email is not valid' ) );
	}

	/**
	 * Check password format
	 */
	if ( strlen( $password ) < 8 ) {
		wp_send_json_error( array( 'message' => 'Password must be at least 8 characters long' ) );
	}

	/**
	 * Check if user exists
	 */
	$user = get_user_by( 'email', $email );
	if ( ! $user ) {
		wp_send_json_error( array( 'message' => 'User with this email not found' ) );
	}

	/**
	 * Check if password is correct
	 */
	if ( ! wp_check_password( $password, $user->user_pass, $user->ID ) ) {
		wp_send_json_error( array( 'message' => 'Password is incorrect' ) );
	}

	/**
	 * Log in user
	 */
	wp_set_current_user( $user->ID );
	wp_set_auth_cookie( $user->ID );

	/**
	 * Redirect to the page, which was set in the redirect_to parameter
	 */

	if ( ! isset( $data['redirect_to'] ) || empty( $data['redirect_to'] ) ) {
		$data['redirect_to'] = get_admin_url();
	}

	wp_send_json_success(
		array(
			'message'  => 'Successfully, please wait redirecting...',
			'redirect' => $data['redirect_to'],
		)
	);
}

function socplugGenerateDynamicStylesLoginForm( $options ) {
	$style = '<style>';

	/**
	 * Section
	 */
	$style .= '.dynamic-style.socplug-login-form {';
	if ( ! empty( $options['background'] ) ) {
		$style .= 'background-color: ' . $options['background'] . ';';
	}
	$style .= '}';

	/**
	 * Divider bg
	 */
	$style .= '.dynamic-style.socplug-login-form .divider-text {';
	if ( ! empty( $options['background'] ) ) {
		$style .= 'background-color: ' . $options['background'] . ';';
	}
	$style .= '}';

	/**
	 * Heading
	 */
	$style .= '.dynamic-style .socplug-login-form-heading h2 {';
	if ( ! empty( $options['heading_font_color'] ) ) {
		$style .= 'color: ' . $options['heading_font_color'] . ';';
	}
	if ( ! empty( $options['heading_font_size'] ) ) {
		$style .= 'font-size: ' . $options['heading_font_size'] . 'px;';
	}
	$style .= '}';

	/**
	 * Subheading and text
	 */
	$style .= '.dynamic-style .socplug-login-form-heading h3, .dynamic-style .socplug-login-form-content h3 {';
	if ( ! empty( $options['text_font_color'] ) ) {
		$style .= 'color: ' . $options['text_font_color'] . ';';
	}
	if ( ! empty( $options['text_font_size'] ) ) {
		$style .= 'font-size: ' . $options['text_font_size'] . 'px;';
	}
	$style .= '}';

	/**
	 * Buttons
	 */
	$style .= '.dynamic-style .network-login-btn {';
	$style .= 'border-width: ' . $options['border_size'] . 'px;';
	$style .= 'border-style: ' . $options['border_type'] . ';';
	$style .= 'border-color: ' . $options['border_color'] . ';';
	$style .= '}';

	$style .= '</style>';

	return $style;
}
