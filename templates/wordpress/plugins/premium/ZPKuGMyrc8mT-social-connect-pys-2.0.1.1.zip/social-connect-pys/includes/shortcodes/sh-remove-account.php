<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add shortcode for the page user can delete his account
 *
 * @return string The HTML of the page.
 */
function socplugRemoveAccountPage(): string {
	/**
	 * Enqueue form script
	 */
	socplugAddCustomAssets( array( 'social-connect-remove-account' ), array( 'social-connect-remove-account' ) );
	$privacy_settings = get_option( 'socplug_privacy' );

	if ( ! is_user_logged_in() ) {
		$not_logged_in_text = $privacy_settings['remove_account_not_logged_in']
		?? __( 'You need to be logged in to delete your account', 'social-connect-pys' );
		return '<p class="socplug_center">' . $not_logged_in_text . '</p>';
	}

	/**
	 * Verify form submit
	 */
	if ( isset( $_POST['form_type'] ) ) {
		$verify = socplugVerifyDeletingFormSubmit( array( 'admin', 'one_user', 'have_provider' ) );
		if ( $verify ) {
			return $verify;
		}
	}

	$data = array(
		'form_type'         => 'remove_account',
		'form_title'        => $privacy_settings['remove_account_text'],
		'button_text'       => $privacy_settings['remove_account_button_text'],
		'confirmation'      => $privacy_settings['remove_account_confirmation'],
		'confirmation_text' => $privacy_settings['remove_account_confirmation_text'],
	);

	return socplugGetDeleteForm( $data );
}

add_shortcode( 'socplug-remove-account', 'socplugRemoveAccountPage' );
