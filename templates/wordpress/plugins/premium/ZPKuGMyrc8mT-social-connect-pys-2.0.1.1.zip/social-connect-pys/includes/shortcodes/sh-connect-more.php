<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_shortcode( 'social-connect-more', 'socialConnectMoreShortcode' );

function socialConnectMoreShortcode() {
	$user_id              = $_SESSION['connectmore_user_id'] ?? null;
	$social_connect       = new SC_Social_Connect();
	$user                 = new SC_User( $user_id );
	$connect_more_options = $social_connect->getConnectMoreOptions();
	$main_buttons_options = $social_connect->getMainButtonsOptions();

	/**
	 * Html structure
	 */
	$html  = '<div class="social-connect-more">';
	$html .= '<div class="social-connect-more-header">';

	/**
	 * Show connect more title
	 */
	if ( ! empty( $connect_more_options['text_title'] ) ) {
		$html .= '<h2>' . $connect_more_options['text_title'] . '</h2>';
	}

	/**
	 * If user has connected, show connected accounts
	 */
	if ( $user->userHasConnected ) {
		$connected_providers = $user->getUserConnectedProviders();

		/**
		 * Show connect more text
		 */
		if ( ! empty( $connect_more_options['text_connected'] ) ) {
			$html .= '<p class="social-connect-more-connected-text">' . $connect_more_options['text_connected'] . '</p>';
		}

		$html .= '<div class="social-connect-more-connected-account">';

		/**
		 * Connected accounts table
		 */
		$html .= '<table>';
		$html .= '<tr>
                    <th>' . __( 'Provider', 'social-connect-pys' ) . '</th>
                    <th>' . __( 'Account', 'social-connect-pys' ) . '</th>
                    <th>' . __( 'Last Login', 'social-connect-pys' ) . '</th>
                    <th>' . __( 'Action', 'social-connect-pys' ) . '</th>
                  </tr>';

		foreach ( $connected_providers as $provider ) {
			$user_provider_name       = $user->getUserProviderName( $provider );
			$user_provider_last_login = $user->getUserProviderLastLogin( $provider );
			$html                    .= '<tr data-provider="' . $provider . '">';
			$html                    .= '<td>' . socplugGetNetworkLoginBtn( $provider, $main_buttons_options['style'] ) . '</td>';
			$html                    .= '<td>' . $user_provider_name . '</td>';
			$html                    .= '<td>' . date( 'd.m.Y, H:i', $user_provider_last_login ) . '</td>';
			$html                    .= '<td><a href="#" class="socplug-disconnect-provider" data-provider="' . $provider . '">' . __( 'Disconnect', 'social-connect-pys' ) . '</a></td>';
			$html                    .= '</tr>';
		}

		$html .= '</table>';
		$html .= '</div>';
		$html .= '</div>';
	}

	/**
	 * Show other providers which user can connect if he has not connected any yet
	 */
	$available_providers = $social_connect->getActiveProviders();
	$available_providers = array_keys( $available_providers );

	/**
	 * Remove connected providers from other which user can connect
	 */
	if ( $user->userHasConnected ) {
		$available_providers = array_diff( $available_providers, $connected_providers );
	}

	if ( count( $available_providers ) > 0 ) {

		/**
		 * Show connect more text
		 */
		if ( ! empty( $connect_more_options['text_connectmore'] ) ) {
			$html .= '<p class="social-connect-more-connectmore-text">' . $connect_more_options['text_connectmore'] . '</p>';
		}

		$html .= '<div class="social-connect-more-available">';
		foreach ( $available_providers as $provider ) {
			$html .= socplugGetNetworkLoginBtn( $provider, $main_buttons_options['style'] );
		}
		$html .= '</div>';
	}

	$html .= '</div>';
	$html .= '</div>';

	/**
	 * Enqueue scripts
	 */
	socplugAddCustomAssets( array( 'social-connect-main' ), array( 'social-connect-more', 'social-connect-login-buttons' ) );

	return $html;
}
