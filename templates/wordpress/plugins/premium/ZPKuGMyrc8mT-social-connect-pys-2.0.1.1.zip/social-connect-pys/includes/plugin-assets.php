<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Third party scripts version
 */
define( 'PYS_SOCIAL_CONNECT_SCRIPTS_VERSION', '1.0.0' );

/**
 * Admin settings scripts
 */
if (
	! empty( $_GET['page'] )
	&& (
		$_GET['page'] === 'socplugAdminSettingsPage'
		|| $_GET['page'] === 'socplugAdminLicensePage'
		|| $_GET['page'] === 'socplugAdminLogsPage'
	)
) {
	add_action( 'admin_enqueue_scripts', 'socplugAdminSettingsScripts' );
}
function socplugAdminSettingsScripts() {
	/**
	 * Main styles
	 */
	wp_enqueue_style( 'socplug-admin-css', PYS_SOCIAL_CONNECT_URL . '/assets/css/admin.min.css', array(), PYS_SOCIAL_CONNECT_VERSION );
	wp_enqueue_style( 'social-connect-main', PYS_SOCIAL_CONNECT_URL . '/assets/css/social-connect-main.min.css', array(), PYS_SOCIAL_CONNECT_VERSION );

	/**
	 * Chart js
	 */
	wp_enqueue_script( 'socplug-chart-js', PYS_SOCIAL_CONNECT_URL . '/assets/js/chart-js/chart.min.js', array(), PYS_SOCIAL_CONNECT_SCRIPTS_VERSION, true );

	/**
	 * Pickr color picker
	 */
	wp_enqueue_style( 'socplug-picker-css', PYS_SOCIAL_CONNECT_URL . '/assets/css/pickr-nano.min.css', array(), PYS_SOCIAL_CONNECT_SCRIPTS_VERSION );
	wp_enqueue_script( 'socplug-picker-js', PYS_SOCIAL_CONNECT_URL . '/assets/js/pickr/pickr.min.js', array(), PYS_SOCIAL_CONNECT_SCRIPTS_VERSION, true );

	/**
	 * JQuery UI Core and Sortable
	 */
	wp_enqueue_script( 'jquery-ui-core' );
	wp_enqueue_script( 'jquery-ui-sortable' );

	/**
	 * Touch punch || for mobile devices
	 */
	wp_enqueue_script( 'socplug-touch-punch-js', PYS_SOCIAL_CONNECT_URL . '/assets/js/jquery-ui-touch.min.js', array( 'jquery' ), PYS_SOCIAL_CONNECT_SCRIPTS_VERSION, true );

	/**
	 * Custom scripts
	 */
	wp_enqueue_script( 'socplug-admin-js', PYS_SOCIAL_CONNECT_URL . '/assets/js/admin.min.js', array( 'jquery', 'jquery-ui-core', 'jquery-ui-sortable', 'socplug-chart-js', 'socplug-picker-js' ), PYS_SOCIAL_CONNECT_VERSION, true );
	wp_localize_script( 'socplug-admin-js', 'socplug', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );

	/**
	 * Assets for preview button
	 */
	socplugAddCustomAssets( array( 'social-connect-login-form', 'social-connect-main' ), array( 'social-connect-login-form' ) );
}

/**
 * Add custom assets
 *
 * @param array $styles
 * @param array $scripts
 * @return void
 */
function socplugAddCustomAssets( $styles = array(), $scripts = array() ) {
	/**
	 * Styles
	 */
	if ( ! empty( $styles ) ) {
		foreach ( $styles as $style ) {
			if ( ! wp_style_is( $style . '-css', 'enqueued' ) ) {
				wp_enqueue_style( $style . '-css', PYS_SOCIAL_CONNECT_URL . '/assets/css/' . $style . '.min.css', array(), PYS_SOCIAL_CONNECT_VERSION );
			}
		}
	}

	/**
	 * Scripts
	 */
	if ( ! empty( $scripts ) ) {
		foreach ( $scripts as $script ) {
			if ( ! wp_script_is( $script . '-js', 'enqueued' ) ) {
				wp_enqueue_script( $script . '-js', PYS_SOCIAL_CONNECT_URL . '/assets/js/' . $script . '.min.js', array( 'jquery' ), PYS_SOCIAL_CONNECT_VERSION, true );
				wp_localize_script( $script . '-js', 'socplug', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
			}
		}
	}
}
