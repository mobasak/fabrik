<?php

/**
 * Settings box for locations
 */
function socplugSettingsBoxLocations() {
	$locations = array(
		'comments' => array(
			'option' => get_option( 'socplug_main_form_comments' ),
			'label'  => __( 'Comments', 'social-connect-pys' ),
		),
		'register' => array(
			'option' => get_option( 'socplug_main_form_register' ),
			'label'  => __( 'Register form', 'social-connect-pys' ),
		),
		'login'    => array(
			'option' => get_option( 'socplug_main_form_login' ),
			'label'  => __( 'Login form', 'social-connect-pys' ),
		),
	);

	$position_options = array(
		'inside_bottom'  => __( 'Inside the form, bottom (default)', 'social-connect-pys' ),
		'inside_top'     => __( 'Inside the form, top', 'social-connect-pys' ),
		'outside_top'    => __( 'Above the register/login form', 'social-connect-pys' ),
		'outside_bottom' => __( 'Below the form', 'social-connect-pys' ),
	);

	$html = '';

	foreach ( $locations as $key => $location ) {
		$html .= '<div class="locations-row">';

		/**
		 * Checkbox
		 */
		$html .= socplugGetFormElCheckbox(
			array(
				'name'     => "socplug_main_form_{$key}[enable]",
				'id'       => "socplug_main_form_{$key}_enable",
				'selected' => $location['option']['enable'],
				'label'    => $location['label'],
			)
		);

		/**
		 * Radio group
		 */
		$radio_options = array();
		foreach ( $position_options as $value => $label ) {
			$radio_options[] = array(
				'name'     => "socplug_main_form_{$key}[position]",
				'value'    => $value,
				'label'    => $label,
				'id'       => "socplug_main_form_{$key}_position_{$value}",
				'selected' => $location['option']['position'],
			);
		}

		$html .= socplugGetFormElRadioGroup(
			array(
				'radio' => $radio_options,
			)
		);

		/**
		 * Remove from last element
		 */
		if ( $key !== 'login' ) {
			$html .= socplugGetCustomHr();
		}

		$html .= '</div>';
	}

	return $html;
}

/**
 * Settings box for custom text
 */
function socplugSettingsBoxCustomText() {
	$custom_text = get_option( 'socplug_main_form_custom_text' );

	$html              = '<div class="custom-text-row">';
	$html             .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_main_form_custom_text[login][enable]',
			'id'       => 'socplug_main_form_custom_text_login_enable',
			'selected' => $custom_text['login']['enable'],
			'label'    => __( 'Text before the Login Form:', 'social-connect-pys' ),
		)
	);
	$login_custom_text = stripslashes( $custom_text['login']['text'] );
	$html             .= '<textarea class="custom-textarea" name="socplug_main_form_custom_text[login][text]" id="socplug_main_form_custom_text_login_text" rows="5" placeholder="' . __( 'Continue with your favorite social network for a smoother experience:', 'social-connect-pys' ) . '">' . $login_custom_text . '</textarea>';
	$html             .= '</div>';

	$html                .= '<div class="custom-text-row">';
	$html                .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_main_form_custom_text[register][enable]',
			'id'       => 'socplug_main_form_custom_text_register_enable',
			'selected' => $custom_text['register']['enable'],
			'label'    => __( 'Text before the Register Form:', 'social-connect-pys' ),
		)
	);
	$register_custom_text = stripslashes( $custom_text['register']['text'] );
	$html                .= '<textarea class="custom-textarea" name="socplug_main_form_custom_text[register][text]" id="socplug_main_form_custom_text_register_text" rows="5" placeholder="' . __( 'Register with your favorite social network for a smoother experience:', 'social-connect-pys' ) . '">' . $register_custom_text . '</textarea>';
	$html                .= '</div>';

	$comment_custom_text = stripslashes( $custom_text['comments']['text'] );
	$html               .= '<div class="custom-text-row">';
	$html               .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_main_form_custom_text[comments][enable]',
			'id'       => 'socplug_main_form_custom_text_comments_enable',
			'selected' => $custom_text['comments']['enable'],
			'label'    => __( 'Text before the Comments Form:', 'social-connect-pys' ),
		)
	);
	$html               .= '<textarea class="custom-textarea" name="socplug_main_form_custom_text[comments][text]" id="socplug_main_form_custom_text_comments_text" rows="5" placeholder="' . __( 'Comment with your favorite social network for a smoother experience:', 'social-connect-pys' ) . '">' . $comment_custom_text . '</textarea>';
	$html               .= '</div>';

	return $html;
}

/**
 * Settings box for design
 */
function socplugSettingsBoxDesign() {
	$buttons = get_option( 'socplug_main_buttons' );

	/**
	 * Select design
	 */
	$html = socplugGetFormElButtonsDesignAndPreview(
		array(
			'label'    => 'Select icon design',
			'name'     => 'socplug_main_buttons[style]',
			'id'       => 'socplug_main_buttons_style',
			'class'    => 'big-select',
			'selected' => $buttons['style'],
		),
		$buttons['order']
	);

	$html .= socplugGetCustomHr();

	/**
	 * Network order
	 */
	$html .= '<div class="network-order">';
	$html .= '<div for="socplug_main_buttons_order" class="network-order-heading">' . __( 'Network order', 'social-connect-pys' ) . '</div>';
	$html .= '<div class="settings-help-text">' . __( 'Drag to reorder', 'social-connect-pys' ) . '</div>';
	$html .= '<div class="network-order-list">';
	if ( ! empty( $buttons['order'] ) && is_array( $buttons['order'] ) ) {
		foreach ( $buttons['order'] as $network_order_value ) {
			$html .= '<div class="network_logo order-item corner-radius ' . $network_order_value . '">';
			$html .= '<input id="socplug_main_buttons_order" type="hidden" name="socplug_main_buttons[order][]" value="' . $network_order_value . '"/>';
			$icon  = socplugGetIconmoonIcon( strtolower( $network_order_value ) );
			$html .= '<span class="iconmoon network-icon network-icon-' . $network_order_value . '">' . $icon . '</span>';
			$html .= '</div>';
		}
	}

	$html .= '</div>';
	$html .= '</div>';

	return $html;
}

/**
 * Settings box for admin bar visibility
 */
function socplugSettingsBoxAdminBarVisibility() {
	$show_admin_bar = get_option( 'socplug_main_show_admin_bar' );

	$html = '<div class="settings-help-text">' . __( 'Control the visibility of the WordPress top bar for logged-in social users - all user roles except Admins.', 'social-connect-pys' ) . '</div>';

	/**
	 * Radio group
	 */
	$html .= socplugGetFormElRadioGroup(
		array(
			'radio' => array(
				array(
					'name'     => 'socplug_main_show_admin_bar',
					'value'    => 'true',
					'label'    => __( 'Show', 'social-connect-pys' ),
					'id'       => 'socplug_main_show_admin_bar_true',
					'selected' => $show_admin_bar,
				),
				array(
					'name'     => 'socplug_main_show_admin_bar',
					'value'    => 'false',
					'label'    => __( 'Hide', 'social-connect-pys' ),
					'id'       => 'socplug_main_show_admin_bar_false',
					'selected' => $show_admin_bar,
				),
			),
		)
	);

	return $html;
}

/**
 * Settings box for store the Meta login ID
 */
function socplugSettingsBoxStoreTheMetaLoginId() {
	$facebook_settings = get_option( 'socplug_settings_facebook' );

	$html  = '<div class="settings-help-text">';
	$html .= __( 'If you store the Meta login ID, PixelYourSite can use send this value with the Meta CAPI events, leading to an improve EMQ score and better ads conversion and tracking.', 'social-connect-pys' );
	$html .= '</div>';

	$html .= '<div class="checkbox-group">';

	$checkbox_options = array(
		array(
			'name'     => 'socplug_settings_facebook[enable]',
			'id'       => 'socplug_settings_facebook_enable',
			'selected' => $facebook_settings['enable'],
			'label'    => __( 'Store the Meta login ID.', 'social-connect-pys' ),
		),
		array(
			'name'     => 'socplug_settings_facebook[privacy]',
			'id'       => 'socplug_settings_facebook_privacy',
			'selected' => $facebook_settings['privacy'],
			'label'    => __( 'Enable privacy opinions on the user\'s account.', 'social-connect-pys' ),
		),
		array(
			'name'     => 'socplug_settings_facebook[allow_track]',
			'id'       => 'socplug_settings_facebook_allow_track',
			'selected' => $facebook_settings['allow_track'],
			'label'    => __( 'Allow us use this value to improve tracking and measurement', 'social-connect-pys' ),
		),
	);

	foreach ( $checkbox_options as $option ) {
		$html .= socplugGetFormElCheckbox( $option );
	}

	$html .= '</div>';

	return $html;
}

/**
 * Settings box for connect more accounts
 */
function socplugSettingsBoxConnectMoreAccounts() {
	$connectmore = get_option( 'socplug_connectmore' );
	$disabled    = ( $connectmore['enabled'] == 'false' ? 'disabled-fields' : '' );

	/**
	 * Enable switcher
	 */
	$html = socplugGetFormElToggle(
		array(
			'name'     => 'socplug_connectmore[enabled]',
			'id'       => 'socplug_connectmore_enabled',
			'selected' => $connectmore['enabled'],
			'label'    => __( 'Enable', 'social-connect-pys' ),
			'class'    => 'second connect_more_switcher',
		)
	);

	$html .= '<div class="settings-help-text ' . $disabled . '">' . __( 'You can use this option to enable support for users to connect additional social accounts', 'social-connect-pys' ) . '</div>';

	/**
	 * Checkbox group
	 */
	$html .= '<div class="checkbox-group ' . $disabled . '">';

	$html .= '<div class="custom-text-row">';
	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_connectmore[show_wp]',
			'id'       => 'socplug_connectmore_show_wp',
			'selected' => $connectmore['show_wp'],
			'label'    => __( 'Show in WordPress account', 'social-connect-pys' ),
			'disabled' => $disabled,
		)
	);
	$html .= '</div>';

	if ( class_exists( 'WooCommerce' ) ) {
		$html .= '<div class="custom-text-row">';
		$html .= socplugGetFormElCheckbox(
			array(
				'name'     => 'socplug_connectmore[show_wc]',
				'id'       => 'socplug_connectmore_show_wc',
				'selected' => $connectmore['show_wc'],
				'label'    => __( 'Show in WooCommerce client account', 'social-connect-pys' ),
				'disabled' => $disabled,
			)
		);
		$html .= '</div>';
	}

	$html .= '</div>';

	/**
	 * Inputs
	 */
	$html .= '<div class="field-row ' . $disabled . '">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => __( 'Title', 'social-connect-pys' ),
			'name'        => 'socplug_connectmore[text_title]',
			'id'          => 'socplug_connectmore_text_title',
			'value'       => $connectmore['text_title'],
			'placeholder' => __( 'Social Login Account', 'social-connect-pys' ),
			'attr'        => ( $disabled ? 'disabled' : '' ),
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row ' . $disabled . '">';

	$html .= socplugGetFormElInputText(
		array(
			'label'       => __( 'Text above connected networks', 'social-connect-pys' ),
			'name'        => 'socplug_connectmore[text_connected]',
			'id'          => 'socplug_connectmore_text_connected',
			'value'       => $connectmore['text_connected'],
			'placeholder' => __( 'Your account is connected to the following social networks', 'social-connect-pys' ),
			'attr'        => ( $disabled ? 'disabled' : '' ),
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row ' . $disabled . '">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => __( 'Text above connect more networks', 'social-connect-pys' ),
			'name'        => 'socplug_connectmore[text_connectmore]',
			'id'          => 'socplug_connectmore_text_connectmore',
			'value'       => $connectmore['text_connectmore'],
			'placeholder' => __( 'You can connect your account to the following networks:', 'social-connect-pys' ),
			'attr'        => ( $disabled ? 'disabled' : '' ),
		)
	);
	$html .= '</div>';

	return $html;
}

/**
 * Settings box for social widget
 */
function socplugSettingsBoxSocialWidget() {
	$socplug_widget = get_option( 'socplug_widget' );

	/**
	 * Helper text
	 */
	$html = '<div class="settings-help-text">' . __( 'You can use it in the WordPress widget section, or by adding this shortcode:', 'social-connect-pys' ) . ' <strong>[social-connect-main]</strong></div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => __( 'Widget title', 'social-connect-pys' ),
			'name'        => 'socplug_widget[title]',
			'id'          => 'socplug_widget_title',
			'value'       => $socplug_widget['title'],
			'placeholder' => __( 'Connect with us', 'social-connect-pys' ),
		)
	);
	$html .= '</div>';

	$html .= '<div class="custom-text-row">';
	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_widget[title_hide]',
			'id'       => 'socplug_widget_title_hide',
			'selected' => $socplug_widget['title_hide'],
			'label'    => __( 'Hide widget title for logged in users', 'social-connect-pys' ),
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => __( 'Unconnected users text', 'social-connect-pys' ),
			'name'        => 'socplug_widget[text_loggedout]',
			'id'          => 'socplug_widget_text_loggedout',
			'value'       => $socplug_widget['text_loggedout'],
			'placeholder' => __( 'Login with your social account:', 'social-connect-pys' ),
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => __( 'Social connected users text', 'social-connect-pys' ),
			'name'        => 'socplug_widget[text_loggedin]',
			'id'          => 'socplug_widget_text_loggedin',
			'value'       => $socplug_widget['text_loggedin'],
			'placeholder' => __( 'Hey, [first_name]', 'social-connect-pys' ),
			'help_text'   => __( 'Personalize the message by using special tags like [first_name], [last_name], [user_email] and [full_name] for a more relatable message', 'social-connect-pys' ),
			'class'       => 'small',
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => __( 'Account link text', 'social-connect-pys' ),
			'name'        => 'socplug_widget[text_accountlink]',
			'id'          => 'socplug_widget_text_accountlink',
			'value'       => $socplug_widget['text_accountlink'],
			'placeholder' => __( 'Go to your account', 'social-connect-pys' ),
		)
	);
	$html .= '</div>';

	$html .= socplugGetCustomHr();

	$html .= '<div class="network-order-heading">' . __( 'Redirect rules', 'social-connect-pys' ) . '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElRadioGroup(
		array(
			'radio' => array(
				array(
					'name'     => 'socplug_widget[redirect_rules]',
					'value'    => 'account',
					'label'    => 'Redirect to WordPress account',
					'id'       => 'socplug_widget_redirect_rules_account',
					'selected' => $socplug_widget['redirect_rules'] ?? 'samepage',
				),
				array(
					'name'     => 'socplug_widget[redirect_rules]',
					'value'    => 'custom_url',
					'label'    => 'Redirect to Custom Url',
					'id'       => 'socplug_widget_redirect_rules_custom_url',
					'selected' => $socplug_widget['redirect_rules'] ?? 'samepage',
				),
				array(
					'name'     => 'socplug_widget[redirect_rules]',
					'value'    => 'samepage',
					'label'    => 'Stay on the same page',
					'id'       => 'socplug_widget_redirect_rules_same_page',
					'selected' => $socplug_widget['redirect_rules'] ?? 'samepage',
				),
			),
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => __( 'Custom Redirect URL', 'social-connect-pys' ),
			'name'        => 'socplug_widget[custom_url]',
			'id'          => 'socplug_widget_custom_url',
			'value'       => $socplug_widget['custom_url'] ?? '',
			'placeholder' => __( 'https://example.com', 'social-connect-pys' ),
		)
	);
	$html .= '</div>';

	$html .= socplugGetCustomHr();

	/**
	 * Styles
	 */
	$html .= socplugSettingsBoxSocialWidgetStyles( $socplug_widget );

	/**
	 * Select design
	 */
	$html .= socplugGetFormElButtonsDesignAndPreview(
		array(
			'label'    => 'Select icon design',
			'name'     => 'socplug_widget[buttons_style]',
			'id'       => 'socplug_widget_buttons_style',
			'class'    => 'big-select',
			'selected' => $socplug_widget['buttons_style'],
		),
		$socplug_widget['network_priority']
	);

	/**
	 * Styles row
	 */
	$html .= '<div class="styles-row">';

	/**
	 * Icon Border type
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Icon Border type',
			'name'     => 'socplug_widget[icon_border_type]',
			'id'       => 'socplug_widget_icon_border_type',
			'class'    => 'big-select',
			'options'  => socplugBorderTypes(),
			'selected' => $socplug_widget['icon_border_type'],
		)
	);
	$html .= '</div>';

	/**
	 * Icon Border color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Icon Border color',
			'name'  => 'socplug_widget[icon_border_color]',
			'id'    => 'socplug_widget_icon_border_color',
			'value' => $socplug_widget['icon_border_color'],
		)
	);
	$html .= '</div>';

	/**
	 * Icon Border size
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Icon Border size',
			'name'     => 'socplug_widget[icon_border_size]',
			'id'       => 'socplug_widget_icon_border_size',
			'class'    => 'small-select',
			'type'     => 'number',
			'from'     => 0,
			'to'       => 20,
			'step'     => 1,
			'selected' => $socplug_widget['icon_border_size'],
		)
	);
	$html .= '</div>';

	/**
	 * End Styles row
	 */
	$html .= '</div>';

	$html .= '<div class="preview-socplug-design socplug-button-filled socplug-blue-button icon-preview" data-preview="social-connect-main">' . __( 'Preview Social Widget', 'social-connect-pys' ) . '</div>';

	/**
	 * Profile pictures
	 */
	$html .= socplugGetCustomHr();
	$html .= '<div class="network-order-heading">' . __( 'Profile Picture', 'social-connect-pys' ) . '</div>';

	$html .= '<div class="profile-pictures-wrapper">';
	$html .= socplugGetFormElToggle(
		array(
			'name'     => 'socplug_widget[profile_picture]',
			'id'       => 'socplug_widget_profile_picture',
			'selected' => $socplug_widget['profile_picture'],
			'class'    => 'second',
			'label'    => __( 'Enable', 'social-connect-pys' ),
		)
	);
	$html .= '<div class="settings-help-text">' . __( 'Use a profile picture in the social widget', 'social-connect-pys' ) . '</div>';
	$html .= '</div>';

	$html .= '<div class="network-order">';
	$html .= '<div class="field-row">';
	$html .= '<div class="network-order-heading">' . __( 'Priority', 'social-connect-pys' ) . '</div>';
	$html .= '<div class="settings-help-text">' . __( 'Drag & Drop the social service icons to change their priority (this applies when the user account is connected to more than one network)', 'social-connect-pys' ) . '</div>';
	$html .= '</div>';
	$html .= '<div class="network-order-list">';

	if ( ! empty( $socplug_widget['network_priority'] ) && is_array( $socplug_widget['network_priority'] ) ) {
		foreach ( $socplug_widget['network_priority'] as $network_order_value ) {
			$html .= '<div class="network_logo order-item corner-radius ' . $network_order_value . '">';
			$html .= '<input id="socplug_widget_network_priority" type="hidden" name="socplug_widget[network_priority][]" value="' . $network_order_value . '"/>';
			$icon  = socplugGetIconmoonIcon( strtolower( $network_order_value ) );
			$html .= '<span class="iconmoon network-icon network-icon-' . $network_order_value . '">' . $icon . '</span>';
			$html .= '</div>';
		}
	}

	$html .= '</div>';
	$html .= '</div>';

	return $html;
}

function socplugSettingsBoxSocialWidgetStyles( $socplug_widget ) {
	/**
	 * Section Styles
	 */
	$html = '<div class="styles-row">';

	/**
	 * Background color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Background color',
			'name'  => 'socplug_widget[background]',
			'id'    => 'socplug_widget_background',
			'value' => $socplug_widget['background'],
		)
	);
	$html .= '</div>';

	/**
	 * Background border type
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Background Border type',
			'name'     => 'socplug_widget[border_type]',
			'id'       => 'socplug_widget_border_type',
			'class'    => 'big-select',
			'options'  => socplugBorderTypes(),
			'selected' => $socplug_widget['border_type'],
		)
	);
	$html .= '</div>';

	/**
	 * Background border color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Background Border color',
			'name'  => 'socplug_widget[border_color]',
			'id'    => 'socplug_widget_border_color',
			'value' => $socplug_widget['border_color'],
		)
	);
	$html .= '</div>';

	/**
	 * Background border size
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Border size',
			'name'     => 'socplug_widget[border_size]',
			'id'       => 'socplug_widget_border_size',
			'class'    => 'small-select',
			'type'     => 'number',
			'from'     => 0,
			'to'       => 20,
			'step'     => 1,
			'selected' => $socplug_widget['border_size'],
		)
	);
	$html .= '</div>';

	/**
	 * End Styles row
	 */
	$html .= '</div>';

	/**
	 * Styles row
	 */
	$html .= '<div class="styles-row">';

	/**
	 * Main font color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Main font color',
			'name'  => 'socplug_widget[main_font_color]',
			'id'    => 'socplug_widget_main_font_color',
			'value' => $socplug_widget['main_font_color'],
		)
	);
	$html .= '</div>';

	/**
	 * Main font size
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Main font size',
			'name'     => 'socplug_widget[main_font_size]',
			'id'       => 'socplug_widget_main_font_size',
			'class'    => 'small-select',
			'type'     => 'number',
			'from'     => 16,
			'to'       => 56,
			'step'     => 2,
			'selected' => $socplug_widget['main_font_size'],
		)
	);
	$html .= '</div>';

	/**
	 * Font color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Font color',
			'name'  => 'socplug_widget[font_color]',
			'id'    => 'socplug_widget_font_color',
			'value' => $socplug_widget['font_color'],
		)
	);
	$html .= '</div>';

	/**
	 * Font size
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Font size',
			'name'     => 'socplug_widget[font_size]',
			'id'       => 'socplug_widget_font_size',
			'class'    => 'small-select',
			'type'     => 'number',
			'from'     => 12,
			'to'       => 36,
			'step'     => 2,
			'selected' => $socplug_widget['font_size'],
		)
	);
	$html .= '</div>';

	/**
	 * End Styles row
	 */
	$html .= '</div>';

	return $html;
}

function socplugSettingsBoxPrivacy() {
	$privacy_settings = get_option( 'socplug_privacy' );

	$html  = '<div class="settings-help-text">';
	$html .= __( 'In order to fully use Facebook authorization, you will need to go through Facebook authentication. Described in paragraph 11, when setting up Facebook.', 'social-connect-pys' );
	$html .= '<br>';
	$html .= __( 'One of the items is a link to a page where you can delete your data. For this, you can use the following shortcodes:', 'social-connect-pys' );
	$html .= '</div>';

	$html .= '<div class="network-order-heading">' . __( 'Remove Account', 'social-connect-pys' ) . '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_privacy_remove_account_not_logged_in">' . __( 'Text to display when user is not logged in', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_privacy[remove_account_not_logged_in]',
			'id'          => 'socplug_privacy_remove_account_not_logged_in',
			'placeholder' => __( 'You need to be logged in to delete your account', 'social-connect-pys' ),
			'value'       => $privacy_settings['remove_account_not_logged_in'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_privacy_remove_account_text">' . __( 'Text to display on the remove account page', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_privacy[remove_account_text]',
			'id'          => 'socplug_privacy_remove_account_text',
			'placeholder' => __( 'Are you sure you want to delete your account? This action is irreversible.', 'social-connect-pys' ),
			'value'       => $privacy_settings['remove_account_text'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_privacy_remove_account_button_text">' . __( 'Button text', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElInputText(
		array(
			'name'        => 'socplug_privacy[remove_account_button_text]',
			'id'          => 'socplug_privacy_remove_account_button_text',
			'placeholder' => __( 'Delete my account', 'social-connect-pys' ),
			'value'       => $privacy_settings['remove_account_button_text'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_privacy[remove_account_confirmation]',
			'id'       => 'socplug_privacy_remove_account_confirmation',
			'value'    => $privacy_settings['remove_account_confirmation'],
			'label'    => __( 'Enable delete account confirmation', 'social-connect-pys' ),
			'selected' => $privacy_settings['remove_account_confirmation'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_privacy_remove_account_confirmation_text">' . __( 'Confirmation text', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_privacy[remove_account_confirmation_text]',
			'id'          => 'socplug_privacy_remove_account_confirmation_text',
			'placeholder' => __( 'I confirm that I want to delete my account', 'social-connect-pys' ),
			'value'       => $privacy_settings['remove_account_confirmation_text'],
		)
	);
	$html .= '</div>';

	$html .= socplugGetCustomHr();

	$html .= '<div class="network-order-heading">' . __( 'Remove Data', 'social-connect-pys' ) . '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_privacy_remove_data_not_logged_in">' . __( 'Text to display when user is not logged in', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_privacy[remove_data_not_logged_in]',
			'id'          => 'socplug_privacy_remove_data_not_logged_in',
			'placeholder' => __( 'You need to be logged in to delete your account', 'social-connect-pys' ),
			'value'       => $privacy_settings['remove_data_not_logged_in'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_privacy_remove_data_text">' . __( 'Text to display on the remove data page', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_privacy[remove_data_text]',
			'id'          => 'socplug_privacy_remove_data_text',
			'placeholder' => __( 'Are you sure you want to delete your account? This action is irreversible.', 'social-connect-pys' ),
			'value'       => $privacy_settings['remove_data_text'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_privacy_remove_account_button_text">' . __( 'Button text', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElInputText(
		array(
			'name'        => 'socplug_privacy[remove_data_button_text]',
			'id'          => 'socplug_privacy_remove_data_button_text',
			'placeholder' => __( 'Remove data', 'social-connect-pys' ),
			'value'       => $privacy_settings['remove_data_button_text'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_privacy[remove_data_confirmation]',
			'id'       => 'socplug_privacy_remove_data_confirmation',
			'value'    => $privacy_settings['remove_data_confirmation'],
			'label'    => __( 'Enable delete data confirmation', 'social-connect-pys' ),
			'selected' => $privacy_settings['remove_data_confirmation'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_privacy_remove_data_confirmation_text">' . __( 'Confirmation text', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_privacy[remove_data_confirmation_text]',
			'id'          => 'socplug_privacy_remove_data_confirmation_text',
			'placeholder' => __( 'I confirm that I want to delete my data', 'social-connect-pys' ),
			'value'       => $privacy_settings['remove_data_confirmation_text'],
		)
	);
	$html .= '</div>';

	$html .= socplugGetCustomHr();

	$html .= '<div class="settings-help-text">' . __( 'You can use the following shortcodes to display the remove account and remove data pages:', 'social-connect-pys' ) . '</div>';
	$html .= '<div class="settings-help-text">' . __( '<b>[socplug-remove-account]</b> - to completely delete an account', 'social-connect-pys' ) . '</div>';
	$html .= '<div class="settings-help-text">' . __( '<b>[socplug-remove-data]</b> - to remove the connection between your account and Facebook', 'social-connect-pys' ) . '</div>';

	return $html;
}

function socplugSettingsBoxDefaultSettings() {
	$html  = '<div class="settings-help-text">';
	$html .= __( 'Here you can reset the plugin settings to default or delete all plugin data from users.', 'social-connect-pys' );
	$html .= '<br>';
	$html .= __( 'Select the option you want to do.', 'social-connect-pys' );
	$html .= '</div>';

	$settings = array(
		'location'                      => __( 'Reset to default locations settings', 'social-connect-pys' ),
		'res_socplug_main_form_custom_text' => __( 'Reset to default custom text settings', 'social-connect-pys' ),
		'res_socplug_main_buttons'          => __( 'Reset to default design settings', 'social-connect-pys' ),
		'res_socplug_widget'                => __( 'Reset to default social widget settings', 'social-connect-pys' ),
		'res_socplug_shortcode_loginform'   => __( 'Reset to default login form shortcode settings', 'social-connect-pys' ),
		'res_socplug_connectmore'           => __( 'Reset to default connect more accounts settings', 'social-connect-pys' ),
		'res_socplug_settings_facebook'     => __( 'Reset to default store the meta login id settings', 'social-connect-pys' ),
		'res_socplug_main_show_admin_bar'   => __( 'Reset to default admin bar visibility settings', 'social-connect-pys' ),
		'res_socplug_privacy'               => __( 'Reset to default privacy settings', 'social-connect-pys' ),
	);

	if ( class_exists( 'WooCommerce' ) ) {
		$settings['woocommerce_display']  = __( 'Reset to default WooCommerce Display settings', 'social-connect-pys' );
		$settings['woocommerce_discount'] = __( 'Reset to default WooCommerce Social Login Discount settings', 'social-connect-pys' );
	}

	/**
	 * Delete all plugin data from users
	 */
	$settings['delete_all_plugin_data'] = __( 'Delete all plugin data from users', 'social-connect-pys' );

	$html .= '<div class="checkbox-group">';
	foreach ( $settings as $key => $label ) {
		$html .= '<div class="field-row">';
		$html .= socplugGetFormElCheckbox(
			array(
				'name'     => $key,
				'id'       => $key,
				'value'    => $key,
				'label'    => $label,
				'selected' => false,
			)
		);
		$html .= '</div>';
	}
	$html .= '</div>';

	$html .= '<div class="settings-help-text">';
	$html .= __( 'This action is irreversible.', 'social-connect-pys' );
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= '<a class="socplug-button-filled socplug-red-button" data-nonce="' . wp_create_nonce( 'socplug_reset_default_settings' ) . '" id="socplug_reset_default_settings">' . __( 'Reset', 'social-connect-pys' ) . '</a>';
	$html .= '</div>';

	return $html;
}

/**
 * Settings box for login form shortcode
 */
function socplugSettingsBoxLoginFormShortcode() {
	/**
	 * Get options for the social login form shortcode
	 * */
	$shortcode_loginform = get_option( 'socplug_shortcode_loginform' );

	$html  = '<div class="settings-help-text">';
	$html .= __(
		'You can use the [social-login] shortcode to include a social login form in any page of your website, with both a regular and social login functionality included.<br> 
                       You can use this shortcode to redirect the user after logging in either to user\'s account section or a custom link, by copying the appropriate version of the shortcode below.',
		'social-connect-pys'
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => 'No redirect form',
			'name'        => 'socplug_shortcode_loginform[redirect_none]',
			'id'          => 'socplug_shortcode_loginform_redirect_none',
			'value'       => '[social-login]',
			'placeholder' => '[social-login]',
			'attr'        => 'disabled',
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => 'Redirect to account',
			'name'        => 'socplug_shortcode_loginform[redirect_account]',
			'id'          => 'socplug_shortcode_loginform_redirect_account',
			'value'       => "[social-login redirect='account']",
			'placeholder' => "[social-login redirect='account']",
			'attr'        => 'disabled',
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => 'Redirect to custom URL',
			'name'        => 'socplug_shortcode_loginform[redirect_custom]',
			'id'          => 'socplug_shortcode_loginform_redirect_custom',
			'value'       => "[social-login redirect='custom']",
			'placeholder' => "[social-login redirect='custom']",
			'attr'        => 'disabled',
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputText(
		array(
			'label'       => 'Custom URL',
			'name'        => 'socplug_shortcode_loginform[custom_url]',
			'id'          => 'socplug_shortcode_loginform_custom_url',
			'value'       => $shortcode_loginform['custom_url'],
			'placeholder' => 'https://www.example.com',
		)
	);
	$html .= '</div>';

	$html .= socplugGetCustomHr();

	$html .= '<div class="network-order-heading">' . __( 'Display', 'social-connect-pys' ) . '</div>';
	$html .= socplugGetFormElRadioGroup(
		array(
			'radio' => array(
				array(
					'name'     => 'socplug_shortcode_loginform[buttons_display]',
					'value'    => 'vertical',
					'label'    => 'Vertical display',
					'id'       => 'socplug_shortcode_loginform_buttons_display_vertical',
					'selected' => $shortcode_loginform['buttons_display'],
				),
				array(
					'name'     => 'socplug_shortcode_loginform[buttons_display]',
					'value'    => 'horizontal',
					'label'    => 'Horizontal display',
					'id'       => 'socplug_shortcode_loginform_buttons_display_horizontal',
					'selected' => $shortcode_loginform['buttons_display'],
				),
			),
		)
	);

	/**
	 * Styles row
	 */
	$html .= socplugSettingsBoxLoginFormShortcodeStyles( $shortcode_loginform );

	/**
	 * Select design
	 */
	$html .= socplugGetFormElButtonsDesignAndPreview(
		array(
			'label'    => 'Select icon design',
			'name'     => 'socplug_shortcode_loginform[buttons_style]',
			'id'       => 'socplug_shortcode_loginform_buttons_style',
			'class'    => 'big-select',
			'selected' => $shortcode_loginform['buttons_style'],
		)
	);

	$html .= '<div class="styles-row">';

	/**
	 * Icon Border type
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Border type',
			'name'     => 'socplug_shortcode_loginform[border_type]',
			'id'       => 'socplug_shortcode_loginform_border_type',
			'class'    => 'big-select',
			'options'  => socplugBorderTypes(),
			'selected' => $shortcode_loginform['border_type'],
		)
	);
	$html .= '</div>';

	/**
	 * Icon Border color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Border color',
			'name'  => 'socplug_shortcode_loginform[border_color]',
			'id'    => 'socplug_shortcode_loginform_border_color',
			'value' => $shortcode_loginform['border_color'],
		)
	);
	$html .= '</div>';

	/**
	 * Icon Border size
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Border size',
			'name'     => 'socplug_shortcode_loginform[border_size]',
			'id'       => 'socplug_shortcode_loginform_border_size',
			'class'    => 'small-select',
			'type'     => 'number',
			'from'     => 0,
			'to'       => 20,
			'step'     => 1,
			'selected' => $shortcode_loginform['border_size'],
		)
	);
	$html .= '</div>';

	/**
	 * End Styles row
	 */
	$html .= '</div>';

	$html .= '<div class="preview-socplug-design socplug-button-filled socplug-blue-button icon-preview" data-preview="social-login">' . sprintf( __( 'Preview %s display', 'social-connect-pys' ), $shortcode_loginform['buttons_display'] ) . '</div>';

	return $html;
}

function socplugSettingsBoxLoginFormShortcodeStyles( $shortcode_loginform ) {

	$html = '<div class="styles-row">';

	/**
	 * Background color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Background color',
			'name'  => 'socplug_shortcode_loginform[background]',
			'id'    => 'socplug_shortcode_loginform_background',
			'value' => $shortcode_loginform['background'],
		)
	);
	$html .= '</div>';

	/**
	 * Heading font color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Heading font color',
			'name'  => 'socplug_shortcode_loginform[heading_font_color]',
			'id'    => 'socplug_shortcode_loginform_heading_font_color',
			'value' => $shortcode_loginform['heading_font_color'],
		)
	);
	$html .= '</div>';

	/**
	 * Heading font size
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Heading font size',
			'name'     => 'socplug_shortcode_loginform[heading_font_size]',
			'id'       => 'socplug_shortcode_loginform_heading_font_size',
			'class'    => 'small-select',
			'type'     => 'number',
			'from'     => 16,
			'to'       => 48,
			'step'     => 2,
			'selected' => $shortcode_loginform['heading_font_size'],
		)
	);
	$html .= '</div>';

	/**
	 * Text font color
	 */
	$html .= '<div class="field-row style-item">';
	$html .= socplugGetFormElColorPicker(
		array(
			'label' => 'Text font color',
			'name'  => 'socplug_shortcode_loginform[text_font_color]',
			'id'    => 'socplug_shortcode_loginform_text_font_color',
			'value' => $shortcode_loginform['text_font_color'],
		)
	);
	$html .= '</div>';

	/**
	 * Text font size
	 */
	$html .= '<div class="style-item select-design">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Text font size',
			'name'     => 'socplug_shortcode_loginform[text_font_size]',
			'id'       => 'socplug_shortcode_loginform_text_font_size',
			'class'    => 'small-select',
			'type'     => 'number',
			'from'     => 8,
			'to'       => 30,
			'step'     => 2,
			'selected' => $shortcode_loginform['text_font_size'],
		)
	);
	$html .= '</div>';

	/**
	 * End Styles row
	 */
	$html .= '</div>';

	return $html;
}


function socplugSettingsBoxSocialLoginDiscount() {
	$coupon_settings = get_option( 'socplug_social_login_discount' );

	/**
	 * Switch to enable/disable the social login coupon
	 */
	$html  = '<div class="field-row">';
	$html .= socplugGetFormElToggle(
		array(
			'name'     => 'socplug_social_login_discount[enable]',
			'id'       => 'socplug_social_login_discount_enable',
			'selected' => $coupon_settings['enable'],
			'class'    => 'second',
			'label'    => __( 'Enable', 'social-connect-pys' ),
		)
	);

	$html .= '<div class="settings-help-text">' . __( 'This Social Coupon will be applied each time a user is using the social login. You can select any WooCommerce coupon.', 'social-connect-pys' ) . '</div>';
	$html .= '</div>';

	$html .= socplugSettingsBoxSocialLoginDisountCouponSelect( $coupon_settings );

	$html .= socplugGetCustomHr();
	$html .= '<div class="network-order-heading">' . __( 'Additional Coupon Settings', 'social-connect-pys' ) . '</div>';

	/**
	 * Checkbox group
	 */
	$html .= '<div class="checkbox-group">';
	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_social_login_discount[not_show_if_used]',
			'id'       => 'socplug_social_login_discount_not_show_if_used',
			'label'    => __( 'Try not to show the offer to user that used it already', 'social-connect-pys' ),
			'selected' => $coupon_settings['not_show_if_used'],
		)
	);

	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_social_login_discount[dont_show_if_used]',
			'id'       => 'socplug_social_login_discount_dont_show_if_used',
			'label'    => __( 'Don\'t offer the discount for users that used it already', 'social-connect-pys' ),
			'selected' => $coupon_settings['dont_show_if_used'],
		)
	);
	$html .= '</div>';

	$html .= socplugGetCustomHr();
	$html .= '<div class="network-order-heading">' . __( 'Social Discount Use Limit', 'social-connect-pys' ) . '</div>';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElInputNumber(
		array(
			'label' => 'Number of times the discount can be applied',
			'name'  => 'socplug_social_login_discount[limit]',
			'id'    => 'socplug_social_login_discount_limit',
			'value' => $coupon_settings['limit'],
		)
	);
	$html .= '</div>';

	$html .= socplugGetCustomHr();
	$html .= '<div class="network-order-heading">' . __( 'Text', 'social-connect-pys' ) . '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_social_login_discount_text_before_login">' . __( 'Before login', 'social-connect-pys' ) . '</label>';
	$html .= '<div class="settings-help-text">' . __( 'Enter the message that will be shown to a customer, encouraging him to use social login to get a get a discount. <br> E.g. "Continue with your favourite social network and you get a 20% discount."', 'social-connect-pys' ) . '</div>';
	$html .= '</div>';

	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_social_login_discount[text_before_login]',
			'id'          => 'socplug_social_login_discount_text_before_login',
			'placeholder' => __( 'Continue with your social profile for a XX% discount', 'social-connect-pys' ),
			'value'       => $coupon_settings['text_before_login'],
		)
	);

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_social_login_discount_text_after_login">' . __( 'After login', 'social-connect-pys' ) . '</label>';
	$html .= '<div class="settings-help-text">' . __( 'Enter the message that will be shown to a customer, when he had successfully used a social login to get a discount. <br> E.g. "Congratulations, you\'ve just got a 20% discount."', 'social-connect-pys' ) . '</div>';
	$html .= '</div>';

	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_social_login_discount[text_after_login]',
			'id'          => 'socplug_social_login_discount_text_after_login',
			'placeholder' => __( 'Congratulations, you just got a XX% discount', 'social-connect-pys' ),
			'value'       => $coupon_settings['text_after_login'],
		)
	);

	$html .= socplugGetCustomHr();

	/**
	 * Switch to enable/disable the social login coupon
	 */
	$html .= '<span class="settings-help-text">' . __( 'Select the way the social login buttons will be displayed on your website.', 'social-connect-pys' ) . '</span>';

	/**
	 * Radio button group
	 */
	$html .= '<div class="social-coupon-display-group">';

	/**
	 * Inside Checkout page
	 */
	$html .= '<div class="social-coupon-display-item">';
	$html .= socplugGetFormElRadioItem(
		array(
			'name'     => 'socplug_social_login_discount[type]',
			'id'       => 'socplug_social_login_discount_type_checkout_inside',
			'value'    => 'checkout_inside',
			'label'    => __( 'Inside Checkout page', 'social-connect-pys' ),
			'selected' => $coupon_settings['type'],
		)
	);

	$html .= '<div class="social-coupon-display-hidden-box corner-radius ' . ( $coupon_settings['type'] !== 'checkout_inside' ? 'disabled-fields' : '' ) . '">';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_social_login_discount_checkout_inside_text">' . __( 'Text', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_social_login_discount[checkout_inside_text]',
			'id'          => 'socplug_social_login_discount_checkout_inside_text',
			'placeholder' => __( 'Example: Continue with your social network for a smoother experience:', 'social-connect-pys' ),
			'value'       => $coupon_settings['checkout_inside_text'],
		)
	);

	$html .= '</div>';
	$html .= '</div>';
	$html .= '</div>';

	/**
	 * Top of Checkout page
	 */
	$html .= '<div class="social-coupon-display-item">';
	$html .= socplugGetFormElRadioItem(
		array(
			'name'     => 'socplug_social_login_discount[type]',
			'id'       => 'socplug_social_login_discount_type_checkout_top',
			'value'    => 'checkout_top',
			'label'    => __( 'Top of Checkout page', 'social-connect-pys' ),
			'selected' => $coupon_settings['type'],
		)
	);

	$html .= '<div class="social-coupon-display-hidden-box corner-radius ' . ( $coupon_settings['type'] !== 'checkout_top' ? 'disabled-fields' : '' ) . '">';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_social_login_discount_checkout_top_text">' . __( 'Text', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_social_login_discount[checkout_top_text]',
			'id'          => 'socplug_social_login_discount_checkout_top_text',
			'placeholder' => __( 'Example: Continue with your social network for a smoother experience:', 'social-connect-pys' ),
			'value'       => $coupon_settings['checkout_top_text'],
		)
	);
	$html .= '</div>';
	$html .= '</div>';
	$html .= '</div>';

	/**
	 * As intermediate page before checkout
	 */
	$html .= '<div class="social-coupon-display-item">';
	$html .= socplugGetFormElRadioItem(
		array(
			'name'     => 'socplug_social_login_discount[type]',
			'id'       => 'socplug_social_login_discount_type_intermediate_page',
			'value'    => 'intermediate_page',
			'label'    => __( 'As intermediate page before checkout', 'social-connect-pys' ),
			'selected' => $coupon_settings['type'],
		)
	);

	$html .= '<div class="social-coupon-display-hidden-box corner-radius ' . ( $coupon_settings['type'] !== 'intermediate_page' ? 'disabled-fields' : '' ) . '">';

	$html .= socplugGetFormElCheckbox(
		array(
			'name'     => 'socplug_social_login_discount[hide_title]',
			'id'       => 'socplug_social_login_discount_hide_title',
			'label'    => __( 'Hide "Intermediate Page" title', 'social-connect-pys' ),
			'selected' => $coupon_settings['hide_title'],
		)
	);

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_social_login_discount_text_intermediate_page">' . __( 'Text', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_social_login_discount[intermediate_page_text]',
			'id'          => 'socplug_social_login_discount_intermediate_page_text',
			'placeholder' => __( 'Example: Continue with your social network for a smoother experience:', 'social-connect-pys' ),
			'value'       => $coupon_settings['intermediate_page_text'],
		)
	);
	$html .= '</div>';

	$html .= '<div class="field-row">';
	$html .= '<label for="socplug_social_login_discount_intermediate_page_skip_link">' . __( 'Skip link text', 'social-connect-pys' ) . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => 'socplug_social_login_discount[intermediate_page_skip_link]',
			'id'          => 'socplug_social_login_discount_intermediate_page_skip_link',
			'placeholder' => __( 'Skip', 'social-connect-pys' ),
			'value'       => $coupon_settings['intermediate_page_skip_link'],
		)
	);
	$html .= '</div>';
	$html .= '</div>';
	$html .= '</div>';

	$html .= '</div>';

	return $html;
}


function socplugSettingsBoxSocialLoginDisountCouponSelect( $coupon_settings ) {

	/**
	 * Select coupon
	 */
	$coupons = get_posts(
		array(
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'asc',
			'post_type'      => 'shop_coupon',
			'post_status'    => 'publish',
		)
	);

	$coupon_options = array(
		'0' => __( 'Select coupon', 'social-connect-pys' ),
	);

	if ( ! empty( $coupons ) ) {
		foreach ( $coupons as $coupon ) {
			if ( ! $coupon->ID || ! $coupon->post_title ) {
				continue;
			}
			$coupon_options[ $coupon->ID ] = $coupon->post_title;
		}
	} else {
		$coupon_options['0'] = __( 'Coupon not available', 'social-connect-pys' );
	}

	$html  = '<div class="field-row">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => 'Coupon',
			'name'     => 'socplug_social_login_discount[coupon_id]',
			'id'       => 'socplug_social_login_discount_coupon_id',
			'class'    => 'big-select',
			'options'  => $coupon_options,
			'selected' => $coupon_settings['coupon_id'],
		)
	);
	$html .= '</div>';

	return $html;
}

/**
 * Settings box for display settings
 */
function socplugSettingsBoxDisplay() {
	$coupon_settings = get_option( 'socplug_social_login_discount' );

	$display_settings = array(
		'single_product_page' => array(
			'label'     => __( 'Show the social login on the single product pages.', 'social-connect-pys' ),
			'positions' => array(
				'top_summary'               => __( 'On top of the summary', 'social-connect-pys' ),
				'before_add_to_cart_button' => __( 'Before the add to cart button', 'social-connect-pys' ),
				'after_add_to_cart_button'  => __( 'After the add to cart button', 'social-connect-pys' ),
				'after_product_meta'        => __( 'After the product meta', 'social-connect-pys' ),
			),
		),
		'cart_page'           => array(
			'label'     => __( 'Show the social login on the cart page.', 'social-connect-pys' ),
			'positions' => array(),
		),
		'checkout_page'       => array(
			'label'     => __( 'Show the social login on the checkout page.', 'social-connect-pys' ),
			'positions' => array(),
		),
	);

	$html = '';

	foreach ( $display_settings as $page => $settings ) {
		$html .= socplugGetSocplugDisplaySettingsItem(
			array(
				'checkbox_name'        => "socplug_social_login_discount[show_on_{$page}]",
				'checkbox_id'          => "socplug_social_login_discount_show_on_{$page}",
				'checkbox_label'       => $settings['label'],
				'checkbox_selected'    => $coupon_settings[ "show_on_{$page}" ],
				'selector_label'       => __( 'Position', 'social-connect-pys' ),
				'selector_name'        => "socplug_social_login_discount[show_on_{$page}_display]",
				'selector_id'          => "socplug_social_login_discount_show_on_{$page}_display",
				'selector_selected'    => $coupon_settings[ "show_on_{$page}_display" ],
				'selector_options'     => $settings['positions'],
				'textarea_label'       => __( 'Text', 'social-connect-pys' ),
				'textarea_name'        => "socplug_social_login_discount[show_on_{$page}_text]",
				'textarea_id'          => "socplug_social_login_discount_show_on_{$page}_text",
				'textarea_placeholder' => __( 'Continue with your social network for a smoother experience:', 'social-connect-pys' ),
				'textarea_value'       => $coupon_settings[ "show_on_{$page}_text" ],
			)
		);
	}

	return $html;
}
