<div class="settings-page-heading">
	<h2 class="page-heading"><?php esc_html_e( 'Woocommerce', 'social-connect-pys' ); ?></h2>
</div>
<div class="socplug-settings-wrapper">
	<form action="#" method="POST" class="settings-form">
		<input type="hidden" name="socplug_save_options" value="true" />
		<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'true_update' ) ); ?>"/>
		<input type="hidden" name="socplug_manage_options" value="true">
		<?php

		/**
		 * Create options list
		 */
		$options = array(
			'Display',
			'Social Login Discount',
		);

		foreach ( $options as $option ) {
			/**
			 * Echo settings box
			 */
			echo wp_kses_post( socplugGetSettingsBox( $option ) );
		}

		?>
	</form>
</div>
