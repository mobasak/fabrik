<?php
/**
 * Settings Page Status
 *
 * @package Social_Connect_Pys
 */

$network_status = socplugStatusGridGetSocialNetworkStatus();

?>
<div class="settings-page-heading">
	<h2 class="page-heading"><?php esc_html_e( 'Social Connect', 'social-connect-pys' ); ?></h2>
</div>
<div class="settings-status-grid">
	<div class="status-grid-item corner-radius status-active-networks">
		<div class="status-item-title"><?php echo esc_html( $network_status['providers_active_count'] ?? 0 ); ?></div>
		<div class="status-item-subtitle"><?php esc_html_e( 'Active Social Networks', 'social-connect-pys' ); ?></div>
	</div>
	<div class="status-grid-item corner-radius status-user-connected">
		<div class="status-item-title"><?php echo esc_html( $network_status['users_connected'] ?? 0 ); ?></div>
		<div class="status-item-subtitle"><?php esc_html_e( 'Users Connected', 'social-connect-pys' ); ?></div>
	</div>
	<?php
	if ( class_exists( 'WooCommerce' ) ) {
		$woocommerce_data = socplugStatusGridGetWoocommerceData();

		/**
		 * Sales inputs
		 */
		echo "<input type='hidden' id='sucplug_sales' name='sucplug_sales' value='" . esc_attr( $woocommerce_data['sales_by_month_data'] ) . "' />";
		echo "<input type='hidden' id='socplug_orders' name='socplug_orders' value='" . esc_attr( $woocommerce_data['orders_by_month_data'] ) . "' />";
		echo "<input type='hidden' name='socplug_currency_symbol' value='" . esc_attr( get_woocommerce_currency_symbol() ) . "' />";

		/**
		 * Graph type
		 */
		$graph_type = 'sales';
		?>
		<div class="status-grid-item corner-radius status-in-sales">
			<div class="status-item-title"><?php echo wp_kses_post( wc_price( $woocommerce_data['sales_by_month'] ) ); ?></div>
			<div class="status-item-subtitle"><?php esc_html_e( 'In sales by social users this month', 'social-connect-pys' ); ?></div>
		</div>
		<div class="status-grid-item corner-radius status-report-graph">
			<div class="status-report-graph-nav">
				<form action="#" method="POST">
					<div class="status-report-graph-type">
						<select name="status-report-graph-type" class="custom-select" id="status-report-graph-type">
							<option value="sales" <?php selected( $graph_type, 'sales', true ); ?>>
								<?php esc_html_e( 'Sales for month by social users', 'social-connect-pys' ); ?>
							</option>
							<option value="orders" <?php selected( $graph_type, 'orders', true ); ?>>
								<?php esc_html_e( 'Orders for month by social users', 'social-connect-pys' ); ?>
							</option>
						</select>
					</div>
					<div class="status-report-graph-period">
						<?php
						/**
						 * Period Nav
						 */
						$periods = array(
							'prev_month'    => __( 'Previous month', 'social-connect-pys' ),
							'current_month' => __( 'Current month', 'social-connect-pys' ),
							'current_week'  => __( 'Current week', 'social-connect-pys' ),
						);

						/**
						 * Active period
						 */
						$report_time = socplugGetReportPeriod();

						foreach ( $periods as $key => $period ) {
							$class = ( $report_time === $key ) ? ' active' : '';
							echo '<a href="#" class="status-report-graph-period-item ' . esc_attr( $class ) . '" data-period="' . esc_attr( $key ) . '">' . esc_html( $period ) . '</a>';
						}

						?>
					</div>
				</form>
			</div>
			<div class="status-report-graph-canvas">
				<canvas id="myChart"></canvas>
			</div>
		</div>
		<?php
	}
	?>

</div>
<form action="" method="POST" class="settings-form">
	<div class="settings-manage-grid">
		<input type="hidden" name="socplug_save_options" value="true" />
		<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'true_update' ) ); ?>" />
		<input type="hidden" name="socplug_manage_providers" value="true">

		<?php
		/**
		 * Manage Networks
		 */
		$social_connect = new SC_Social_Connect();
		$providers      = $social_connect->getProvidersOptions();

		if ( ! empty( $providers['providers'] ) ) {
			foreach ( $providers['providers'] as $key => $provider ) {
				echo wp_kses_post( socplugStatusGridGetManageNetworkItem( $key, $network_status['providers_count'][ $key ], $provider ) );
			}
		}

		?>
	</div>
</form>
