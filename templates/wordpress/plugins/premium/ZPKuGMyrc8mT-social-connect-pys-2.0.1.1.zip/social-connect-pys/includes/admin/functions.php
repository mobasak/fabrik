<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php'; // Ensure logger is included

/**
 * Get social network status
 */
function socplugStatusGridGetSocialNetworkStatus(): array {
	$providers       = get_option( 'socplug_main_providers' );
	$providers_items = $providers['providers'];

	/**
	 * Count the number of users that connected a for each social network
	 */
	$providers_count = socplugGetUsersByProviders( $providers_items );

	/**
	 * Get number of active social networks
	 */
	$providers_active_count = 0;
	foreach ( $providers_items as $providers_item_value ) {
		if ( 'true' === $providers_item_value['enabled'] ) {
			++$providers_active_count;
		}
	}

	/**
	 * Get User Connected number
	 */
	$users_connected = socplugGetUsersConnectedCount();

	return array(
		'providers_count'        => $providers_count,
		'providers_active_count' => $providers_active_count,
		'users_connected'        => $users_connected,
	);
}

/**
 * Get User Connected number
 *
 * @return int The user connected count.
 */
function socplugGetUsersConnectedCount() {
	/**
	 * Get User Connected number
	 */
	$cache_key = 'users_connected_count';

	/**
	 * Check if users connected count is cached
	 */
	$users_connected = get_transient( $cache_key );

	if ( false === $users_connected ) {
		/**
		 * Get users connected count
		 */
		$args = array(
			'meta_query'  => array(
				array(
					'key'     => '_socplug_social_providers',
					'value'   => '',
					'compare' => '!=',
				),
			),
			'fields'      => 'ID',
			'number'      => 1,
			'count_total' => true,
		);

		$user_query      = new WP_User_Query( $args );
		$users_connected = $user_query->get_total();

		/**
		 * Set users connected count to cache
		 */
		set_transient( $cache_key, $users_connected, 300 );
	}

	return $users_connected;
}

/**
 * Get users by providers
 *
 * @param array $providers_items The providers items.
 * @return array The users by providers.
 */
function socplugGetUsersByProviders( $providers_items ) {
	$providers_count = array();

	if ( empty( $providers_items ) ) {
		return $providers_count;
	}

	foreach ( $providers_items as $provider_key => $provider_value ) {
		$transient_key = 'provider_count_' . $provider_key;
		$count         = get_transient( $transient_key );

		if ( false === $count ) {
			$args = array(
				'meta_query'  => array(
					array(
						'key'     => '_socplug_social_providers',
						'value'   => $provider_key,
						'compare' => 'LIKE',
					),
				),
				'fields'      => 'ID',
				'number'      => 1,
				'count_total' => true,
			);

			$user_query = new WP_User_Query( $args );
			$count      = $user_query->get_total();

			set_transient( $transient_key, $count, 300 );
		}

		$providers_count[ $provider_key ] = $count;
	}

	return $providers_count;
}


/**
 * Get Report Period from URL
 */
function socplugGetReportPeriod() {
	$report_time = 'current_week';

	if ( empty( $_GET['report_time'] ) ) {
		return $report_time;
	}

	if ( in_array( $_GET['report_time'], array( 'prev_month', 'current_month', 'current_week' ) ) ) {
		return $_GET['report_time'];
	}

	return $report_time;
}

/**
 * Ajax get data for graph
 */
add_action(
	'wp_ajax_socplugAjaxGetGraphData',
	'socplugAjaxGetGraphData'
);
add_action( 'wp_ajax_nopriv_socplugAjaxGetGraphData', 'socplugAjaxGetGraphData' );

/**
 * Ajax get data for graph
 *
 * @return void
 */
function socplugAjaxGetGraphData() {
	$period = wp_unslash( $_POST['period'] );

	if ( empty( $period ) ) {
		wp_send_json_error( 'We had an error, please try later.' );
	}

	$data = socplugStatusGridGetWoocommerceData( $period );

	wp_send_json_success(
		array(
			'message'    => 'Fetch graph data successfully.',
			'graph_data' => $data,
		)
	);
}

/**
 * Save Options
 */
add_action( 'wp_ajax_socplugAjaxSaveSettings', 'socplugAjaxSaveSettings' );
add_action( 'wp_ajax_nopriv_socplugAjaxSaveSettings', 'socplugAjaxSaveSettings' );

/**
 * Save Options
 *
 * @return void
 */
function socplugAjaxSaveSettings() {
	/**
	 * Check if form submitted
	 */
	if ( ! isset( $_POST['socplug_save_options'] ) ) {
		SC_Logger::record( 'system', 'socplugAjaxSaveSettings: socplug_save_options not valid', 'error' );
		return;
	}

	/**
	 * Check nonce
	 */
	if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['_wpnonce'] ), 'true_update' ) ) {
		SC_Logger::record( 'system', 'socplugAjaxSaveSettings: not valid nonce', 'error' );
		wp_send_json_error( __( 'Error: Nonce verification failed', 'social-connect-pys' ) );
		return;
	}

	$success_message = 'Settings saved successfully.';

	/**
	 * Update option Enable or Disable Network
	 */
	if (
		! empty( $_POST['socplug_manage_providers'] )
		&& $_POST['socplug_manage_providers'] == 'true'
		&& ! empty( $_POST['socplug_main_providers']['providers'] )
	) {
		socplugUpdateProvidersStatus();
		wp_send_json_success( array( 'message' => $success_message ) );
	}

	if ( ! empty( $_POST['socplug_manage_options'] ) && 'true' === $_POST['socplug_manage_options'] ) {
		socplugUpdateMainSettings();
		wp_send_json_success( array( 'message' => $success_message ) );
	}

	wp_send_json_success( array( 'message' => $success_message ) );
}

/**
 * Update Main Settings
 *
 * @return void
 */
function socplugUpdateMainSettings() {
	$main_settings = array(
		'socplug_main_form_comments',
		'socplug_main_form_register',
		'socplug_main_form_login',
		'socplug_main_form_custom_text',
		'socplug_main_buttons',
		'socplug_widget',
		'socplug_woo_avatar',
		'socplug_shortcode_loginform',
		'socplug_connectmore',
		'socplug_settings_facebook',
		'socplug_main_show_admin_bar',
		'socplug_social_login_discount',
		'socplug_privacy',
		'socplug_logs',
	);

	foreach ( $main_settings as $setting ) {
		if ( empty( $_POST[ $setting ] ) ) {
			continue;
		}

		/**
		 * Add rules for Social Login Coupon saving and Connectmore
		 */
		if ( $setting == 'socplug_social_login_discount' || $setting == 'socplug_connectmore' ) {
			$current_options = get_option( $setting );

			/**
			 * Update all fiedls, but not delete fields which are not in the POST
			 */
			foreach ( $_POST[ $setting ] as $key => $value ) {
				$current_options[ $key ] = $value;
			}

			update_option( $setting, $current_options );
			continue;
		}

		update_option( $setting, $_POST[ $setting ] );
	}
}

/**
 * Get custom hr
 */
function socplugGetCustomHr() {
	return '<hr class="custom-hr">';
}

/**
 * Selects data
 */
function socplugBorderTypes() {
	return array(
		'none'   => __( 'None', 'social-connect-pys' ),
		'solid'  => __( 'Line', 'social-connect-pys' ),
		'dotted' => __( 'Dotted', 'social-connect-pys' ),
		'dashed' => __( 'Dashed', 'social-connect-pys' ),
		'double' => __( 'Double', 'social-connect-pys' ),
		'groove' => __( 'Groove', 'social-connect-pys' ),
		'ridge'  => __( 'Ridge', 'social-connect-pys' ),
		'inset'  => __( 'Inset', 'social-connect-pys' ),
		'outset' => __( 'Outset', 'social-connect-pys' ),
	);
}

/**
 * Get login btn redirect url
 *
 * @param string $redirect The redirect url.
 * @return string The redirect url.
 */
function socplugGetLoginBtnRedirectUrl( $redirect ) {

	switch ( $redirect ) {
		case 'samepage':
		case '':
			$url = isset( $_SERVER['REQUEST_URI'] )
			? site_url() . esc_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) )
			: site_url();
			break;
		case 'checkout':
			$url = get_permalink( wc_get_page_id( 'checkout' ) );
			break;
		default:
			$url = esc_url( $redirect );
			break;
	}

	return $url;
}

/**
 * Reset to default settings Ajax
 */
add_action( 'wp_ajax_socplugResetDefaultSettingsAjax', 'socplugResetDefaultSettingsAjax' );

/**
 * Reset to default settings Ajax
 *
 * @return void
 */
function socplugResetDefaultSettingsAjax() {
	/**
	 * Validate nonce and checkboxes
	 */
	if ( empty( $_POST['nonce'] )
	|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'socplug_reset_default_settings' )
	|| empty( $_POST['checkboxes'] ) ) {
		wp_send_json_error( 'Invalid nonce or checkboxes' );
	}

	/**
	 * Default options
	 */
	$default_options = array(
		'socplug_main_form_custom_text',
		'socplug_main_buttons',
		'socplug_widget',
		'socplug_shortcode_loginform',
		'socplug_connectmore',
		'socplug_settings_facebook',
		'socplug_main_show_admin_bar',
		'socplug_privacy',
	);

	$custom_options = array(
		'location',
		'woocommerce_display',
		'woocommerce_discount',
		'delete_all_plugin_data',
	);

	$default_settings = json_decode( file_get_contents( PYS_SOCIAL_CONNECT_PATH . '/includes/default-settings.json' ), true );
	$options_to_reset = isset( $_POST['checkboxes'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['checkboxes'] ) ) : array();

	foreach ( $options_to_reset as $checkbox ) {
		$checkbox = str_replace( 'res_', '', $checkbox );
		if ( in_array( $checkbox, $default_options, true ) && isset( $default_settings[ $checkbox ] ) ) {
			update_option( $checkbox, $default_settings[ $checkbox ] );
		} elseif ( in_array( $checkbox, $custom_options, true ) ) {
			switch ( $checkbox ) {
				case 'location':
					socplugLocationOptionsReset( $default_settings );
					break;
				case 'woocommerce_display':
					socplugWooCommerceDisplayOptionsReset( $default_settings );
					break;
				case 'woocommerce_discount':
					socplugWooCommerceDiscountOptionsReset( $default_settings );
					break;
				case 'delete_all_plugin_data':
					socplugDeleteAllPluginData();
					break;
			}
		}
	}

	wp_send_json_success( 'Settings reset to default' );
}

/**
 * Location options reset
 *
 * @param array $default_settings The default settings.
 * @return void
 */
function socplugLocationOptionsReset( $default_settings ) {
	update_option( 'socplug_main_form_comments', $default_settings['socplug_main_form_comments'] );
	update_option( 'socplug_main_form_register', $default_settings['socplug_main_form_register'] );
	update_option( 'socplug_main_form_login', $default_settings['socplug_main_form_login'] );
}

/**
 * WooCommerce display options reset
 *
 * @param array $default_settings The default settings.
 * @return void
 */
function socplugWooCommerceDisplayOptionsReset( $default_settings ) {
	$woocommerce = get_option( 'socplug_social_login_discount' );

	$update_options = array(
		'show_on_single_product_page',
		'show_on_single_product_page_display',
		'show_on_single_product_page_text',
		'show_on_cart_page',
		'show_on_cart_page_display',
		'show_on_cart_page_text',
		'show_on_checkout_page',
		'show_on_checkout_page_display',
		'show_on_checkout_page_text',
	);

	foreach ( $update_options as $option ) {
		$woocommerce[ $option ] = $default_settings['socplug_social_login_discount'][ $option ];
	}

	update_option( 'socplug_social_login_discount', $woocommerce );
}

/**
 * WooCommerce discount options reset
 *
 * @param array $default_settings The default settings.
 * @return void
 */
function socplugWooCommerceDiscountOptionsReset( $default_settings ) {
	$woocommerce = get_option( 'socplug_social_login_discount' );

	$skip_options = array(
		'show_on_single_product_page',
		'show_on_single_product_page_display',
		'show_on_single_product_page_text',
		'show_on_cart_page',
		'show_on_cart_page_display',
		'show_on_cart_page_text',
		'show_on_checkout_page',
		'show_on_checkout_page_display',
		'show_on_checkout_page_text',
	);

	foreach ( $woocommerce as $key => $value ) {
		if ( in_array( $key, $skip_options, true ) ) {
			continue;
		}

		$woocommerce[ $key ] = $default_settings['socplug_social_login_discount'][ $key ];
	}

	update_option( 'socplug_social_login_discount', $woocommerce );
}

/**
 * Delete all plugin data
 *
 * @return void
 */
function socplugDeleteAllPluginData() {
	$users = get_users();
	foreach ( $users as $user ) {
		socplugDeleteSocialConnectDataFromUser( $user->ID );
	}

	delete_transient( 'users_connected_count' );

	/**
	 * Check if WooCommerce is installed
	 */
	if ( class_exists( 'WooCommerce' ) ) {
		socplugDeleteWooCommerceData();
	}
}
/**
 * Delete Plugin Data from WooCommerce orders
 *
 * @return void
 */
function socplugDeleteWooCommerceData() {
	$order_ids = wc_get_orders(
		array(
			'limit'  => -1,
			'return' => 'ids',
		)
	);

	if ( empty( $order_ids ) ) {
		return;
	}

	foreach ( $order_ids as $order_id ) {
		$meta = get_post_meta( $order_id, 'socplug_user_networks', true );
		if ( empty( $meta ) ) {
			continue;
		}

		delete_post_meta( $order_id, 'socplug_user_networks' );
	}
}


/**
 * Preview design ajax
 */
add_action( 'wp_ajax_socplugPreviewDesignAjax', 'socplugPreviewDesignAjax' );
add_action( 'wp_ajax_nopriv_socplugPreviewDesignAjax', 'socplugPreviewDesignAjax' );

/**
 * Preview design ajax
 *
 * @return void
 */
function socplugPreviewDesignAjax() {
	$shortcode = $_POST['shortcode'] ?? '';

	/**
	 * Check if shortcode exists
	 */
	if ( ! shortcode_exists( $shortcode ) ) {
		wp_send_json_error( 'Shortcode not found' );
	}

	/**
	 * Set in session variable page_now
	 */
	$_SESSION['page_now'] = 'preview';

	/**
	 * Add brakets to shortcode
	 */
	$shortcode = '[' . $shortcode . ']';

	/**
	 * Get shortcode content
	 */
	$content = do_shortcode( $shortcode );

	/**
	 * Add wrapper
	 */
	$html = '<div class="socplug-preview-design-wrapper">
               <div class="socplug-preview-design-content">
               ' . $content . '
               </div>';

	$html .= '</div>';

	/**
	 * Unset session variable page_now
	 */
	unset( $_SESSION['page_now'] );

	wp_send_json_success( $html );
}


/**
 * Get Socplug Display Settings Item
 *
 * @param array $data The data to get the Socplug Display Settings Item for.
 * @return string The Socplug Display Settings Item HTML.
 */
function socplugGetSocplugDisplaySettingsItem( $data ) {

	$html = socplugGetFormElCheckbox(
		array(
			'name'     => $data['checkbox_name'],
			'id'       => $data['checkbox_id'],
			'label'    => $data['checkbox_label'],
			'selected' => $data['checkbox_selected'],
		)
	);

	if ( 'socplug_social_login_discount_show_on_single_product_page' === $data['checkbox_id'] ) {
		$html .= '<div class="settings-help-text">' . __( 'If the login buttons are not displayed on the product page, check if you are using WooCommerce templates generated by the Elementor plugin. In that case, you need to open the product page template editor and manually add the login buttons, which will be available in the Social Connect section.', 'social-connect-pys' ) . '</div>';
	}

	if ( empty( $data['selector_options'] ) ) {
		$data['selector_options'] = array(
			'top'    => __( 'Top', 'social-connect-pys' ),
			'bottom' => __( 'Bottom', 'social-connect-pys' ),
		);
	}

	$html .= '<div class="socplug-display-box-wrapper">';

	$html .= '<div class="field-row">';
	$html .= socplugGetFormElSelector(
		array(
			'label'    => $data['selector_label'],
			'name'     => $data['selector_name'],
			'id'       => $data['selector_id'],
			'class'    => 'big-select',
			'options'  => $data['selector_options'],
			'selected' => $data['selector_selected'],
		)
	);

	$html .= '</div>';

	$html .= '<div class="social-coupon-display-hidden-box corner-radius">';

	$html .= '<div class="field-row">';
	$html .= '<label for="' . $data['textarea_id'] . '">' . $data['textarea_label'] . '</label>';
	$html .= socplugGetFormElTextarea(
		array(
			'name'        => $data['textarea_name'],
			'id'          => $data['textarea_id'],
			'placeholder' => $data['textarea_placeholder'],
			'value'       => $data['textarea_value'],
		)
	);
	$html .= '</div></div></div>';

	return $html;
}

/**
 * Get network login btn
 *
 * @param string $network The network to get the login btn for.
 * @param string $addClass The class to add to the login btn.
 * @param string $redirect The redirect to add to the login btn.
 * @return string The network login btn HTML.
 */
function socplugGetNetworkLoginBtn( $network, $addClass = '', $redirect = '', $add_discount = false ): string {

	if ( ! empty( $addClass ) ) {
		$addClass = str_replace( '_', ' ', $addClass );
	}

	/**
	 * Generate provider url
	 */
	$provider_url = site_url() . '/socplug/auth?provider=' . $network;

	/**
	 * Add redirect url to provider url
	 */
	$provider_url .= '&moved_from=' . socplugGetLoginBtnRedirectUrl( $redirect );

	/**
	 * Check if add discount is true
	 */
	if ( $add_discount ) {
		$provider_url .= '&ds=true';
	}

	$html = '<div data-provider-url="' . $provider_url . '" class="network-login-btn ' . $addClass . '">';

	/**
	 * Icon
	 */
	$icon  = socplugGetIconmoonIcon( strtolower( $network ) );
	$html .= '<span class="iconmoon network-icon network-icon-' . $network . '">' . $icon . '</span>';

	/**
	 * Full text
	 */
	$html .= '<span class="network-text full-text">' . __( 'Login with ', 'social-connect-pys' ) . ucfirst( $network ) . '</span>';

	/**
	 * Short text
	 */
	$html .= '<span class="network-text short-text">' . ucfirst( $network ) . '</span>';

	$html .= '</div>';
	return $html;
}

/**
 * Get steps for each network
 *
 * @param string $network The network to get the steps for.
 * @return string The steps HTML.
 */
function socplugNetworkConfigurationSteps( $network ) {
	/**
	 * Get json file with config information
	 */
	$file_name = 'config-steps-' . $network . '.json';
	$file_path = PYS_SOCIAL_CONNECT_PATH . '/includes/network-config-steps/' . $file_name;

	if ( ! file_exists( $file_path ) ) {
		return '';
	}

	/**
	 * Json decode
	 */
	$file_content = file_get_contents( $file_path );
	$config_steps = json_decode( $file_content, true );

	if ( empty( $config_steps ) ) {
		return '';
	}

	/**
	 * Generate steps html
	 */
	$steps_html = '';
	foreach ( $config_steps['steps'] as $step ) {
		if ( empty( $step['step'] ) ) {
			$steps_html .= '<div class="network-step"><div class="step-instruction">' . $step['instruction'] . '</div></div>';
			continue;
		}

		if ( 'facebook' === $network ) {
			/**
			 * Replace redirect uri
			 */
			$step['instruction'] = str_replace( 'replace_facebook_redirect_uri', site_url( '/socplug/auth?provider=Facebook' ), $step['instruction'] );
			$step['instruction'] = str_replace(
				'facebook_default_icon',
				'<a class="download-link" download href="' . site_url( '/wp-content/plugins/social-connect-pys/assets/images/facebook-app-image.gif' ) . '" target="_blank">click to download</a>',
				$step['instruction']
			);
		}

		if ( 'google' === $network ) {
			/**
			 * Replace redirect uri
			 */
			$step['instruction'] = str_replace( 'google_replace_site_url_redirect', site_url( '/socplug/auth?provider=Google' ), $step['instruction'] );
			$step['instruction'] = str_replace( 'google_replace_site_url', site_url(), $step['instruction'] );
		}

		$steps_html .= '<div class="network-step"><div class="step-number">Step: ' . $step['step'] . '</div><div class="step-instruction">' . $step['instruction'] . '</div></div>';
	}

	return $steps_html;
}

/**
 * Update info about enable or disable provider
 */
function socplugUpdateProvidersStatus() {
	$providers       = ! empty( $_POST['socplug_main_providers']['providers'] ) ? $_POST['socplug_main_providers']['providers'] : array();
	$current_options = get_option( 'socplug_main_providers' );

	foreach ( $providers as $provider_key => $provider_value ) {
		$current_options['providers'][ $provider_key ]['enabled'] = $provider_value['enabled'];

		/**
		 * Check if need to update Client ID and Secret
		 */
		if ( ! empty( $_POST['socplug_network_settings'] ) ) {
			$current_options['providers'][ $provider_key ]['keys'] = $_POST['socplug_network_settings'][ $provider_key ]['keys'];
		}
	}

	update_option( 'socplug_main_providers', $current_options );
}



/**
 * Get start and end report date
 *
 * @param string $report_time The report time to get the data for.
 * @return array The data for the report.
 */
function socplugGetStartAndEndReportDate( $report_time ) {
	$dates = array(
		'start_date' => '',
		'end_date'   => '',
	);

	switch ( $report_time ) {
		case 'current_week':
			$current_date = gmdate( 'Y-m-d' );
			$current_day  = gmdate( 'N', strtotime( $current_date ) );

			$monday = new DateTime( $current_date );
			$sunday = new DateTime( $current_date );

			$monday->modify( '-' . ( $current_day - 1 ) . ' days' );
			$sunday->modify( '+' . ( 7 - $current_day ) . ' days' );

			$dates['start_date'] = $monday->format( 'Y-m-d' );
			$dates['end_date']   = $sunday->format( 'Y-m-d' );
			break;

		case 'prev_month':
			$current_month = gmdate( 'm' );
			$current_year  = gmdate( 'Y' );

			if ( 1 === $current_month ) {
				$month = 12;
				$year  = $current_year - 1;
			} else {
				$month = $current_month - 1;
				$year  = $current_year;
			}

			$month    = str_pad( $month, 2, '0', STR_PAD_LEFT );
			$last_day = gmdate( 't', strtotime( "$year-$month-01" ) );

			$dates['start_date'] = "$year-$month-01";
			$dates['end_date']   = "$year-$month-$last_day";
			break;
		case 'current_month':
			$year     = gmdate( 'Y' );
			$month    = gmdate( 'm' );
			$last_day = gmdate( 't', strtotime( "$year-$month-01" ) );

			$dates['start_date'] = "$year-$month-01";
			$dates['end_date']   = "$year-$month-$last_day";
			break;
		default:
			break;
	}

	return $dates;
}

/**
 * Status Grid Get WooCommerce Data by sales
 *
 * @param string $report_time The report time to get the data for.
 * @return array The data for the report.
 */
function socplugStatusGridGetWoocommerceData( $report_time = false ) {
	$data = array();

	/**
	 * Include WooCommerce's admin report class, from WooCommerce plugin
	 */
	include_once WP_PLUGIN_DIR . '/woocommerce/includes/admin/reports/class-wc-admin-report.php';

	/**
	 * Include Social Connect status grid sales class
	 */
	include_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-status-grid-sales.php';

	/* set report time */
	if ( ! $report_time ) {
		$report_time = socplugGetReportPeriod();
	}

	/* set the report start and end date parameters */
	$dates      = socplugGetStartAndEndReportDate( $report_time );
	$start_date = $dates['start_date'];
	$end_date   = $dates['end_date'];

	$date_range = socplugDateRange( $start_date, $end_date, '+1 day', 'd.m.Y' );

	/* request socials sales report */

	$sales_by_date                 = new SC_Status_Grid_Sales();
	$sales_by_date->start_date     = strtotime( $start_date . ' 00:00' );
	$sales_by_date->end_date       = strtotime( $end_date . ' 23:59' );
	$sales_by_date->chart_groupby  = 'day';
	$sales_by_date->group_by_query = 'YEAR(posts.post_date), MONTH(posts.post_date), DAY(posts.post_date)';

	$sales_by_date_values = $sales_by_date->getReportData();

	$orders_by_month = array();
	$sales_by_month  = array();

	$data['sales_by_month'] = 0;

	$sales_by_month_chart = array(
		'labels'  => array(),
		'dataset' => array(),
	);

	$orders_by_month_chart = array(
		'labels'  => array(),
		'dataset' => array(),
	);

	foreach ( $date_range as $date_range_single ) {

		$sales_by_month[ $date_range_single ] = 0;

		$orders_by_month[ $date_range_single ] = 0;
	}

	/* populate month sales array with total sales for each date */
	if ( count( $sales_by_date_values->orders ) > 0 ) {

		foreach ( $sales_by_date_values->orders as $single_order ) {
			$single_order_date                    = gmdate( 'd.m.Y', strtotime( $single_order->post_date ) );
			$sales_by_month[ $single_order_date ] = floatval( $single_order->total_sales );
		}

		/* sum of all sales for the month */

		$data['sales_by_month'] = array_sum( $sales_by_month );
	}

	/* populate month orders array with total orders for each day */
	if ( count( $sales_by_date_values->order_counts ) > 0 ) {

		foreach ( $sales_by_date_values->order_counts as $single_order ) {
			$single_order_date                     = gmdate( 'd.m.Y', strtotime( $single_order->post_date ) );
			$orders_by_month[ $single_order_date ] = floatval( $single_order->count );
		}
	}

	/* convert sales data into array of objects for the chart library */
	foreach ( $sales_by_month as $sales_by_month_key => $sales_by_month_value ) {
		$sales_by_month_chart['labels'][]  = gmdate( 'd/m', strtotime( $sales_by_month_key ) );
		$sales_by_month_chart['dataset'][] = $sales_by_month_value;
	}

	$data['sales_by_month_data'] = wp_json_encode( $sales_by_month_chart );
	foreach ( $orders_by_month as $orders_by_month_key => $orders_by_month_value ) {
		$orders_by_month_chart['labels'][]  = gmdate( 'd M', strtotime( $orders_by_month_key ) );
		$orders_by_month_chart['dataset'][] = $orders_by_month_value;
	}

	$data['orders_by_month_data'] = wp_json_encode( $orders_by_month_chart );

	return $data;
}

/**
 * Get manage network item block
 *
 * @param string $key The key of the network.
 * @param string $connected_accounts The connected accounts of the network.
 * @param array  $provider The provider of the network.
 * @return string The manage network item block HTML.
 */
function socplugStatusGridGetManageNetworkItem( $key, $connected_accounts, $provider ) {
	$network_name_lower = strtolower( $key );
	$res                = '<div class="status-grid-item corner-radius status-manage-' . $network_name_lower . '">';

	/**
	 * Manage block heading
	 */
	$res .= '<div class="status-grid-item-heading">';

	/**
	 * Network Icon
	 */
	$icon = socplugGetIconmoonIcon( $network_name_lower );
	$res .= '<span class="status-grid-item-icon iconmoon network-icon network-icon-' . $network_name_lower . '">' . $icon . '</span>';

	/**
	 * Network Name
	 */
	$network_name = sprintf( 'Manage Your %s Login', ucfirst( $key ) );
	$res         .= '<div class="status-grid-item-name">' . $network_name . '</div>';

	/**
	 * Network Toggle
	 */
	$res .= '<div class="status-grid-item-toggle">
                <label class="switch" for="socplug_main_providers_providers_' . ucfirst( $key ) . '_enabled">
                    <input type="hidden" name="socplug_main_providers[providers][' . ucfirst( $key ) . '][enabled]"  value="false">
                    <input type="checkbox" name="socplug_main_providers[providers][' . ucfirst( $key ) . '][enabled]" value="true" id="socplug_main_providers_providers_' . ucfirst( $key ) . '_enabled" class="manage-network-toggle" ' . checked( $provider['enabled'], 'true', false ) . '>
                    <span class="slider round"></span>
                </label>
            </div>';

	$res .= '</div>';

	/**
	 * Manage block Content
	 */
	$res .= '<div class="status-grid-item-content">';

	$res .= '<div class="status-grid-item-info">';
	$res .= '<div class="status-item-title">' . $connected_accounts . '</div>';
	$res .= '<div class="status-item-subtitle">' . __( 'Connected Accounts', 'social-connect-pys' ) . '</div>';
	$res .= '</div>';

	/**
	 * Manage block action
	 */
	$button_link = PYS_SOCIAL_CONNECT_ADMIN_URL . '&section=social&network=' . $network_name_lower;
	$icon        = socplugGetIconmoonIcon( 'configure' );

	$res .= '<div class="status-manage-network-action">
                <a class="social-button social-button-configure" href="' . $button_link . '">
                ' . $icon . '
                ' . __( 'Configure', 'social-connect-pys' ) . '
                </a>
            </div>';

	$res .= '</div></div>';
	return $res;
}

/**
 * Get settings box
 *
 * @param string $option The option to get settings box for.
 * @return string The settings box HTML.
 */
function socplugGetSettingsBox( $option ) {
	$section_name = str_replace( ' ', '_', strtolower( $option ) );
	$html         = '<div class="network-settings row-wrapper margin-top">';
	$html        .= '<div class="settings-row-heading info-icon form-row-heading">';
	$html        .= esc_html__( $option, 'social-connect-pys' );
	$html        .= '<div class="settings-icon">' . socplugGetSettingsSvgIcon() . '</div>';
	$html        .= '</div>';
	$html        .= '<div class="network-settings-item network-settings-item-toggle-div hidden ' . esc_attr( $section_name ) . '-section">';
	$html        .= '<div class="network-settings-item-inner gap">';

	/**
	 * Generate function name
	 */
	$function_name = socplugGenerateSettingsBoxFunctionName( $section_name );

	if ( function_exists( $function_name ) ) {
		$html .= $function_name();
	}

	$html .= '</div></div></div>';

	return $html;
}

/**
 * Generate function name
 *
 * @param string $section_name The section name to generate function name from.
 *
 * @return string The generated function name
 */
function socplugGenerateSettingsBoxFunctionName( $section_name ) {
	$function_name        = explode( '_', $section_name );
	$function_name_single = '';

	foreach ( $function_name as $value ) {
		$function_name_single .= ucfirst( $value );
	}

	$function_name_single = 'socplugSettingsBox' . $function_name_single;

	return $function_name_single;
}


/**
 * Get mobile nav
 */
function socplugGetMobileNav(): string {
	$menu = socplugGetSettingsMenuBar();

	$html          = '<div class="social-connect-mobile-nav">';
	$selected_item = array();

	/**
	 * Show dropdown menu
	 */
	$html .= '<div class="social-connect-mobile-nav-dropdown">';
	foreach ( $menu as $value ) {
		if ( 'active' === $value['active'] ) {
			$selected_item = $value;
		}

		$html .= '<a href="' . $value['url'] . '" class="socplug-nav-link ' . $value['active'] . '">' . $value['title'] . '</a>';
	}
	$html .= '</div>';

	/**
	 * Check if selected item is empty || might be empty, if user go to provider configuration page
	 */
	if ( empty( $selected_item ) ) {
		$selected_item = $menu['main'];
	}

	/**
	 * Show selected item
	 */
	$html .= '<div class="social-connect-mobile-nav-selected-item">';
	$html .= '<a href="' . $selected_item['url'] . '" class="socplug-nav-link ' . $selected_item['active'] . '">' . $selected_item['title'] . '</a>';
	$html .= '</div></div>';

	return $html;
}

/**
 * Check provider config
 *
 * @return void
 */
function socplugCheckProviderConfigAjax() {

	/**
	 * Delete transients, if they exist
	 */
	delete_transient( 'check_provider_config' );
	delete_transient( 'check_provider_config_send_query' );

	/**
	 * Set new transient
	 */
	set_transient( 'check_provider_config', true, 180 );
	wp_send_json_success( array( true ) );
}

add_action( 'wp_ajax_socplugCheckProviderConfigAjax', 'socplugCheckProviderConfigAjax' );
add_action( 'wp_ajax_nopriv_socplugCheckProviderConfigAjax', 'socplugCheckProviderConfigAjax' );

/**
 * Get Logs Data for the logs page
 *
 * @return array
 */
function socplugGetLogsData() {

	// Include the logger class.
	require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php';

	$log_types    = array( 'system', 'facebook', 'google' );
	$loggers      = array();
	$log_contents = array();

	// Instantiate loggers.
	foreach ( $log_types as $type ) {
		$loggers[ $type ] = new SC_Logger( $type );
	}

	foreach ( $log_types as $type ) {
		$log_file_content = $loggers[ $type ]->get_log_content();
		if ( false === $log_file_content || empty( trim( $log_file_content ) ) ) {
			$log_contents[ $type ] = '<pre class="sc-log-content">' . esc_html__( 'Log file is empty or could not be read.', 'social-connect-pys' ) . '</pre>';
		} else {
			$lines                = explode( "\n", trim( $log_file_content ) );
			$reversed_lines       = array_reverse( $lines );
			$reversed_log_content = implode( "\n", $reversed_lines );

			$log_contents[ $type ] = '<pre class="sc-log-content">' . esc_textarea( $reversed_log_content ) . '</pre>';
		}
	}

	return array(
		'log_types'    => $log_types,
		'log_contents' => $log_contents,
	);
}



/**
 * Ajax download logs
 *
 * @return void
 */
function socplugAjaxDownloadLogs() {
	$type  = isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : null;
	$nonce = isset( $_POST['nonce'] ) ? sanitize_key( $_POST['nonce'] ) : null;

	if ( ! $type || ! $nonce || ! wp_verify_nonce( $nonce, 'sc_download_log_' . $type ) ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'Invalid request or security check failed.', 'social-connect-pys' ),
			)
		);
	}

	// Include the logger class.
	require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php';

	// Validate log type again against allowed types.
	$logger        = new SC_Logger( $type );
	$log_file_path = $logger->get_log_file_path_for_download();

	if ( ! $log_file_path || ! file_exists( $log_file_path ) ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'Log file not found or logger not configured correctly.', 'social-connect-pys' ),
			)
		);
	}

	// Generate download URL with nonce.
	$download_url = add_query_arg(
		array(
			'action'   => 'sc_download_log',
			'log_type' => $type,
			'_wpnonce' => wp_create_nonce( 'sc_download_log_' . $type ),
		),
		admin_url( 'admin.php' )
	);

	wp_send_json_success(
		array(
			'download_url' => $download_url,
		)
	);
}
add_action( 'wp_ajax_socplugDownloadLogsAjax', 'socplugAjaxDownloadLogs' );

/**
 * Handle log file download requests.
 *
 * @return void
 */
function socplug_handle_log_download() {

	// Check if the current user has permission to manage options.
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'social-connect-pys' ) );
	}

	// Get log type and nonce from query parameters.
	$log_type = isset( $_GET['log_type'] ) ? sanitize_key( $_GET['log_type'] ) : null;
	$nonce    = isset( $_GET['_wpnonce'] ) ? sanitize_key( $_GET['_wpnonce'] ) : null;

	// Verify nonce.
	if ( ! $log_type || ! $nonce || ! wp_verify_nonce( $nonce, 'sc_download_log_' . $log_type ) ) {
		wp_die( esc_html__( 'Invalid request or security check failed.', 'social-connect-pys' ) );
	}

	// Include the logger class.
	require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php';

	// Validate log type again against allowed types.
	$logger        = new SC_Logger( $log_type ); // Constructor validates type internally.
	$log_file_path = $logger->get_log_file_path_for_download(); // Need to add this method to SC_Logger.

	if ( ! $log_file_path || ! file_exists( $log_file_path ) ) {
		wp_die( esc_html__( 'Log file not found or logger not configured correctly.', 'social-connect-pys' ) );
	}

	// Prepare filename for download.
	$filename = basename( $log_file_path );

	// Set headers for file download.
	header( 'Content-Description: File Transfer' );
	header( 'Content-Type: text/plain' ); // Or application/octet-stream for generic binary.
	header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
	header( 'Expires: 0' );
	header( 'Cache-Control: must-revalidate' );
	header( 'Pragma: public' );
	header( 'Content-Length: ' . filesize( $log_file_path ) );

	// Clean output buffer.
	ob_clean();
	flush();

	// Read the file and output its contents.
	readfile( $log_file_path );

	// Stop script execution.
	exit;
}
add_action( 'admin_action_sc_download_log', 'socplug_handle_log_download' );

/**
 * Ajax clear logs
 *
 * @return void
 */
function socplugAjaxClearLogs() {
	$type  = isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : null;
	$nonce = isset( $_POST['nonce'] ) ? sanitize_key( $_POST['nonce'] ) : null;

	if ( ! $type || ! $nonce || ! wp_verify_nonce( $nonce, 'sc_clear_logs_' . $type ) ) {
		wp_send_json_error(
			array(
				'message'   => esc_html__( 'Invalid request or security check failed.', 'social-connect-pys' ),
				'clear_log' => false,
			)
		);
	}

	// Include the logger class.
	require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php';

	// Validate log type again against allowed types.
	$logger = new SC_Logger( $type );
	if ( ! $logger->clear_log() ) {
		wp_send_json_error(
			array(
				'message'   => esc_html__( 'Failed to clear logs.', 'social-connect-pys' ),
				'clear_log' => false,
			)
		);
	}

	wp_send_json_success(
		array(
			'message'   => esc_html__( 'Logs cleared successfully.', 'social-connect-pys' ),
			'clear_log' => true,
		)
	);
}
add_action( 'wp_ajax_socplugClearLogsAjax', 'socplugAjaxClearLogs' );
