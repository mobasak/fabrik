<?php
/**
 * Selector
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetFormElSelector( $data ) {
	$html  = '';
	$class = $data['class'] ?? '';

	if ( ! empty( $data['label'] ) ) {
		$html .= '<label for="' . esc_attr( $data['id'] ) . '" >' . esc_html( $data['label'] ) . '</label>';
	}

	if ( isset( $data['type'] ) && 'number' === $data['type'] ) {
		$html .= '<select name="' . esc_attr( $data['name'] ) . '" id="' . esc_attr( $data['id'] ) . '" class="custom-select ' . esc_attr( $class ) . '">';
		for ( $i = $data['from']; $i <= $data['to']; $i += $data['step'] ) {
			$html .= '<option value="' . esc_attr( $i ) . '" ' . selected( $data['selected'], $i, false ) . '>' . esc_html( $i ) . '</option>';
		}
		$html .= '</select>';
	} else {
		$html .= '<select name="' . esc_attr( $data['name'] ) . '" id="' . esc_attr( $data['id'] ) . '" class="custom-select ' . esc_attr( $class ) . '">';
		foreach ( $data['options'] as $key => $value ) {
			$html .= '<option value="' . esc_attr( $key ) . '" ' . selected( $data['selected'], $key, false ) . '>' . esc_html( $value ) . '</option>';
		}
		$html .= '</select>';
	}

	return $html;
}

/**
 * Color picker
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetFormElColorPicker( $data ) {

	$html = '';

	if ( ! empty( $data['label'] ) ) {
		$html .= '<label
			' . ( ! empty( $data['id'] ) ? 'for="' . esc_attr( $data['id'] ) . '"' : '' ) . '
			>' . esc_html( $data['label'] ) . '</label>';
	}

	$html .= '<div class="color-picker-wrapper">';
	$html .= '<input ' . ( ! empty( $data['name'] ) ? 'name="' . esc_attr( $data['name'] ) . '"' : '' ) . '
				placeholder="#FFFFFF"
				class="color-picker-input"
				readonly
				' . ( ! empty( $data['value'] ) ? 'value="' . esc_attr( $data['value'] ) . '"' : '' ) . '
				' . ( ! empty( $data['id'] ) ? 'id="' . esc_attr( $data['id'] ) . '"' : '' ) . '
				>';
	$html .= '<div class="color-picker"></div>';
	$html .= '</div>';

	return $html;
}

/**
 * Select design
 *
 * @param array $data The data.
 * @param bool  $order The order.
 *
 * @return string The HTML.
 */
function socplugGetFormElButtonsDesignAndPreview( $data, $order = false ) {
	$html = '<div class="select-design">';

	$html .= socplugGetFormElSelector(
		array(
			'label'    => $data['label'],
			'name'     => $data['name'],
			'id'       => $data['id'],
			'class'    => $data['class'],
			'options'  => array(
				'base'                  => __( 'Square color', 'social-connect-pys' ),
				'monochrome'            => __( 'Square monochrome', 'social-connect-pys' ),
				'circle'                => __( 'Circle color', 'social-connect-pys' ),
				'circle_monochrome'     => __( 'Circle monochrome', 'social-connect-pys' ),
				'big'                   => __( 'Square color (big)', 'social-connect-pys' ),
				'big_monochrome'        => __( 'Square monochrome (big)', 'social-connect-pys' ),
				'circle_big'            => __( 'Circle color (big)', 'social-connect-pys' ),
				'circle_big_monochrome' => __( 'Circle monochrome (big)', 'social-connect-pys' ),
				'full'                  => __( 'Wide color', 'social-connect-pys' ),
				'short'                 => __( 'Wide color (no text)', 'social-connect-pys' ),
			),
			'selected' => $data['selected'],
		)
	);

	/**
	 * Preview buttons
	 */
	$html .= '<div class= "select-design-preview corner-radius">';

	$options        = new SC_Social_Connect();
	$active_network = $options->getActiveProviders();

	if ( ! $order ) {
		$order = array( 'Facebook', 'Google' );
	}

	foreach ( $order as $network_name ) {
		if ( ! isset( $active_network[ $network_name ] ) ) {
			continue;
		}

		$html .= socplugGetNetworkLoginBtn( $network_name, ' ' . str_replace( '_', ' ', $data['selected'] ) );
	}

	$html .= '</div>';
	$html .= '</div>';

	return $html;
}

/**
 * Input number
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetFormElInputNumber( $data ) {
	$html = '<div class="custom-input-number">';

	if ( ! empty( $data['label'] ) ) {
		$html .= '<span class="input-number-label">' . esc_html( $data['label'] ) . '</span>';
	}

	$html .= '<div class="input-number-wrapper">';
	$html .= '<span class="input-number-button minus"></span>';
	$html .= '<input type="number" readonly name="' . esc_attr( $data['name'] ) . '" id="' . esc_attr( $data['id'] ) . '" min="0" max="999" value="' . esc_attr( $data['value'] ) . '">';
	$html .= '<span class="input-number-button plus"></span>';
	$html .= '</div>';

	$html .= '</div>';
	return $html;
}

/**
 * Input text
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetFormElInputText( $data ) {
	$html        = '';
	$placeholder = $data['placeholder'] ?? '';

	if ( ! empty( $data['label'] ) ) {
		$html .= '<label for="' . esc_attr( $data['id'] ) . '">' . esc_html( $data['label'] ) . '</label>';
	}

	if ( ! empty( $data['name'] ) && ! empty( $data['id'] ) ) {
		$html .= '<input type="text" value="' . esc_attr( $data['value'] ) . '" ' . ( ! empty( $data['attr'] ) ? $data['attr'] : '' ) . ' placeholder="' . esc_attr( $placeholder ) . '" name="' . esc_attr( $data['name'] ) . '" id="' . esc_attr( $data['id'] ) . '">';
	}

	if ( ! empty( $data['help_text'] ) ) {
		$html .= '<div class="settings-help-text ' . esc_attr( $data['class'] ) . '">' . esc_html( $data['help_text'] ) . '</div>';
	}

	return $html;
}

/**
 * Radio item
 *
 * @param array $radio The radio.
 *
 * @return string The HTML.
 */
function socplugGetFormElRadioItem( $radio ) {
	$html  = '<div class="custom-radio">';
	$html .= '<input type="radio" name="' . esc_attr( $radio['name'] ) . '" value="' . esc_attr( $radio['value'] ) . '" ' . checked( $radio['value'], $radio['selected'], false ) . ' id="' . esc_attr( $radio['id'] ) . '">';
	$html .= '<label for="' . esc_attr( $radio['id'] ) . '">' . esc_html( $radio['label'] ) . '</label>';
	$html .= '</div>';

	return $html;
}

/**
 * Radio group
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetFormElRadioGroup( $data ) {

	$html = '<div class="radio-group">';

	if ( ! empty( $data['radio'] ) ) {
		foreach ( $data['radio'] as $radio ) {
			$html .= socplugGetFormElRadioItem( $radio );
		}
	}

	$html .= '</div>';

	return $html;
}

/**
 * Textarea
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetFormElTextarea( $data ) {
	$html        = '';
	$placeholder = $data['placeholder'] ?? '';

	if ( ! empty( $data['label'] ) ) {
		$html .= '<label for="' . esc_attr( $data['id'] ) . '">' . esc_html( $data['label'] ) . '</label>';
	}

	$login_custom_text = stripslashes( $data['value'] );
	$html             .= '<textarea class="custom-textarea" name="' . esc_attr( $data['name'] ) . '" id="' . esc_attr( $data['id'] ) . '" rows="5" placeholder="' . esc_attr( $placeholder ) . '">' . esc_html( $login_custom_text ) . '</textarea>';

	return $html;
}

/**
 * Toggle
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetFormElToggle( $data ) {
	if ( empty( $data['name'] ) || empty( $data['id'] ) ) {
		return '';
	}

	$html  = '<div class="network-action-toggle">';
	$html .= '<label for="' . esc_attr( $data['id'] ) . '" class="switch ' . esc_attr( $data['class'] ) . '">';
	$html .= '<input type="hidden" name="' . esc_attr( $data['name'] ) . '"  value="false">';
	$html .= '<input type="checkbox" name="' . esc_attr( $data['name'] ) . '" value="true" id="' . esc_attr( $data['id'] ) . '" ' . checked( $data['selected'], 'true', false ) . '>';
	$html .= '<span class="slider"></span>';
	$html .= '</label>';
	if ( ! empty( $data['label'] ) ) {
		$html .= '<label for="' . esc_attr( $data['id'] ) . '" class="switcher-text">' . esc_html( $data['label'] ) . '</label>';
	}
	$html .= '</div>';

	return $html;
}

/**
 * Checkbox
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetFormElCheckbox( $data ) {
	if ( empty( $data['name'] ) || empty( $data['id'] ) ) {
		return '';
	}

	$html  = '<div class="custom-checkbox">';
	$html .= '<input type="hidden" name="' . esc_attr( $data['name'] ) . '" value="false" />';
	$html .= '<input type="checkbox" name="' . esc_attr( $data['name'] ) . '" value="true" ' . ( ! empty( $data['disabled'] ) ? 'disabled' : '' ) . ' id="' . esc_attr( $data['id'] ) . '" ' . checked( $data['selected'], 'true', false ) . '>';
	if ( ! empty( $data['label'] ) ) {
		$html .= '<label for="' . esc_attr( $data['id'] ) . '">' . esc_html( $data['label'] ) . '</label>';
	}
	$html .= '</div>';

	return $html;
}
