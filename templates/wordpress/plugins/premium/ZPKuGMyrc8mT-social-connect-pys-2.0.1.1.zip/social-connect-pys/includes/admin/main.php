<?php
/**
 * Social Connect - Admin functionality
 *
 * Handles admin menu, settings pages and license validation for the Social Connect plugin.
 *
 * @package SocialConnect
 */

require_once PYS_SOCIAL_CONNECT_PATH . '/includes/admin/functions.php';
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/admin/section-boxes.php';
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/admin/form-elements.php';

/**
 * Add admin menu items and handle license validation
 *
 * @return void
 */
function socplugAdminMenu() {
	$license   = get_option( 'socplug_license' );
	$valid_lic = false;

	if (
		! empty( $license['license_key'] )
		&& in_array( $license['license_status'], array( 'valid', 'expired' ), true )
	) {
		$valid_lic = true;
	}

	/**
	 * Set parent menu page
	 */
	add_menu_page(
		'Social Connect',
		'Social Connect',
		'manage_options',
		$valid_lic ? 'socplugAdminSettingsPage' : 'socplugAdminLicensePage',
		$valid_lic ? 'socplugAdminSettingsPage' : 'socplugAdminLicensePage',
		$valid_lic ? PYS_SOCIAL_CONNECT_URL . '/assets/images/favicon.png' : null
	);

	/**
	 * Add submenu pages only if license is valid
	 */
	if ( $valid_lic ) {
		add_submenu_page(
			'socplugAdminSettingsPage',
			'Social Connect settings',
			'Settings',
			'manage_options',
			'socplugAdminSettingsPage',
			'socplugAdminSettingsPage'
		);

		add_submenu_page(
			'socplugAdminSettingsPage',
			'Social Connect Logs',
			'Logs',
			'manage_options',
			'socplugAdminLogsPage',
			'socplugAdminLogsPage'
		);
	}

	/**
	 * Add License submenu (always visible)
	 */
	add_submenu_page(
		$valid_lic ? 'socplugAdminSettingsPage' : 'socplugAdminLicensePage',
		'Social Connect license',
		'License',
		'manage_options',
		'socplugAdminLicensePage',
		'socplugAdminLicensePage'
	);
}

add_action( 'admin_menu', 'socplugAdminMenu' );

/**
 * Display License page html
 *
 * @return void
 */
function socplugAdminLicensePage() {
	$menu = socplugGetSettingsMenuBar();

	$license      = get_option( 'socplug_license' );
	$licenseClass = new SC_Plugin_License();
	$logo_icon    = PYS_SOCIAL_CONNECT_URL . '/assets/images/icon-logo.svg';

	?>

	<div class="social-connect-container">
		<div class="socplug-loading-screen"><span class="loader"></span></div>
		<div class="social-connect-nav">
			<div class="social-connect-nav-logo">
				<?php
				if (
					'valid' !== $license['license_status']
					&& 'expired' !== $license['license_status']
				) {
					echo '<a href="#" class="social-connect-logo-link">';
				} else {
					echo '<a href="' . esc_url( PYS_SOCIAL_CONNECT_ADMIN_URL ) . '"
                    class="social-connect-logo-link">';
				}
				?>
				<img src="<?php echo esc_url( $logo_icon ); ?>" alt="Logo" class="social-connect-logo">
				</a>
			</div>
			<div class="social-connect-nav-menu">
				<?php
				/**
				 * Show menu
				 */
				foreach ( $menu as $value ) {
					if (
						'valid' === $license['license_status']
						|| ( 'expired' === $license['license_status']
							&& '' !== $license['license_key'] )
					) {
						echo '<a
                        href="' . esc_url( $value['url'] ) . '"
                        class="socplug-nav-link ' . esc_attr( $value['active'] ) . '">
                        ' . esc_html( $value['title'] ) . '
                        </a>';
					} else {
						echo '<a
                        href="#"
                        class="socplug-nav-link disabled-link">
                        ' . esc_html( $value['title'] ) . '
                        </a>';
					}
				}
				?>
			</div>
		</div>

		<?php
		echo wp_kses_post( socplugGetMobileNav() );
		?>

		<div class="social-connect">
			<?php $licenseClass->renderLicenseForm(); ?>
		</div>

	</div>
	<?php
}

/**
 * Display Custom Logs page html
 *
 * @return void
 */
function socplugAdminLogsPage() {
	$menu         = socplugGetSettingsMenuBar();
	$logo_icon    = PYS_SOCIAL_CONNECT_URL . '/assets/images/icon-logo.svg';
	$logs_data    = socplugGetLogsData();
	$logs_options = get_option( 'socplug_logs' );
	?>
	<div class="social-connect-container">
		<div class="socplug-loading-screen"><span class="loader"></span></div>
		<div class="social-connect-nav">
			<?php
			echo wp_kses_post(
				socplugGetSettingsNav(
					array(
						'logo_icon' => $logo_icon,
						'menu'      => $menu,
					)
				)
			);
			?>
		</div>

		<?php echo wp_kses_post( socplugGetMobileNav() ); ?>

		<div class="social-connect">
			<div class="settings-page-heading">
				<h2 class="page-heading"><?php esc_html_e( 'Logs', 'social-connect-pys' ); ?></h2>
			</div>

			<div class="socplug-settings-wrapper">
				<form action="#" class="settings-form" method="POST">
				<input type="hidden" name="socplug_save_options" value="true" />
				<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'true_update' ) ); ?>" />
				<input type="hidden" name="socplug_manage_options" value="true">
					<?php
					foreach ( $logs_data['log_types'] as $type ) :
						?>
						<div class="logs-<?php echo esc_attr( $type ); ?>" style="margin-bottom: 30px;">
							<div class="network-settings row-wrapper margin-top">
							<div class="network-settings-item">
								<div class="network-settings-item-inner gap">
									<div class="custom-logs-container">
										<!-- translators: %s: log type -->
										<h3>
											<?php
											// translators: %s: log type.
											$label = sprintf( __( '%s Logs', 'social-connect-pys' ), ucfirst( $type ) );

											echo wp_kses_post(
												socplugGetFormElToggle(
													array(
														'name' => 'socplug_logs[' . $type . ']',
														'id'   => 'socplug_logs' . $type . '',
														'selected' => $logs_options[ $type ] ?? 'false',
														'class' => 'second',
														'label' => $label,
													)
												)
											);

											?>
										</h3>
										<div class="logs-message"></div>
										<?php echo wp_kses_post( $logs_data['log_contents'][ $type ] ); ?>
										
									</div>
									<div class="logs-actions">
										<a href="#" data-type="<?php echo esc_attr( $type ); ?>" data-nonce="<?php echo wp_create_nonce( 'sc_download_log_' . $type ); ?>" class="logs-download-btn button socplug-button" style="margin-right: 10px;"><?php printf( esc_html__( 'Download %s Logs', 'social-connect-pys' ), esc_html( ucfirst( $type ) ) ); ?></a>
										<a href="#" data-type="<?php echo esc_attr( $type ); ?>" data-nonce="<?php echo wp_create_nonce( 'sc_clear_logs_' . $type ); ?>" class="logs-clear-btn button socplug-button" style="margin-right: 10px;"><?php printf( esc_html__( 'Clear %s Logs', 'social-connect-pys' ), esc_html( ucfirst( $type ) ) ); ?></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
				</form>
			</div>
		</div>

		<?php echo wp_kses_post( socplugGetSaveBar() ); ?>
	</div>
	<?php
}

/**
 * Display settings page html
 *
 * @return void
 */
function socplugAdminSettingsPage() {
	$menu      = socplugGetSettingsMenuBar();
	$logo_icon = PYS_SOCIAL_CONNECT_URL . '/assets/images/icon-logo.svg';
	?>
	<div class="social-connect-container">
		<div class="socplug-loading-screen"><span class="loader"></span></div>
		<div class="social-connect-nav">
			<?php
			echo wp_kses_post(
				socplugGetSettingsNav(
					array(
						'logo_icon' => $logo_icon,
						'menu'      => $menu,
					)
				)
			);
			?>
		</div>

		<?php echo wp_kses_post( socplugGetMobileNav() ); ?>

		<div class="social-connect">
			<?php
			$base_path = PYS_SOCIAL_CONNECT_PATH . '/includes/admin/settings/';
			$paths     = array(
				'woo'    => $base_path . 'settings-woocommerce.php',
				'main'   => $base_path . 'settings-main.php',
				'social' => $base_path . 'settings-config-network.php',
				'status' => $base_path . 'settings-status.php',
			);

			$section = isset( $_GET['section'] ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : '';
			if ( ! in_array( $section, array( 'woo', 'main', 'social', '' ), true ) ) {
				$section = 'status';
			}

			if ( 'woo' === $section ) {
				/**
				 * WooCommerce Settings
				 */
				include_once $paths['woo'];
			} elseif ( 'main' === $section ) {
				/**
				 * Main Settings
				 */
				include_once $paths['main'];
			} elseif ( 'social' === $section ) {
				/**
				 * Networks Settings
				 */
				include_once $paths['social'];
			} else {
				/**
				 * Status Settings
				 */
				include_once $paths['status'];
			}

			?>
		</div>

		<?php echo wp_kses_post( socplugGetSaveBar() ); ?>
	</div>
	<?php
}

/**
 * Get Save Bar HTML
 *
 * @return string
 */
function socplugGetSaveBar() {

	$html = '<div class="social-connect-save-bar">';

	/**
	 * Recomendation Link
	 */
	if ( ! empty( PYS_SOCIAL_CONNECT_VIDEO_URL ) && ! empty( PYS_SOCIAL_CONNECT_VIDEO_TITLE ) ) {

		$html .= '<div class="socplug-recomendation-link">';
		$html .= '<span>';
		$html .= esc_html__( 'Recommended: ', 'social-connect-pys' );
		$html .= '</span>';
		$html .= '<a href="' . esc_url( PYS_SOCIAL_CONNECT_VIDEO_URL ) . '" target="_blank" rel="noopener"
						class="socplug-recomendation-link-title">';
		$html .= esc_html( PYS_SOCIAL_CONNECT_VIDEO_TITLE );
		$html .= '</a>';
		$html .= '</div>';
	}

	$html .= '<div class="social-connect-action-save">';
	if ( isset( $_GET['section'] ) && 'social' === $_GET['section'] ) {
		$html .= '<a href="#" class="social-connect-back-btn socplug-button-filled socplug-blue-button">';
		$html .= esc_html__( 'Back', 'social-connect-pys' );
		$html .= '</a>';
	}

	$html .= '<a href="#" class="social-connect-save-btn">';
	$html .= esc_html__( 'Save Changes', 'social-connect-pys' );
	$html .= '</a>';
	$html .= '</div>';
	$html .= '</div>';

	return $html;
}

/**
 * Get Settings Nav
 *
 * @param array $data The data.
 *
 * @return string The HTML.
 */
function socplugGetSettingsNav( $data ) {
	$html  = '<div class="social-connect-nav-logo">';
	$html .= '<a href="' . esc_url( PYS_SOCIAL_CONNECT_ADMIN_URL ) . '" class="social-connect-logo-link">';
	$html .= '<img src="' . esc_url( $data['logo_icon'] ) . '" alt="Logo" class="social-connect-logo">';
	$html .= '</a>';
	$html .= '</div>';
	$html .= '<div class="social-connect-nav-menu">';

	/**
	 * Show menu
	 */
	foreach ( $data['menu'] as $value ) {
		$html .= '<a 
                    href="' . esc_url( $value['url'] ) . '" 
                    class="socplug-nav-link ' . esc_attr( $value['active'] ) . '">
                    ' . esc_html( $value['title'] ) . '
                    </a>';
	}

	$html .= '</div>';

	return $html;
}

/**
 * Get settings menu bar
 *
 * @return array
 */
function socplugGetSettingsMenuBar() {
	$license      = new SC_Plugin_License();
	$license_data = $license->getLicenseData();

	$menu = array(
		'main'     => array(
			'title'  => __( 'Main', 'social-connect-pys' ),
			'url'    => ( 'valid' === $license_data['license_status'] || 'expired' === $license_data['license_status'] ? PYS_SOCIAL_CONNECT_ADMIN_URL : '#' ),
			'active' => ( ! isset( $_GET['section'] ) && ! isset( $_GET['page'] ) ? 'active' : '' ),
		),
		'settings' => array(
			'title'  => __( 'Settings', 'social-connect-pys' ),
			'url'    => ( 'valid' === $license_data['license_status'] || 'expired' === $license_data['license_status'] ? PYS_SOCIAL_CONNECT_ADMIN_URL . '&section=main' : '#' ),
			'active' => ( isset( $_GET['section'] ) && 'main' === $_GET['section'] ? 'active' : '' ),
		),
	);

	/**
	 * Add Woocommerce page to menu if installed
	 */
	if ( class_exists( 'WooCommerce' ) ) {
		$menu['woo'] = array(
			'title'  => __( 'WooCommerce', 'social-connect-pys' ),
			'url'    => ( 'valid' === $license_data['license_status'] || 'expired' === $license_data['license_status'] ? PYS_SOCIAL_CONNECT_ADMIN_URL . '&section=woo' : '#' ),
			'active' => ( isset( $_GET['section'] ) && 'woo' === $_GET['section'] ? 'active' : '' ),
		);
	}

	/**
	 * Add Logs page to menu in the end
	 */
	$menu['logs'] = array(
		'title'  => __( 'Logs', 'social-connect-pys' ),
		'url'    => ( 'valid' === $license_data['license_status'] || 'expired' === $license_data['license_status'] ? admin_url( 'admin.php?page=socplugAdminLogsPage' ) : '#' ),
		'active' => ( isset( $_GET['page'] ) && 'socplugAdminLogsPage' === $_GET['page'] ? 'active' : '' ),
	);

	return $menu;
}
