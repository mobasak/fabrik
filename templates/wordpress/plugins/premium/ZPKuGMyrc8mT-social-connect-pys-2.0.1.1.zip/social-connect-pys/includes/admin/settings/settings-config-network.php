<?php
/**
 * Settings Config Network
 *
 * @package Social_Connect_Pys
 */

$network         = isset( $_GET['network'] ) ? sanitize_text_field( wp_unslash( $_GET['network'] ) ) : '';
$networks        = get_option( 'socplug_main_providers' );
$network_options = $networks['providers'][ ucfirst( $network ) ] ?? '';
$network_name    = ucfirst( $network );

?>
<div class="settings-page-heading">
	<?php /* translators: %s: Network name */ ?>
	<h2 class="page-heading"><?php printf( esc_html__( '%s Social Login', 'social-connect-pys' ), esc_html( $network_name ) ); ?></h2>
</div>
<div class="settings-network-config">
	<form action="#" method="POST" class="settings-form">
		<input type="hidden" name="socplug_save_options" value="true" />
		<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'true_update' ) ); ?>" />
		<input type="hidden" name="socplug_manage_providers" value="true">

		<div class="network-action row-wrapper">
			<?php
			/**
			 * Network Icon
			 */
			$icon = socplugGetIconmoonIcon( $network );
			echo '<span class="iconmoon network-icon network-icon-' . esc_attr( $network ) . '">' . wp_kses_post( $icon ) . '</span>';

			/**
			 * Network Name
			 */
			/* translators: %s: Network name */
			echo '<div class="form-row-heading">' . esc_html( sprintf( __( '%s Social Login', 'social-connect-pys' ), $network_name ) ) . '</div>';

			/**
			 * Network Toggle
			 */
			echo '<div class="network-action-toggle">
                <label class="switch" for="socplug_main_providers_providers_' . esc_attr( $network_name ) . '_enabled">
                    <input type="hidden" name="socplug_main_providers[providers][' . esc_attr( $network_name ) . '][enabled]"  value="false">
                    <input type="checkbox" name="socplug_main_providers[providers][' . esc_attr( $network_name ) . '][enabled]" value="true" id="socplug_main_providers_providers_' . esc_attr( $network_name ) . '_enabled" class="manage-network-toggle" ' . checked( $network_options['enabled'], 'true', false ) . '>
                    <span class="slider round"></span>
                </label>
            </div>';
			?>
		</div>

		<?php
		/**
		 * Questions Box
		 */
		?>
		<div class="network-config-steps network-settings row-wrapper margin-top">
			<div class="settings-row-heading info-icon form-row-heading">
				<?php
				/**
				 * Icon
				 */
				$icon = socplugGetIconmoonIcon( 'info' );
				echo '<span class="iconmoon network-icon network-icon-' . esc_attr( $network ) . '">' . wp_kses_post( $icon ) . '</span>';

				/**
				 * Title
				 */
				printf( 'How to get your %s App keys', esc_html( $network_name ) );

				/**
				 * Settings icon
				 */
				$settings_icon = socplugGetSettingsSvgIcon();
				echo '<div class="settings-icon">' . wp_kses_post( $settings_icon ) . '</div>';

				?>
			</div>
			<div class="network-config-steps-items network-settings-item-toggle-div">
				<div class="network-config-steps-items-inner">
					<?php echo wp_kses_post( socplugNetworkConfigurationSteps( $network ) ); ?>
				</div>
			</div>
		</div>

		<div class="network-keys row-wrapper margin-top">
			<div class="network-keys-heading form-row-heading">
				<?php
				/**
				 * Title
				 */
				printf( 'Your %s App Settings', esc_html( $network_name ) );
				?>
			</div>
			<div class="form-rows">
				<div class="field-row">
					<label for="socplug_network_settings_<?php echo esc_attr( $network_name ); ?>_keys_id">
						<?php esc_html_e( 'Client ID', 'social-connect-pys' ); ?>
					</label>
					<input type="text" value="<?php echo esc_attr( $network_options['keys']['id'] ); ?>"
						name="socplug_network_settings[<?php echo esc_attr( $network_name ); ?>][keys][id]"
						id="socplug_network_settings_<?php echo esc_attr( $network_name ); ?>_keys_id">
				</div>
				<div class="field-row">
					<label for="socplug_network_settings_<?php echo esc_attr( $network_name ); ?>_keys_secret">
						<?php esc_html_e( 'Client Secret', 'social-connect-pys' ); ?>
					</label>
					<?php
					$input_type = ! empty( $network_options['keys']['secret'] ) ? 'password' : 'text';
					?>
					<input type="<?php echo esc_attr( $input_type ); ?>" value="<?php echo esc_attr( $network_options['keys']['secret'] ); ?>"
						name="socplug_network_settings[<?php echo esc_attr( $network_name ); ?>][keys][secret]"
						id="socplug_network_settings_<?php echo esc_attr( $network_name ); ?>_keys_secret">
				</div>
				<!-- <div class="field-row">
					<a href="#" 
					class="socplug-check-config socplug-button-filled socplug-blue-button"
					data-link="<?php // echo esc_url( site_url( '/socplug/auth?provider=' . $network_name ) ); ?>"
					>
						<?php // esc_html_e( 'Check Configuration', 'social-connect-pys' ); ?>
					</a>
				</div>  -->
			</div>
		</div>
	</form>
</div>
