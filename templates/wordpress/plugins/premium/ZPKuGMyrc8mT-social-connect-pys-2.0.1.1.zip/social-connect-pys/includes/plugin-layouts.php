<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Function to set social login buttons to right position
 */

add_action( 'init', 'socplugSetSocialLoginButtons' );
function socplugSetSocialLoginButtons(): void {
	$social_connect = new SC_Social_Connect();
	$settings       = $social_connect->getLayoutSettings();
	$providers      = $social_connect->getActiveProviders();

	if ( empty( $settings ) || empty( $providers ) ) {
		return;
	}

	$is_register_page = isset( $_GET['action'] ) && $_GET['action'] === 'register';

	/**
	 * Handle register page
	 */
	if ( $is_register_page ) {
		socplugHandleRegisterPage( $settings );
	}

	/**
	 * Handle login page
	 */
	if ( ! $is_register_page ) {
		socplugHandleLoginPage( $settings );
	}

	/**
	 * Handle comments form
	 */
	socplugHandleCommentsForm( $settings );
}

function socplugHandleRegisterPage( $settings ): void {
	if ( $settings['socplug_main_form_register']['enable'] !== 'true' ) {
		return;
	}

	$register_settings = array(
		'position'    => $settings['socplug_main_form_register']['position'] ?? 'inside_top',
		'order'       => $settings['socplug_main_buttons']['order'] ?? array( 'Facebook', 'Google' ),
		'style'       => $settings['socplug_main_buttons']['style'] ?? 'base',
		'custom_text' => socplugGetCustomText( $settings, 'register' ),
		'form'        => 'register',
		'redirect'    => admin_url(),
	);

	add_action(
		'login_head',
		function () use ( $register_settings ) {
			echo wp_kses_post( socplugGetSocialLoginButtons( $register_settings ) );
		}
	);
}

function socplugHandleLoginPage( $settings ): void {
	if ( $settings['socplug_main_form_login']['enable'] !== 'true' ) {
		return;
	}

	$login_settings = array(
		'position'    => $settings['socplug_main_form_login']['position'] ?? 'inside_top',
		'order'       => $settings['socplug_main_buttons']['order'] ?? array( 'Facebook', 'Google' ),
		'style'       => $settings['socplug_main_buttons']['style'] ?? 'base',
		'custom_text' => socplugGetCustomText( $settings, 'login' ),
		'form'        => 'login',
		'redirect'    => admin_url(),
	);

	/**
	 * Default login page
	 */
	add_action(
		'login_head',
		function () use ( $login_settings ) {
			echo wp_kses_post( socplugGetSocialLoginButtons( $login_settings ) );
		}
	);

	/**
	 * WooCommerce login page
	 */
	if ( class_exists( 'WooCommerce' ) ) {
		$woocommerce_hooks = array(
			'inside_top'     => 'woocommerce_login_form_start',
			'inside_bottom'  => 'woocommerce_login_form_end',
			'outside_top'    => 'woocommerce_before_customer_login_form',
			'outside_bottom' => 'woocommerce_after_customer_login_form',
		);

		$login_settings['is_woocommerce'] = true;

		if ( isset( $woocommerce_hooks[ $settings['socplug_main_form_login']['position'] ] ) ) {
			add_action(
				$woocommerce_hooks[ $settings['socplug_main_form_login']['position'] ],
				function () use ( $login_settings ) {
					echo wp_kses_post( socplugGetSocialLoginButtons( $login_settings ) );
				}
			);
		}
	}
}

function socplugHandleCommentsForm( $settings ): void {
	if ( $settings['socplug_main_form_comments']['enable'] !== 'true' || is_user_logged_in() ) {
		return;
	}

	$comment_hooks = array(
		'inside_top'     => 'comment_form_top',
		'inside_bottom'  => 'comment_form_after_fields',
		'outside_top'    => 'comment_form_top',
		'outside_bottom' => 'comment_form_after_fields',
	);

	$comment_settings = array(
		'position'    => $settings['socplug_main_form_comments']['position'] ?? 'inside_top',
		'order'       => $settings['socplug_main_buttons']['order'] ?? array( 'Facebook', 'Google' ),
		'style'       => $settings['socplug_main_buttons']['style'] ?? 'base',
		'custom_text' => socplugGetCustomText( $settings, 'comments' ),
		'form'        => 'comments',
	);

	if ( isset( $comment_hooks[ $settings['socplug_main_form_comments']['position'] ] ) ) {
		add_action(
			$comment_hooks[ $settings['socplug_main_form_comments']['position'] ],
			function () use ( $comment_settings ) {
				echo wp_kses_post( socplugGetSocialLoginButtons( $comment_settings ) );
			}
		);
	}
}

/**
 * Get custom text
 *
 * @param array  $settings The settings array.
 * @param string $form_type The form type.
 *
 * @return string The custom text.
 */
function socplugGetCustomText( $settings, $form_type ): string {
	if (
		'true' === $settings['socplug_main_form_custom_text'][ $form_type ]['enable']
		&& ! empty( $settings['socplug_main_form_custom_text'][ $form_type ]['text'] )
	) {
		return $settings['socplug_main_form_custom_text'][ $form_type ]['text'];
	}
	return '';
}

/**
 * Get social login buttons
 *
 * @param array $settings The settings array.
 *
 * @return string The HTML output.
 */
function socplugGetSocialLoginButtons( $settings ): string {
	$is_woocommerce = isset( $settings['is_woocommerce'] ) ? $settings['is_woocommerce'] : false;
	$redirect       = isset( $settings['redirect'] ) ? $settings['redirect'] : false;
	$html           = '<div class="social-connect-replace-form ' . $settings['position'] . ' social-connect-replace-form-' . $settings['form'] . '" data-form="' . $settings['form'] . '" data-position="' . $settings['position'] . '" ' . ( ! $is_woocommerce ? 'style="display:none;"' : '' ) . '>';
	$html          .= '<div class="social-connect-custom-text">' . $settings['custom_text'] . '</div>';
	$html          .= '<div class="social-connect-buttons">';
	$html          .= '<div class="social-connect-buttons-wrapper">';
	$html          .= socplugGetButtons( $settings['order'], $settings['style'], $redirect );
	$html          .= '</div>';
	$html          .= '</div>';
	$html          .= '</div>';

	/**
	 * Enqueue scripts
	 */
	socplugAddCustomAssets( array( 'social-connect-main' ), array( 'social-connect-login-buttons', 'social-connect-layouts' ) );

	return $html;
}
