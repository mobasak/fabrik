<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php'; // Ensure logger is included

/**
 * Social connect class
 */
class SC_Social_Connect {

	/**
	 * Providers
	 *
	 * @var array
	 */
	protected $providers;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->providers = get_option( 'socplug_main_providers' );
	}

	/**
	 * Get all providers
	 *
	 * @return array
	 */
	public function getProvidersOptions() {
		return $this->sortProviders( $this->providers );
	}

	/**
	 * Sort providers Facebook first
	 *
	 * @param array $providers Providers.
	 * @return array[]
	 */
	public function sortProviders( $providers ) {
		return array(
			'providers' => array(
				'Facebook' => $providers['providers']['Facebook'] ?? array(),
				'Google'   => $providers['providers']['Google'] ?? array(),
			),
		);
	}

	/**
	 * Get login form options
	 *
	 * @return array
	 */
	public function getLoginFormOptions() {
		return get_option( 'socplug_shortcode_loginform' );
	}

	/**
	 * Get connect more options
	 *
	 * @return array
	 */
	public function getConnectMoreOptions() {
		return get_option( 'socplug_connectmore' );
	}

	/**
	 * Get woocommerce coupon options
	 */
	public function getWooCouponOptions() {
		return get_option( 'socplug_social_login_discount' );
	}

	/**
	 * Get social coupon data
	 */
	public function getSocialCouponData() {
		$data = $this->getWooCouponOptions();

		if ( ! empty( $data['enable'] )
			&& 'true' === $data['enable']
			&& ! empty( $data['coupon_id'] )
			&& 0 !== $data['coupon_id'] ) {
			$coupon = new WC_Coupon( $data['coupon_id'] );
			if ( null !== $coupon->get_id() ) {
				return $coupon;
			}

			return false;
		}

		return false;
	}

	/**
	 * Generate social coupon discount text
	 *
	 * @param string $text Text.
	 * @return string
	 */
	public function generateSocialCouponDiscountText( $text ) {

		if ( ! is_string( $text ) || empty( $text ) || ! str_contains( $text, 'XX%' ) ) {
			return $text;
		}

		$social_coupon = $this->getSocialCouponData();

		if ( ! $social_coupon ) {
			return $text;
		}

		$discount      = $social_coupon->get_amount();
		$discount_type = $social_coupon->get_discount_type();

		if ( 'percent' === $discount_type ) {
			$discount = $discount . '%';
		} elseif ( 'fixed_cart' === $discount_type ) {
			$discount = wc_price( $discount );
		}

		$text = str_replace( 'XX%', $discount, $text );

		return $text;
	}

	/**
	 * Get main buttons options
	 *
	 * @return array
	 */
	public function getMainButtonsOptions() {
		return get_option( 'socplug_main_buttons' );
	}

	/**
	 * Get all active providers
	 *
	 * @return array
	 */
	public function getActiveProviders() {
		$providers = $this->getProvidersOptions();
		return array_filter(
			$providers['providers'],
			function ( $provider ) {
				return (
					isset( $provider['enabled'] )
					&& ! empty( $provider['keys']['id'] )
					&& ! empty( $provider['keys']['secret'] )
					&& 'true' === $provider['enabled']
				);
			}
		);
	}

	/**
	 * Set default options, from default-settings.json
	 *
	 * @return void
	 */
	public function setDefaultOptions() {
		/**
		 *  Get data from json file
		 */
		$default_options = $this->getDefaultSettingsFromFile();

		if ( empty( $default_options ) ) {
			SC_Logger::record( 'system', 'setDefaultOptions: file with default settings is empty', 'error' );
			return;
		}

		$skipped_options = array(
			'socplug_license',
			'socplug_last_check_license',
			'socplug_main_providers',
		);

		/**
		 *  Update options
		 */
		foreach ( $default_options as $key => $value ) {
			if ( in_array( $key, $skipped_options ) ) {
				continue;
			}

			update_option( $key, $value );
		}
	}

	/**
	 * Get default settings from json file
	 *
	 * @return array
	 */
	private function getDefaultSettingsFromFile() {
		$default_settings = file_get_contents( PYS_SOCIAL_CONNECT_PATH . '/includes/default-settings.json' );
		$default_settings = json_decode( $default_settings, true );
		return $default_settings;
	}

	/**
	 * Set default options on plugin activation
	 *
	 * @return void
	 */
	public function onPluginActivation() {
		/**
		 *  Get data from json file
		 */
		$default_options = $this->getDefaultSettingsFromFile();

		if ( empty( $default_options ) ) {
			SC_Logger::record( 'system', 'onPluginActivation: file with default settings is empty', 'error' );
			return;
		}

		foreach ( $default_options as $key => $value ) {
			$saved_options = get_option( $key );
			if ( empty( $saved_options ) ) {
				update_option( $key, $value );
			}
		}
	}

	/**
	 * Get layout settings
	 *
	 * @return array
	 */
	public function getLayoutSettings() {
		return array(
			'socplug_main_form_comments'    => get_option( 'socplug_main_form_comments' ),
			'socplug_main_form_register'    => get_option( 'socplug_main_form_register' ),
			'socplug_main_form_login'       => get_option( 'socplug_main_form_login' ),
			'socplug_main_form_custom_text' => get_option( 'socplug_main_form_custom_text' ),
			'socplug_main_buttons'          => get_option( 'socplug_main_buttons' ),
		);
	}
}
