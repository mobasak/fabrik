<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php'; // Ensure logger is included

/**
 * Authentication class
 */
class SC_Authentication {

	/**
	 * Provider
	 *
	 * @var string
	 */
	public $provider;

	/**
	 * Hybridauth object
	 *
	 * @var object
	 */
	public function initHybridAuth() {
		static $hauth = null;

		if ( null !== $hauth ) {
			return $hauth;
		}

		/**
		 * Get active providers
		 */
		$social_connect   = new SC_Social_Connect();
		$active_providers = $social_connect->getActiveProviders();

		if ( empty( $active_providers ) || ! is_array( $active_providers ) ) {
			return $hauth;
		}

		$config = array();

		/**
		 * Add provider to callback url
		 */
		$config['callback'] = site_url( '/socplug/auth?provider=' ) . $this->provider;

		/**
		 * Set active providers
		 */
		$config['providers'] = $active_providers;

		$hauth = new \Hybridauth\Hybridauth( $config );
		return $hauth;
	}

	/**
	 * Main authenticate process
	 *
	 * @return void
	 */
	public function authenticateProcess() {
		/**
		 * Configure hybrid auth
		 */
		$hybridauth = $this->initHybridAuth();

		try {
			/**
			 * Authenticate user, if user is not connected, then return
			 */
			$adapter = $hybridauth->authenticate( $this->provider );
			if ( ! $adapter->isConnected() ) {
				SC_Logger::record( 'system', 'User is not connected', 'error' );
				return;
			}

			/**
			 * Get user profile
			 */
			$user_profile = $adapter->getUserProfile();

			/**
			 * Check if user profile is an object
			 */
			if ( ! is_object( $user_profile ) ) {
				SC_Logger::record( 'system', 'User profile is not an object', 'error' );
				return;
			}

			if ( is_user_logged_in() ) {
				/**
				 * User is logged in, so we need to update user by profile
				 */
				$this->updateUserByProfile( $user_profile );
			} else {
				/**
				 * User is not logged in, so we need to check if user email exist in our database, if not, then register user
				 */
				$this->searchOrRegisterUser( $user_profile );
			}
		} catch ( Exception $e ) {
			SC_Logger::record( 'system', 'Authenticate process failed - ' . $e->getMessage(), 'error' );
			return;
		}
	}

	/**
	 * Update user by profile
	 *
	 * @param object $user_profile User profile.
	 * @return void
	 */
	protected function updateUserByProfile( $user_profile ) {
		$user = new SC_User();
		$user->updateUserByProfileAfterAuth( $user_profile, $this->provider );
	}

	/**
	 * Search or register user
	 *
	 * @param object $user_profile User profile.
	 * @return void
	 */
	protected function searchOrRegisterUser( $user_profile ) {
		$user = new SC_User();
		$user->searchOrRegisterUser( $user_profile, $this->provider );
	}

	/**
	 * Logout all providers
	 *
	 * @param array $providers Providers.
	 * @return array
	 */
	public function logoutProviders( $providers = array() ) {
		$hybridauth         = $this->initHybridAuth();
		$disabled_providers = array();

		if ( ! isset( $hybridauth ) ) {
			return $disabled_providers;
		}

		/**
		 * Get all connected adapters, and disconnect them
		 */
		$connectedAdapters = $hybridauth->getConnectedAdapters();

		if ( empty( $connectedAdapters ) ) {
			SC_Logger::record( 'system', 'logoutProviders: User is not connected to any provider', 'info' );
			return $providers;
		}

		/**
		 * If providers is empty, disconnect all providers
		 * If providers is not empty, then disconnect only providers from this array
		 */
		foreach ( $connectedAdapters as $provider_name => $adapter ) {
			if ( empty( $providers ) ) {
				$adapter->disconnect();
				$disabled_providers[] = $provider_name;
				continue;
			}

			if ( in_array( $provider_name, $providers ) ) {
				$adapter->disconnect();
				$disabled_providers[] = $provider_name;
			}
		}

		return $disabled_providers;
	}
}
