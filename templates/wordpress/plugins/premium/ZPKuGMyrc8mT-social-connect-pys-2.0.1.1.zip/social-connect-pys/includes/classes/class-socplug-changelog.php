<?php
/**
 * Class for displaying changelog in admin area
 *
 * @package Social_Connect_Pys
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Socplug_Changelog
 */
class Socplug_Changelog {

	/**
	 * Changelog data
	 *
	 * @var array
	 */
	private $changelog_data;

	/**
	 * Initialize the class
	 */
	public function __construct() {
		add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );
		add_action( 'admin_init', array( $this, 'handle_changelog_display' ) );
		$this->load_changelog_data();
	}

	/**
	 * Load changelog data from file
	 */
	private function load_changelog_data() {
		$changelog_file = PYS_SOCIAL_CONNECT_PATH . '/includes/data/changelog.php';
		if ( file_exists( $changelog_file ) ) {
			$this->changelog_data = require $changelog_file;
		} else {
			$this->changelog_data = array();
		}
	}

	/**
	 * Add View Details link to plugin row
	 *
	 * @param array  $plugin_meta Plugin meta links
	 * @param string $plugin_file Plugin file
	 * @return array
	 */
	public function plugin_row_meta( $plugin_meta, $plugin_file ) {
		if ( plugin_basename( PYS_SOCIAL_CONNECT_PLUGIN_FILE ) === $plugin_file ) {
			$plugin_meta[] = sprintf(
				'<a href="%s" class="thickbox open-plugin-details-modal" aria-label="%s" data-title="%s">%s</a>',
				esc_url( network_admin_url( 'plugin-install.php?tab=plugin-information&plugin=social-connect-pys&section=changelog&TB_iframe=true&width=772&height=600' ) ),
				esc_attr( __( 'View Social Connect changelog', 'social-connect-pys' ) ),
				esc_attr( __( 'Social Connect by PixelYourSite', 'social-connect-pys' ) ),
				__( 'View details', 'social-connect-pys' )
			);
		}
		return $plugin_meta;
	}

	/**
	 * Handle changelog display in thickbox
	 */
	public function handle_changelog_display() {
		if ( isset( $_GET['tab'] ) && 'plugin-information' === $_GET['tab'] 
			&& isset( $_GET['plugin'] ) && 'social-connect-pys' === $_GET['plugin']
			&& isset( $_GET['section'] ) && 'changelog' === $_GET['section']
		) {
			$this->render_changelog_page();
			exit;
		}
	}

	/**
	 * Render changelog page
	 */
	public function render_changelog_page() {
		if ( defined( 'IFRAME_REQUEST' ) ) {
			?>
			<!DOCTYPE html>
			<html>
			<head>
				<meta charset="<?php bloginfo( 'charset' ); ?>">
				<title><?php _e( 'Plugin Information', 'social-connect-pys' ); ?></title>
				<?php wp_admin_css( 'install', true ); ?>
			</head>
			<body class="plugin-details-modal">
			<?php
		}
		?>
		<div class="wrap plugin-information">
			<h2><?php echo esc_html( __( 'Social Connect by PixelYourSite', 'social-connect-pys' ) ); ?></h2>
			<div class="socplug-changelog">
				<?php foreach ( $this->changelog_data as $version ) : ?>
					<h3><?php echo esc_html( $version['version'] ); ?></h3>
					<p class="release-date">Release Date – <?php echo esc_html( $version['release_date'] ); ?></p>
					<ul>
						<?php foreach ( $version['changes'] as $change ) : ?>
							<li><?php echo esc_html( $change ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endforeach; ?>
			</div>
		</div>
		<style>
			.socplug-changelog {
				padding: 20px;
				margin-top: 20px;
			}
			.socplug-changelog h2 {
				margin-top: 30px;
				padding-bottom: 10px;
				border-bottom: 1px solid #eee;
			}
			.socplug-changelog h3 {
				margin: 30px 0 5px;
				font-size: 1.4em;
			}
			.socplug-changelog .release-date {
				color: #646970;
				font-style: italic;
				margin: 0 0 15px;
			}
			.socplug-changelog ul {
				margin: 0 0 30px 20px;
				list-style: disc;
			}
			.socplug-changelog li {
				margin-bottom: 8px;
			}
		</style>
		<?php
		if ( defined( 'IFRAME_REQUEST' ) ) {
			?>
			</body>
			</html>
			<?php
		}
	}
} 
