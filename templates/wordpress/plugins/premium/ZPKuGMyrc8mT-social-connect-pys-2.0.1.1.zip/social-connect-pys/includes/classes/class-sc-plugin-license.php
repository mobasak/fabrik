<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once PYS_SOCIAL_CONNECT_PATH . '/includes/classes/class-sc-logger.php'; // Ensure logger is included

/**
 * SC_Plugin_License
 *
 * @package Social_Connect_Pys
 */
class SC_Plugin_License {

	/**
	 * License data
	 *
	 * @var array
	 */
	private $licenseData;

	/**
	 * Request URL
	 *
	 * @var string
	 */
	private $requestUrl;

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->licenseData = get_option( 'socplug_license' );
		$this->requestUrl  = 'https://www.pixelyoursite.com';
	}

	/**
	 * Get plugin slug
	 *
	 * @return string
	 */
	public function getSlug(): string {
		return PYS_SOCIAL_CONNECT_ITEM_NAME;
	}


	/**
	 * Get license data
	 *
	 * @return array
	 */
	public function getLicenseData(): array {
		if ( ! is_array( $this->licenseData ) ) {
			$default_license_data = array(
				'license_key'     => '',
				'license_status'  => '',
				'license_expires' => '',
			);

			update_option( 'socplug_license', $default_license_data );
			$this->licenseData = $default_license_data;
		}

		return $this->licenseData;
	}

	/**
	 * Get license input attributes
	 *
	 * @return array
	 */
	private function getLicenseInputAttributes(): array {
		$isValidOrExpired = in_array( $this->licenseData['license_status'], array( 'valid', 'expired' ), true );

		return array(
			'input_type'   => $isValidOrExpired ? 'password' : 'text',
			'input_attr'   => $isValidOrExpired ? 'readonly' : '',
			'button_style' => $isValidOrExpired ? 'socplug-green-button' : 'socplug-blue-button',
			'button_text'  => $isValidOrExpired ? 'Reactivate License' : 'Activate License',
		);
	}

	/**
	 * Render license form
	 *
	 * @return void
	 */
	public function renderLicenseForm() {
		$license_key    = $this->licenseData['license_key'] ?? '';
		$license_status = $this->licenseData['license_status'] ?? '';
		$licenseAttrs   = $this->getLicenseInputAttributes();
		$logo_url       = PYS_SOCIAL_CONNECT_URL . '/assets/images/icon-logo.svg';
		?>
		<div class="settings-page-heading">
			<h2 class="page-heading"><?php esc_html_e( 'Licenses', 'social-connect-pys' ); ?></h2>
		</div>
		<div
			class="socplug-settings-wrapper socplug-license-form-wrapper socplug-license-form-wrapper-<?php echo esc_attr( $license_status ); ?>">
			<form action="#" class="license-form" method="POST">
				<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( wp_create_nonce( 'license_form' ) ); ?>" />
				<input type="hidden" name="socplug_license_form" value="true">

				<div class="network-settings socplug-license-form row-wrapper margin-top ">
					<div class="settings-row-heading info-icon form-row-heading">
						<img src="<?php echo esc_url( $logo_url ); ?>" alt="Logo"
							class="social-connect-logo">
					<?php esc_html_e( 'SocialConnect', 'social-connect-pys' ); ?>
						<div class="license-action-status">
						<?php
						if ( 'valid' === $license_status || 'expired' === $license_status ) {
							?>
								<button class="socplug-deactivate-license socplug-button-filled socplug-red-button">
								<?php esc_html_e( 'Deactivate License', 'social-connect-pys' ); ?>
								</button>
								<?php
						}
						?>
						</div>
					</div>
					<div class="network-settings-item">
						<div class="network-settings-item-inner gap">
							<div class="input-box">
								<input type="<?php echo esc_attr( $licenseAttrs['input_type'] ); ?>" <?php echo esc_attr( $licenseAttrs['input_attr'] ); ?> name="socplug_license_key"
									id="socplug_license_key" value="<?php echo esc_attr( $license_key ); ?>" class="custom-input">
								<button type="submit"
									class="socplug-button-filled <?php echo esc_attr( $licenseAttrs['button_style'] ); ?>">
								<?php
								echo esc_html( $licenseAttrs['button_text'] );
								?>
								</button>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
			<?php
	}

	/**
	 * Get request params
	 *
	 * @param string $action     Action name.
	 * @param string $license_key License key.
	 * @return array
	 */
	public function getRequestParams( $action, $license_key ) {
		return array(
			'timeout'   => 120,
			'sslverify' => false,
			'body'      => array(
				'edd_action' => $action,
				'license'    => $license_key,
				'item_name'  => urlencode( $this->getSlug() ),
				'url'        => home_url(),
			),
		);
	}

	/**
	 * Deactivate license
	 *
	 * @return array
	 */
	public function deactivateLicense() {
		$license_key = $this->licenseData['license_key'];
		/**
		 *  Prepare API params
		 */
		$request  = $this->getRequestParams( 'deactivate_license', $license_key );
		$response = wp_remote_post( $this->requestUrl, $request );

		/**
		 *  Check if response is an error
		 */
		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => 'Error deactivating license',
				'type'    => 'error',
			);
		}

		/**
		 *  Return response
		 */
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		if ( empty( $license_data ) ) {
			return array(
				'success' => false,
				'message' => 'License data not found',
				'type'    => 'error',
			);
		}

		return $this->setDataLicense( $license_data, $license_key );
	}

	/**
	 *  Set license data
	 *
	 * @param array  $license_data License data.
	 * @param string $license_key License key.
	 * @return array
	 */
	public function setDataLicense( $license_data, $license_key ) {
		$result = array(
			'license_status'  => 'failed',
			'license_expires' => '',
			'license_key'     => '',
		);

		$message = array(
			'success' => false,
			'message' => __( 'License status not found', 'social-connect-pys' ),
			'type'    => 'error',
		);

		/**
		 *  Check if license data is isset
		 */
		if ( ! isset( $license_data->license ) ) {
			return $message;
		}

		/**
		 *  Update last check license time
		 */
		update_option(
			'socplug_last_check_license',
			array(
				'name' => $this->getSlug(),
				'time' => time(),
			)
		);

		/**
		 *  Map license statuses
		 */
		$license_status_map = $this->getLicenseStatusMap();

		/**
		 *  Get values from map
		 */
		if ( isset( $license_status_map[ $license_data->license ] ) ) {
			$status_data               = $license_status_map[ $license_data->license ];
			$result['license_status']  = $status_data['status'];
			$result['license_expires'] = 'valid' === $license_data->license || 'expired' === $license_data->license ? $license_data->expires : '';
			$result['license_key']     = 'valid' === $license_data->license || 'expired' === $license_data->license ? $license_key : '';

			$message['success'] = $status_data['success'];
			$message['message'] = $status_data['message'];
			$message['type']    = $status_data['type'];
		}

		/**
		 *  Update license in database
		 */
		update_option( 'socplug_license', $result );

		return $message;
	}

	/**
	 * Get license status map
	 *
	 * @return array
	 */
	private function getLicenseStatusMap(): array {
		return array(
			'deactivated'         => array(
				'status'  => 'deactivated',
				'message' => __( 'Your license was successfully deactivated for this site.', 'social-connect-pys' ),
				'success' => true,
				'type'    => 'warning',
			),
			'valid'               => array(
				'status'  => 'valid',
				'message' => __( 'Your license is working fine. Good job!', 'social-connect-pys' ),
				'success' => true,
				'type'    => 'success',
			),
			'expired'             => array(
				'status'  => 'expired',
				'message' => __( 'Your license has expired, please renew it.', 'social-connect-pys' ),
				'success' => true,
				'type'    => 'warning',
			),
			'missing'             => array(
				'status'  => 'invalid',
				'message' => __( 'Invalid license', 'social-connect-pys' ),
				'success' => false,
				'type'    => 'error',
			),
			'invalid'             => array(
				'status'  => 'invalid',
				'message' => __( 'Invalid license', 'social-connect-pys' ),
				'success' => false,
				'type'    => 'error',
			),
			'failed'              => array(
				'status'  => 'failed',
				'message' => __( 'License failed, please try again later. If the problem persists, contact our support.', 'social-connect-pys' ),
				'success' => false,
				'type'    => 'error',
			),
			'site_inactive'       => array(
				'status'  => 'site_inactive',
				'message' => __( 'Your license is not active for this URL.', 'social-connect-pys' ),
				'success' => false,
				'type'    => 'error',
			),
			'item_name_mismatch'  => array(
				'status'  => 'item_name_mismatch',
				'message' => sprintf( __( 'This appears to be an invalid license key for %s.', 'social-connect-pys' ), $this->getSlug() ),
				'success' => false,
				'type'    => 'error',
			),
			'no_activations_left' => array(
				'status'  => 'no_activations_left',
				'message' => __( 'Your license key has reached its activation limit.', 'social-connect-pys' ),
				'success' => false,
				'type'    => 'error',
			),
			'revoked'             => array(
				'status'  => 'revoked',
				'message' => __( 'Your license key has been disabled.', 'social-connect-pys' ),
				'success' => false,
				'type'    => 'error',
			),
		);
	}


	/**
	 * Activate license
	 *
	 * @param string $license_key License key.
	 * @return WP_Error|array
	 */
	public function activateLicense( $license_key ) {
		$request = $this->getRequestParams( 'activate_license', $license_key );

		$response = wp_remote_post( $this->requestUrl, $request );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		if ( empty( $license_data ) ) {
			return array(
				'success' => false,
				'message' => 'License data not found',
				'type'    => 'error',
			);
		}

		return $this->setDataLicense( $license_data, $license_key );
	}

	/**
	 * Cron to daily check license
	 *
	 * @return void
	 */
	public function cronCheckLicense() {
		$last_check_license = get_option( 'socplug_last_check_license' );

		if (
		(
			! $last_check_license
			|| empty( $last_check_license['time'] )
			|| $last_check_license['time'] < time()
		)
		&& $this->licenseData['license_key'] && ! empty( $this->licenseData['license_key'] )
		) {
			$this->singleCheckLicense();
		}
	}

	/**
	 * Single check license
	 *
	 * @return void
	 */
	public function singleCheckLicense() {
		$request  = $this->getRequestParams( 'check_license', $this->licenseData['license_key'] );
		$response = wp_remote_post( $this->requestUrl, $request );

		if ( is_wp_error( $response ) ) {
			SC_Logger::record( 'system', 'singleCheckLicense: ' . $response->get_error_message(), 'error' );
			return;
		}

		$license_data = json_decode( wp_remote_retrieve_body( $response ) );

		if ( empty( $license_data ) ) {
			SC_Logger::record( 'system', 'singleCheckLicense: License data is empty', 'error' );
			return;
		}

		$this->setDataLicense( $license_data, $this->licenseData['license_key'] );
	}
}
