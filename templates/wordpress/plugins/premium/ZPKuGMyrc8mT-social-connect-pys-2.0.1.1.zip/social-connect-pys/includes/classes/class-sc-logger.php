<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SC_Logger
 *
 * Handles logging functionality for the Social Connect plugin.
 *
 * @package SocialConnect
 */
class SC_Logger {

	/**
	 * Log file path.
	 *
	 * @var string|null
	 */
	private $log_file_path = null;

	/**
	 * Log type (e.g., system, facebook, google).
	 *
	 * @var string
	 */
	private $log_type;

	/**
	 * Allowed log types.
	 *
	 * @var array
	 */
	private const ALLOWED_TYPES = array( 'system', 'facebook', 'google' );

	/**
	 * Constructor.
	 *
	 * @param string $type The type of log (system, facebook, google). Defaults to 'system'.
	 */
	public function __construct( string $type = 'system' ) {
		$this->log_type = in_array( $type, self::ALLOWED_TYPES, true ) ? $type : 'system';
		$this->set_log_file_path();
	}

	/**
	 * Set the log file path based on the log type.
	 *
	 * Creates the log directory if it doesn't exist.
	 */
	private function set_log_file_path() {
		$upload_dir = wp_upload_dir();
		// Define a specific subdirectory for our logs within uploads.
		$log_dir = $upload_dir['basedir'] . '/social-connect-pys-logs';

		// Create the directory if it doesn't exist.
		if ( ! file_exists( $log_dir ) ) {
			// Use wp_mkdir_p for potentially nested directory creation.
			wp_mkdir_p( $log_dir );

			// Optionally, add an index.php or .htaccess file for security.
			// Prevent directory listing.
			if ( ! file_exists( $log_dir . '/index.php' ) ) {
				file_put_contents( $log_dir . '/index.php', '<?php // Silence is golden.' );
			}
			if ( ! file_exists( $log_dir . '/.htaccess' ) && function_exists( 'insert_with_markers' ) ) {
				$htaccess_content = "Options -Indexes\n";
				insert_with_markers( $log_dir . '/.htaccess', 'SocialConnectLogs', $htaccess_content );
			}
		}

		// Generate filename based on type.
		$filename            = sprintf( 'social-connect-pys-%s.log', $this->log_type );
		$this->log_file_path = $log_dir . '/' . $filename;
	}

	/**
	 * Log a message to the file.
	 *
	 * @param string $message The message to log.
	 * @param string $level The log level (e.g., 'info', 'warning', 'error'). Defaults to 'info'.
	 */
	public function log( string $message, string $level = 'info' ) {
		if ( empty( $this->log_file_path ) ) {
			// Error: Log file path not set (could happen if directory is not writable, though unlikely here).
			error_log( sprintf( 'SC_Logger Error (%s): Log file path is not set.', $this->log_type ) );
			return;
		}

		$timestamp = gmdate( 'Y-m-d H:i:s' );
		$log_entry = sprintf( "[%s] [%s] %s\n", $timestamp, strtoupper( $level ), $message );

		// Append the log entry to the file.
		// Use LOCK_EX to prevent conflicts when writing concurrently.
		file_put_contents( $this->log_file_path, $log_entry, FILE_APPEND | LOCK_EX );
	}

	/**
	 * Get the content of the log file.
	 *
	 * @return string|false Log file content or false on failure.
	 */
	public function get_log_content() {
		if ( file_exists( $this->log_file_path ) ) {
			return file_get_contents( $this->log_file_path );
		}
		return false;
	}

	/**
	 * Clear the log file.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function clear_log() {
		if ( file_exists( $this->log_file_path ) ) {
			// Use LOCK_EX to prevent conflicts when writing concurrently.
			return file_put_contents( $this->log_file_path, '', LOCK_EX ) !== false;
		}
		return true; // No file to clear, considered success.
	}

	/**
	 * Get the full path to the log file.
	 *
	 * Added specifically for the download handler to access the path.
	 *
	 * @return string|null The log file path or null if not set.
	 */
	public function get_log_file_path_for_download(): ?string {
		return $this->log_file_path;
	}

	/**
	 * Static method to log a message to a specific log type file.
	 *
	 * Convenience method so you don't have to instantiate the logger every time.
	 *
	 * @param string $type    The type of log (system, facebook, google).
	 * @param string $message The message to log.
	 * @param string $level   The log level (e.g., 'info', 'warning', 'error'). Defaults to 'info'.
	 */
	public static function record( string $type, string $message, string $level = 'info' ) {
		// Basic validation of type, although the constructor handles defaulting.
		if ( ! in_array( $type, self::ALLOWED_TYPES, true ) ) {
			error_log( 'SC_Logger::record called with invalid type: ' . $type . '. Defaulting to system log for this message.' );
			$type = 'system';
		}

		// Check if logging is enabled for this type in WordPress options.
		$log_options = get_option( 'socplug_logs' );

		// Determine if logging is explicitly enabled for this type.
		// Consider '1', 'true', 'yes', 'on' or boolean true as enabled. Assume disabled otherwise.
		$is_enabled = false; // Default to disabled.
		if ( isset( $log_options[ $type ] ) ) {
			$value = $log_options[ $type ];
			// Check for boolean true first.
			if ( true === $value ) {
				$is_enabled = true;
			} else {
				// Check for specific string values that mean enabled.
				$enabled_strings = array( '1', 'true', 'yes', 'on' );
				if ( is_string( $value ) && in_array( strtolower( $value ), $enabled_strings, true ) ) {
					$is_enabled = true;
				}
			}
		}

		// Return early if logging is not enabled for this type.
		if ( ! $is_enabled ) {
			// Logging is disabled for this type, so we stop execution here.
			return;
		}

		try {
			$logger = new self( $type ); // Create an instance for the specified type.
			$logger->log( $message, $level );
		} catch ( Exception $e ) {
			// Log potential errors during logger instantiation or logging itself to PHP error log.
			error_log( 'Error using SC_Logger::record: ' . $e->getMessage() );
		}
	}
}
