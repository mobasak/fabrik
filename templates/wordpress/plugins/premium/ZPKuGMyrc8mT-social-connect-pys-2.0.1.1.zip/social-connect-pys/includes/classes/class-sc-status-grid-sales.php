<?php

if (!defined('ABSPATH')) {
    exit;
}


class SC_Status_Grid_Sales extends WC_Admin_Report
{

    private $reportData;

    public function getReportData()
    {

        if (empty($this->reportData)) {

            $this->queryReportData();
        }

        return $this->reportData;
    }

    private function queryReportData()
    {

        $this->reportData = new stdClass;

        $this->reportData->order_counts = (array) $this->get_order_report_data(array(
            'nocache' => true,
            'data' => array(
                'ID' => array(
                    'type' => 'post_data',
                    'function' => 'COUNT',
                    'name' => 'count',
                    'distinct' => true,
                ),
                'post_date' => array(
                    'type' => 'post_data',
                    'function' => '',
                    'name' => 'post_date'
                )
            ),
            'where_meta' => array(
                array(
                    'meta_key' => 'socplug_user_networks',
                    'meta_value' => '',
                    'operator' => '!='
                )
            ),
            'group_by' => $this->group_by_query,
            'order_by' => 'post_date ASC',
            'query_type' => 'get_results',
            'filter_range' => true,
            'order_types' => wc_get_order_types('order-count'),
            'order_status' => array('completed', 'processing', 'on-hold', 'refunded')
        ));

        /**
         * Order totals by date. Charts should show GROSS amounts to avoid going -ve.
         */
        $this->reportData->orders = (array) $this->get_order_report_data(array(
            'nocache' => true,
            'data' => array(
                '_order_total' => array(
                    'type' => 'meta',
                    'function' => 'SUM',
                    'name' => 'total_sales'
                ),
                '_order_shipping' => array(
                    'type' => 'meta',
                    'function' => 'SUM',
                    'name' => 'total_shipping'
                ),
                '_order_tax' => array(
                    'type' => 'meta',
                    'function' => 'SUM',
                    'name' => 'total_tax'
                ),
                '_order_shipping_tax' => array(
                    'type' => 'meta',
                    'function' => 'SUM',
                    'name' => 'total_shipping_tax'
                ),
                'post_date' => array(
                    'type' => 'post_data',
                    'function' => '',
                    'name' => 'post_date'
                ),
            ),
            'where_meta' => array(
                array(
                    'meta_key' => 'socplug_user_networks',
                    'meta_value' => '',
                    'operator' => '!='
                )
            ),
            'group_by' => $this->group_by_query,
            'order_by' => 'post_date ASC',
            'query_type' => 'get_results',
            'filter_range' => true,
            'order_types' => wc_get_order_types('sales-reports'),
            'order_status' => array('completed', 'processing', 'on-hold', 'refunded')
        ));

        if (count($this->reportData->orders) > 0) {

            // Total the refunds and sales amounts. Sales subract refunds.
            $this->reportData->total_sales = wc_format_decimal(array_sum(wp_list_pluck($this->reportData->orders, 'total_sales')), 2);

            // Total orders and discounts also includes those which have been refunded at some point
            $this->reportData->total_orders = absint(array_sum(wp_list_pluck($this->reportData->order_counts, 'count')));
        }
    }
}
