<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * User class
 */
class SC_User {

	/**
	 * User ID
	 *
	 * @var int
	 */
	public $userId;

	/**
	 * User has connected providers
	 *
	 * @var bool
	 */
	public $userHasConnected;

	/**
	 * Constructor
	 *
	 * @param int|null $user_id User ID.
	 */
	public function __construct( $user_id = null ) {
		$this->userId           = ( ! empty( $user_id ) ) ? $user_id : get_current_user_id();
		$this->userHasConnected = ! empty( $this->getUserConnectedProviders() );
	}

	/**
	 * Check if user has avatar from social connect plugin and return it
	 *
	 * @return bool
	 */
	public function getSocplugAvatar() {
		$user_avatar_facebook = get_user_meta( $this->userId, '_socplug_avatar_Facebook', true );
		if ( $user_avatar_facebook ) {
			return $user_avatar_facebook;
		}

		$user_avatar_google = get_user_meta( $this->userId, '_socplug_avatar_Google', true );
		if ( $user_avatar_google ) {
			return $user_avatar_google;
		}

		return false;
	}

	/**
	 * Get user connected providers
	 *
	 * @return array
	 */
	public function getUserConnectedProviders() {
		return get_user_meta( $this->userId, '_socplug_social_providers', true );
	}

	/**
	 * Get user data by user id
	 *
	 * @return bool|WP_User
	 */
	public function getUserData() {
		return get_user_by( 'id', $this->userId );
	}

	/**
	 * Get user provider name
	 *
	 * @param string $provider Provider name.
	 * @return string
	 */
	public function getUserProviderName( $provider ) {
		return get_user_meta( $this->userId, '_socplug_social_user_' . $provider, true );
	}

	/**
	 * Get user provider last login
	 *
	 * @param string $provider Provider name.
	 * @return string
	 */
	public function getUserProviderLastLogin( $provider ) {
		return get_user_meta( $this->userId, '_socplug_social_lastlogin_' . $provider, true );
	}

	/**
	 * Check if provider is connected to user
	 *
	 * @param string $provider Provider name.
	 * @return bool
	 */
	public function isProviderConnected( $provider ) {
		$providers = $this->getUserConnectedProviders();
		return in_array( $provider, $providers );
	}

	/**
	 * Get user by social id
	 *
	 * @param mixed $service Service name.
	 * @param mixed $social_id Social ID.
	 * @return mixed
	 */
	public function getUserBySocialId( $service, $social_id ) {
		$users = get_users(
			array(
				'meta_key'   => '_socplug_social_id_' . $service,
				'meta_value' => $social_id,
				'number'     => 1,
				'fields'     => 'ids',
			)
		);

		return ! empty( $users ) ? reset( $users ) : false;
	}

	/**
	 * Get user by email
	 *
	 * @param string $email Email.
	 * @return mixed
	 */
	public function getUserByEmail( $email ) {
		return get_user_by( 'email', $email );
	}

	/**
	 * Add provider login (Facebook, Google, etc) to user
	 *
	 * @param string $provider Provider name.
	 * @return void
	 */
	public function addProviderToUser( $provider ) {
		$current_user_providers = $this->getUserConnectedProviders();

		if ( empty( $current_user_providers ) ) {
			$current_user_providers = array();
		}

		if ( is_array( $current_user_providers ) && ! in_array( $provider, $current_user_providers ) ) {
			$current_user_providers[] = $provider;
			update_user_meta( $this->userId, '_socplug_social_providers', $current_user_providers );
		}
	}

	/**
	 * Save social id on user
	 *
	 * @param string $provider Provider name.
	 * @param object $user_profile User profile object.
	 * @return void
	 */
	public function saveSocialIdOnUser( $provider, $user_profile ) {
		$socplug_settings_facebook = get_option( 'socplug_settings_facebook' );
		if ( 'Facebook' === $provider && 'true' === $socplug_settings_facebook['enable'] ) {
			update_user_meta( $this->userId, '_socplug_social_id_' . $provider, $user_profile->identifier );
		}
	}

	/**
	 * Check if user has social discount
	 *
	 * @param int|null $id User ID.
	 * @param bool     $is_new Is new user.
	 * @return void
	 */
	public function checkUserHasSocialDiscount( $id = null, $is_new = false ) {
		if ( null === $id ) {
			$id = $this->userId;
		}

		if ( $is_new ) {
			update_user_meta( $id, '_socplug_social_discount_used', 0 );
			return;
		}

		$social_discount = get_user_meta( $id, '_socplug_social_discount_used' );
		if ( empty( $social_discount ) ) {
			update_user_meta( $id, '_socplug_social_discount_used', 0 );
		}
	}

	/**
	 * Get user social discount data
	 */
	public function getUserSocialDiscountData() {
		return get_user_meta( $this->userId, '_socplug_social_discount_used', true );
	}

	/**
	 * Set user social discount data
	 *
	 * @param int $value Value.
	 * @return void
	 */
	public function setUserSocialDiscountData( $value ) {
		update_user_meta( $this->userId, '_socplug_social_discount_used', $value );
	}


	/**
	 * Update last login time to this provider
	 *
	 * @param string $provider Provider name.
	 * @return void
	 */
	public function updateLastLoginTime( $provider ) {
		update_user_meta(
			$this->userId,
			'_socplug_social_lastlogin_' . $provider,
			time()
		);
	}

	/**
	 * Set social user name
	 *
	 * @param string $provider Provider name.
	 * @param object $user_profile User profile object.
	 * @return void
	 */
	public function setSocialUserName( $provider, $user_profile ) {
		$social_user = get_user_meta( $this->userId, '_socplug_social_user_' . $provider, true );
		if ( empty( $social_user ) ) {
			add_user_meta(
				$this->userId,
				'_socplug_social_user_' . $provider,
				( isset( $user_profile->displayName ) ? $user_profile->displayName : $user_profile->email )
			);
		}
	}

	/**
	 * Update user by profile after authentication
	 *
	 * @param object $user_profile User profile object.
	 * @param string $provider Provider name.
	 * @return void
	 */
	public function updateUserByProfileAfterAuth( $user_profile, $provider ) {
		$user_data = $this->getUserData();
		if ( ! $user_data ) {
			SC_Logger::record( 'system', 'Update user by profile after auth: User data not found', 'error' );
			return;
		}

		if ( 'Facebook' === $provider ) {
			SC_Logger::record( 'facebook', 'User successfully authorized with Facebook', 'info' );
			SC_Logger::record( 'facebook', 'User ID: ' . $this->userId, 'info' );
		}

		if ( 'Google' === $provider ) {
			SC_Logger::record( 'google', 'User successfully authorized with Google', 'info' );
			SC_Logger::record( 'google', 'User ID: ' . $this->userId, 'info' );
		}

		/**
		 * Check if user has avatar, if yes, then import avatar
		 */
		$image_url = $user_profile->photoURL ?? '';
		if ( '' !== $image_url ) {
			socplugImportAvatar( $image_url, $this->userId, $provider );
		}

		/**
		 * Check if user has social providers, if not, then add provider
		 */
		$this->addProviderToUser( $provider );

		/**
		 * Check if provider is Facebook, and option save social login id is enabled, then save social login id
		 */
		$this->saveSocialIdOnUser( $provider, $user_profile );

		/**
		 * Check if user has applied social discount
		 */
		$this->checkUserHasSocialDiscount();

		/**
		 * Set social user name if empty
		 */
		$this->setSocialUserName( $provider, $user_profile );

		/**
		 * Update last login time
		 */
		$this->updateLastLoginTime( $provider );

		/**
		 * Redirect to connectmore page
		 */
		setcookie( 'socplug_redirect_after_auth', true, time() + 300, '/' );
	}

	/**
	 * Search or register user
	 *
	 * @param object $user_profile User profile object.
	 * @param string $provider Provider name.
	 */
	public function searchOrRegisterUser( $user_profile, $provider ) {
		/**
		 * Try to find user by social ID first
		 */
		$user_id = $this->getUserBySocialId( $provider, $user_profile->identifier );

		/**
		 * If not found by social ID, try to find by email
		 */
		if ( ! $user_id && ! empty( $user_profile->email ) ) {
			$user    = $this->getUserByEmail( $user_profile->email );
			$user_id = $user ? $user->ID : false;
		}

		/**
		 * If user registration is disabled, then redirect to login page
		 */
		if ( ! get_option( 'users_can_register' ) ) {
			SC_Logger::record( 'system', 'User not found, and user registration is disabled on site', 'error' );
			setcookie( 'socplug_redirect_after_auth', true, time() + 300, '/' );

			return false;
		}

		/**
		 * If still not found, register new user
		 */
		if ( ! $user_id ) {
			$user_id = $this->registerUser( $user_profile );
			if ( ! $user_id ) {
				SC_Logger::record( 'system', 'User not found, and user registration failed', 'error' );
				return false;
			}
		}

		/**
		 * Set user id for current user
		 */
		$this->userId = $user_id;

		/**
		 * Authorize user
		 */
		wp_set_auth_cookie( $user_id, true );

		if ( 'Facebook' === $provider ) {
			SC_Logger::record( 'facebook', 'User successfully authorized with Facebook', 'info' );
			SC_Logger::record( 'facebook', 'User ID: ' . $user_id, 'info' );
		}

		if ( 'Google' === $provider ) {
			SC_Logger::record( 'google', 'User successfully authorized with Google', 'info' );
			SC_Logger::record( 'google', 'User ID: ' . $user_id, 'info' );
		}

		/**
		 * Check if user has social discount, if yes, then add discount
		 */
		$this->checkUserHasSocialDiscount();

		/**
		 * Check if user have avatar, if yes, then import avatar
		 */
		if ( ! empty( $user_profile->photoURL ) ) {
			socplugImportAvatar( $user_profile->photoURL, $user_id, $provider );
		}

		/**
		 * Check if user has social providers, if not, then add provider
		 */
		$this->addProviderToUser( $provider );

		/**
		 * Save social id on user
		 */
		$this->saveSocialIdOnUser( $provider, $user_profile );

		/**
		 * Set social user name
		 */
		$this->setSocialUserName( $provider, $user_profile );

		/**
		 * Update last login time
		 */
		$this->updateLastLoginTime( $provider );

		/**
		 * Redirect to register
		 */
		setcookie( 'socplug_redirect_after_auth', true, time() + 300, '/' );
	}

	/**
	 * Register user
	 *
	 * @param object $user_profile User profile object.
	 * @return int
	 */
	public function registerUser( $user_profile ) {
		$email      = $user_profile->email;
		$user_login = ! empty( $email ) ? $email : $user_profile->identifier;
		$nickname   = $user_profile->firstName . ' ' . $user_profile->lastName;

		$user_data = array(
			'user_pass'       => $user_profile->identifier,
			'user_login'      => $user_login,
			'user_email'      => $email,
			'nickname'        => $nickname,
			'display_name'    => $user_profile->displayName,
			'first_name'      => $user_profile->firstName ?? '',
			'last_name'       => $user_profile->lastName ?? '',
			'user_registered' => date( 'Y-m-d H:i:s' ),
		);

		$user_id = wp_insert_user( $user_data );

		/**
		 * If WooCommerce is active, then add WooCommerce user meta
		 */
		if ( class_exists( 'WooCommerce' ) ) {
			$this->addWoocommerceUserMeta( $user_id, $user_profile );
		}

		if ( is_wp_error( $user_id ) ) {
			SC_Logger::record( 'system', 'Error while registering user', 'error' );
			SC_Logger::record( 'system', print_r( $user_id->get_error_message(), true ), 'error' );
			return 0;
		}

		$this->registered = true;

		/**
		 * Save registration timestamp
		 */
		update_user_meta( $user_id, '_socplug_reg_timestamp', time() );

		return $user_id;
	}

	/**
	 * Add WooCommerce user meta
	 *
	 * @param int    $user_id User ID.
	 * @param object $user_profile User profile object.
	 * @return void
	 */
	public function addWoocommerceUserMeta( $user_id, $user_profile ) {
		add_user_meta( $user_id, 'billing_email', $user_profile->email );
		add_user_meta( $user_id, 'billing_first_name', $user_profile->firstName );
		add_user_meta( $user_id, 'billing_last_name', $user_profile->lastName );
	}
}
