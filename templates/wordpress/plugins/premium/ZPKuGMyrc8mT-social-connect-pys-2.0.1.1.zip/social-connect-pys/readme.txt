## Web Design Sun® Plugin Build

- Contributors: Web Design Sun®
- Requires at least: 6.1
- Tested up to: 6.4

## Description

This Custom Plugin is Unique and Created with Soul and Care in a Single Copy only for PixelYourSite by Web Design Sun®. The plugin utilizes a modern technology stack including SCSS for styles, Gulp for builds and structured template code for improved development. 

## Server technical requirements

- PHP >= 7.4.33
- MariaDB >= 10.5.27
- Apache
- curl, gd, mbstring, openssl, xml, zip
- Node.js >= 18.20.5
- NPM >= 10.8.2
- NPX >= 10.8.2
- Gulp >= 4.0.2

## Install dependencies and run the builder

- npm install                     # Dependency management

## Gulp commands

- gulp watch                      # Watch for changes and compile
- gulp styles                     # Compile scss into css
- gulp scripts                    # Compile js and minify
- gulp build                      # Create Production Archive


## Project structure

social-connect-pys/
│
├── assets/                       # Static resources
│   ├── css/                      # Compiled CSS files
│   ├── fonts/                    # Fonts
│   ├── images/                   # Images
│   ├── js/                       # JavaScript files
│   ├── js_gulp/                  # JavaScript files for Gulp
│   └── scss/                     # Source files SCSS
│
├── includes/                     # Supporting functions and plugin hooks
│   ├── admin/                    # Admin functions and hooks
│   ├── classes/                  # Classes
│   ├── elementor/                # Elementor functions and widgets
│   ├── network-config-steps/     # Network config steps
│   ├── shortcodes/               # Shortcodes
│   ├── widgets/                  # Widgets
│   ├── woocommerce/              # WooCommerce functions
│   ├── functions.php             # Theme functions
│   ├── plugin-activation.php     # Plugin activation functions
│   ├── plugin-assets.php         # Plugin assets functions
│   ├── plugin-authentication.php # Plugin authentication functions
│   ├── plugin-layouts.php        # Plugin layouts functions
│   ├── plugin-license.php        # Plugin license functions
│   ├── plugin-shortcodes.php     # Plugin shortcodes functions
│   ├── plugin-user-avatar.php    # Plugin user avatar functions
│   ├── plugin-widgets.php        # Plugin widgets functions
│   └── socplug-auth-handler.php  # Plugin auth handler functions

│
├── vendor/                       # Vendor files
│   ├── hybridauth/               # HybridAuth library

└── social-connect-pys.php        # The main plugin file

## Fonts used From Google fonts

    Noto Sans
        Copyright 2022 The Noto Project Authors (https://github.com/notofonts/latin-greek-cyrillic)
        License: SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007

## Plugin Description

This is a social media plugin that allows you to connect your social media accounts to your WordPress site.
It adds the ability to log in to your site using social media, or create an account if you are logging in for the first time.

## Plugin Features

- Create an account using social networks
- Authorize using social networks
- Add a coupon for connected accounts (Woocommerce)
- Track sales / orders of connected accounts (Woocommerce)

## Plugin Shortcodes

- [social-connect-main]            # Main shortcode for the plugin
- [social-connect-more]            # Shortcode for adding more social networks
- [social-login]                   # Shortcode for the login form
- [social-remove-data]             # Shortcode for the remove data form
- [social-remove-account]          # Shortcode for the remove account form
