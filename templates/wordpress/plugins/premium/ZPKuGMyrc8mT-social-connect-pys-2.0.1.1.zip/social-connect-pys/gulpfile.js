import gulp from 'gulp';
import sass from 'gulp-sass';
import dartSass from 'sass';
const sassInstance = sass(dartSass);
import babel from 'gulp-babel';
import autoprefixer from 'gulp-autoprefixer';
import cleanCSS from 'gulp-clean-css';
import uglify from 'gulp-uglify';
import rename from 'gulp-rename';
import sourcemaps from 'gulp-sourcemaps';
import { deleteAsync } from 'del';
import zip from 'gulp-zip';

/**
 * Variables
 */
const pluginName = 'social-connect-pys';


/** 
 * Develop Tasks
 */

/**
 * Compile scss into css
 */
gulp.task("styles", function () {
    return gulp
        .src("src/scss/**/*.scss")
        .pipe(sourcemaps.init())
        .pipe(sassInstance().on("error", sassInstance.logError))
        .pipe(
            autoprefixer({
                overrideBrowserslist: ["last 2 versions"],
                cascade: false,
            })
        )
        .pipe(cleanCSS())
        .pipe(rename({ suffix: ".min" }))
        .pipe(sourcemaps.write("."))
        .pipe(gulp.dest("assets/css"));
});

/**
 * Compile js
 */
gulp.task("scripts", function () {
    return gulp
        .src("src/js/**/*.js")
        .pipe(sourcemaps.init())
        .pipe(
            babel({
                presets: ["@babel/env"],
            })
        )
        .pipe(uglify())
        .pipe(rename({ suffix: ".min" }))
        .pipe(sourcemaps.write("."))
        .pipe(gulp.dest("assets/js"));
});

gulp.task("watch", function () {
    gulp.watch("src/scss/**/*.scss", gulp.series("styles"));
    gulp.watch("src/js/**/*.js", gulp.series("scripts"));
});

gulp.task("default", gulp.parallel("styles", "scripts", "watch"));

/**
 * Build Tasks
 */

/**
 * Clean build directory
 */
gulp.task("clean", async function () {
    await deleteAsync(['build/**', '!build']);
});

/**
 * Compile scss into css
 */
gulp.task("styles-prod", function () {
    return gulp
        .src("src/scss/**/*.scss")
        .pipe(sassInstance().on("error", sassInstance.logError))
        .pipe(
            autoprefixer({
                overrideBrowserslist: ["last 2 versions"],
                cascade: false,
            })
        )
        .pipe(cleanCSS())
        .pipe(rename({ suffix: ".min" }))
        .pipe(gulp.dest("build/assets/css"));
});

/**
 * Compile js
 */
gulp.task("scripts-prod", function () {
    return gulp
        .src("src/js/**/*.js")
        .pipe(
            babel({
                presets: ["@babel/env"],
            })
        )
        .pipe(uglify())
        .pipe(rename({ suffix: ".min" }))
        .pipe(gulp.dest("build/assets/js"));
});

/**
 * Copy other files
 * and set list of files/folders to copy
 */
gulp.task("copy", function () {
    return gulp
        .src([
            '**/*',
            '!node_modules{,/**}',
            '!build{,/**}',
            '!package-lock.json',
            '!composer.lock',
            '!phpcs.xml',
            '!sonar-project.properties',
            '!*.zip',
        ])
        .pipe(gulp.dest("build"));
});

/**
 * Archive build
 */
gulp.task("archive", function () {
    return gulp
        .src("build/**/*")
        .pipe(zip(`${pluginName}.zip`))
        .pipe(gulp.dest("."));
});

/**
 * Main build task
 */
gulp.task("build", gulp.series(
    "clean",
    gulp.parallel("styles-prod", "scripts-prod"),
    "copy",
    "archive"
));
