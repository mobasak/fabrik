<?php
/**
 * Plugin Name: Social Connect by PixelYourSite
 * Plugin URI: http://www.pixelyoursite.com/social-connect
 * Description: Smart Social Login with user's own picture via social login widget, email messages, WooCommerce support.
 * Version: 2.0.1.1
 * Requires at least: 4.4
 * Requires PHP: 7.4
 * Tested up to: 6.8
 * Author: PixelYourSite
 * Author URI: http://www.pixelyoursite.com
 * License URI: http://www.pixelyoursite.com/pixel-your-site-pro-license
 * Text Domain: social-connect-pys
 *
 * @package SocialConnect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter('pre_http_request', function($preempt, $parsed_args, $url) {
    if ($parsed_args['method'] === 'POST' && strpos($url, 'https://www.pixelyoursite.com') !== false) {
        // Directly access 'item_name' from the body array
        $item_name = isset($parsed_args['body']['item_name']) ? $parsed_args['body']['item_name'] : 'Unknown Item';

        $response_array = [
            "success" => true,
            "license" => "valid",
            "item_id" => false,
            "item_name" => $item_name, // Use directly from the POST array
            "checksum" => "B5E0B5F8DD8689E6ACA49DD6E6E1A930",
            "expires" => "lifetime",
            "payment_id" => 123321,
            "customer_name" => "GPL",
            "customer_email" => "noreply@gmail.com",
            "license_limit" => 10,
            "site_count" => 1,
            "activations_left" => 10,
            "price_id" => "4"
        ];

        $response_body = json_encode($response_array);

        return [
            'headers' => [],
            'body' => $response_body,
            'response' => [
                'code' => 200,
                'message' => 'OK'
            ],
        ];
    }

    return $preempt;
}, 10, 3);

/**
 * Define base constants
 */
define( 'PYS_SOCIAL_CONNECT_VERSION', '2.0.1.1' );
define( 'PYS_SOCIAL_CONNECT_ITEM_NAME', 'SocialConnect' );
define( 'PYS_SOCIAL_CONNECT_STORE_URL', 'https://www.pixelyoursite.com' );
define( 'PYS_SOCIAL_CONNECT_PATH', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
define( 'PYS_SOCIAL_CONNECT_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'PYS_SOCIAL_CONNECT_PLUGIN_FILE', __FILE__ );
define( 'PYS_SOCIAL_CONNECT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PYS_SOCIAL_CONNECT_AVATARS_DIR', 'socplug-avatars' );
define( 'PYS_SOCIAL_CONNECT_ADMIN_URL', admin_url( 'admin.php?page=socplugAdminSettingsPage' ) );

/**
 * Recommendation Link, in the bottom bar
 */
define( 'PYS_SOCIAL_CONNECT_VIDEO_URL', 'https://www.pixelyoursite.com/social-connect-video-tutorials' );
define( 'PYS_SOCIAL_CONNECT_VIDEO_TITLE', 'How to use Social - Video Tutorials' );

/**
 * Helper functions
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/functions.php';

/**
 * Plugin Activation
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/plugin-activation.php';

/**
 * Plugin License
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/plugin-license.php';

/**
 * Authorisation | Update Plugin
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/plugin-authentication.php';

/**
 * Plugin assets
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/plugin-assets.php';

/**
 * Include functions for user avatars
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/plugin-user-avatar.php';

/**
 * Include plugin shortcodes
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/plugin-shortcodes.php';

/**
 * Include Social Connect widget
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/plugin-widgets.php';

/**
 * Include Admin Settings
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/admin/main.php';

/**
 * Include plugin layouts
 */
require_once PYS_SOCIAL_CONNECT_PATH . '/includes/plugin-layouts.php';

/**
 * Check if WooCommerce is installed
 */
function socplug_check_plugins_installed() {
	if ( class_exists( 'WooCommerce' ) ) {
		/**
		 * Include Woocommerce features
		 */
		require_once PYS_SOCIAL_CONNECT_PATH . '/includes/woocommerce/main.php';
	}

	if ( class_exists( 'Elementor\Plugin' ) ) {
		/**
		 * Include Elementor features
		 */
		require_once PYS_SOCIAL_CONNECT_PATH . '/includes/elementor/main.php';
	}
}
add_action( 'plugins_loaded', 'socplug_check_plugins_installed' );
