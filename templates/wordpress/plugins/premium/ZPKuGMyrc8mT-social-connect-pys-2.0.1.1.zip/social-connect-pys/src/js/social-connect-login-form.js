jQuery(document).ready(function ($) {
    /**
     * Login form 
     */
    const loginForm = $('.socplug-login-form');
    if (loginForm.length > 0) {
  
      /**
       * Set placeholder for login form
       */
      $(loginForm).find('input[id="user_login"]').attr('placeholder', 'Email');
      $(loginForm).find('input[id="user_pass"]').attr('placeholder', 'Password');
  
      /**
       * Remember me from form login
       */
      let rememberMe = $(loginForm).find('.login-remember input');
  
      /**
       * Custom checkbox for remember me
       */
      let checkboxes = $('.socplug-login-form-remember input');
  
      /**
       * Change remember me from form login
       */
      $(checkboxes).on('change', function () {
        if ($(this).is(':checked')) {
          $(rememberMe).prop('checked', true);
          $(checkboxes).prop('checked', true);
        } else {
          $(rememberMe).prop('checked', false);
          $(checkboxes).prop('checked', false);
        }
      });
  
      /**
       * Login form ajax
       */
      let login_form_ajax = null;
      $(loginForm).find('form').on('submit', function (e) {
        e.preventDefault();
        let form = $(this);
  
        let email = $(form).find('input[id="user_login"]').val();
        let password = $(form).find('input[id="user_pass"]').val();
        if (!email || !password) {
          return;
        }
  
        let data = new FormData(this);
        data.append('action', 'socplugLoginFormSubmit');
  
        login_form_ajax = $.ajax({
          url: socplug.ajaxurl,
          type: 'POST',
          dataType: 'json',
          processData: false,
          contentType: false,
          data: data,
          beforeSend: function () {
            if (login_form_ajax !== null) {
              login_form_ajax.abort();
            }
            $(form).find('.socplug-status').remove();
            $(form).addClass('loading');
          },
          success: function (response) {
            show_form_status(form, response);
  
            if(response.success && response.data.redirect) {
              window.location.href = response.data.redirect;
            }
  
            $(form).removeClass('loading');
          },
          error: function (error) {
            console.log('Error login form submit');
            console.log(error);
            $(form).removeClass('loading');
          }
        });
      });
    }
  
    /**
     * Show form status
     */
    function show_form_status(form, response) {
      $(form).append('<p class="socplug-status status-' + response.success + '">' + response.data.message + '</p>');
    }
  
  });