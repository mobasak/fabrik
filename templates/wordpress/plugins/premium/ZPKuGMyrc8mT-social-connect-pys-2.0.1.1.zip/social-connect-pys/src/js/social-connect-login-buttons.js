jQuery(document).ready(function ($) {
  const socialConnectLoginButtons = $('.network-login-btn');
  if (socialConnectLoginButtons.length > 0) {
    socialConnectLoginButtons.on('click', function (e) {
      const providerUrl = $(this).attr('data-provider-url');
      if (!providerUrl) {
        console.log('No provider url found');
        return;
      }
      
      /**
       * Open new window with login provider
       */
      let width = 1200;
      let height = 800;
      let left = (screen.width - width) / 2;
      let top = (screen.height - height) / 2;

      window.open(providerUrl, 'Social Login', 'width=' + width + ',height=' + height + ',left=' + left + ',top=' + top);
    });
  }
});
