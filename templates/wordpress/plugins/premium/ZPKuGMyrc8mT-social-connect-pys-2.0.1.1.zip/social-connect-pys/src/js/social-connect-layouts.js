jQuery(document).ready(function ($) {
    /**
     * Check if we had to replace social login form
     */
    const socialLoginForm = $('.social-connect-replace-form');
    if (socialLoginForm.length > 0) {
        socplug_replace_social_login_form(socialLoginForm);
    }

    function socplug_replace_social_login_form(form) {
        const position = $(form).attr('data-position');
        const type = $(form).attr('data-form');
        const targetForm = type === 'login' ? $('#loginform') : $('#registerform');

        /*
         * Only proceed if we have a valid position
         */
        const validPositions = ['inside_bottom', 'inside_top', 'outside_top', 'outside_bottom'];
        if (!validPositions.includes(position)) {
            return;
        }

        /*
         * Place the form based on position
         */
        switch(position) {
            case 'inside_bottom':
                $(targetForm).find('.submit').after(form);
                break;
            case 'inside_top':
                $(targetForm).find('#user_login').parent().before(form);
                break;
            case 'outside_top':
                $(targetForm).before(form);
                break;
            case 'outside_bottom':
                $(targetForm).after(form);
                break;
        }

        /*
         * Show the form with animation
         */
        $(form).show('fast');
    }
});
