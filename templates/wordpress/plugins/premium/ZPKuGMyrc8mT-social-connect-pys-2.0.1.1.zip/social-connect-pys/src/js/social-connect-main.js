jQuery(document).ready(function ($) {
  /**
   * Check if we had to replace social login form
   */
  const socialLoginForm = $('.social-connect-replace-form');
  if (socialLoginForm.length > 0) {
    socplug_replace_social_login_form(socialLoginForm);
  }

  function socplug_replace_social_login_form(form) {
    const position = $(form).attr('data-position');
    const type = $(form).attr('data-form');
    const formSelector = type === 'login' ? '#loginform' : '#registerform';
    const targetForm = $(formSelector);

    const positionMap = {
      'inside_bottom': () => targetForm.find('.submit').after(form),
      'inside_top': () => targetForm.find('#user_login').parent().before(form),
      'outside_top': () => targetForm.before(form),
      'outside_bottom': () => targetForm.after(form)
    };

    if (type === 'login' || type === 'register') {
      if (positionMap[position]) {
        positionMap[position]();
        $(form).show('fast');
      }
    }
  }

  /**
   * Disconnect provider
   */
  let disconnect_provider = null;
  $('.socplug-disconnect-provider').on('click', function (e) {
    e.preventDefault();
    let provider = $(this).attr('data-provider');

    if (!provider) {
      console.log('No provider found');
      return;
    }

    /**
     * Disable disconnect button
     */
    $(this).addClass('disabled');

    disconnect_provider = $.ajax({
      url: socplug.ajaxurl,
      type: 'POST',
      data: {
        action: 'socplugDisconnectProviderAjax',
        provider: $(this).attr('data-provider'),
      },
      beforeSend: function () {
        if (disconnect_provider !== null) {
          disconnect_provider.abort();
        }

        $('.social-connect-more tr[data-provider="' + provider + '"] td').addClass('remove-processing');
      },
      success: function (response) {
        if (response.data) {
          $.each(response.data, function (index, provider) {
            $('.social-connect-more tr[data-provider="' + provider + '"]').remove();
          })
        }
        window.location.reload();
      },
      error: function (error) {
        console.log('Error', error);
      }
    });

  });

});