jQuery(document).ready(function ($) {
    /**
     * Disconnect provider
     */
    let disconnect_provider = null;
    $('.socplug-disconnect-provider').on('click', function (e) {
      e.preventDefault();
      let provider = $(this).attr('data-provider');
  
      if (!provider) {
        console.log('No provider found');
        return;
      }
  
      /**
       * Disable disconnect button
       */
      $(this).addClass('disabled');
  
      disconnect_provider = $.ajax({
        url: socplug.ajaxurl,
        type: 'POST',
        data: {
          action: 'socplugDisconnectProviderAjax',
          provider: $(this).attr('data-provider'),
        },
        beforeSend: function () {
          if (disconnect_provider !== null) {
            disconnect_provider.abort();
          }
  
          $('.social-connect-more tr[data-provider="' + provider + '"] td').addClass('remove-processing');
        },
        success: function (response) {
          if (response.data) {
            $.each(response.data, function (index, provider) {
              $('.social-connect-more tr[data-provider="' + provider + '"]').remove();
            })
          }
          window.location.reload();
        },
        error: function (error) {
          console.log('Error', error);
        }
      });
    });
  });