jQuery(document).ready(function ($) {
  let chart = $("#myChart");
  let change_period = null;
  let myChart = null;
  let chart_state = 'sales';
  let currency_symbol = '';
  let canvas_wrapper = '';
  let canvas_nav = '';

  if (chart.length > 0) {
    chart = $("#myChart").get(0).getContext("2d");
    canvas_wrapper = $('.status-report-graph-canvas');
    canvas_nav = $('.status-report-graph-period');

    /**
     * Graph data
     */
    let sales_data = $("#sucplug_sales").val();

    /**
     * Json decode
     */
    sales_data = JSON.parse(sales_data);

    let graph_data = {
      labels: sales_data.labels,
      dataset: sales_data.dataset,
    };

    currency_symbol = $("input[name=socplug_currency_symbol]").val();

    /**
     * Create gradient for chart background
     */
    let gradient = chart.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, "rgba(37, 227, 248, 0.4)");
    gradient.addColorStop(1, "rgba(37, 227, 248, 0)");

    if (graph_data.labels.length > 0 && graph_data.dataset.length > 0) {
      $(canvas_wrapper).addClass('week-graph');
      $(canvas_nav).addClass('week-nav');
      myChart = create_graph(chart, graph_data, gradient, currency_symbol);
    }
  }

  /**
   * Create graph main fn
   */
  function create_graph(chart, graph_data, gradient, currency_symbol) {
    return new Chart(chart, {
      type: "line",
      data: {
        labels: graph_data.labels,
        datasets: [
          {
            data: graph_data.dataset,
            backgroundColor: gradient,
            borderColor: "rgba(37, 227, 248, 1)",
            borderWidth: 2,
            fill: true,
            pointBackgroundColor: "rgba(255, 255, 255, 1)",
            pointBorderColor: "rgba(37, 227, 248, 1)",
            pointBorderWidth: 2,
            pointRadius: 3,
          },
        ],
      },
      options: {
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              color: "rgba(93, 93, 93, 1)",
              font: {
                size: 14,
              },
              callback: function (value) {
                return chart_state === 'sales' ? currency_symbol + value : value;
              },
              stepSize: chart_state === 'sales' ? undefined : 1,
            },
            grid: {
              color: "rgba(240, 240, 241, 1)",
            },
          },
          x: {
            ticks: {
              color: "rgba(93, 93, 93, 1)",
              font: {
                size: 14,
              },
            },
            grid: {
              color: "rgba(240, 240, 241, 1)",
            },
          },
        },
        plugins: {
          legend: {
            display: false,
          },
        },
      },
    });
  }

  /**
   * Graph period on change
   */
  $(".status-report-graph-period-item").on("click", function (e) {
    e.preventDefault();
    /**
     * Check if already active
     */
    if ($(this).hasClass("active")) {
      return;
    }

    /**
     * Remove from all and add to current
     */
    $(".status-report-graph-period-item").removeClass("active");
    $(this).addClass("active");

    /**
     * Get graph data
     */
    socplug_get_graph_data(this);
  });

  /**
   * Graph type on change
   */
  $(".status-report-graph-type").on("change", function (e) {
    e.preventDefault();

    /**
     * Get period
     */
    let period = $(".status-report-graph-period-item.active");

    /**
     * Get graph data
     */
    socplug_get_graph_data(period);
  });

  /**
   * Get New data for graph
   */
  function socplug_get_graph_data(period) {
    let graph_type = $("#status-report-graph-type").val();
    period = $(period).attr("data-period");

    if (!graph_type || !period) {
      alert("Please try again");
      return;
    }

    /**
     * Fetch graph data
     */
    socplug_fetch_graph_data(graph_type, period);
  }

  function socplug_fetch_graph_data(graph_type, period) {
    change_period = $.ajax({
      url: socplug.ajaxurl,
      type: "POST",
      data: {
        action: "socplugAjaxGetGraphData",
        period: period,
      },
      beforeSend: function () {
        if (change_period !== null) {
          change_period.abort();
        }
        loading();
      },
      success: function (response) {
        if (!response.success) {
          console.log(response);
          return;
        }

        let graph_data = select_data_to_display_on_graph(
          response.data.graph_data,
          graph_type
        );

        if (graph_data.labels.length > 0 && graph_data.dataset.length > 0) {
          myChart.data.labels = graph_data.labels;
          myChart.data.datasets[0].data = graph_data.dataset;

          /**
           * Change graph state and ticks
           */
          if (graph_type === 'sales') {
            chart_state = 'sales';
            myChart.options.scales.y.ticks.callback = function (value) { return currency_symbol + value; };
            myChart.options.scales.y.ticks.stepSize = undefined;
          } else if (graph_type === 'orders') {
            chart_state = 'orders';
            myChart.options.scales.y.ticks.callback = function (value) { return value; };
            myChart.options.scales.y.ticks.stepSize = 1;
          }

          /**
           * Update graph wrapper class | Add week-graph class or month-graph class
           * Update nav wrapper class | Add week-nav class or month-nav class
           */
          update_graph_wrapper_class(period, canvas_wrapper);
          update_graph_wrapper_class(period, canvas_nav);

          /**
           * Update graph
           */
          myChart.update();
        } else {
          console.log("Data not provided");
        }
        loading(false);
      },
    });
  }

  function update_graph_wrapper_class(period, item) {
    $(item).removeClass('week-graph month-graph');
    $(item).addClass(period === 'current_week' ? 'week-graph' : 'month-graph');
  }

  function select_data_to_display_on_graph(data, graph_type) {
    let data_type = '';

    if (graph_type === "sales") {
      data_type = JSON.parse(data.sales_by_month_data);
    } else if (graph_type === "orders") {
      data_type = JSON.parse(data.orders_by_month_data);
    }

    return {
      labels: data_type.labels,
      dataset: data_type.dataset,
    };
  }

  /**
   * Back button on mobile
   */
  let back_button = $('.social-connect-back-btn');
  if (back_button.length > 0) {
    $(back_button).on('click', function (e) {
      e.preventDefault();
      /**
       * Back in history by 1 page
       * Do not use history.back(), is not working correctly in mobile browser
       */
      window.location.href = document.referrer;
    });
  }

  /**
   * Submit main form on page settings, when custom button is clicked
   */
  let save_form = null;

  $(".social-connect-save-btn").on("click", function (e) {
    e.preventDefault();

    /**
     * Search main settings form on page
     */
    let form = $(".settings-form");
    if (form.length <= 0) {
      console.log("Form not found");
      return;
    }

    socplug_save_settings(form);
  });

  function socplug_save_settings(form) {
    /**
     * Add action to form data
     */
    form = new FormData(form[0]);
    form.append("action", "socplugAjaxSaveSettings");

    /**
     * Send ajax request
     */
    save_form = $.ajax({
      url: socplug.ajaxurl,
      type: "POST",
      data: form,
      dataType: "json",
      processData: false,
      contentType: false,
      beforeSend: function () {
        if (save_form !== null) {
          save_form.abort();
        }
        loading();
      },
      success: function (response) {
        if (!response.success) {
          console.log('Error saving settings');
        }
        loading(false);
      },
    });
  }


  /**
   * Loading screen
   */
  const loading_screen = $(".socplug-loading-screen");

  function loading(enable = true) {
    if (!enable) {
      $(loading_screen).removeClass("active");
      return;
    }

    $(loading_screen).addClass("active");
  }

  /**
   * Hover on settings icon svg
   */
  $(".settings-icon").on("click", function () {
    let svg = $(this).find("svg");
    $(svg).toggleClass("active");
    $(this).closest('.network-settings').find(".network-settings-item-toggle-div").slideToggle().toggleClass("active");
  });

  /**
   * Select Network Design
   */
  $(".select-design select").on("change", function () {
    updateNetworkDesign(this);
  });

  function updateNetworkDesign(select) {
    let design = $(select).val();
    if (!design) {
      return;
    }

    /**
     * Replace _ with space
     */
    design = design.replaceAll("_", " ");

    $(select).parent().find(".select-design-preview .network-login-btn").each(function () {
      /**
       * Remove all classes
       */
      $(this).removeClass("big monochrome full short circle");
      $(this).addClass(design);
    });
  }

  /**
   * Sortable networks
   */
  let order_list = $(".network-order-list");
  if (order_list.length > 0) {
    $(order_list).sortable({
      axis: "x",
      tolerance: "pointer",
      containment: "parent",
      cursor: "move",
      scroll: false,
      distance: 5,
      opacity: 0.6,
      zIndex: 9999,
    });
  }

  /**
   * Connect-more switcher
   */
  let connect_more_switcher = $(".connect_more_switcher input");
  if (connect_more_switcher.length > 0) {
    $(connect_more_switcher).on("change", function () {
      let parent = $(this).closest(".network-settings-item");
      if ($(this).is(":checked")) {
        $(parent)
          .find(".settings-help-text, .checkbox-group, .field-row")
          .removeClass("disabled-fields")
          .find("input")
          .attr("disabled", false)
      } else {
        $(parent)
          .find(".settings-help-text, .checkbox-group, .field-row")
          .addClass("disabled-fields")
          .find("input")
          .attr("disabled", true)
      }
    });
  }

  /**
   * Init Color Picker inputs
   */
  $(".color-picker-wrapper").each(function () {
    let parent = $(this);
    let picker = $(this).find(".color-picker");
    if (picker.length === 0) {
      return;
    }

    let default_color = $(this).find("input").val();

    let color_picker = new Pickr({
      el: picker[0],
      theme: "nano",
      container: parent[0],
      default: default_color,
      appClass: "custom-picker-app",
      components: {
        preview: true,
        opacity: true,
        hue: true,

        interaction: {
          input: true,
        }
      },
    });

    color_picker.on("change", function (color) {
      $(parent).find(".color-picker-input").val(color.toHEXA().toString()).change();
      $(parent).find("button").css("--pcr-color", color.toHEXA().toString());
    });
  });

  /**
   * Custom input number
   */
  $(".custom-input-number").each(function () {
    let input = $(this).find("input");
    let minus = $(this).find(".minus");
    let plus = $(this).find(".plus");

    $(minus).on("click", function () {
      let value = parseInt($(input).val());
      if (value > 0) {
        $(input).val(value - 1);
      }
    });

    $(plus).on("click", function () {
      let value = parseInt($(input).val());
      if (value < 999) {
        $(input).val(value + 1);
      }
    });
  });

  /**
   * Social Login Coupon, change Display Type
   */
  $('.social-coupon-display-group input[type="radio"]').on('change', function () {
    let parent = '';
    let box = '';

    /**
     * Search not selected radio button
     */
    let not_selected = $('.social-coupon-display-group input[type="radio"]:not(:checked)');
    if (not_selected.length > 0) {
      parent = $(not_selected).closest('.social-coupon-display-item');
      box = $(parent).find('.social-coupon-display-hidden-box');
      /**
       * Make textarea read only and checkbox disabled
       */
      $(box).find('textarea').prop('readonly', true);
      $(box).find('input[type="checkbox"]').prop('disabled', true);
      $(box).addClass('disabled-fields');
    }

    /**
     * Make selected radio button enabled
     */
    parent = $(this).closest('.social-coupon-display-item');
    box = $(parent).find('.social-coupon-display-hidden-box');
    $(box).find('textarea').prop('readonly', false);
    $(box).find('input[type="checkbox"]').prop('disabled', false);
    $(box).removeClass('disabled-fields');
  });

  /**
   * License form
   */
  let activate_license = null;
  $('.license-form').on('submit', function (e) {
    e.preventDefault();
    let form = $(this);
    let license_key_input = $(form).find('#socplug_license_key');
    let license_key_value = $(license_key_input).val().trim();

    if (!license_key_value) {
      socplug_show_license_message({ 'message': 'License key is required, please enter license key', 'type': 'error' });
      return;
    }

    socplug_remove_license_message();

    /**
     * Set form not active
     */
    socplug_activate_license(license_key_value, form);
  });

  function socplug_activate_license(license_key_value, form) {
    activate_license = $.ajax({
      url: socplug.ajaxurl,
      type: 'POST',
      data: {
        action: 'socplugActivateLicenseAjax',
        license_key: license_key_value,
      },
      beforeSend: function () {
        if (activate_license !== null) {
          activate_license.abort();
        }
        socplug_form_loaded({ form: form, loading: true, buttons_disabled: true, input_disabled: true });
      },
      success: function (response) {
        if (response.data.type && response.data.message) {
          socplug_show_license_message({ 'message': response.data.message, 'type': response.data.type });
        }

        if (!response.success) {
          socplug_form_loaded({ form: form });
          return;
        }

        socplug_success_request(form);
      },
      error: function () {
        socplug_show_license_message({ 'message': 'Something went wrong, please try again.', 'type': 'error' });
        socplug_form_loaded({ form: form });
      },
    });
  }

  /**
   * Deactivate license
   */
  let deactivate_license = null;
  $('.socplug-deactivate-license').on('click', function (e) {
    e.preventDefault();
    let form = $('.license-form');

    deactivate_license = $.ajax({
      url: socplug.ajaxurl,
      type: 'POST',
      data: {
        action: 'socplugDeactivateLicenseAjax',
      },
      beforeSend: function () {
        if (deactivate_license !== null) {
          deactivate_license.abort();
        }
        socplug_form_loaded({ form: form, loading: true, buttons_disabled: true, input_disabled: true });
      },
      success: function (response) {
        if (response.data.type && response.data.message) {
          socplug_show_license_message({ 'message': response.data.message, 'type': response.data.type });
        }

        if (!response.success) {
          socplug_form_loaded({ form: form });
          return;
        }

        socplug_success_request();
      },
      error: function (xhr) {
        socplug_show_license_message({ 'message': 'Something went wrong, please try again.', 'type': 'error' });
        socplug_form_loaded({ form: form });
        console.log(xhr);
      },
    })
  });

  /**
   * License for styles
   */
  function socplug_form_loaded(data) {
    if (!data.form) {
      return;
    }

    if (data.loading) {
      $(data.form).find('.license-action-status').html(`<span class="iconmoon icon-loading"></span>`);
    } else {
      $(data.form).find('.license-action-status').find('.icon-loading').remove();
    }

    if (data.buttons_disabled) {
      $(data.form).find('button').prop('disabled', true);
    } else {
      $(data.form).find('button').prop('disabled', false);
    }

    if (data.input_disabled) {
      $(data.form).find('input').prop('disabled', true).addClass('inprocess');
    } else {
      $(data.form).find('input').prop('disabled', false).removeClass('inprocess');
    }

  }

  function socplug_success_request(form) {
    socplug_form_loaded({ form: form, loading: false, buttons_disabled: true, input_disabled: true });
    setTimeout(function () {
      location.reload();
    }, 1000);
  }

  function socplug_remove_license_message() {
    $('.socplug-license-message').remove();
  }

  function socplug_show_license_message(data) {
    $('.socplug-license-message').remove();
    $('.socplug-license-form .network-settings-item-inner')
      .append(`<div class="socplug-license-message socplug-license-message-${data.type}">
              <span class="socplug-license-message-icon iconmoon icon-${data.type} "></span>
              <div class="socplug-license-message-text">${data.message}</div>
            </div>`);
  }

  /**
   * Preview buttons
   */
  const preview_buttons = $('.preview-socplug-design');
  let preview_ajax = null;
  if (preview_buttons.length > 0) {
    $(preview_buttons).on('click', function () {
      socplug_preview_design(this);
    });
  }

  function socplug_preview_design(button) {
    const shortcode = $(button).attr('data-preview');

    if (!shortcode) {
      console.log('No shortcode found');
      return;
    }

    preview_ajax = $.ajax({
      url: socplug.ajaxurl,
      type: 'POST',
      data: {
        action: 'socplugPreviewDesignAjax',
        shortcode: shortcode,
      },
      beforeSend: function () {
        if (preview_ajax !== null) {
          preview_ajax.abort();
        }
        loading();
      },
      success: function (response) {
        if (response.data) {
          $('body').append(response.data);

          $('.socplug-preview-design-wrapper').on('click', function () {
            $(this).remove();
          });
        }

        loading(false);
      },
      error: function (xhr) {
        console.log(xhr.responseText);
        loading(false);
      },
    });
  }

  /**
   * Reset to default settings
   */
  let reset_button = $('#socplug_reset_default_settings');
  if (reset_button.length > 0) {
    let reset_default_settings = null;

    reset_button.on('click', function () {
      let checkboxes = $('.default_settings-section input[type="checkbox"]:checked');
      let confirm_reset = confirm('Are you sure you want to reset the plugin settings to default?');
      if (!confirm_reset) {
        return;
      }

      let checkboxes_data = [];
      checkboxes.each(function () {
        checkboxes_data.push($(this).attr('name'));
      });

      reset_default_settings = $.ajax({
        url: socplug.ajaxurl,
        type: 'POST',
        data: {
          action: 'socplugResetDefaultSettingsAjax',
          nonce: $(reset_button).attr('data-nonce'),
          checkboxes: checkboxes_data,
        },
        beforeSend: function () {
          if (reset_default_settings !== null) {
            reset_default_settings.abort();
          }
          $(reset_button).prop('disabled', true);
          loading();
        },
        success: function (response) {
          if (response.success) {
            location.reload();
          }
        },
        error: function (xhr) {
          console.log(xhr.responseText);
          loading(false);
        },
      });
    });
  }

  /**
   * Mobile nav
   */
  let mobile_nav = $('.social-connect-mobile-nav');
  if (mobile_nav.length > 0) {
    $(mobile_nav).on('click', function () {
      $(this).toggleClass('open');
      $(this).find('.social-connect-mobile-nav-dropdown').slideToggle();
    });
  }

  /**
   * Check Provider Configuration
   */

  let check_condfig_btn = $('.socplug-check-config');
  if (check_condfig_btn.length > 0) {
    $(check_condfig_btn).on('click', function (e) {
      e.preventDefault();
      socplug_check_provider_config(this);
    });
  }

  function socplug_check_provider_config_ajax(button) {
    let link = $(button).attr('data-link');
    if (!link) {
      return;
    }

    window.open(link, '_blank');
  }

  function socplug_check_provider_config(button) {

    $.ajax({
      url: socplug.ajaxurl,
      type: 'POST',
      data: {
        'action': 'socplugCheckProviderConfigAjax',
      },
      beforeSend: function () {
        loading();
      },
      success: function (response) {
        loading(false);
        console.log(response);
        socplug_check_provider_config_ajax(button);
      },
      error: function (xhr) {
        console.log(xhr.responseText);
        loading(false);
      },
    });
  }

  /**
   * Copy link to clipboard 
   */
  $('.step-instruction .copy-link').on('click', function (e) {
    e.preventDefault();
    let link = $(this).attr('href');
    navigator.clipboard.writeText(link);
    $(this).append('<span class="copied">Copied</span>');

    setTimeout(function () {
      $('body').find('.step-instruction .copied').remove();
    }, 2000);
  });

  /**
   * Logs
   */

  $('.logs-download-btn, .logs-clear-btn').on('click', function (e) {
    e.preventDefault();
    let action = $(this).hasClass('logs-download-btn') ? 'socplugDownloadLogsAjax' : 'socplugClearLogsAjax';
    let type = $(this).attr('data-type');
    let nonce = $(this).attr('data-nonce');
    socplug_logs_action(type, action, nonce);
  });

  

  function socplug_logs_action(type, action, nonce) {
    $.ajax({
      url: socplug.ajaxurl,
      type: 'POST',
      data: {
        'action': action,
        'type': type,
        'nonce': nonce,
      },
      beforeSend: function () {
        loading();
      },
      success: function (response) {

        if (response.success && response.data.download_url) {
          window.location.href = response.data.download_url;
        }

        if (response.success && response.data.message) {
          $('.logs-' + type + ' .logs-message').html(response.data.message);
        }

        if (response.success && response.data.clear_log) {
          $('.logs-' + type + ' .sc-log-content').html('Cleared');
        }


        setTimeout(function () {
          loading(false);
        }, 1500);
      },
      error: function (xhr) {
        console.log(xhr.responseText);
        loading(false);
      },
    });
  }

});
