document.addEventListener("DOMContentLoaded", () => {
    const removeAccountForm = document.getElementById('socplug_social_data_remove');
    if (!removeAccountForm) {
        return;
    }

    removeAccountForm.addEventListener('submit', (event) => {
        let submit_button = event.target.querySelector('button[type="submit"]');
        let confirmation_enabled = submit_button.getAttribute('data-confirmation');
        let confirmation_text = submit_button.getAttribute('data-confirmation-text');

        if (confirmation_enabled === 'true' && confirmation_text.length > 0) {
            console.log('Confirmation enabled');
            const confirmation = confirm(confirmation_text);
            if (!confirmation) {
                event.preventDefault();
                /**
                 * Prevent form submission
                 */
                return;
            }
        } else {
            console.log('Confirmation not enabled');
        }
        /**
         * Delete account or remove social links
         */
    });
});
