<?php
/**
 * Convert Pro Addon Automation
 *
 * @package Convert Pro Addon
 * @author Brainstorm Force
 */

// Prohibit direct script loading.
defined( 'ABSPATH' ) || die( 'No direct script access allowed!' );

require_once 'class-cpro-automation-loader.php';
