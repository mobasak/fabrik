<?php
/**
 * ConverPlug Service Constant Contact
 *
 * @package Convert Pro Addon
 * @author Brainstorm Force
 */

/**
 * Helper class for the Constant Contact API.
 *
 * @since 1.0.0
 */
final class CPRO_Service_Constant_Contact extends CPRO_Service {

	/**
	 * The ID for this service.
	 *
	 * @since 1.0.0
	 * @var string $id
	 */
	public $id = 'constant-contact';

	/**
	 * The api url for this service.
	 *
	 * @since 1.0.0
	 * @var string $api_url
	 */
	public $api_url = 'https://api.cc.email/v3/';

	/**
	 * Default Custom field array.
	 * This is predefined custom fields array that Constant Contact
	 * has already defined. When Constant Contact releases the new
	 * set of fields, we need to update this array.
	 *
	 * @since 1.0.0
	 * @var string $id
	 */
	public static $mapping_fields = array( 'prefix_name', 'first_name', 'last_name', 'middle_name', 'job_title', 'home_phone', 'work_phone', 'cell_phone', 'company_name', 'city', 'state' );

	/**
	 * Test the API connection.
	 *
	 * @since 1.0.0
	 * @param array $fields A valid API credentials.
	 * @return array{
	 *      @type bool|string $error The error message or false if no error.
	 *      @type array $data An array of data used to make the connection.
	 * }
	 */
	public function connect( $fields = array() ) {
		$response = array(
			'error' => false,
			'data'  => array(),
		);

		// Make sure we have an API key.
		if ( ! isset( $fields['access_token'] ) || empty( $fields['access_token'] ) ) {
			$response['error'] = __( 'Error: You must provide an Access Token.', 'convertpro-addon' );
		} elseif ( ! isset( $fields['refresh_token'] ) || empty( $fields['refresh_token'] ) ) {
			// Make sure we have an access token.
			$response['error'] = __( 'Error: You must provide an refresh token.', 'convertpro-addon' );
		} elseif ( ! isset( $fields['client_id'] ) || empty( $fields['client_id'] ) ) {
			$response['error'] = __( 'Error: You must provide an Client ID.', 'convertpro-addon' );
		} elseif ( ! isset( $fields['client_secret'] ) || empty( $fields['client_secret'] ) ) {
			// Make sure we have an access token.
			$response['error'] = __( 'Error: You must provide an Client Secret.', 'convertpro-addon' );
		} else {
			// Try to connect and store the connection data.
			$url     = $this->api_url . 'contact_lists?include_count=true&status=active&include_membership_count=all';
			$args    = array(
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $fields['access_token'],
				),
			);
			$request = json_decode( wp_remote_retrieve_body( wp_remote_get( $url, $args ) ) );

			if ( is_array( $request ) ) {
				foreach ( $request as $req ) {
					if ( isset( $req->error_message ) ) {
						$response['error'] = sprintf( __( 'Error: Could not connect to Constant Contact. %s', 'convertpro-addon' ), $req->error_message );
						break;
					}
				}
			} elseif ( isset( $request->error_message ) ) {
				$response['error'] = sprintf( __( 'Error: Could not connect to Constant Contact. %s', 'convertpro-addon' ), $request->error_message );
			} else {
				$response['data'] = array(
					'client_id'     => $fields['client_id'],
					'client_secret' => $fields['client_secret'],
					'access_token'  => $fields['access_token'],
					'refresh_token' => $fields['refresh_token'],
				);
			}
		}

		return $response;
	}

	/**
	 * Renders the markup for the connection settings.
	 *
	 * @since 1.0.0
	 * @return string The connection settings markup.
	 */
	public function render_connect_settings() {
		ob_start();
		$constant_contact_register_url = add_query_arg( array(), 'https://app.constantcontact.com/pages/dma/portal/' );
		$constant_contact_api_url      = add_query_arg( array(), 'https://www.convertpro.net/constant-contact/' );
		ConvertPlugHelper::render_input_html(
			'client_id',
			array(
				'class' => 'cpro-input',
				'type'  => 'text',
				'label' => __( 'Client ID', 'convertpro-addon' ),
				'help'  => __( 'Your Constant Contact Client ID.', 'convertpro-addon' ),
			)
		);
		ConvertPlugHelper::render_input_html(
			'client_secret',
			array(
				'class' => 'cpro-input',
				'type'  => 'text',
				'label' => __( 'Client Secret', 'convertpro-addon' ),
				'help'  => __( 'Your Constant Contact Client Secret.', 'convertpro-addon' ),
			)
		);
		ConvertPlugHelper::render_input_html(
			'access_token',
			array(
				'class' => 'cpro-input',
				'type'  => 'text',
				'label' => __( 'Access Token', 'convertpro-addon' ),
				'help'  => __( 'Your Constant Contact access Token.', 'convertpro-addon' ),
			)
		);
		ConvertPlugHelper::render_input_html(
			'refresh_token',
			array(
				'class' => 'cpro-input',
				'type'  => 'text',
				'label' => __( 'Refresh Token', 'convertpro-addon' ),
				'help'  => __( 'Your Constant Contact refresh token.', 'convertpro-addon' ),
				/* translators: %s Links */
				'desc'  => sprintf( __( '<p>Generate Access Token & Refresh Token from here: <a%2$s rel="noopener">Link</a> <br/>Note: You must register a <a%1$s rel="noopener">Developer Account</a> with Constant Contact to obtain tokens.</p>', 'convertpro-addon' ), ' href="' . $constant_contact_register_url . '" target="_blank"', ' href="' . $constant_contact_api_url . '" target="_blank"' ),
			)
		);
		return ob_get_clean();
	}

	/**
	 * Returns the api_key and access_token in array format
	 *
	 * @since 1.0.0
	 * @param @type string $auth_meta A valid API credentials.
	 * @return array Array of api_key
	 */
	public function render_auth_meta( $auth_meta ) {
		return array(
			'access_token'  => $auth_meta['access_token'],
			'refresh_token' => $auth_meta['refresh_token'],
			'client_id'     => $auth_meta['client_id'],
			'client_secret' => $auth_meta['client_secret'],
		);
	}

	/**
	 * Render the markup for service specific fields.
	 *
	 * @since 1.0.0
	 * @param string $account The name of the saved account.
	 * @param object $settings Saved module settings.
	 * @return array {
	 *      @type bool|string $error The error message or false if no error.
	 *      @type string $html The field markup.
	 * }
	 */
	public function render_fields( $account, $settings ) {
		$account_data  = ConvertPlugServices::get_account_data( $account );
		$refresh_token = $account_data['refresh_token'];
		$access_token  = $account_data['access_token'];

		$url      = $this->api_url . 'contact_lists?include_count=true&status=active&include_membership_count=all';
		$args     = array(
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			),
		);
		$request  = json_decode( wp_remote_retrieve_body( wp_remote_get( $url, $args ) ) );
		$response = array(
			'error'          => false,
			'html'           => '',
			'mapping_fields' => self::$mapping_fields,
		);

		if ( is_array( $request ) ) {
			foreach ( $request as $req ) {
				if ( isset( $req->error_message ) ) {
					$response['error'] = sprintf( __( 'Error: Could not connect to Constant Contact. %s', 'convertpro-addon' ), $req->error_message );
					break;
				}
			}
		} elseif ( isset( $request->error_message ) ) {
			$response['error'] = sprintf( __( 'Error: Could not connect to Constant Contact. %s', 'convertpro-addon' ), $request->error_message );
		} else {
			$response['html'] = $this->render_list_field( $request, $settings );
		}

		return $response;
	}

	/**
	 * Render markup for the list field.
	 *
	 * @since 1.0.0
	 * @param array  $lists List data from the API.
	 * @param object $settings Saved module settings.
	 * @return string The markup for the list field.
	 * @access private
	 */
	private function render_list_field( $lists, $settings ) {
		ob_start();

		$options = array(
			'-1' => __( 'Choose...', 'convertpro-addon' ),
		);
		$default = '';
		foreach ( $lists->lists as $list ) {
			$options[ $list->list_id ] = esc_attr( $list->name );
		}

		if ( isset( $settings['isEdit'] ) && $settings['isEdit'] ) {
			$default = ( isset( $settings['default'] ) ) ? ( ( isset( $settings['default']['list_id'] ) ) ? $settings['default']['list_id'] : '' ) : '';
		}
		ConvertPlugHelper::render_input_html(
			'list_id',
			array(
				'class'   => 'cpro-select',
				'type'    => 'select',
				'label'   => _x( 'List', 'An email list from a third party provider.', 'convertpro-addon' ),
				'options' => $options,
				'default' => $default,
			),
			$settings
		);

		return ob_get_clean();
	}

	/**
	 * Mapping fields.
	 *
	 * @since 1.0.0
	 */
	public function render_mapping() {
		return self::$mapping_fields;
	}

	/**
	 * Subscribe an email address to Constant Contact.
	 *
	 * @since 1.0.0
	 * @param object $settings A module settings object.
	 * @param string $email The email to subscribe.
	 * @param string $name Optional. The full name of the person subscribing.
	 * @return array {
	 *      @type bool|string $error The error message or false if no error.
	 * }
	 */
	public function subscribe( $settings, $email, $name = false ) {
		$account_data = ConvertPlugServices::get_account_data( $settings['api_connection'] );
		// Check if the data is valid before saving it.
		if ( is_array( $account_data ) ) {
			// Save the data into a WordPress option.
			update_option( 'cp_constant_contact_account_data', $account_data );
		}

		$response = array(
			'error' => false,
		);

		if ( ! $account_data ) {
			$response['error'] = __( 'There was an error subscribing to Constant Contact! The account is no longer connected.', 'convertpro-addon' );
		} else {
			$refresh_token = $account_data['refresh_token'];
			$access_token  = $account_data['access_token'];
			$client_id     = $account_data['client_id'];
			$client_secret = $account_data['client_secret'];
			$list_id       = $settings['list_id'];
			$url           = $this->api_url . 'contacts';

			// Prepare fields from mapping.
			$fields        = array();
			$custom_fields = array();
			$cust_fields   = array();

			foreach ( $settings['param'] as $key => $p ) {
				if ( 'email' !== $key && 'date' !== $key ) {
					if ( 'custom_field' !== $settings['meta'][ $key ] ) {
						$fields[ $settings['meta'][ $key ] ] = $p;
					} else {
						$custom_fields = array(
							'name'  => $settings['meta'][ $key . '-input' ],
							'value' => $p,
						);
						array_push( $cust_fields, $custom_fields );
					}
				}
			}

			// Prepare the request body.
			$contact_data = array(
				'email_address'    => array(
					'address'            => $email,
					'permission_to_send' => 'implicit',
				),
				'list_memberships' => array( $list_id ),
				'create_source'    => 'Account',
			);

			// Add mapped fields to contact data.
			foreach ( $fields as $key => $value ) {
				if ( in_array( $key, self::$mapping_fields, true ) ) {
					if ( 'city' === $key || 'state' === $key ) {
						// Handling address fields requires a special structure.
						if ( ! isset( $contact_data['street_addresses'] ) ) {
							$contact_data['street_addresses'] = array(
								array(
									'kind' => 'home',
								),
							);
						}

						if ( 'city' === $key ) {
							$contact_data['street_addresses'][0]['city'] = $value;
						} elseif ( 'state' === $key ) {
							$contact_data['street_addresses'][0]['state'] = $value;
						}
					} else {
						// Regular fields.
						$contact_data[ $key ] = $value;
					}
				}
			}

			// Process custom fields if any.
			if ( ! empty( $cust_fields ) ) {
				$contact_data['custom_fields'] = array();
				foreach ( $cust_fields as $field ) {
					$contact_data['custom_fields'][] = array(
						'custom_field_id' => $field['name'],
						'value'           => $field['value'],
					);
				}
			}

			// Process name if provided but not already set in fields.
			if ( $name && ! isset( $contact_data['first_name'] ) && ! isset( $contact_data['last_name'] ) ) {
				$names = explode( ' ', $name );
				if ( isset( $names[0] ) ) {
					$contact_data['first_name'] = $names[0];
				}
				if ( isset( $names[1] ) ) {
					$contact_data['last_name'] = $names[1];
				}
			}

			// Prepare the request.
			$args = array(
				'method'      => 'POST',
				'data_format' => 'body',
				'headers'     => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $access_token,
				),
				// phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode
				'body'        => json_encode( $contact_data ),
			);

			// Make the API request.
			$request       = wp_remote_post( $url, $args );
			$response_code = wp_remote_retrieve_response_code( $request );
			$response_body = json_decode( wp_remote_retrieve_body( $request ) );

			// Check for errors in the response body, even if the status code is 200.
			if ( isset( $response_body->error_message ) ) {
				$response['error'] = sprintf( __( 'There was an error subscribing to Constant Contact! %s', 'convertpro-addon' ), $response_body->error_message );
				// Call update_tokens to refresh the tokens.
				$this->update_tokens( $settings );
			} else {
				switch ( $response_code ) {
					case 201: // 201 = successfully created
						// Success, do nothing
						break;
					case 401: // 401 = unauthorized
						$response['error'] = __( 'Authorization failed. Please try again.', 'convertpro-addon' );
						// Try to refresh the token.
						$this->update_tokens( $settings );
						break;
					case 409: // 409 = conflict (already exists)
						// The contact already exists, let's try to update them
						$this->update_existing_contact( $email, $list_id, $contact_data, $access_token );
						break;
					default:
						if ( is_wp_error( $request ) ) {
							$response['error'] = $request->get_error_message();
						} elseif ( isset( $response_body->error_message ) ) {
							$response['error'] = sprintf( __( 'There was an error subscribing to Constant Contact! %s', 'convertpro-addon' ), $response_body->error_message );
						} else {
							$response['error'] = __( 'An unknown error occurred while subscribing to Constant Contact.', 'convertpro-addon' );
						}
						break;
				}
			}
		}

		return $response;
	}

	/**
	 * Updates an existing contact in Constant Contact.
	 *
	 * @since 1.0.0
	 * @param string $email The email address of the contact.
	 * @param string $list_id The list ID to add the contact to.
	 * @param array  $contact_data The contact data to update.
	 * @param string $access_token The access token for authentication.
	 * @return bool Success or failure.
	 */
	private function update_existing_contact( $email, $list_id, $contact_data, $access_token ) {
		// First, look up the contact by email to get their ID.
		$search_url = $this->api_url . 'contacts?email=' . urlencode( $email ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.urlencode_urlencode
		$args       = array(
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			),
		);

		$search_request  = wp_remote_get( $search_url, $args );
		$search_response = json_decode( wp_remote_retrieve_body( $search_request ) );

		if ( ! empty( $search_response->contacts ) && isset( $search_response->contacts[0]->contact_id ) ) {
			$contact_id = $search_response->contacts[0]->contact_id;

			// Add the list to the contact's memberships.
			if ( ! isset( $contact_data['list_memberships'] ) ) {
				$contact_data['list_memberships'] = array();
			}

			// phpcs:ignore WordPress.PHP.StrictInArray.MissingTrueStrict
			if ( ! in_array( $list_id, $contact_data['list_memberships'] ) ) {
				$contact_data['list_memberships'][] = $list_id;
			}

			// Update the contact.
			$update_url  = $this->api_url . 'contacts/' . $contact_id;
			$update_args = array(
				'method'      => 'PUT',
				'data_format' => 'body',
				'headers'     => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $access_token,
				),
				// phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode
				'body'        => json_encode( $contact_data ),
			);

			$update_request = wp_remote_request( $update_url, $update_args );
			$response_code  = wp_remote_retrieve_response_code( $update_request );

			return ( 200 === $response_code );
		}

		return false;
	}

	/**
	 * Refreshes the access token when it expires.
	 *
	 * @since 1.0.0
	 * @param array $settings Module settings containing the account info.
	 * @return bool Success or failure.
	 */
	public function update_tokens( $settings ) {
		$account_data = ConvertPlugServices::get_account_data( $settings['api_connection'] );

		if ( ! $account_data ) {
			return false;
		}

		$refresh_token = $account_data['refresh_token'];
		$client_id     = $account_data['client_id'];
		$client_secret = $account_data['client_secret'];

		// Use cURL to refresh the tokens.
		$ch = curl_init(); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init

		// Define base URL.
		$base = 'https://authz.constantcontact.com/oauth2/default/v1/token';

		// Create full request URL.
		$url = $base . '?refresh_token=' . $refresh_token . '&grant_type=refresh_token';
		curl_setopt( $ch, CURLOPT_URL, $url ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt

		// Set authorization header.
		$auth          = $client_id . ':' . $client_secret;
		$credentials   = base64_encode( $auth ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		$authorization = 'Authorization: Basic ' . $credentials;
		curl_setopt( $ch, CURLOPT_HTTPHEADER, array( $authorization, 'Content-Type: application/x-www-form-urlencoded' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt

		// Set method and to expect response.
		curl_setopt( $ch, CURLOPT_POST, true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt

		// Make the call.
		$result = curl_exec( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
		curl_close( $ch ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close

		// Decode the response.
		$response = json_decode( $result, true );

		// Check if the response contains the new tokens.
		if ( isset( $response['access_token'] ) && isset( $response['refresh_token'] ) ) {
			// Update the account data with the new tokens.
			$account_data['access_token']  = $response['access_token'];
			$account_data['refresh_token'] = $response['refresh_token'];

			// Save the updated data back to the WordPress option.
			update_option( 'cp_constant_contact_account_data', $account_data );

			return true;
		}

		return false;
	}


}
