<?php

class wfCommonPasswords {

	const BASE_LIST = [
		"password",
		"1234567890",
		"123456789",
		"12345678",
		"1234567",
		"123456",
		"12345",
		"1234",
		"123",
		"12",
		"1"
	];

	const EXTENDED_LIST = [
		"Password",
		"passwd",
		"admin",
		"administrator",
		"super",
		"superuser",
		"supervisor",
		"root",
		"manager",
		"mgr",
		"abc123",
		"qwerty",
		"asdf",
		"zxcv",
		"9876543210",
		"876543210",
		"76543210",
		"6543210",
		"543210",
		"43210",
		"3210",
		"210",
		"10",
		"0",
		"1",
		"11",
		"111",
		"1111",
		"11111",
		"2",
		"22",
		"222",
		"2222",
		"22222",
		"3",
		"33",
		"333",
		"3333",
		"33333",
		"4",
		"44",
		"444",
		"4444",
		"44444",
		"5",
		"55",
		"555",
		"5555",
		"55555",
		"6",
		"66",
		"666",
		"6666",
		"66666",
		"7",
		"77",
		"777",
		"7777",
		"77777",
		"8",
		"88",
		"888",
		"8888",
		"88888",
		"9",
		"99",
		"999",
		"9999",
		"99999",
		"0",
		"00",
		"000",
		"0000",
		"00000"
	];

	public static function getList($extended = false) {
		$list = self::BASE_LIST;
		if ($extended)
			$list = array_merge($list, self::EXTENDED_LIST);
		return $list;
	}

	public static function addToKeyedList(&$list, $extended = false) {
		foreach (self::getList($extended) as $password) {
			$list[$password] = true;
		}
	}

}