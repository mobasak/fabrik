<?php
namespace BooklyCustomDuration\Lib;

use Bookly\Lib;

class Updater extends Lib\Base\Updater
{
    public function update_2_8()
    {
        $new_pc_key = 'bookly_custom_duration_purchase_code';
        $old_pc_key = 'bookly_custom_duration_envato_purchase_code';
        $current_pc = get_option( $old_pc_key, 'missing' );
        if ( $current_pc === 'missing' ) {
            add_option( $new_pc_key, '' );
        } else {
            if ( $current_pc ) {
                add_option( $new_pc_key, $current_pc );
            }
            delete_option( $old_pc_key );
        }
    }

    public function update_1_5()
    {
        delete_option( 'bookly_custom_duration_enabled' );
    }
}