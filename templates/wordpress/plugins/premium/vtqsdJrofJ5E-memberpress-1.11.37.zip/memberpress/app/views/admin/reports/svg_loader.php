<?php

if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; display: block;" width="40px" height="40px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
<circle cx="50" cy="50" fill="none" stroke="#2271b1" stroke-width="5" r="24" stroke-dasharray="113.09733552923255 39.69911184307752">
  <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1.3888888888888888s" values="0 50 50;360 50 50" keyTimes="0;1"></animateTransform>
</circle>
</svg>