<?php if (!defined('ABSPATH')) {
    die('You are not allowed to call this page directly.');
} ?>
<?php
for ($i = 0; $i < $count; $i++) : ?>
<div class="info_block skeleton">
  <h3>&nbsp;</h3>
</div>
<?php endfor; ?>