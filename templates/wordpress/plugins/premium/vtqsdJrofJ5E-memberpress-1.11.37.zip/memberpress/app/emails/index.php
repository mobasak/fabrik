<?php

/* Silence will fall */
