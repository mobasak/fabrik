<?php
use EDD\TwoCheckout\Gateway;
use EDD\Orders\Order;

/**
 * Retrieve the API credentials
 *
 * @since 2.0
 * @return array
 */
function edd_2co_get_credentials() {

	$tco_account_number  = trim( edd_get_option( 'tco_account_number' ) );
	$tco_secret_word     = trim( edd_get_option( 'tco_secret_word' ) );
	$tco_secret_word_ins = trim( edd_get_option( 'tco_secret_word_ins' ) );
	$tco_secret_key      = trim( edd_get_option( 'tco_secret_key' ) );

	if ( empty( $tco_secret_word ) || empty( $tco_account_number ) || empty( $tco_secret_key ) || empty( $tco_secret_word_ins ) ) {
		return false;
	}

	return array(
		'tco_account_number'  => $tco_account_number,
		'tco_secret_word'     => $tco_secret_word,
		'tco_secret_word_ins' => $tco_secret_word_ins,
		'tco_secret_key'      => $tco_secret_key,
	);
}

/**
 * Renders the 2Checkout credit card form.
 *
 * @param bool $echo
 * @return void
 */
function edd_2co_credit_card_form( $echo = true ) {

	ob_start();

	if ( ! wp_script_is( 'edd-2co-js' ) ) {
		$assets = new \EDD\TwoCheckout\Assets\PayJS();
		$assets->enqueue( true );
	}

	do_action( 'edd_before_cc_fields' );
	?>

	<fieldset id="edd_cc_fields" class="edd-do-validate">
		<legend><?php esc_html_e( 'Payment Info', 'edd-2checkout' ); ?></legend>
		<?php if ( is_ssl() ) : ?>
			<div id="edd_secure_site_wrapper">
				<span class="padlock">
				<?php
				echo edd_get_payment_icon(
					array(
						'icon'    => 'lock',
						'width'   => 18,
						'height'  => 28,
						'classes' => array(
							'edd-icon',
							'edd-icon-lock',
						),
					)
				);
				?>
				</span>
				<span><?php esc_html_e( 'This is a secure SSL encrypted payment.', 'edd-2checkout' ); ?></span>
			</div>
		<?php endif; ?>
		<div id="edd-card-wrap">
			<p id="edd-card-name-wrap">
				<label for="card_name" class="edd-label">
					<?php esc_html_e( 'Name on the Card', 'edd-2checkout' ); ?>
					<span class="edd-required-indicator">*</span>
				</label>
				<input type="text" name="card_name" id="card_name" class="card-name edd-input required" placeholder="<?php esc_attr_e( 'Card name', 'edd-2checkout' ); ?>" autocomplete="cc-name" required/>
			</p>
			<div id="edd-2co-card-element"></div>
			<p class="edds-field-spacer-shim"></p><!-- Extra spacing -->
			<input type="hidden" id="edd-2checkout-client-token" name="edd_2checkout_client_token" value="">
		</div>

	</fieldset>
	<?php
	echo edd_2co_get_tokenizer_input();

	do_action( 'edd_after_cc_fields' );

	$form = ob_get_clean();

	if ( false !== $echo ) {
		echo $form;
	}

	return $form;
}
add_action( 'edd_2checkout-payjs_cc_form', 'edd_2co_credit_card_form' );

/**
 * Check if 2Checkout PayJS is the active gateway
 *
 * @since 2.0.0
 * @return bool
 */
function edd_2co_is_gateway_active_payjs() {
	return edd_is_gateway_active( '2checkout-payjs' );
}

/**
 * Get the tokenized input field
 *
 * @since 2.0.0
 * @param string $custom_id
 * @return string
 */
function edd_2co_get_tokenizer_input( $custom_id = '' ) {

	$id = 'edd-process-2co-token';
	if ( $custom_id ) {
		$id .= '-' . $custom_id;
	}
	$timestamp = time();

	return sprintf(
		'<input type="hidden" id="%s" data-timestamp="%s" data-token="%s" />',
		esc_attr( $id ),
		esc_attr( $timestamp ),
		esc_attr( \EDD\Utils\Tokenizer::tokenize( $timestamp ) )
	);
}
