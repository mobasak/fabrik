<?php

/**
 * Register our settings section
 *
 * @param array $sections The Registered EDD Sections array.
 *
 * @return array
 */
function edd2co_settings_section( $sections ) {
	$sections['2checkout'] = __( '2Checkout', 'edd-2checkout' );

	return $sections;
}
add_filter( 'edd_settings_sections_gateways', 'edd2co_settings_section' );

/**
 * Register the gateway settings
 *
 * @access      public
 * @since       1.0
 *
 * @param array $settings The currently registered settings.
 *
 * @return      array
 */
function edd2co_add_settings( $settings ) {

	$edd2co_settings = array(
		array(
			'id'   => 'tco_account_number',
			'name' => __( '2Checkout Merchant Code', 'edd-2checkout' ),
			'type' => 'text',
		),
		array(
			'id'   => 'tco_secret_key',
			'name' => __( '2Checkout Secret Key', 'edd-2checkout' ),
			'type' => 'password',
		),
		array(
			'id'   => 'tco_secret_word_ins',
			'name' => __( 'Instant Notification Service (INS) secret word', 'edd-2checkout' ),
			'desc' => __( 'The Instant Notification Service (INS) secret word is used to validate webhooks coming from 2Checkout.', 'edd-2checkout' ),
			'type' => 'password',
			'size' => 'regular',
		),
		array(
			'id'   => 'tco_secret_word',
			'name' => __( 'Buy Link Secret Word', 'edd-2checkout' ),
			'desc' => __( 'The Buy Link secret word is used to validate the initial order data sent to 2Checkout.', 'edd-2checkout' ),
			'type' => 'password',
			'size' => 'regular',
		),
		array(
			'id'   => 'tco_webhook_description',
			'type' => 'descriptive_text',
			'name' => __( 'Instant Notification System (INS)', 'edd-2checkout' ),
			'desc' =>
				/* translators: %s: 2Checkout account URL */
				'<p>' . sprintf( __( 'In order for 2Checkout to function completely, you must configure your Instant Notification System. Visit your <a href="%s" target="_blank">account dashboard</a> to configure them. Please add the URL below to all notification types.', 'edd-2checkout' ), 'https://secure.2checkout.com/cpanel/webhooks_api.php' ) . '</p>' .
				/* translators: %s: INS URL */
				'<p><strong>' . sprintf( __( 'INS URL: %s', 'edd-2checkout' ), home_url( 'index.php?edd-listener=2COINS' ) ) . '</strong></p>' .
				/* translators: %s: Documentation URL */
				'<p>' . sprintf( __( 'See our <a href="%s">documentation</a> for more information.', 'edd-2checkout' ), 'https://easydigitaldownloads.com/docs/2checkout-gateway-configuration/' ) . '</p>',
		),
	);

	$settings['2checkout'] = $edd2co_settings;

	return $settings;
}
add_filter( 'edd_settings_gateways', 'edd2co_add_settings' );
