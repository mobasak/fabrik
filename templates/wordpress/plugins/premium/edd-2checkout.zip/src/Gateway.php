<?php
/**
 * 2Checkout Payment Gateway
 *
 * @package EDD\2Checkout
 */

namespace EDD\TwoCheckout;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Gateway {

	/**
	 * The 2Checkout specific operations for the plugin.
	 *
	 * @var $gateway_plus EDD_2Checkout_Plus
	 */
	public static $instance;
	public $twcoapi;
	public $gateway_plus;
	public $gateway_payjs;

	public static function instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Gateway ) ) {
			self::$instance = new self();
			self::$instance->includes();
			self::$instance->loader();
			self::$instance->filters();
			self::$instance->actions();
		}

		return self::$instance;
	}

	private function loader() {
		self::$instance->twcoapi       = new Api();
		self::$instance->gateway_plus  = new Gateways\Plus();
		self::$instance->gateway_payjs = new Gateways\PayJs();
		$gateways                      = (array) edd_get_option( 'gateways', array() );
		$legacy_gateways               = array( '2checkout', '2checkout_onsite' );
		if ( ! empty( $gateways ) && array_intersect( array_keys( $gateways ), $legacy_gateways ) ) {
			new Legacy\Gateway();
		}
	}

	/**
	 * Include required files.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	private function includes() {
		require_once EDD_2CHECKOUT_PLUGIN_DIR . '/includes/functions.php';

		if ( is_admin() ) {
			require_once EDD_2CHECKOUT_PLUGIN_DIR . '/includes/admin/settings.php';
		}
	}

	private function filters() {
	}

	/**
	 * Setup the actions.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	private function actions() {
		add_action( 'init', array( $this, 'process_webhooks' ) );
		add_action( 'init', array( $this, 'load_textdomain' ) );
		//Handle refund request from EDD
		add_action( 'edd_refund_order', array( $this, 'maybe_refund_charge' ), 10, 3 );

		add_action(
			'edd_extension_license_init',
			function ( \EDD\Extensions\ExtensionRegistry $registry ) {
				$registry->addExtension( EDD_2CHECKOUT_PLUGIN_FILE, '2Checkout Payment Gateway', 518, EDD_2CHECKOUT_PLUGIN_VERSION );
			}
		);
	}

	/**
	 * Internationalization
	 *
	 * @since 2.0.0
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'edd-2checkout', false, WP_LANG_DIR . '/plugins' );
	}

	/**
	 * Process webhooks sent from 2checkout via INS
	 *
	 * @since 2.0
	 * @return void
	 */
	public function process_webhooks() {

		if ( empty( $_GET['edd-listener'] ) || '2COINS' !== $_GET['edd-listener'] ) {
			return;
		}

		$listener = new Webhooks\Listener( $this->twcoapi );
		$listener->process( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	/**
	 * If selected, refunds a charge in 2Checkout when creating a new refund record.
	 * This acts as a router for all 2Checkout gateways and executes the coresponding one
	 * in each individual Gateway Class file.
	 *
	 * @todo This could be moved in the Base class and use the switch for each?
	 *
	 * @since <next-versio>
	 *
	 * @param int  $order_id     ID of the order we're processing a refund for.
	 * @param int  $refund_id    ID of the newly created refund record.
	 * @param bool $all_refunded Whether or not this was a full refund.
	 */
	public function maybe_refund_charge( $order_id, $refund_id, $all_refunded ) {

		if ( ! current_user_can( 'edit_shop_payments', $order_id ) ) {
			return;
		}

		if ( empty( $_POST['data'] ) ) {
			return;
		}

		// Get our data out of the serialized string.
		parse_str( $_POST['data'], $form_data );

		$order = edd_get_order( $order_id );

		if ( empty( $order->gateway ) ) {
			return;
		}

		$refund_gateways = array( '2checkout-plus', '2checkout-inline', '2checkout-payjs' );
		if ( ! in_array( $order->gateway, $refund_gateways, true ) ) {
			return;
		}

		switch ( $order->gateway ) {
			case '2checkout-plus':
				$this->gateway_plus->try_refund_charge( $order, $refund_id, $all_refunded, $form_data );
				break;

			case '2checkout-payjs':
				$this->gateway_payjs->try_refund_charge( $order, $refund_id, $all_refunded, $form_data );
				break;
		}
	}

	/**
	 * Logs a message to EDD's debug log
	 *
	 * @since 1.3.13
	 * @param string $message The message to log
	 *
	 * @return void
	 */
	private function log( $message ) {
		edd_debug_log( $message );
	}
}
