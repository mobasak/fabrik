<?php

namespace EDD\TwoCheckout\Webhooks;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Listener {
	use Traits\MessageType;
	use Traits\Validate;

	/**
	 * The API object.
	 *
	 * @since 2.0.0
	 * @var \EDD\TwoCheckout\Api
	 */
	private $api;

	/**
	 * The order object.
	 *
	 * @since 2.0.0
	 * @var \EDD\Orders\Order
	 */
	private $order;

	/**
	 * Listener constructor.
	 *
	 * @param $api
	 */
	public function __construct( $api ) {
		$this->api = $api;
	}

	/**
	 * Processes webhooks from the payment processor.
	 *
	 * @since 2.0.0
	 */
	public function process( $data ) {

		$is_valid = $this->is_valid( $data );
		if ( true !== $is_valid ) {
			die( esc_attr( $is_valid ) );
		}

		if ( ! empty( $data['recurring'] ) && class_exists( '\\EDD_Recurring_Gateway' ) ) {
			$webhooks = new \EDD\TwoCheckout\Recurring\Webhooks\Listener( $this->api, $this->order );
			$webhooks->process( $data );
		}

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Order ' . $this->order->id . ' is valid' );

		$this->maybe_attach_customer( $this->order, $data );

		$message_type_class = $this->get_handler( $data['message_type'] );
		if ( class_exists( "\\EDD\\TwoCheckout\\Webhooks\\Types\\{$message_type_class}" ) ) {
			$class_name = "\\EDD\\TwoCheckout\\Webhooks\\Types\\{$message_type_class}";
			$handler    = new $class_name( $this->api, $this->order, $data );
			$handler->process();

			edd_debug_log( 'EDD 2Checkout 2.0.0 INS - processing reached end of logic' );
			die( '1' );
		}
	}

	/**
	 * Attach the customer to the order if not already attached.
	 *
	 * @since 2.0.0
	 * @param \EDD\Orders\Order $order
	 * @param array             $data
	 * @return void
	 */
	private function maybe_attach_customer( $order, $data ) {
		if ( ! empty( $order->email ) ) {
			return;
		}
		$this->log( 'EDD 2Checkout INS - Email blank on payment ' . $order->id . ', updating it to ' . $data['customer_email'] );

		$payment_email = sanitize_email( $data['customer_email'] );
		$customer      = new \EDD_Customer( $payment_email );

		if ( $customer->id < 1 ) {
			$customer->create(
				array(
					'email' => $payment_email,
					'name'  => sanitize_text_field( $data['customer_first_name'] ) . ' ' . sanitize_text_field( $data['customer_last_name'] ),
				)
			);
		}

		$customer->attach_payment( $order->id, false );

		// No email associated with purchase, so store from PayPal
		edd_update_order(
			$order->id,
			array(
				'email'       => $payment_email,
				'customer_id' => $customer->id,
			)
		);

		// Setup and store the customers's details.
		$address = array(
			'type'     => 'billing',
			'order_id' => $order->id,
			'name'     => sanitize_text_field( $data['customer_first_name'] ) . ' ' . sanitize_text_field( $data['customer_last_name'] ),
		);
		if ( ! empty( $data['bill_street_address'] ) ) {
			$address['address'] = sanitize_text_field( $data['bill_street_address'] );
		}
		if ( ! empty( $data['bill_street_address2'] ) ) {
			$address['address2'] = sanitize_text_field( $data['bill_street_address2'] );
		}
		if ( ! empty( $data['bill_city'] ) ) {
			$address['city'] = sanitize_text_field( $data['bill_city'] );
		}
		if ( ! empty( $data['bill_state'] ) ) {
			$address['region'] = sanitize_text_field( $data['bill_state'] );
		}
		if ( ! empty( $data['bill_country'] ) ) {
			$address['country'] = sanitize_text_field( $data['bill_country'] );
		}
		if ( ! empty( $data['bill_postal_code'] ) ) {
			$address['postal_code'] = sanitize_text_field( $data['bill_postal_code'] );
		}

		edd_add_order_address( $address );
	}
}
