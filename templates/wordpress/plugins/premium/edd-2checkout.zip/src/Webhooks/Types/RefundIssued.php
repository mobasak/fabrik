<?php

namespace EDD\TwoCheckout\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class RefundIssued extends Type {

	/**
	 * Process the webhook.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function process() {
		$i = count( $this->order->items );

		// Look for the new refund line item.
		if ( isset( $this->data[ 'item_list_amount_' . ( $i + 1 ) ] ) && $this->data[ 'item_list_amount_' . ( $i + 1 ) ] < $this->order->total ) {
			$refunded = edd_sanitize_amount( $this->data[ 'item_list_amount_' . ( $i + 1 ) ] );
			/* translators: %s: Refunded amount */
			edd_insert_payment_note( $this->order->id, sprintf( __( 'Partial refund for %s processed in 2Checkout' ), edd_currency_filter( $refunded ) ) );

		} else {
			edd_update_order_status( $this->order->id, 'refunded' );
			edd_insert_payment_note( $this->order->id, __( 'Payment refunded in 2Checkout', 'edd-2checkout' ) );
		}

		edd_debug_log( 'EDD 2Checkout INS - INS type ' . $this->data['message_type'] . ' processing complete' );
	}
}
