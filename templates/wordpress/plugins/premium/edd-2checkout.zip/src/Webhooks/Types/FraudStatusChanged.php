<?php

namespace EDD\TwoCheckout\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class FraudStatusChanged extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process() {
		edd_debug_log( 'EDD 2Checkout INS - INS type ' . $this->data['message_type'] . ' processing' );

		switch ( $this->data['fraud_status'] ) {
			case 'pass':
				edd_debug_log( 'EDD 2Checkout INS - INS type ' . $this->data['message_type'] . ' processing complete' );
				break;

			case 'fail':
				edd_update_order_status( $this->order->id, 'revoked' );
				edd_insert_payment_note( $this->order->id, __( '2Checkout fraud review failed', 'edd-2checkout' ) );
				break;

			case 'wait':
				edd_insert_payment_note( $this->order->id, __( '2Checkout fraud review in progress', 'edd-2checkout' ) );
				break;
		}
	}
}
