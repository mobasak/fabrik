<?php

namespace EDD\TwoCheckout\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class OrderCreated extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process() {
		$order_validation = $this->validate_order_webhook();
		if ( false === $order_validation['success'] ) {
			edd_update_order_status( $this->order->id, 'failed' );
			edd_add_note(
				array(
					'content'     => $order_validation['message'],
					'object_id'   => $this->order->id,
					'object_type' => 'order',
				)
			);
		} else {
			edd_update_order_status( $this->order->id, 'complete' );
		}

		edd_set_payment_transaction_id( $this->order->id, sanitize_text_field( $this->data['order_ref'] ) );
		edd_insert_payment_note( $this->order->id, __( '2Checkout fraud review passed', 'edd-2checkout' ) );

		edd_debug_log( 'EDD 2Checkout INS - INS type ' . $this->data['message_type'] . ' processing complete' );
	}

	/**
	 * Validate the $this->data data with the payment data that's recorded in EDD
	 *
	 * @since 1.3.6
	 * @param EDD_Payment $payment The EDD_Payment object for the related payment
	 *
	 * @return bool
	 */
	private function validate_order_webhook() {
		if ( $this->order->total > $this->data['invoice_list_amount'] ) {
			return array(
				'success' => false,
				'message' => sprintf(
					/* translators: 1: 2Checkout total, 2: EDD total */
					__( '2Checkout total (%1$s) did not match payment total (%2$s).', 'edd-2checkout' ),
					$this->data['invoice_list_amount'],
					$this->order->total
				),
			);
		}

		return array(
			'success' => true,
			'message' => '',
		);
	}
}
