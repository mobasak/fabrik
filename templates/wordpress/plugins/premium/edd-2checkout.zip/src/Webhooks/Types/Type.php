<?php

namespace EDD\TwoCheckout\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

abstract class Type {

	/**
	 * API instance.
	 *
	 * @var \EDD\TwoCheckout\Api
	 */
	protected $api;

	/**
	 * Order instance.
	 *
	 * @var \EDD\Orders\Order
	 */
	protected $order;

	/**
	 * Data from the webhook.
	 *
	 * @var array
	 */
	protected $data;

	/**
	 * Type constructor.
	 *
	 * @param \EDD\TwoCheckout\Api $api   API instance.
	 * @param \EDD\Orders\Order    $order Order instance.
	 * @param array                $data  Data from the webhook.
	 */
	public function __construct( $api, $order, $data ) {
		$this->api   = $api;
		$this->order = $order;
		$this->data  = $data;
	}

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	abstract public function process();
}
