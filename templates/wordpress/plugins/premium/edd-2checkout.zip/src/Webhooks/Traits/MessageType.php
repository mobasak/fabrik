<?php

namespace EDD\TwoCheckout\Webhooks\Traits;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

trait MessageType {

	/**
	 * Get the handler class name for the message type.
	 *
	 * @param string $message_type
	 * @return string|bool
	 */
	private function get_handler( $message_type ) {
		$type = str_replace( '_', ' ', strtolower( $message_type ) );
		$type = ucwords( $type );
		$type = str_replace( ' ', '', $type );

		return $type;
	}
}
