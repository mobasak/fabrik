<?php

namespace EDD\TwoCheckout\Webhooks\Traits;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Trait Validate
 *
 * @since 2.0.0
 */
trait Validate {

	/**
	 * Checks whether the data is valid.
	 *
	 * @since 2.0.0
	 * @param array $data
	 * @return true|string Returns true if the webhook data is valid, otherwise returns an error code.
	 */
	protected function is_valid( $data ) {
		if ( empty( $data['sale_id'] ) ) {
			edd_debug_log( 'EDD 2Checkout 2.0.0 INS - processing stopped due to missing required parameters. Input data: ' . var_export( $data, true ) );
			return '-1';
		}

		if ( empty( $data['message_type'] ) ) {
			return '-2';
		}

		if ( empty( $data['vendor_id'] ) ) {
			return '-3';
		}

		$credentials = edd_2co_get_credentials();
		if ( ! $credentials ) {
			return '-4';
		}

		$purchase_key = sanitize_text_field( $data['vendor_order_id'] );
		$this->order  = edd_get_order_by( 'payment_key', $purchase_key );
		if ( ! $this->order ) {
			edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Payment not found, processing stopped' );
			return '-5';
		}

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Payment ' . $this->order->id . ' found' );

		$hash = strtoupper( md5( $data['sale_id'] . $credentials['tco_account_number'] . $data['invoice_id'] . $credentials['tco_secret_word_ins'] ) );
		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Calculated hash: ' . $hash );

		if ( ! hash_equals( $hash, $data['md5_hash'] ) ) {
			edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Invalid hash. Expected: ' . $hash . '. Provided: ' . $data['md5_hash'] );
			return '-6';
		}

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - processing started. Input data: ' . var_export( $data, true ) );

		return true;
	}
}
