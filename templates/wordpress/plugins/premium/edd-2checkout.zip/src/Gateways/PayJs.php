<?php
/**
 * Class PayJs
 *
 * @link https://verifone.cloud/docs/2checkout/API-Integration/2Pay.js-payments-solution/2Pay.js-Payments-Solution-Integration-Guide
 *
 * @package EDD_2Checkout
 * @since   2.0.0
 */

namespace EDD\TwoCheckout\Gateways;

use EDD\TwoCheckout\Gateway;

defined( 'ABSPATH' ) || exit;

class PayJs extends Base {

	/**
	 * Gateway ID.
	 *
	 * @var string
	 */
	public $id = '2checkout-payjs';

	/**
	 * Load up any hooks or filters needed.
	 *
	 */
	public function __construct() {
		parent::__construct();
		add_action( 'edd_2checkout-payjs_cc_form', '__return_false' );
		add_action( 'edd_gateway_2checkout-payjs', array( $this, 'process_payment' ) );
		add_filter( 'edd_require_billing_address', array( $this, 'require_billing_address' ) );
		add_filter( 'edd_purchase_form_required_fields', array( $this, 'update_required_fields' ) );
		add_action( 'edd_before_checkout_cart', array( $this, 'enqueue' ) );
		add_action( 'edd_after_cc_fields', array( $this, 'add_error_container' ), 999 );
		add_action( 'edd_setup_components', array( $this, 'recurring' ) );
	}

	/**
	 * Add recurring support for the PayJS gateway.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function recurring() {
		if ( class_exists( '\\EDD_Recurring_Gateway' ) ) {
			new \EDD\TwoCheckout\Recurring\PayJS();
		}
	}

	/**
	 * Register the gateway.
	 *
	 * @since 2.0.0
	 * @param array $gateways
	 * @return array
	 */
	public function register( $gateways ) {
		$gateways['2checkout-payjs'] = array(
			'admin_label'    => __( '2Checkout Onsite', 'edd-2checkout' ),
			'checkout_label' => __( 'Credit Card', 'edd-2checkout' ),
			'icons'          => array(
				'mastercard',
				'visa',
				'discover',
				'americanexpress',
			),
		);

		return $gateways;
	}

	/**
	 * Enqueue the 2Checkout PayJS scripts.
	 *
	 * @since 2.0.0
	 */
	public function enqueue() {
		if ( false === edd_2co_is_gateway_active_payjs() ) {
			return;
		}
		$assets = new \EDD\TwoCheckout\Assets\PayJS();
		$assets->enqueue();
	}

	/**
	 * Process the purchase data and send it to 2Checkout.
	 *
	 * @since 2.0.0
	 *
	 * @param array $purchase_data Contains the array of purchase data from the EDD Purchase process.
	 */
	public function process_payment( $purchase_data ) {

		if ( empty( $purchase_data['post_data']['edd_2checkout_client_token'] ) ) {
			$this->handle_processing_error( 'missing_payment_method_nonce', __( 'Missing payment method token. Please try again.', 'edd-2checkout' ) );
		}

		// Record the pending order.
		$order_id = edd_build_order( $purchase_data );

		if ( false === $order_id ) {
			$this->handle_processing_error( 'payment_error', __( 'An error occurred, but your payment may have gone through. Please contact the site administrator.', 'edd-2checkout' ) );
		}

		// Get order object.
		$order           = edd_get_order( $order_id );
		$billing_details = $this->get_order_billing_data( $order );

		// Get the success url
		$return_url = add_query_arg(
			array(
				'payment-confirmation' => $this->id,
				'payment-id'           => $order_id,
			),
			edd_get_success_page_uri()
		);

		$order_params = array(
			'Currency'          => $order->currency,
			'CustomerIP'        => edd_get_ip(),
			'ExternalReference' => $order->payment_key,
			'Language'          => self::get_language(),
			'Source'            => 'EasyDigitalDownloads_' . EDD_VERSION,
			'BillingDetails'    =>
				array(
					'FirstName'   => $billing_details['first_name'],
					'LastName'    => $billing_details['last_name'],
					'Address1'    => $billing_details['address'],
					'City'        => $billing_details['city'],
					'State'       => $billing_details['state'],
					'CountryCode' => $billing_details['country'],
					'Email'       => $order->email,
					'Zip'         => $billing_details['zip'],
				),
			'Items'             => $this->get_order_items( $order ),
			'PaymentDetails'    =>
				array(
					'Type'          => edd_is_test_mode() ? 'TEST' : 'EES_TOKEN_PAYMENT', //'TEST' or 'EES_TOKEN_PAYMENT' for 2Pay.js
					'Currency'      => $order->currency,
					'PaymentMethod' =>
						array(
							'EesToken'           => $purchase_data['post_data']['edd_2checkout_client_token'],
							'Vendor3DSReturnURL' => $return_url,
							'Vendor3DSCancelURL' => edd_get_checkout_uri( '?payment-mode=' . $this->id ),
						),
				),
		);

		$response = Gateway::instance()->twcoapi->call( '/orders/', $order_params );

		if ( ! $response || ( isset( $response['error_code'] ) && ! empty( $response['error_code'] ) ) ) {
			$error_message = __( 'Payment failed, please try again.', 'edd-2checkout' );
			if ( $response && ! empty( $response['message'] ) ) {
				$error_message = $response['message'];
			}

			$this->handle_processing_error( 'api_payment_error', $error_message );
		}

		if ( $response['Errors'] ) { // errors that must be shown to the client

			$error_message = '';

			foreach ( $response['Errors'] as $key => $value ) {
				$error_message .= $value . PHP_EOL;
			}

			/* translators: %s: error message */
			$this->handle_processing_error( 'payment_error', sprintf( __( 'Payment failed. %s', 'edd-2checkout' ), $error_message ) );
		}

		// At this point the transaction is in good standing.
		// @todo Handle 3DS
		$has3ds = false;
		if ( isset( $response['PaymentDetails']['PaymentMethod']['Authorize3DS'] ) ) {
			$has3ds = $this->has_authorize_3DS( $response['PaymentDetails']['PaymentMethod']['Authorize3DS'] );
		}

		if ( $has3ds ) {
			$redirect_url = $has3ds;
		}

		if ( in_array( $response['Status'], array( 'AUTHRECEIVED', 'COMPLETE' ), true ) ) {
			edd_set_payment_transaction_id( $order_id, $response['RefNo'] );
			edd_update_order_status( $order_id, 'complete' );
			edd_empty_cart();
			edd_send_to_success_page();
		}

		$errors = edd_get_errors();

		if ( $errors ) {
			$this->handle_processing_error( 'general_error' );
		}
	}

	/**
	 * Require billing address for 2Checkout.
	 *
	 * @since 2.0.0
	 *
	 * @param bool $billing_address_required Whether or not the billing address is required.
	 * @return bool
	 */
	public function require_billing_address( $billing_address_required ) {
		if ( edd_get_chosen_gateway() === $this->id ) {
			return true;
		}

		return $billing_address_required;
	}

	/**
	 * Update the required fields for 2Checkout.
	 *
	 * @since 2.0.0
	 *
	 * @param array $required_fields Contains the required fields.
	 * @return array
	 */
	public function update_required_fields( $required_fields ) {
		if ( edd_get_chosen_gateway() === $this->id ) {
			$required_fields['edd_last']     = array(
				'error_id'      => 'edd_last',
				'error_message' => __( 'The last name is required.', 'edd-2checkout' ),
			);
			$required_fields['card_address'] = array(
				'error_id'      => 'card_address',
				'error_message' => __( 'The address is required.', 'edd-2checkout' ),
			);
		}

		return $required_fields;
	}

	/**
	 * Format the order items for 2Checkout.
	 * Because of the way 2Checkout handles products, we need to send the cart items as a single product.
	 * This allows us to safely account for discounts, fees, and taxes.
	 *
	 * @since 2.0.0
	 *
	 * @param obj $order The order object.
	 * @return array Contains the items formatted
	 */
	public function get_order_items( $order ) {
		return array(
			array(
				'Code'             => null,
				'Quantity'         => 1,
				'Name'             => get_bloginfo(),
				'Description'      => 'N/A',
				'RecurringOptions' => null,
				'IsDynamic'        => true,
				'Tangible'         => false,
				'PurchaseType'     => 'PRODUCT',
				'Price'            => array(
					'Amount' => (string) edd_sanitize_amount( $order->total ),
					'Type'   => 'CUSTOM',
				),
			),
		);
	}

	/**
	 * Add the error container below the credit card fields.
	 *
	 * @since 2.0.0
	 */
	public function add_error_container() {
		if ( edd_2co_is_gateway_active_payjs() ) {
			echo '<div id="edd-2co-dropin-errors"></div>';
		}
	}

	/**
	 * Check if the payment method has 3DS.
	 *
	 * @since 2.0.0
	 *
	 * @param array $has3ds
	 * @return string|null
	 */
	private function has_authorize_3DS( $has3ds ) {
		if ( isset( $has3ds ) && isset( $has3ds['Href'] ) && ! empty( $has3ds['Href'] ) ) {
			return $has3ds['Href'] . '?avng8apitoken=' . $has3ds['Params']['avng8apitoken'];
		}

		return null;
	}

	/**
	 * Sets an error and returns the user back to checkout.
	 *
	 * @param string $error_code    Error code.
	 * @param string $error_message Optional error message. If omitted, a default is used.
	 *
	 * @since 1.2
	 */
	protected function handle_processing_error( $error_code, $error_message = '' ) {
		if ( empty( $error_message ) ) {
			$error_message = __( 'An unexpected error occurred while processing your payment.', 'edd-2checkout' );
		}
		//@todo This does not seem to show the erro message when you get sent back to the checkout page
		edd_debug_log( sprintf( '2Checkout Processing Error: Code: %s; Message: %s', $error_code, $error_message ) );
		edd_set_error( '2checkout_' . sanitize_key( $error_code ), $error_message );
		edd_send_back_to_checkout( '?payment-mode=' . $this->id );
	}
}
