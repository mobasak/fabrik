<?php

namespace EDD\TwoCheckout\Gateways\Utilities;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Redirect utility.
 *
 * @since 2.0.0
 */
class Redirect {
	use \EDD\TwoCheckout\Gateways\Traits\Language;

	/**
	 * Get the redirect URL for checking out with the Plus gateway.
	 *
	 * @since 2.0.0
	 * @param array $args
	 * @return string
	 */
	public static function get( $args ) {
		$api  = new \EDD\TwoCheckout\Api();
		$args = wp_parse_args(
			$args,
			array(
				'merchant'    => $api->get_merchant_id(),
				'dynamic'     => 1,
				'src'         => 'EasyDigitalDownloads_' . EDD_VERSION,
				'expiration'  => time() + ( 3600 * 5 ),
				'return-type' => 'redirect',
				'language'    => self::get_language(),
			)
		);
		if ( edd_is_test_mode() ) {
			$args['test'] = '1';
		}
		$args['signature'] = $api->get_signature( $args );
		$redirect          = 'https://secure.2checkout.com/checkout/buy/?';
		$redirect         .= http_build_query( $args );
		$redirect          = str_replace( '&amp;', '&', $redirect );

		return $redirect;
	}
}
