<?php

namespace EDD\TwoCheckout\Gateways;

defined( 'ABSPATH' ) || exit;

abstract class Base {
	use Traits\BillingData;
	use Traits\Currency;
	use Traits\Language;

	/**
	 * Gateway ID.
	 *
	 * @var string
	 */
	public $id;

	/**
	 * Base constructor.
	 */
	public function __construct() {
		add_filter( 'edd_payment_gateways', array( $this, 'register' ) );
		add_filter( 'edd_payment_details_transaction_id-' . $this->id, array( $this, 'link_transaction_id' ), 11, 2 );
		add_action( 'edd_after_submit_refund_table', array( $this, 'show_refund_checkbox' ) );
		add_action( 'edd_gateway_id-' . $this->id, array( $this, 'process_payment' ) );
		add_filter( 'edd_is_gateway_setup_' . $this->id, array( $this, 'is_gateway_setup' ) );
		add_filter( 'edd_gateway_settings_url_' . $this->id, array( $this, 'get_settings_uri' ) );
		add_action( 'edd_checkout_error_checks', array( $this, 'validate_fields' ), 10, 2 );
	}

	/**
	 * Register the gateway.
	 *
	 * @since 2.0.0
	 * @param array $gateways
	 * @return array
	 */
	abstract public function register( $gateways );

	/**
	 * Process the payment.
	 *
	 * @since 2.0.0
	 * @param array $purchase_data
	 * @return void
	 */
	abstract public function process_payment( $purchase_data );

	/**
	 * Check if the gateway is setup.
	 *
	 * @since 2.0.0
	 * @return bool
	 */
	public function is_gateway_setup() {
		return (bool) edd_2co_get_credentials();
	}

	/**
	 * Get the settings URI.
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_settings_uri() {
		return edd_get_admin_url(
			array(
				'page'    => 'edd-settings',
				'tab'     => 'gateways',
				'section' => '2checkout',
			)
		);
	}

	/**
	 * Show the refund checkbox.
	 *
	 * @since 2.0.0
	 * @param @param \EDD\Orders\Order $order
	 * @return void
	 */
	public function show_refund_checkbox( \EDD\Orders\Order $order ) {

		if ( $this->id !== $order->gateway ) {
			return;
		}
		?>
		<div class="edd-form-group edd-<?php echo esc_attr( $this->id ); ?>-refund-transaction">
			<div class="edd-form-group__control">
				<input
					type="checkbox"
					id="edd-<?php echo esc_attr( $this->id ); ?>-refund"
					name="edd-<?php echo esc_attr( $this->id ); ?>-refund"
					class="edd-form-group__input"
					value="1"
					<?php echo esc_attr( 'on_hold' === $order->status ? 'disabled' : '' ); ?>
				>
				<label for="edd-<?php echo esc_attr( $this->id ); ?>-refund" class="edd-form-group__label">
					<?php esc_html_e( 'Refund Charge in 2Checkout', 'edd-2checkout' ); ?>
				</label>
			</div>
			<p class="edd-form-group__help description">
				<?php esc_html_e( 'Partial refunds must be manually refunded in 2Checkout.', 'edd-2checkout' ); ?>
			</p>
			<?php if ( 'on_hold' === $order->status ) : ?>
				<p class="edd-form-group__help description">
					<?php esc_html_e( 'This order is currently on hold. You can create the refund transaction in EDD; 2Checkout may have already issued a refund.', 'edd-2checkout' ); ?>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Validate the fields.
	 *
	 * @since 2.0.0
	 * @param array $data
	 * @param array $post_data
	 * @return void
	 */
	public function validate_fields( $data, $post_data ) {
		if ( $this->id !== $data['gateway'] ) {
			return;
		}
		$currency = edd_get_currency();
		if ( ! in_array( $currency, $this->get_supported_currencies(), true ) ) {
			/* translators: %s: currency code */
			edd_set_error( 'currency', sprintf( __( '2Checkout does not support the %s currency.', 'edd-2checkout' ), $currency ) );
		}
	}

	/**
	 * Refunds a charge in 2Checkout.
	 *
	 * @since 2.0.0
	 *
	 * @param obj  $order     ID of the order we're processing a refund for.
	 * @param int  $refund_id    ID of the newly created refund record.
	 * @param bool $all_refunded Whether or not this was a full refund.
	 */
	public function try_refund_charge( $order, $refund_id, $all_refunded, $form_data ) {

		if ( empty( $form_data[ "edd-{$this->id}-refund" ] ) ) {
			edd_debug_log( '2Checkout - Exiting refund process, as checkbox was not selected.' );

			edd_add_note(
				array(
					'object_id'   => $order->id,
					'object_type' => 'order',
					'user_id'     => is_admin() ? get_current_user_id() : 0,
					'content'     => __( 'Charge not refunded in 2Checkout, as checkbox was not selected.', 'edd-2checkout' ),
				)
			);

			return;
		}

		edd_debug_log( sprintf( '2Checkout - Maybe processing refund for order #%d.', $order->id ) );

		$refund = edd_get_order( $refund_id );
		if ( empty( $refund->total ) ) {
			edd_debug_log(
				sprintf(
					'2Checkout - Exiting refund for order #%d - refund total is empty.',
					$order->id
				)
			);

			return;
		}

		try {
			$this->handle_refund( $order, $refund );
		} catch ( \Exception $e ) {
			edd_debug_log( sprintf( 'Exception thrown while refunding order #%d. Message: %s', $order->id, $e->getMessage() ) );
		}
	}

	/**
	 * Refunds a charge made via 2Checkout.
	 *
	 * @since 2.0.0
	 *
	 * @param int|Order  $order         The object (EDD 3.0+ only) of the order to refund.
	 * @param Order|null $refund        Optional. The refund object associated with this
	 *                                  charge refund. If provided, then the refund amount
	 *                                  is used as the charge refund amount (for partial refunds), and
	 *                                  an EDD transaction record will be inserted (EDD 3.0+ only).
	* @throws \Exception
	*/
	protected function handle_refund( $order, $refund = null ) {

		if ( ! is_numeric( $order->id ) ) {
			throw new \Exception( esc_html__( 'Invalid order ID.', 'edd-2Checkout' ), 400 );
		}

		edd_debug_log(
			sprintf(
				'Processing 2Checkout refund for order #%d',
				$order->id
			)
		);

		$transaction_id = edd_get_payment_transaction_id( $order->id );

		// Bail if no charge ID was found.
		if ( empty( $transaction_id ) ) {
			edd_insert_payment_note( $order->id, __( 'The order could not be refunded at 2Checkout.', 'edd-2checkout' ) );
			edd_debug_log( sprintf( 'Exiting refund of order #%d. No 2Checkout charge found.', $order->id ) );
			return;
		}

		//Validate order with 2Checkout.
		$twcoapi    = \EDD\TwoCheckout\Gateway::instance()->twcoapi;
		$order_data = $twcoapi->call( '/orders/' . $transaction_id . '/', array(), 'GET' );

		//Check the Order exists in 2Checkout.
		if ( ! $order_data ) {
			edd_insert_payment_note( $order->id, __( 'The order could not be refunded at 2Checkout.', 'edd-2checkout' ) );
			edd_debug_log( sprintf( 'The order #%d, with transaction ID %s, does not exist with 2Checkout.', $order->id, $transaction_id ) );

			return;
		}

		$args = $this->get_refund_parameters( $order, $refund );
		if ( false === $args ) {
			return;
		}
		$refund_response = $twcoapi->call( '/orders/' . $transaction_id . '/refund/', $args, 'POST' );

		if ( isset( $refund_response['error_code'] ) && ! empty( $refund_response['error_code'] ) ) {
			edd_insert_payment_note( $order->id, __( 'The order could not be refunded at 2Checkout.', 'edd-2checkout' ) );
			edd_debug_log( 'Refund failed. Please login to your 2Checkout admin to issue the refund manually.' );
			return;
		}

		$order_note = sprintf(
			/* translators: %1$s the amount refunded; %2$s Refund ID */
			__( '%1$s refunded in 2Checkout. Refund ID %2$s', 'edd-2checkout' ),
			edd_currency_filter( $order_data['GrossPrice'], strtoupper( $refund->currency ) ),
			$refund->id
		);

		edd_insert_payment_note( $order->id, $order_note );
	}

	/**
	 * Link the transaction ID to the payment ID.
	 *
	 * @param int $transaction_id
	 * @param int $payment_id
	 * @return string
	 */
	public function link_transaction_id( $transaction_id, $payment_id ) {
		$base_url = 'https://secure.2checkout.com/cpanel/order_info.php?refno=';
		$url      = '<a href="' . esc_url( $base_url . $transaction_id ) . '" target="_blank">' . $transaction_id . '</a>';

		return apply_filters( 'edd_2checkout_link_payment_details_transaction_id', $url );
	}

	/**
	 * Get the refund parameters.
	 *
	 * @since 2.0.0
	 * @param \EDD\Orders\Order $order
	 * @param \EDD\Orders\Order $refund
	 * @return array
	 */
	private function get_refund_parameters( $order, $refund ) {
		if ( abs( $refund->total ) !== abs( $order->total ) ) {
			edd_debug_log(
				sprintf(
					'A partial refund was created in EDD for order #%d; the refund must be manually created in 2Checkout. Refund amount: %s.',
					$order->id,
					edd_currency_filter( $refund->total, $refund->currency )
				)
			);

			return false;
		}

		edd_debug_log( sprintf( 'Processing full 2Checkout refund for order #%d.', $order->id ) );

		return array(
			'reason'  => 'Other',
			'comment' => 'Refunded by EDD',
			'amount'  => $order->total,
		);
	}
}
