<?php
/**
 * Class Plus
 *
 * @link https://verifone.cloud/docs/2checkout/Documentation/07Commerce/2Checkout-ConvertPlus/ConvertPlus_URL_parameters#buy__002dlink-parameters
 *
 * @package EDD\2Checkout
 * @since   2.0.0
 */

namespace EDD\TwoCheckout\Gateways;

use EDD\TwoCheckout\Gateway;

defined( 'ABSPATH' ) || exit;

class Plus extends Base {

	/**
	 * Gateway ID.
	 *
	 * @var string
	 */
	public $id = '2checkout-plus';

	/**
	 * Load up any hooks or filters needed.
	 */
	public function __construct() {
		parent::__construct();
		add_filter( 'edd_payment_confirm_2checkout-plus', array( $this, 'pending_success_page' ) );

		// We need to remove the `name` parameter from the return url.
		add_action( 'template_redirect', array( $this, 'remove_2checkout_name' ) );
		add_action( 'edd_2checkout-plus_cc_form', '__return_false' );
		add_action( 'edd_gateway_2checkout-plus', array( $this, 'process_payment' ) );
		add_action( 'edd_setup_components', array( $this, 'recurring' ) );
	}

	/**
	 * Add recurring support for the Plus gateway.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function recurring() {
		if ( class_exists( '\\EDD_Recurring_Gateway' ) ) {
			new \EDD\TwoCheckout\Recurring\Plus();
		}
	}

	/**
	 * Remove the `name` parameter from the return url.
	 *
	 * @since 2.0.0
	 */
	public function remove_2checkout_name() {
		if ( isset( $_GET['name'] ) && ( isset( $_GET['payment-confirmation'] ) && '2checkout-plus' === $_GET['payment-confirmation'] ) ) {
			edd_redirect( remove_query_arg( 'name' ) );
		}
	}

	/**
	 * Register the gateway.
	 *
	 * @since 2.0.0
	 * @param array $gateways
	 * @return array
	 */
	public function register( $gateways ) {
		$gateways['2checkout-plus'] = array(
			'admin_label'    => __( '2Checkout Convert Plus', 'edd-2checkout' ),
			'checkout_label' => __( '2Checkout', 'edd-2checkout' ),
			'icons'          => array(
				'mastercard',
				'visa',
				'discover',
				'americanexpress',
			),
		);

		return $gateways;
	}

	/**
	 * Process the purchase data and send it to Braintree.
	 *
	 * @param array $purchase_data Contains the array of purchase data from the EDD Purchase process.
	 */
	public function process_payment( $purchase_data ) {

		$order_id = edd_build_order( $purchase_data );

		if ( $order_id ) {
			$twcoapi = Gateway::instance()->twcoapi;
			$order   = edd_get_order( $order_id );

			// Get the success url
			$return_url = add_query_arg(
				array(
					'payment-confirmation' => $this->id,
					'payment-id'           => $order_id,
				),
				edd_get_success_page_uri()
			);

			$base_args = array(
				'return-url'       => $return_url,
				'back-url'         => edd_get_checkout_uri( '?payment-mode=' . $this->id ),
				'order-ext-ref'    => $order->payment_key,
				'customer-ext-ref' => $order->email,
				'currency'         => $order->currency,
			);

			// Setup the products in the cart
			$products_data = $this->get_order_items( $order );
			$billing_data  = parent::get_order_billing_data( $order );

			$base_args = array_merge( $base_args, $products_data, $billing_data );
			$base_args = apply_filters( 'edd_2co_redirect_args', $base_args, $purchase_data );
			$redirect  = Utilities\Redirect::get( $base_args );

			// Check if any errors are present.
			$errors = edd_get_errors();

			if ( $errors ) {
				edd_send_back_to_checkout( '?payment-mode=' . $this->id );
			}

			wp_redirect( $redirect ); // phpcs:ignore WordPress.Security.SafeRedirect
			exit;
		} else {
			// if errors are present, send the user back to the purchase page so they can be corrected
			edd_send_back_to_checkout( '?payment-mode=' . $this->id );
		}
	}

	/**
	 * Format the cart items to follow 2Checkout's requests.
	 * Because of the way 2Checkout handles products, we need to send the cart items as a single product.
	 * This allows us to safely account for discounts, fees, and taxes.
	 *
	 * @since 2.0.0
	 *
	 * @param array $purchase_data Contains the array of purchase data from the EDD Purchase process.
	 * @return array Contains the items formatted
	 */
	public function get_order_items( $order ) {
		return array(
			'prod'     => get_bloginfo(),
			'price'    => edd_sanitize_amount( $order->total ),
			'qty'      => 1,
			'type'     => 'PRODUCT',
			'tangible' => 0, // Send TRUE or 1 for products that require physical delivery.
		);
	}

	/**
	 * Shows "Purchase Processing" message for 2Checkout payments on site return
	 *
	 * This helps address the Race Condition, as detailed in issue #1839
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function pending_success_page( $content ) {

		$order_id = filter_input( INPUT_GET, 'payment-id', FILTER_SANITIZE_NUMBER_INT );
		if ( ! $order_id ) {
			$purchase_session = edd_get_purchase_session();
			if ( ! empty( $purchase_session['purchase_key'] ) ) {
				$order_id = edd_get_purchase_id_by_key( $purchase_session['purchase_key'] );
			}
		}
		if ( ! $order_id ) {
			return $content;
		}

		edd_empty_cart();

		$order = edd_get_order( $order_id );

		// Payment is still pending so show processing indicator to fix the race condition.
		if ( $order && 'pending' === $order->status ) {
			ob_start();
			edd_get_template_part( 'payment', 'processing' );

			return ob_get_clean();
		}

		return $content;
	}
}
