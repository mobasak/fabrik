<?php

namespace EDD\TwoCheckout\Gateways\Traits;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

trait BillingData {

	/**
	 * Get the billing data for an order.
	 *
	 * @since 2.0.0
	 *
	 * @param obj $order The order object.
	 * @return array
	 */
	protected function get_order_billing_data( $order ) {

		$addresses = edd_get_order_addresses(
			array(
				'order_id' => $order->id,
				'type'     => 'billing',
				'number'   => 1,
			)
		);

		if ( ! empty( $addresses[0] ) ) {
			$address = $addresses[0];

			$customer = edd_get_customer( $order->customer_id );

			return array(
				'fullname'   => $customer->name,
				'first_name' => $this->get_customer_first_name( $customer->name ),
				'last_name'  => $this->get_customer_last_name( $customer->name ),
				'address'    => $address->address,
				'address2'   => $address->address2,
				'city'       => $address->city,
				'state'      => $address->region,
				'zip'        => $address->postal_code,
				'country'    => $address->country,
				'email'      => $order->email,
			);
		}

		// We try to send at least the email to be prefilled in the Purchase form
		return array(
			'email' => $order->email,
		);
	}

	/**
	 * Get the first name of the customer.
	 *
	 * @since 2.0.0
	 *
	 * @param string $name The customer name.
	 * @return string
	 */
	protected function get_customer_first_name( $name ) {
		$names = explode( ' ', $name );

		return ! empty( $names[0] ) ? $names[0] : '';
	}

	/**
	 * Get the last name of the customer.
	 *
	 * @since 2.0.0
	 *
	 * @param string $name The customer name.
	 * @return string
	 */
	protected function get_customer_last_name( $name ) {

		$names     = explode( ' ', $name );
		$last_name = '';
		if ( ! empty( $names[1] ) ) {
			unset( $names[0] );
			$last_name = implode( ' ', $names );
		}

		return $last_name;
	}
}
