<?php

namespace EDD\TwoCheckout\Gateways\Traits;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

trait Language {

	/**
	 * Get the language code.
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public static function get_language() {

		$current_locale_setting = get_option( 'WPLANG' );
		$current_store_lang     = get_locale();
		$lang                   = ! $current_store_lang ? $current_locale_setting : $current_store_lang;

		return strstr( $lang, '_', true );
	}
}
