<?php

namespace EDD\TwoCheckout\Gateways\Traits;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Trait Currency
 *
 * @since 2.0.0
 * @package EDD\TwoCheckout\Gateways\Traits
 */
trait Currency {

	/**
	 * Get the supported currencies.
	 * @source https://verifone.cloud/docs/2checkout/Documentation/07Commerce/Checkout-links-and-options/Billing-currencies
	 *
	 * @since 2.0.0
	 * @return array
	 */
	private function get_supported_currencies() {
		return array(
			'AED',
			'AFN',
			'ALL',
			'ARS',
			'AUD',
			'AZN',
			'BBD',
			'BDT',
			'BGN',
			'BMD',
			'BND',
			'BOB',
			'BRL',
			'BSD',
			'BWP',
			'BYN',
			'BYR',
			'BZD',
			'CAD',
			'CHF',
			'CNY',
			'COP',
			'CRC',
			'CZK',
			'DKK',
			'DOP',
			'DZD',
			'EGP',
			'EUR',
			'FJD',
			'GBP',
			'GTQ',
			'HKD',
			'HNL',
			'HUF',
			'IDR',
			'ILS',
			'INR',
			'JMD',
			'JOD',
			'JPY',
			'KES',
			'KRW',
			'KWD',
			'KZT',
			'LAK',
			'LBP',
			'LKR',
			'LRD',
			'MAD',
			'MDL',
			'MMK',
			'MOP',
			'MRO',
			'MUR',
			'MVR',
			'MXN',
			'MYR',
			'NAD',
			'NGN',
			'NIO',
			'NOK',
			'NPR',
			'NZD',
			'OMR',
			'PEN',
			'PGK',
			'PHP',
			'PKR',
			'PLN',
			'PYG',
			'QAR',
			'RON',
			'RSD',
			'RUB',
			'SAR',
			'SBD',
			'SCR',
			'SEK',
			'SGD',
			'THB',
			'TND',
			'TOP',
			'TTD',
			'TWD',
			'UAH',
			'USD',
			'UYU',
			'VND',
			'VUV',
			'WST',
			'XCD',
			'XOF',
			'YER',
			'ZAR',
		);
	}
}
