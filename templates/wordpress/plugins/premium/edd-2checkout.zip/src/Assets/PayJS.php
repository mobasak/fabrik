<?php

namespace EDD\TwoCheckout\Assets;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class PayJS
 *
 * @package EDD_2Checkout
 * @since   2.0.0
 */
class PayJS {

	/**
	 * Enqueue the 2Checkout PayJS scripts.
	 *
	 * @since 2.0.0
	 * @param bool $force_load_scripts Whether to force load the scripts or not.
	 * @return void
	 */
	public function enqueue( $force_load_scripts = false ) {

		wp_register_script(
			'edd2co-2checkout-js-v1',
			'https://2pay-js.2checkout.com/v1/2pay.js',
			array( 'edd-checkout-global' ),
			'v1',
			true
		);

		$is_checkout = edd_is_checkout() && 0 < edd_get_cart_total();
		if ( ! $is_checkout && ! $force_load_scripts ) {
			return;
		}

		$script_source = EDD_2CHECKOUT_PLUGIN_URL . 'assets/js/edd-2co.js';
		$script_deps   = array(
			'edd2co-2checkout-js-v1',
			'jquery',
			'edd-ajax',
		);

		wp_register_script(
			'edd-2co-js',
			$script_source,
			$script_deps,
			EDD_2CHECKOUT_PLUGIN_VERSION,
			true
		);

		wp_enqueue_script( 'edd-2co-js' );
		wp_localize_script( 'edd-2co-js', 'edd_2co_vars', $this->get_localization() );
		wp_add_inline_style( 'edd-styles', '#two-co-iframe {min-height: 190px;height:auto !important;}' );
	}

	/**
	 * Get the localized variables for the 2Checkout PayJS script.
	 *
	 * @since 2.0.0
	 * @return array
	 */
	private function get_localization() {
		$edd2co_localized_vars = array(
			'merchantID'                     => trim( edd_get_option( 'tco_account_number', '' ) ),
			'container'                      => '#edd-2co-card-element',
			'isTestMode'                     => edd_is_test_mode() ? 'true' : 'false',
			'is_ajaxed'                      => edd_is_ajax_enabled() ? 'true' : 'false',
			'currency'                       => edd_get_currency(),
			'country'                        => edd_get_option( 'base_country', 'US' ),
			'is_zero_decimal'                => edds_is_zero_decimal_currency() ? 'true' : 'false',
			'store_name'                     => ! empty( edd_get_option( 'entity_name' ) ) ? edd_get_option( 'entity_name' ) : get_bloginfo( 'name' ),
			'checkout_required_fields_error' => __( 'Please fill out all required fields to continue your purchase.', 'edd-2checkout' ),
			'checkout_agree_to_terms'        => __( 'Please agree to the terms to complete your purchase.', 'edd-2checkout' ),
			'checkout_agree_to_privacy'      => __( 'Please agree to the privacy policy to complete your purchase.', 'edd-2checkout' ),
			'generic_error'                  => __( 'Unable to complete your request. Please try again.', 'edd-2checkout' ),
			'successPageUri'                 => edd_get_success_page_uri(),
			'failurePageUri'                 => edd_get_failed_transaction_uri(),
			'debuggingEnabled'               => defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? 'true' : 'false',
			'formLoadingText'                => __( 'Please wait...', 'edd-2checkout' ),
			'cartHasSubscription'            => function_exists( 'edd_recurring' ) && edd_recurring()->cart_contains_recurring() ? 'true' : 'false',
			'style'                          => array(
				'margin'                     => 0,
				'fontFamily'                 => 'Helvetica, sans-serif',
				'fontSize'                   => '1rem',
				'fontWeight'                 => '400',
				'lineHeight'                 => '1.5',
				'color'                      => '#212529',
				'textAlign'                  => 'left',
				'backgroundColor'            => 'transparent',
				'boxSizing'                  => 'border-box',
				'*'                          => array(
					'boxSizing' => 'border-box',
				),
				'.no-gutters'                => array(
					'marginRight' => 0,
					'marginLeft'  => 0,
				),
				'.row'                       => array(
					'display'  => 'flex',
					'flexWrap' => 'wrap',
				),
				'.col'                       => array(
					'flexBasis' => '0',
					'flexGrow'  => '1',
					'maxWidth'  => '100%',
					'padding'   => '0',
					'position'  => 'relative',
					'width'     => '100%',
				),
				'div'                        => array(
					'display' => 'block',
				),
				'.field-container'           => array(
					'paddingBottom' => '14px',
				),
				'.field-wrapper'             => array(
					'paddingRight' => '0',
				),
				'.input-wrapper'             => array(
					'position' => 'relative',
				),
				'label'                      => array(
					'display'      => 'block',
					'marginBottom' => '9px',
					'color'        => '#313131',
					'fontSize'     => '14px',
					'fontWeight'   => '300',
					'lineHeight'   => '17px',
				),
				'input'                      => array(
					'overflow'        => 'visible',
					'margin'          => 0,
					'fontFamily'      => 'inherit',
					'display'         => 'block',
					'width'           => '100%',
					'height'          => '42px',
					'padding'         => '10px 12px',
					'fontSize'        => '18px',
					'fontWeight'      => '400',
					'lineHeight'      => '22px',
					'color'           => '#313131',
					'backgroundColor' => '#fff',
					'backgroundClip'  => 'padding-box',
					'border'          => '1px solid #CBCBCB',
					'borderRadius'    => '3px',
					'transition'      => 'border-color .15s ease-in-out,box-shadow .15s ease-in-out',
					'outline'         => 0,
				),
				'input:focus'                => array(
					'border'          => '1px solid #5D5D5D',
					'backgroundColor' => '#FFFDF2',
				),
				'.is-error input'            => array(
					'border' => '1px solid #D9534F',
				),
				'.is-error input:focus'      => array(
					'backgroundColor' => '#D9534F0B',
				),
				'.is-valid input'            => array(
					'border' => '1px solid #1BB43F',
				),
				'.is-valid input:focus'      => array(
					'backgroundColor' => '#1BB43F0B',
				),
				'.validation-message'        => array(
					'color'        => '#D9534F',
					'fontSize'     => '10px',
					'fontStyle'    => 'italic',
					'marginTop'    => '6px',
					'marginBottom' => '-5px',
					'display'      => 'block',
					'lineHeight'   => '1',
				),
				'.card-expiration-date'      => array(
					'paddingRight' => '.5rem',
				),
				'.is-empty input'            => array(
					'color' => '#EBEBEB',
				),
				'.lock-icon'                 => array(
					'top'   => 'calc(50% - 7px)',
					'right' => '10px',
				),
				'.valid-icon'                => array(
					'top'   => 'calc(50% - 8px)',
					'right' => '-25px',
				),
				'.error-icon'                => array(
					'top'   => 'calc(50% - 8px)',
					'right' => '-25px',
				),
				'.card-icon'                 => array(
					'top'     => 'calc(50% - 10px)',
					'left'    => '10px',
					'display' => 'none',
				),
				'.is-empty .card-icon'       => array(
					'display' => 'block',
				),
				'.is-focused .card-icon'     => array(
					'display' => 'none',
				),
				'.card-type-icon'            => array(
					'right'   => '30px',
					'display' => 'block',
				),
				'.card-type-icon.visa'       => array(
					'top' => 'calc(50% - 14px)',
				),
				'.card-type-icon.mastercard' => array(
					'top' => 'calc(50% - 14.5px)',
				),
				'.card-type-icon.amex'       => array(
					'top' => 'calc(50% - 14px)',
				),
				'.card-type-icon.discover'   => array(
					'top' => 'calc(50% - 14px)',
				),
				'.card-type-icon.jcb'        => array(
					'top' => 'calc(50% - 14px)',
				),
				'.card-type-icon.dankort'    => array(
					'top' => 'calc(50% - 14px)',
				),
				'.card-type-icon.cartebleue' => array(
					'top' => 'calc(50% - 14px)',
				),
				'.card-type-icon.diners'     => array(
					'top' => 'calc(50% - 14px)',
				),
				'.card-type-icon.elo'        => array(
					'top' => 'calc(50% - 14px)',
				),
			),
		);

		return apply_filters( 'edd_2checkout_js_vars', $edd2co_localized_vars );
	}
}
