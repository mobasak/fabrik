<?php
/**
 * Class API
 * Makes API calls to the 2Checkout platform
 *
 * @package EDD\2Checkout
 * @since   2.0.0
 */

namespace EDD\TwoCheckout;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Api {

	const API_URL     = 'https://api.2checkout.com/rest/';
	const API_VERSION = '6.0';

	/**
	 * used for auth with 2co api
	 * @var string
	 */
	private $merchant_id;
	private $secret_key;
	private $secret_word;
	private $secret_word_ins;

	public function __construct() {

		$credentials = edd_2co_get_credentials();

		if ( ! $credentials ) {
			return;
		}

		$this->merchant_id     = $credentials['tco_account_number'];
		$this->secret_key      = $credentials['tco_secret_key'];
		$this->secret_word     = $credentials['tco_secret_word'];
		$this->secret_word_ins = $credentials['tco_secret_word_ins'];
	}

	/**
	 * Gets the merchant id.
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_merchant_id() {
		return $this->merchant_id;
	}

	/**
	 * Gets the secret key.
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_secret_key() {
		return $this->secret_key;
	}

	/**
	 * Gets the secret word.
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_secret_word() {
		return $this->secret_word;
	}

	/**
	 * Gets the INS secret word.
	 *
	 * @since 2.0.0
	 * @return string
	 */
	public function get_secret_word_ins() {
		return $this->secret_word_ins;
	}

	/**
	 *  sets the header with the auth has and params
	 * @return array
	 * @throws Exception
	 */
	private function get_headers() {

		if ( ! $this->merchant_id || ! $this->secret_key ) {
			throw new \Exception( 'Merchandiser needs a valid 2Checkout Merchant Code and SecretKey to authenticate!' );
		}

		$gmt_date = gmdate( 'Y-m-d H:i:s' );
		$string   = strlen( $this->merchant_id ) . $this->merchant_id . strlen( $gmt_date ) . $gmt_date;
		$hash     = hash_hmac( 'sha3-256', $string, $this->secret_key );

		return array(
			'Content-Type'              => 'application/json',
			'Accept'                    => 'application/json',
			'X-Avangate-Authentication' => sprintf(
				'code="%s" date="%s" hash="%s" algo="sha3-256"',
				$this->merchant_id,
				$gmt_date,
				$hash
			),
		);
	}

	/**
	 * Generates an encrypted hash for the request
	 *
	 * @param $vendor_code
	 * @param $secret
	 * @param $request_date_time
	 * @return string
	 *
	 * @since 2.0.0
	 *
	 * @throws Exception
	 */
	public function generate_hash( $vendor_code, $secret, $request_date_time ) {
		$string = sprintf( '%s%s%s%s', strlen( $vendor_code ), $vendor_code, strlen( $request_date_time ), $request_date_time );
		$hash   = hash_hmac( 'sha3-256', $string, $secret );

		// the hash_hmac may fail for various reasons
		if ( false === $hash ) {
			throw new \Exception( 'Unable to create the hash, hash_hmac returned false.' );
		}

		return $hash;
	}

	/**
	 * Make API request call
	 *
	 * @param string $endpoint
	 * @param array $params
	 * @param string $method
	 *
	 * @todo This could be improved/changed?
	 *
	 * @return mixed
	 * @throws Exception
	 */
	public function call( string $endpoint, array $params, $method = 'POST' ) {

		try {
			$url    = self::API_URL . self::API_VERSION . $endpoint;
			$method = strtoupper( $method ); // Ensure method is uppercase

			$args = array(
				'headers'     => $this->get_headers(),
				'sslverify'   => false, // Disabling SSL verification, like CURLOPT_SSL_VERIFYPEER
				'timeout'     => 30,
				'httpversion' => '1.1',
			);

			$accepted_status_codes = array( 200 );
			switch ( $method ) {
				case 'GET':
					$url      = add_query_arg( $params, $url ); // Append GET params to URL
					$response = wp_remote_get( $url, $args );
					break;
				case 'POST':
					$accepted_status_codes = array( 200, 201 );
					$args['body']          = wp_json_encode( $params, JSON_UNESCAPED_UNICODE ); // Set POST body
					$response              = wp_remote_post( $url, $args );
					break;
				case 'PUT':
					$args['method'] = 'PUT'; // Set method to PUT
					$args['body']   = wp_json_encode( $params, JSON_UNESCAPED_UNICODE ); // Set PUT body
					$response       = wp_remote_request( $url, $args );
					break;
				case 'DELETE':
					$args['method'] = 'DELETE'; // Set method to DELETE
					$args['body']   = wp_json_encode( $params, JSON_UNESCAPED_UNICODE ); // Set DELETE body
					$response       = wp_remote_request( $url, $args );
					break;
			}

			if ( is_wp_error( $response ) ) {
				$error_message = $response->get_error_message();
				// Handle error
			} else {
				$response_code = wp_remote_retrieve_response_code( $response );
				$response_body = wp_remote_retrieve_body( $response );
				$decoded       = json_decode( $response_body, true );

				if ( ! in_array( $response_code, $accepted_status_codes, true ) ) {
					if ( ! empty( $decoded['message'] ) ) {
						return $decoded;
					}

					return json_decode( __( 'An unknown error occurred.', 'edd-2checkout' ) );
				} else {
					return $decoded;
				}
			}
		} catch ( \Exception $e ) {
			return json_decode( $e->getMessage(), true );
		}
	}

	/**
	 * Generate signature for Plus gateway
	 *
	 * @param $parameters
	 *
	 * @since 2.0.0
	 * @return mixed
	 * @throws Exception
	 */
	public function get_signature( $parameters ) {
		$response = wp_remote_post(
			'https://secure.2checkout.com/checkout/api/encrypt/generate/signature',
			array(
				'body'        => wp_json_encode( $parameters ),
				'headers'     => array(
					'content-type'   => 'application/json',
					'cache-control'  => 'no-cache',
					'merchant-token' => $this->generate_JWT_token(),
				),
				'timeout'     => 30,
				'redirection' => 5,
				'blocking'    => true,
				'cookies'     => array(),
			)
		);

		if ( is_wp_error( $response ) ) {
			edd_set_error( '2checkout_plus_signature_failed', __( 'Error generating purchase signature. Please try again or contact support if the issue persists.', 'edd-2checkout' ) );
			return false;
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$response_data = json_decode( $response_body, true );
		if ( 200 === $response_code && isset( $response_data['signature'] ) ) {
			return $response_data['signature'];
		}

		edd_set_error( '2checkout_plus_signature_error', __( 'Error creating order. Please try again or contact support if the issue persists.', 'edd-2checkout' ) );
		return false;
	}

	/**
	 * Generate JWT Token.
	 *
	 * @since 2.0.0
	 * @return string The generated token.
	 */
	public function generate_JWT_token() {
		$iat = time();
		$exp = time() + 3600;

		$header    = $this->encode(
			json_encode(
				array(
					'alg' => 'HS512',
					'typ' => 'JWT',
				)
			)
		);
		$payload   = $this->encode(
			json_encode(
				array(
					'sub' => $this->merchant_id,
					'iat' => $iat,
					'exp' => $exp,
				)
			)
		);
		$signature = $this->encode(
			hash_hmac( 'sha512', "$header.$payload", $this->secret_word, true )
		);

		return implode(
			'.',
			array(
				$header,
				$payload,
				$signature,
			)
		);
	}

	/**
	 * Base 64 encode
	 *
	 * @param $data
	 *
	 * @since 2.0.0
	 * @return string|string[]
	 */
	private function encode( $data ) {
		return str_replace( '=', '', strtr( base64_encode( $data ), '+/', '-_' ) );
	}
}
