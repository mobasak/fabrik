<?php

namespace EDD\TwoCheckout\Recurring;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * 2Checkout Plus gateway.
 *
 * @since 2.0.0
 */
class Plus extends Base {

	/**
	 * Initialize the gateway.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function init() {
		$this->id            = '2checkout-plus';
		$this->friendly_name = __( '2Checkout Plus', 'edd-2checkout' );
		$this->offsite       = true;
		parent::init();
	}

	/**
	 * Create the payment profiles.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function complete_signup() {
		wp_redirect( $this->get_redirect_url() ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}

	/**
	 * Gets the redirect URL for the 2Checkout Plus gateway.
	 *
	 * @since 2.0.0
	 * @return string
	 */
	private function get_redirect_url() {
		$return_url = add_query_arg(
			array(
				'payment-confirmation' => $this->id,
				'payment-id'           => $this->payment_id,
			),
			edd_get_success_page_uri()
		);
		$order      = edd_get_order( $this->payment_id );
		foreach ( $this->subscriptions as $key => $subscription ) {
			$products_data = $this->get_order_line_items( $subscription );
			break;
		}
		$base_args = array(
			'return-url'       => $return_url,
			'back-url'         => edd_get_checkout_uri( '?payment-mode=' . $this->id ),
			'order-ext-ref'    => $order->payment_key,
			'customer-ext-ref' => $order->email,
			'currency'         => $order->currency,
		);

		$billing_data = parent::get_order_billing_data( $order );
		$base_args    = array_merge( $base_args, $products_data, $billing_data );
		$base_args    = apply_filters( 'edd_recurring_2checkout_redirect_args', $base_args, $this );

		return \EDD\TwoCheckout\Gateways\Utilities\Redirect::get( $base_args );
	}

	/**
	 * Gets the line items for the order data to send to 2Checkout.
	 *
	 * @since 2.0.0
	 * @param array $subscription
	 * @return array
	 */
	protected function get_order_line_items( $subscription ) {
		$contract_details = $this->get_contract_details( $subscription );
		if ( empty( $contract_details['length'] ) ) {
			$contract_details['length'] = 1;
			$contract_details['unit']   = 'FOREVER';
		}

		return array(
			'price'         => $subscription['initial_amount'],
			'qty'           => 1,
			'type'          => 'PRODUCT',
			'prod'          => $subscription['name'],
			'item-ext-ref'  => $subscription['id'],
			'renewal-price' => $subscription['recurring_amount'],
			'recurrence'    => $contract_details['frequency'] . ':' . strtoupper( $contract_details['period'] ),
			'duration'      => $contract_details['length'] . ':' . strtoupper( $contract_details['unit'] ),
			'tangible'      => '0',
		);
	}
}
