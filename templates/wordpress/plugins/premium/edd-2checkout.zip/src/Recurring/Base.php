<?php

namespace EDD\TwoCheckout\Recurring;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use EDD\TwoCheckout\Gateway;
use EDD\TwoCheckout\Webhooks\Listener;

class Base extends \EDD_Recurring_Gateway {
	use \EDD\TwoCheckout\Gateways\Traits\BillingData;
	use \EDD\TwoCheckout\Gateways\Traits\Currency;
	use \EDD\TwoCheckout\Gateways\Traits\Language;

	/**
	 * The API object.
	 *
	 * @since 2.0.0
	 * @var \EDD\TwoCheckout\Api
	 */
	protected $api;

	/**
	 * Base constructor.
	 */
	public function __construct() {
		$this->api = Gateway::instance()->twcoapi;
		parent::__construct();
	}

	/**
	 * Initialize the gateway.
	 *
	 * @since 2.0.0
	 */
	public function init() {
		add_filter( 'edd_subscription_profile_link_' . $this->id, array( $this, 'link_profile_id' ), 10, 2 );
	}

	/**
	 * Validate the fields.
	 *
	 * @since 2.0.0
	 * @param array $data
	 * @param array $posted
	 * @return void
	 */
	public function validate_fields( $data, $posted ) {
		if ( empty( $this->api->get_secret_word() ) || empty( $this->api->get_merchant_id() ) ) {
			if ( current_user_can( 'manage_shop_settings' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown
				edd_set_error( 'missing_account_number', __( 'You must enter your merchant ID and secret word in settings.', 'edd-2checkout' ) );
			} else {
				edd_set_error( 'missing_account_number', __( 'There was an error processing your payment. Please try again.', 'edd-2checkout' ) );
			}
		}

		$currency = edd_get_currency();
		if ( ! in_array( $currency, $this->get_supported_currencies(), true ) ) {
			/* translators: %s: currency code */
			edd_set_error( 'currency', sprintf( __( '2Checkout does not support the %s currency.', 'edd-2checkout' ), $currency ) );
		}

		if ( count( edd_get_cart_contents() ) > 1 && ! $this->can_purchase_multiple_subs() ) {
			edd_set_error( 'subscription_invalid', __( 'Only one subscription may be purchased at a time through 2Checkout.', 'edd-2checkout' ) );
		}
	}

	/**
	 * Store pending profile IDs
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function create_payment_profiles() {
		foreach ( $this->subscriptions as $key => $subscription ) {
			if ( ! empty( $subscription['has_trial'] ) ) {
				edd_set_error( 'free_trial_not_supported', __( 'Free trials are not supported by 2Checkout.', 'edd-2checkout' ) );
				return;
			}
			$this->subscriptions[ $key ]['profile_id'] = '2checkout-' . $this->purchase_data['purchase_key'] . '-' . $key;
		}
	}

	/**
	 * Processes webhooks from the payment processor.
	 * This is empty because the base class will handle the processing.
	 *
	 * @since 2.0.0
	 */
	public function process_webhooks() {}

	/**
	 * Determines if 2Checkout allows multiple subscriptions to be purchased at once.
	 *
	 * 2Checkout does not allow multiple subscriptions to be purchased at the same time.
	 *
	 * @since 2.0.0
	 * @return bool
	 */
	public function can_purchase_multiple_subs() {
		return false;
	}

	/**
	 * Determines if the subscription can be cancelled.
	 *
	 * @since 2.0.0
	 * @return bool
	 */
	public function can_cancel( $ret, $subscription ) {
		if ( empty( $subscription->profile_id ) ) {
			return false;
		}

		if ( $subscription->gateway === $this->id && in_array( $subscription->status, edd_recurring_get_cancellable_statuses(), true ) ) {
			return true;
		}

		return $ret;
	}

	/**
	 * Cancels a subscription in 2Checkout.
	 *
	 * @since 2.0.0
	 *
	 * @param EDD_Subscription $subscription
	 * @param bool             $valid
	 *
	 * @return bool
	 */
	public function cancel( $subscription, $valid ) {

		if ( empty( $valid ) ) {
			return false;
		}

		// Attempt to retrive subscription from 2Checkout.
		$sub = $this->api->call( '/subscriptions/' . sanitize_text_field( $subscription->profile_id ) . '/', array(), 'GET' );

		if ( ! $sub['SubscriptionEnabled'] && empty( $sub['NextBillingDate'] ) ) {
			// Subscription is cancelled in 2Checkout.
			return false;
		}

		// Make the request to cancel the subscription.
		$request = $this->api->call( '/subscriptions/' . sanitize_text_field( $subscription->profile_id ) . '/renewal/', array(), 'DELETE' );

		if ( ! empty( $request['error_code'] ) && ! empty( $request['message'] ) ) {
			$subscription->add_note( sprintf( esc_html__( 'Attempted cancellation but was unable. Message was %s.', 'edd-2checkout' ), $request['message'] ) );

			return false;
		}

		$subscription->add_note( esc_html__( 'The subscription was cancelled at 2Checkout.', 'edd-2checkout' ) );

		return true;
	}

	/**
	 * Gets the line items for the order data to send to 2Checkout.
	 *
	 * @since 2.0.0
	 * @param array $subscription
	 * @return array
	 */
	protected function get_order_line_items( $subscription ) {
		$contract_details = $this->get_contract_details( $subscription );

		return array(
			array(
				'Price'            => array(
					'Amount' => round( $subscription['initial_amount'], 2 ),
					'Type'   => 'CUSTOM',
				),
				'productId'        => $subscription['id'],
				'Name'             => $subscription['name'],
				'Quantity'         => '1',
				'Tangible'         => false,
				'PurchaseType'     => 'PRODUCT',
				'IsDynamic'        => true,
				'RecurringOptions' => array(
					'CycleLength'    => $contract_details['frequency'],
					'CycleUnit'      => $contract_details['period'],
					'CycleAmount'    => round( $subscription['recurring_amount'], 2 ),
					'ContractLength' => $contract_details['length'],
					'ContractUnit'   => $contract_details['unit'],
				),
			),
		);
	}

	/**
	 * Get the contract details.
	 *
	 * @since 2.0.0
	 * @param array $subscription
	 * @return array
	 */
	protected function get_contract_details( $subscription ) {
		$contract_length = 0;
		$contract_period = ucfirst( $subscription['period'] );

		switch ( $subscription['period'] ) {
			case 'quarter':
				$frequency = 3;
				$period    = 'MONTH';
				if ( ! empty( $subscription['bill_times'] ) ) {
					$contract_length = $subscription['bill_times'] * 3;
					$contract_period = 'Month';
				}
				break;

			case 'semi-year':
				$frequency = 6;
				$period    = 'MONTH';
				if ( ! empty( $subscription['bill_times'] ) ) {
					$contract_length = $subscription['bill_times'] * 6;
					$contract_period = 'Month';
				}
				break;

			default:
				$frequency = 1;
				$period    = strtoupper( $subscription['period'] );
				if ( ! empty( $subscription['bill_times'] ) ) {
					$contract_length = $subscription['bill_times'];
				}
				break;
		}

		return array(
			'frequency' => $frequency,
			'period'    => $period,
			'length'    => $contract_length,
			'unit'      => $contract_period,
		);
	}

	/**
	 * Link the recurring profile in 2Checkout.
	 *
	 * @since  2.0.0
	 * @param  string $profile_id   The recurring profile id
	 * @param  object $subscription The Subscription object
	 * @return string               The link to return or just the profile id
	 */
	public function link_profile_id( $profile_id, $subscription ) {
		if ( empty( $profile_id ) ) {
			return $profile_id;
		}

		$url = 'https://secure.2checkout.com/cpanel/license_info.php?&refno=' . urlencode( $subscription->profile_id );

		return '<a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( $profile_id ) . '</a>';
	}
}
