<?php

namespace EDD\TwoCheckout\Recurring;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class PayJS extends Base {


	/**
	 * Initialize the gateway.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function init() {
		$this->id            = '2checkout-payjs';
		$this->friendly_name = __( '2Checkout Onsite', 'edd-2checkout' );
		parent::init();
	}

	/**
	 * Create the payment profiles.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function create_payment_profiles() {
		if ( empty( $_POST['edd_2checkout_client_token'] ) ) {
			edd_set_error( 'missing_payment_method_nonce', __( 'Missing payment method token. Please try again.', 'edd-2checkout' ) );
		}

		parent::create_payment_profiles();
		if ( ! empty( edd_get_errors() ) ) {
			return;
		}

		foreach ( $this->subscriptions as $key => $subscription ) {
			$line_items = $this->get_order_line_items( $subscription );
			break;
		}

		try {

			$order_params = array(
				'Language'          => self::get_language(),
				'Source'            => 'EasyDigitalDownloads_' . EDD_VERSION,
				'ExternalReference' => $this->purchase_data['purchase_key'],
				'token'             => $this->purchase_data['post_data']['edd_2checkout_client_token'],
				'Currency'          => edd_get_currency(),
				'BillingDetails'    => array(
					'FirstName'   => $this->get_customer_first_name( $this->purchase_data['card_info']['card_name'] ),
					'LastName'    => $this->get_customer_last_name( $this->purchase_data['card_info']['card_name'] ),
					'Address1'    => $this->purchase_data['card_info']['card_address'],
					'City'        => $this->purchase_data['card_info']['card_city'],
					'State'       => $this->purchase_data['card_info']['card_state'],
					'CountryCode' => $this->purchase_data['card_info']['card_country'],
					'Email'       => $this->purchase_data['user_email'],
					'Zip'         => $this->purchase_data['card_info']['card_zip'],
				),
				'Items'             => $line_items,
				'PaymentDetails'    => array(
					'Type'          => edd_is_test_mode() ? 'TEST' : 'EES_TOKEN_PAYMENT',
					'Currency'      => edd_get_currency(),
					'PaymentMethod' => array(
						'EesToken'           => $this->purchase_data['post_data']['edd_2checkout_client_token'],
						'Vendor3DSReturnURL' => edd_get_success_page_uri(), // Probably should be something else.
						'Vendor3DSCancelURL' => edd_get_checkout_uri( '?payment-mode=' . $this->id ),
						'RecurringEnabled'   => true,
					),
				),
			);

			$response = $this->api->call( '/orders/', $order_params );

			if ( in_array( $response['Status'], array( 'AUTHRECEIVED', 'COMPLETE' ), true ) ) {
				$this->purchase_data['transaction_id'] = $response['RefNo'];
			} else {
				edd_set_error( '2checkout_error', $response['message'] );
			}
		} catch ( \Exception $e ) {
			edd_set_error( '2checkout_error', $e->getMessage() );
		}
	}

	/**
	 * Finishes the signup process by redirecting to the success page or to an off-site payment page
	 *
	 * @since 2.0.0
	 */
	public function complete_signup() {
		edd_set_payment_transaction_id( $this->payment_id, $this->purchase_data['transaction_id'] );
		wp_safe_redirect( edd_get_success_page_uri() );
		exit;
	}
}
