<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class FraudStatusChanged extends Type {

	/**
	 * Process the webhook.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function process( $i ) {
		$fraud_status = sanitize_text_field( $this->data['fraud_status'] );

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - FRAUD_STATUS_CHANGED processing status of ' . $fraud_status );

		switch ( $fraud_status ) {

			case 'fail':
				$this->sub->cancel();

				$payment_id      = $this->sub->parent_payment_id;
				$initial_payment = edd_get_payment( $payment_id );

				$initial_payment->update_status( 'revoked' );
				$initial_payment->add_note( __( '2Checkout fraud review failed.', 'edd-2checkout' ) );

				break;

			case 'wait':
				$args = array(
					'status' => 'pending',
				);

				$this->sub->update( $args );

				$payment_id      = $this->sub->parent_payment_id;
				$initial_payment = edd_get_payment( $payment_id );

				$initial_payment->update_status( 'pending' );
				$initial_payment->add_note( __( '2Checkout fraud review in progress.', 'edd-2checkout' ) );
				break;

			case 'pass':
				$args = array(
					'status' => 'active',
				);

				$this->sub->update( $args );

				$payment_id      = $this->sub->parent_payment_id;
				$initial_payment = edd_get_payment( $payment_id );

				$initial_payment->update_status( 'complete' );
				$initial_payment->add_note( __( '2Checkout fraud review passed.', 'edd-2checkout' ) );
				break;
		}
	}
}
