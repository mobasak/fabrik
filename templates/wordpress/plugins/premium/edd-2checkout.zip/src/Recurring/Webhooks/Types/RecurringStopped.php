<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class RecurringStopped extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process( $i ) {
		$this->sub->cancel();

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - RECURRING_STOPPED for ' . $this->sub->id );
	}
}
