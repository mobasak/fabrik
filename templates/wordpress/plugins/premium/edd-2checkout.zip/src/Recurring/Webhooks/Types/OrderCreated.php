<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class OrderCreated extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process( $i ) {
		$profile_id = sanitize_text_field( $this->data['sale_id'] ) . '-' . $i;

		// Set the 2Checkout Order Ref # to EDD Order.
		edd_update_order_status( $this->order->id, 'complete' );
		edd_set_payment_transaction_id( $this->order->id, $this->data['order_ref'] );

		// Attempt to retrieve the line item_id from 2Checkout
		$sale = $this->api->call( '/orders/' . sanitize_text_field( $this->data['order_ref'] ) . '/', array(), 'GET' );

				// At this point we are looking at an order with a single Subscription attached.
		if ( $sale && ! empty( $sale['Items'][0]['ProductDetails']['Subscriptions'][0] ) ) {

			$sub_data = $sale['Items'][0]['ProductDetails']['Subscriptions'][0];
			edd_debug_log( 'EDD 2Checkout 2.0.0 INS - ORDER_CREATED profile ID found: ' . $sub_data['SubscriptionReference'] );

			// This is the real subscription ID.
			$profile_id = $sub_data['SubscriptionReference'];
		}

		$this->sub->update(
			array(
				'profile_id'     => $profile_id,
				'transaction_id' => sanitize_text_field( $this->data['order_ref'] ),
				'status'         => 'active',
			)
		);

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - ORDER_CREATED subscription ' . $this->sub->id . ' updated' );
	}
}
