<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class InvoiceStatusChanged extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process( $i ) {
		$status = strtolower( sanitize_text_field( $this->data['invoice_status'] ) );

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - INVOICE_STATUS_CHANGED processing status of ' . $status );

		switch ( $status ) {

			case 'deposited':
				$args = array(
					'status' => 'active',
				);

				$this->sub->update( $args );

				$payment_id      = $this->sub->parent_payment_id;
				$initial_payment = edd_get_payment( $payment_id );

				$initial_payment->update_status( 'complete' );
				$initial_payment->add_note( __( '2Checkout Invoice status set to deposited.', 'edd-recurring' ) );
				break;
		}
	}
}
