<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class RefundIssued extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process( $i ) {
		$initial_order = edd_get_order( $this->sub->parent_payment_id );
		$cart_count    = count( $initial_order->items );

		// Look for the new refund line item
		if ( isset( $data[ 'item_list_amount_' . ( $cart_count + 1 ) ] ) && $data[ 'item_list_amount_' . ( $cart_count + 1 ) ] < $this->order->total ) {

			$refunded = edd_sanitize_amount( $data[ 'item_list_amount_' . ( $cart_count + 1 ) ] );
			edd_insert_payment_note(
				$this->order->id,
				/* translators: %s: Refunded amount */
				sprintf( __( 'Partial refund for %s processed in 2Checkout' ), edd_currency_filter( $refunded, $this->order->currency ) )
			);

		} else {

			$this->sub->cancel();

			edd_update_order_status( $initial_order->id, 'refunded' );
			edd_insert_payment_note(
				$initial_order->id,
				__( 'Payment refunded in 2Checkout.', 'edd-recurring' )
			);
		}

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - REFUND_ISSUED for ' . $this->sub->id );
	}
}
