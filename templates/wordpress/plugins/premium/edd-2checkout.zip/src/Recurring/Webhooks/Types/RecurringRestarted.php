<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class RecurringRestarted extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process( $i ) {
		$date = date( 'Y-n-d H:i:s', strtotime( $this->data[ 'item_rec_date_next_' . $i ] ) );

		$this->sub->update(
			array(
				'status'     => 'active',
				'expiration' => $date,
			)
		);

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - RECURRING_RESTARTED for ' . $this->sub->id );
	}
}
