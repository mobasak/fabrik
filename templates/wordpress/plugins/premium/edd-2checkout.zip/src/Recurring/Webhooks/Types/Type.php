<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

abstract class Type {

	/**
	 * API instance.
	 *
	 * @var \EDD\TwoCheckout\Api
	 */
	protected $api;

	/**
	 * Order instance.
	 *
	 * @var \EDD\Orders\Order
	 */
	protected $order;

	/**
	 * Data from the webhook.
	 *
	 * @var array
	 */
	protected $data;

	/**
	 * Subscription instance.
	 *
	 * @var \EDD\Recurring\Subscription
	 */
	protected $sub;

	/**
	 * Type constructor.
	 *
	 * @param \EDD\TwoCheckout\Api $api   API instance.
	 * @param \EDD\Orders\Order    $order Order instance.
	 * @param array                $data  Data from the webhook.
	 * @param \EDD\Recurring\Subscription $sub Subscription instance.
	 */
	public function __construct( $api, $order, $data, $subscription ) {
		$this->api   = $api;
		$this->order = $order;
		$this->data  = $data;
		$this->sub   = $subscription;
	}

	/**
	 * Process the webhook.
	 *
	 * @since 2.0.0
	 * @param int $i
	 * @return void
	 */
	abstract public function process( $i );
}
