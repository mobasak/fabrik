<?php

namespace EDD\TwoCheckout\Recurring\Webhooks;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class Listener {
	use \EDD\TwoCheckout\Webhooks\Traits\MessageType;
	use \EDD\TwoCheckout\Webhooks\Traits\Validate;

	/**
	 * The API object.
	 *
	 * @since 2.0.0
	 * @var \EDD\TwoCheckout\Api
	 */
	private $api;

	/**
	 * The order object.
	 *
	 * @since 2.0.0
	 * @var \EDD\Orders\Order
	 */
	private $order;

	public function __construct( $api, $order ) {
		$this->api   = $api;
		$this->order = $order;
	}

	/**
	 * Process the webhook.
	 *
	 * @since 2.0.0
	 * @param array $data
	 * @return void
	 */
	public function process( $data ) {
		$db = new \EDD_Subscriptions_DB();

		$subs = false;
		foreach ( $this->order->items as $key => $item ) {
			$item_id = $item->product_id;
			if ( empty( $item_id ) ) {
				edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Processing stopped due to missing item ID' );
				continue;
			}

			$subs = $db->get_subscriptions(
				array(
					'parent_payment_id' => $this->order->id,
					'product_id'        => $item_id,
					'number'            => 1,
				)
			);
			if ( empty( $subs ) ) {
				edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Processing stopped due to subscription not being found' );
				continue;
			}
			break;
		}

		if ( empty( $subs ) ) {
			edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Processing stopped due to subscription not being found' );
			die( '-10' );
		}

		$sub = reset( $subs );

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - Preparing to process INS type ' . $data['message_type'] );

		$message_type_class = $this->get_handler( $data['message_type'] );
		if ( class_exists( "\\EDD\\TwoCheckout\\Recurring\\Webhooks\\Types\\{$message_type_class}" ) ) {
			$class_name = "\\EDD\\TwoCheckout\\Recurring\\Webhooks\\Types\\{$message_type_class}";
			$handler    = new $class_name( $this->api, $this->order, $data, $sub );
			$handler->process( ++$key );
			die( '1' );
		}
	}
}
