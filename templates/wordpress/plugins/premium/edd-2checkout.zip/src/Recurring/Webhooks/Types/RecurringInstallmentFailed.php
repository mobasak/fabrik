<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class RecurringInstallmentFailed extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process( $i ) {
		$this->sub->failing();

		edd_debug_log( 'EDD 2Checkout 2.0.0 INS - RECURRING_INSTALLMENT_FAILED for ' . $this->sub->id );

		do_action( 'edd_recurring_payment_failed', $this->sub );
	}
}
