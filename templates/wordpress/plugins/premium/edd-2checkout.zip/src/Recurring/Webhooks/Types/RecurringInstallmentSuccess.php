<?php

namespace EDD\TwoCheckout\Recurring\Webhooks\Types;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class RecurringInstallmentSuccess extends Type {

	/**
	 * Process the webhook.
	 *
	 * @return void
	 */
	public function process( $i ) {
		// Build the array for adding a subscription order.
		$subscription_payment_args = array(
			'amount'         => sanitize_text_field( $this->data[ 'item_list_amount_' . $i ] ),
			'transaction_id' => sanitize_text_field( $this->data['order_ref'] ),
		);

		/**
		 * First just make sure we have a timestamp value in the $this->data.
		 *
		 */
		if ( ! empty( $this->data['timestamp'] ) ) {

			/**
			 * Create a DateTime object of the timestamp, so we can adjust as needed.
			 *
			 * 2Checkout INS sends this data in a Zulu Time (not an actual timestamp), which is equivalent to GMT/UTC.
			 * Example date passed: 2024-05-01 14:16:32 EEST
			*/
			$subscription_payment_date = new \DateTime( $this->data['timestamp'] );

			// Again, be careful here and ensure that we have a DateTime object to work with.
			if ( $subscription_payment_date instanceof \DateTime ) {
				// Now set the date into the arguments for creating the renewal payment.
				$subscription_payment_args['date'] = $this->get_formatted_order_date( $subscription_payment_date );
			}
		}

		$payment_id = $this->sub->add_payment( $subscription_payment_args );

		if ( ! empty( $payment_id ) ) {
			$this->sub->renew( $payment_id );
			edd_debug_log( 'EDD 2Checkout 2.0.0 INS - RECURRING_INSTALLMENT_SUCCESS subscription' . $this->sub->id . ' renewed' );
		}
	}

	/**
	 * Convert a DateTime object of the order date and return it in the MySQL DATETIME format.
	 *
	 * @since 2.0.0
	 * @param DateTime $date_time The DateTime object of the order date.
	 * @return string The MySQL DATETIME formatted date, converted into the timezone depending on EDD version.
	 */
	protected function get_formatted_order_date( \DateTime $date_time ) {
		/**
		 * EDD 3.0+ uses GMT format for all dates.
		 */
		$store_timezone = 'GMT';

		// Set the timezone on the DateTime object.
		$date_time->setTimezone( new \DateTimeZone( $store_timezone ) );

		// Now set the date into the arguments for creating the renewal payment.
		return $date_time->format( 'Y-m-d H:i:s' );
	}
}
