<?php
/**
 * Plugin Name: Easy Digital Downloads - 2Checkout Gateway
 * Plugin URL: https://easydigitaldownloads.com/downloads/2checkout
 * Description: Adds a payment gateway for 2Checkout.com.
 * Version: 2.0.0
 * Requires at least: 5.4
 * Requires PHP: 7.1
 * Author: Easy Digital Downloads
 * Author URI: https://easydigitaldownloads.com/
 * Text Domain: edd-2checkout
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Define the plugin file.
defined( 'EDD_2CHECKOUT_PLUGIN_FILE' ) || define( 'EDD_2CHECKOUT_PLUGIN_FILE', __FILE__ );

// Plugin Name.
if ( ! defined( 'EDD_2CHECKOUT_PLUGIN_NAME' ) ) {
	define( 'EDD_2CHECKOUT_PLUGIN_NAME', '2Checkout' );
}

// Plugin Version.
if ( ! defined( 'EDD_2CHECKOUT_PLUGIN_VERSION' ) ) {
	define( 'EDD_2CHECKOUT_PLUGIN_VERSION', '2.0.0' );
}

// Plugin Folder Path.
if ( ! defined( 'EDD_2CHECKOUT_PLUGIN_DIR' ) ) {
	define( 'EDD_2CHECKOUT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

// Plugin Folder URL.
if ( ! defined( 'EDD_2CHECKOUT_PLUGIN_URL' ) ) {
	define( 'EDD_2CHECKOUT_PLUGIN_URL', plugin_dir_url( EDD_2CHECKOUT_PLUGIN_FILE ) );
}

// Plugin Assets URL.
if ( ! defined( 'EDD_2CHECKOUT_ASSETS_URL' ) ) {
	define( 'EDD_2CHECKOUT_ASSETS_URL', EDD_2CHECKOUT_PLUGIN_URL . 'assets/' );
}

/**
 * Load our plugin
 *
 * @since 1.2
 * @return void
 */
function edd_2checkout_load() {
	EDD\TwoCheckout\Gateway::instance();

	// Alias the old class name to the new one.
	class_alias( EDD\TwoCheckout\Gateway::class, 'EDD_2Checkout_Gateway' );
}

require_once __DIR__ . '/vendor/autoload.php';
\EDD\ExtensionUtils\v1\ExtensionLoader::loadOrQuit(
	__FILE__,
	'edd_2checkout_load',
	array(
		'php'                    => '7.1',
		'wp'                     => '5.4',
		'easy-digital-downloads' => '3.1.5',
	)
);
