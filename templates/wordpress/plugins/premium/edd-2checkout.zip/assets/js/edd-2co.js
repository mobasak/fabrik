/* global edd_2co_vars */
// Initialize the JS Payments SDK client.
var jsPaymentClient = new TwoPayClient( edd_2co_vars.merchantID );

var EDD_2Checkout = {
	dropInInstance: null,

	component: null,

	errorClasses: [ 'edd-alert', 'edd-alert-error' ],

	/**
	 * Set up events, etc.
	 */
	init: function () {

		EDD_2Checkout.mountCardForm();

		jQuery( document.body ).on( 'edd_discount_applied', EDD_2Checkout.maybeDestroyInstance );
		jQuery( '#edd_purchase_form' ).on( 'submit', EDD_2Checkout.onSubmit );
	},

	/**
	 * Mounts the drop-in UI card form.
	 */
	mountCardForm: function () {
		// Create the component that will hold the card fields.
		EDD_2Checkout.component = jsPaymentClient.components.create( 'card', edd_2co_vars.style );
		EDD_2Checkout.component.mount( '#edd-2co-card-element' );

	},

	/**
	 * Handles showing error messages.
	 *
	 * @param error
	 */
	handleError: function ( error ) {
		console.log( 'Gateway Error', error );

		const errorWrapper = document.getElementById( 'edd-2co-dropin-errors' );
		if ( !errorWrapper ) {
			return;
		}

		for ( let i = 0; i < EDD_2Checkout.errorClasses.length; i++ ) {
			errorWrapper.classList.add( EDD_2Checkout.errorClasses[ i ] );
		}

		let errorMessage = edd_2co_vars.generic_error;
		if ( 'string' === typeof error ) {
			errorMessage = error;
		} else if ( 'undefined' !== typeof error.message ) {
			errorMessage = error.message;
		}

		errorWrapper.innerHTML = errorMessage;

		EDD_2Checkout.enableForm();
	},

	/**
	 * Clears errors.
	 */
	clearErrors: function () {
		const errorWrapper = document.getElementById( 'edd-2co-dropin-errors' );
		if ( !errorWrapper ) {
			return;
		}
		errorWrapper.innerHTML = '';

		for ( let i = 0; i < EDD_2Checkout.errorClasses.length; i++ ) {
			errorWrapper.classList.remove( EDD_2Checkout.errorClasses[ i ] );
		}
	},

	/**
	 * Enables the submission form & hides errors.
	 */
	enableForm: function () {
		// Update button text.
		const purchaseButton = document.getElementById( 'edd-purchase-button' );
		if ( purchaseButton ) {
			purchaseButton.value = edd_global_vars.complete_purchase;
			purchaseButton.removeAttribute( 'disabled' );
		}

		const ajaxLoader = document.querySelector( '.edd-loading-ajax' );
		if ( ajaxLoader ) {
			ajaxLoader.remove();
		}
		const errors = document.querySelector( '.edd_errors' );
		if ( errors ) {
			errors.remove();
		}
	},

	/**
	 * When a discount is added, resulting in a $0.00 total, destroy the drop-in instance.
	 *
	 * @param event
	 * @param discountResponse
	 */
	maybeDestroyInstance: function ( event, discountResponse ) {
		if ( 0 === discountResponse.total_plain && EDD_2Checkout.dropInInstance ) {
			EDD_2Checkout.dropInInstance.teardown()
				.catch( function ( error ) {
					EDD_2Checkout.handleError( error );
				} );
		}
	},

	/**
	 * When the form is submitted, create a payment token.
	 *
	 * @param event
	 * @returns {undefined}
	 */
	onSubmit: function ( event ) {
		const gateway = document.querySelector( 'input[name="edd-gateway"]' ).value;
		const cartTotal = document.querySelector( '.edd_cart_total .edd_cart_amount' ).getAttribute( 'data-total' );

		if ( '2checkout-payjs' === gateway && cartTotal > 0 ) {
			event.preventDefault();

			// Clear errors each time.
			EDD_2Checkout.clearErrors();

			EDD_2Checkout.tokenizePayment();
		}
	},

	/**
	 * Tokenizes the payment and re-submits the form to actually process payment.
	 */
	tokenizePayment: function () {

		const billingDetails = {
			name: document.querySelector( '#card_name' ).value,
			//scope: 'subscription' // accepted values: subscription, ordering
		};

		// Call the generate method using the component as the first parameter
		// and the billing details as the second one
		jsPaymentClient.tokens.generate( EDD_2Checkout.component, billingDetails ).then( ( response ) => {
			const purchaseForm = jQuery( '#edd_purchase_form' );

			document.getElementById( 'edd-2checkout-client-token' ).value = response.token;

			// Remove our submit event.
			purchaseForm.off( 'submit', EDD_2Checkout.onSubmit );

			// Submit the form.
			purchaseForm.submit();
		} ).catch( ( error ) => {
			EDD_2Checkout.handleError( error );
		} );

	}
};

/**
 * Listen for gateway switch.
 */
jQuery( document.body ).on( 'edd_gateway_loaded', function ( e, gateway ) {
	if ( '2checkout-payjs' !== gateway ) {
		return;
	}

	EDD_2Checkout.init();
} );
