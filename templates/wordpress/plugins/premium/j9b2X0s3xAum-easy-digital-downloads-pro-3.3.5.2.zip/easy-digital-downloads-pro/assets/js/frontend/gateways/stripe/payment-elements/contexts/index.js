export { setup as setupCheckout, createAndCompleteOrder } from './checkout.js';
export { setup as setupBuyNow } from './buy-now.js';
