// Empty file for backwards compatibility.
// @see assets/js/admin/orders/index.js
