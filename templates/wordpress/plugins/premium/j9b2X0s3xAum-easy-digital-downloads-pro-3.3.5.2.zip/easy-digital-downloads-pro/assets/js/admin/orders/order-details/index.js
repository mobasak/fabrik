import './address.js';
import './customer.js';
import './receipt.js';
