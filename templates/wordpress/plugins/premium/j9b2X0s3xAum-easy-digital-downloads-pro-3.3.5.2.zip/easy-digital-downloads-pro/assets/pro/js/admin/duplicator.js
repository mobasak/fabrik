/**
 * WordPress dependencies
 */
const { createElement } = window.wp.element;
const { registerPlugin } = window.wp.plugins;
const { PluginPostStatusInfo } = window.wp.editPost;

registerPlugin( 'edd-duplicator', {
	render: () => {
		return createElement(
			PluginPostStatusInfo,
			{
				className: 'edd-duplicator'
			},
			createElement(
				'a',
				{
					className: 'components-button is-secondary',
					href: eddDuplicator.url,
					target: '_blank',
				},
				eddDuplicator.label
			)
		);
	}
} );
