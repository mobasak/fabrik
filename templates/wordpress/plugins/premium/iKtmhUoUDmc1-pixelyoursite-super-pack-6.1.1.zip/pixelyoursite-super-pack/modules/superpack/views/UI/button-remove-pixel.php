<?php

namespace PixelYourSite;

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<div class="remove_pixel">
	<button type="button" class="button-remove-row remove-row">
		<i class="fa fa-trash-o" aria-hidden="true"></i>
	</button>
</div>
