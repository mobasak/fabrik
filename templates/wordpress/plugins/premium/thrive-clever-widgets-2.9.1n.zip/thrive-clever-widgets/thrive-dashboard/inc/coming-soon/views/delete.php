<div class="delete-page-wrapper">
	<span><?php echo __( 'Are you sure you want to remove this coming soon page?', TVE_DASH_TRANSLATE_DOMAIN ); ?></span>
	<div class="buttons-wrapper">
		<button class="keep-page enable-state" data-enable="view"><?php echo __( 'Keep this page', TVE_DASH_TRANSLATE_DOMAIN ); ?></button>
		<button class="remove-page enable-state" data-enable="search"><?php echo __( 'Remove this page', TVE_DASH_TRANSLATE_DOMAIN ); ?></button>
	</div>
</div>