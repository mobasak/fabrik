/*! Thrive Clever Widgets 2022-02-25
* http://www.thrivethemes.com 
* Copyright (c) 2022 * Thrive Themes */
var tcw_app=tcw_app||{};!function(){"use strict";tcw_app.Hangers=Backbone.Collection.extend({model:tcw_app.Hanger,uncheckAll:function(){this.each(function(a){a.uncheckAll()})}})}(jQuery);