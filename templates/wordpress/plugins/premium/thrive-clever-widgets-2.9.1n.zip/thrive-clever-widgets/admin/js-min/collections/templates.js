/*! Thrive Clever Widgets 2022-02-25
* http://www.thrivethemes.com 
* Copyright (c) 2022 * Thrive Themes */
var tcw_app=tcw_app||{};!function(){tcw_app.Templates=Backbone.Collection.extend({model:tcw_app.Template})}(jQuery);