<?php
/**
 * EDD_RP_Logs_Table Class
 *
 * Renders the file downloads log view
 *
 * @since 1.2.6
 */

// Load WP_List_Table if not loaded
if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class EDD_RP_Logs_Table extends WP_List_Table {

	/**
	 * Number of items per page
	 *
	 * @var int
	 * @since 1.2.6
	 */
	public $per_page = 15;

	/**
	 * Base URL
	 *
	 * @var int
	 * @since 1.2.6
	 */
	public $base;

	/**
	 * Get things started
	 *
	 * @since 1.2.6
	 * @see WP_List_Table::__construct()
	 */
	public function __construct() {
		global $status, $page;

		// Set parent defaults
		parent::__construct( array(
			'singular' => 'recommendation',
			'plural'   => 'recommendations',
			'ajax'     => false,
		) );

		if ( function_exists( 'edd_get_admin_url' ) ) {
			$this->base = edd_get_admin_url( array(
				'page' => 'edd-tools',
				'tab'  => 'logs',
				'view' => 'recommendations'
			) );
		} else {
			$this->base = admin_url( 'edit.php?post_type=download&page=edd-reports&tab=logs&view=recommendations' );
		}
		add_action( 'edd_log_view_actions', array( $this, 'source_filter' ) );
		add_action( 'edd_log_view_actions', array( $this, 'download_filter' ) );

	}

	/**
	 * Retrieve the table columns
	 *
	 * @access public
	 * @since 1.2.6
	 * @return array $columns Array of all the list table columns
	 */
	public function get_columns() {
		return array(
			'id'       => __( 'ID', 'edd-rp-txt' ),
			'source'   => __( 'Source', 'edd-rp-txt' ),
			'download' => __( 'Purchased', 'edd-rp-txt' ),
			'payment'  => __( 'Payment', 'edd-rp-txt' ),
			'amount'   => __( 'Amount', 'edd-rp-txt' ),
			'date'     => __( 'Date', 'edd-rp-txt' ),
		);
	}

	/**
	 * This function renders most of the columns in the list table.
	 *
	 * @access public
	 * @since 1.2.6
	 *
	 * @param array $item Contains all the data of the discount code
	 * @param string $column_name The name of the column
	 *
	 * @return string Column Name
	 */
	public function column_default( $item, $column_name ) {
		switch ( $column_name ) {
			case 'id':
				return $item['id'];
			case 'download':
				return '<a href="' . esc_url( add_query_arg( array( 'download' => urlencode( $item['download'] ) ), $this->base ) ) . '">' . esc_html( get_the_title( $item['download'] ) ) . '</a>';
			case 'source':
				return '<a href="' . esc_url( add_query_arg( array( 'source' => urlencode( $item['source'] ) ), $this->base ) ) . '">' . esc_html( get_the_title( $item['source'] ) ) . '</a>';
			case 'payment':
				return '<a href="' . esc_url( admin_url( 'edit.php?post_type=download&page=edd-payment-history&view=view-order-details&id=' . urlencode( $item['payment'] ) ) ) . '">' . esc_html( $item['payment'] ) . '</a>';

			case 'amount':
				return edd_currency_filter( edd_format_amount( $item['amount'] ) );
			default:
				return $item[ $column_name ];
		}
	}

	/**
	 * Retrieves the search query string
	 *
	 * @access public
	 * @since 1.2.6
	 * @return mixed string If search is present, false otherwise
	 */
	public function get_search() {
		return ! empty( $_GET['s'] ) ? urldecode( trim( $_GET['s'] ) ) : false;
	}

	/**
	 * Displays the source dropdown menu
	 *
	 * @since  1.2.6
	 * @return void
	 */
	public function source_filter() {

		$edd_logs = new EDD_Logging();

		$log_query = array(
			'log_type'       => 'recommendation_sale',
			'posts_per_page' => 9999999,
			'fields'         => function_exists( 'edd_get_logs' ) ? array( 'object_id' ) : array( 'post_parent' ),
		);

		$logs = $edd_logs->get_connected_logs( $log_query );

		if ( $logs ) {
			$sources = array();

			foreach ( $logs as $log ) {
				$download_id = false;
				// EDD 2.x uses `post_parent`; 3.0+ uses `object_id.
				if ( isset( $log->post_parent ) ) {
					$download_id = $log->post_parent;
				} elseif ( isset( $log->object_id ) ) {
					$download_id = $log->object_id;
				}

				if ( ! empty( $download_id ) ) {
					$sources[ $download_id ] = get_the_title( $download_id );
				}
			}

			$dropdown_args = array(
				'options'          => $sources,
				'name'             => 'source',
				'id'               => 'source',
				'selected'         => ! empty( $_GET['source'] ) ? absint( $_GET['source'] ) : false,
				'show_option_all'  => _x( 'All Sources', 'all dropdown items', 'edd-rp-txt' ),
				'show_option_none' => false,
			);

			echo EDD()->html->select( $dropdown_args );

		}
	}

	/**
	 * Displayes the download dropdown menu
	 *
	 * @since  1.2.6
	 * @return void
	 */
	public function download_filter() {
		$downloads = get_posts( array(
			'post_type'              => 'download',
			'post_status'            => 'any',
			'posts_per_page'         => -1,
			'orderby'                => 'title',
			'order'                  => 'ASC',
			'fields'                 => 'ids',
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false
		) );

		$selected = ! empty( $_GET['download'] ) ? absint( $_GET['download'] ) : false;

		if ( $downloads ) {
			echo '<select name="download" id="edd-log-download-filter">';
				echo '<option value="0">' . esc_html__( 'All Purchased Items', 'edd-rp-txt' ) . '</option>';
				foreach ( $downloads as $download ) {
					echo '<option value="' . esc_attr( $download ) . '"' . selected( $download, $selected ) . '>' . esc_html( get_the_title( $download ) ) . '</option>';
				}
			echo '</select>';
		}
	}

	/**
	 * Gets the meta query for the log query
	 *
	 * This is used to return log entries that match our search query, user query, or download query
	 *
	 * @access public
	 * @since 1.2.6
	 * @return array $meta_query
	 */
	public function get_meta_query() {

		$download  = ! empty( $_GET['download'] ) ? absint( $_GET['download'] ) : false;

		$meta_query = array();

		if ( $download ) {
			// Show only logs from a specific site
			$meta_query[] = array(
				'key'   => '_edd_log_download_id',
				'value' => $download
			);
		}

		return $meta_query;
	}

	/**
	 * Retrieve the current page number
	 *
	 * @access public
	 * @since 1.2.6
	 * @return int Current page number
	 */
	function get_paged() {
		return isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
	}

	/**
	 * Outputs the log views
	 *
	 * @access public
	 * @since 1.2.6
	 * @return void
	 */
	public function bulk_actions( $which = '' ) {
		// These aren't really bulk actions but this outputs the markup in the right place
		edd_log_views();
	}

	/**
	 * Gets the log entries for the current view
	 *
	 * @param bool $count If true, a count is returned. If false, array of data is returned.
	 *
	 * @access public
	 * @since 1.2.6
	 * @return array|int $logs_data Array of all the Log entries, or the number of found logs if `$count`
	 *                   was passed as `true`.
	 */
	function get_logs( $count = false ) {
		if ( function_exists( 'edd_get_logs' ) ) {
			return $this->get_logs_v3( $count );
		} else {
			return $this->get_logs_v2( $count );
		}
	}

	/**
	 * Queries for logs in EDD 3.0+
	 *
	 * @param bool $count If true, a count is returned. If false, array of data is returned.
	 *
	 * @since 1.2.13
	 * @return array|int
	 */
	private function get_logs_v3( $count = false ) {
		$args = array(
			'type'   => 'recommendation_sale',
			'number' => $this->per_page,
			'offset' => ( $this->get_paged() - 1 ) * $this->per_page
		);

		if ( ! empty( $_GET['source'] ) && is_numeric( $_GET['source'] ) ) {
			$args['object_id'] = absint( $_GET['source'] );
		}

		if ( ! empty( $_GET['download'] ) ) {
			$args['meta_query'] = array(
				array(
					'key'   => 'download_id',
					'value' => absint( $_GET['download'] )
				)
			);
		}

		if ( $count ) {
			return edd_count_logs( $args );
		}

		$log_data = array();
		$logs     = edd_get_logs( $args );

		if ( empty( $logs ) ) {
			return $log_data;
		}

		foreach ( $logs as $log ) {
			$log_data[] = array(
				'id'       => $log->id,
				'payment'  => edd_get_log_meta( $log->id, 'payment_id', true ),
				'date'     => edd_date_i18n( strtotime( $log->date_created ) ) . '<br>' . edd_date_i18n( $log->date_created, 'time' ) . ' ' . edd_get_timezone_abbr(),
				'source'   => $log->object_id,
				'download' => edd_get_log_meta( $log->id, 'download_id', true ),
				'amount'   => edd_get_log_meta( $log->id, 'price', true )
			);
		}

		return $log_data;
	}

	/**
	 * Queries for logs in EDD 2.x
	 *
	 * @param bool $count If true, a count is returned. If false, array of data is returned.
	 *
	 * @since 1.2.13
	 * @return array|int
	 */
	private function get_logs_v2( $count = false ) {
		/**
		 * @var EDD_Logging $edd_logs
		 */
		global $edd_logs;

		$post_parent = null;
		if ( ! empty( $_GET['source'] ) && is_numeric( $_GET['source'] ) ) {
			$post_parent = absint( $_GET['source'] );
		}

		if ( $count ) {
			return $edd_logs->get_log_count( $post_parent, 'recommendation_sale', $this->get_meta_query() );
		}

		// Prevent the queries from getting cached. Without this there are occasional memory issues for some installs
		wp_suspend_cache_addition( true );

		$logs_data = array();
		$paged     = $this->get_paged();
		$log_query = array(
			'log_type'       => 'recommendation_sale',
			'paged'          => $paged,
			'meta_query'     => $this->get_meta_query(),
			'posts_per_page' => $this->per_page,
			'orderby'        => 'ID',
		);

		if ( $post_parent ) {
			$log_query['post_parent'] = $post_parent;
		}

		$logs = $edd_logs->get_connected_logs( $log_query );

		if ( $logs ) {
			foreach ( $logs as $log ) {

				$logs_data[] = array(
					'id'       => $log->ID,
					'payment'  => get_post_meta( $log->ID, '_edd_log_payment_id', true ),
					'date'     => $log->post_date,
					'source'   => $log->post_parent ,
					'download' => get_post_meta( $log->ID, '_edd_log_download_id', true ),
					'amount'   => get_post_meta( $log->ID, '_edd_log_price', true ),
				);
			}
		}

		return $logs_data;
	}

	/**
	 * Setup the final data for the table
	 *
	 * @access public
	 * @since 1.2.6
	 * @return void
	 */
	function prepare_items() {
		$columns               = $this->get_columns();
		$hidden                = array(); // No hidden columns
		$sortable              = $this->get_sortable_columns();
		$this->_column_headers = array( $columns, $hidden, $sortable );
		$this->items           = $this->get_logs();
		$total_items           = $this->get_logs( true );
		$this->set_pagination_args( array(
			'total_items'  => $total_items,
			'per_page'     => $this->per_page,
			'total_pages'  => ceil( $total_items / $this->per_page )
		) );
	}
}
