<?php

/**
 * Returns the path to the RP templates directory.
 *
 * @return string
 */
function edd_rp_get_templates_dir() {
	return EDD_RP_PLUGIN_DIR . 'templates';
}

/**
 * Retrieves the requested template part.
 *
 * @param string      $slug
 * @param string|null $name
 * @param bool        $load
 *
 * @return false|string
 */
function edd_rp_get_template_part( $slug, $name = null, $load = true ) {
	// Execute code for this part

	// Setup possible parts
	$templates = array();

	if ( isset( $name ) ) {
		$templates[] = $slug . '-' . $name . '.php';
	}

	$templates[] = $slug . '.php';

	// Return the part that is found
	return edd_rp_locate_template( $templates, $load, false );
}

/**
 * Attempts to locate (and optionally, load) a template part.
 *
 * @param array $template_names
 * @param bool  $load
 * @param bool  $require_once
 *
 * @return string|false Full path to the located template, or false on failure.
 */
function edd_rp_locate_template( $template_names, $load = false, $require_once = true ) {
	// No file found yet
	$located = false;

	// Try to find a template file
	foreach ( (array) $template_names as $template_name ) {

		// Continue if template is empty
		if ( empty( $template_name ) ) {
			continue;
		}

		// Trim off any slashes from the template name
		$template_name = ltrim( $template_name, '/' );

		// Check child theme first
		if ( file_exists( trailingslashit( get_stylesheet_directory() ) . 'edd_templates/' . $template_name ) ) {
			$located = trailingslashit( get_stylesheet_directory() ) . 'edd_templates/' . $template_name;
			break;

		// Check parent theme next
		} elseif ( file_exists( trailingslashit( get_template_directory() ) . 'edd_templates/' . $template_name ) ) {
			$located = trailingslashit( get_template_directory() ) . 'edd_templates/' . $template_name;
			break;

		// Check theme compatibility last
		} elseif ( file_exists( trailingslashit( edd_rp_get_templates_dir() ) . $template_name ) ) {
			$located = trailingslashit( edd_rp_get_templates_dir() ) . $template_name;
			break;
		}
	}

	if ( ( true == $load ) && ! empty( $located ) ) {
		add_filter( 'edd_add_schema_microdata', '__return_false' );
		load_template( $located, $require_once );
		remove_filter( 'edd_add_schema_microdata', '__return_false' );
	}

	return $located;
}

/**
 * Displays recommendations on single download pages.
 */
function edd_rp_display_single() {
	global $post;

	EDD()->session->set( 'edd_has_recommendations', $post->ID );
	edd_rp_get_template_part( 'single_recommendations' );
}

/**
 * Displays recommendations on checkout.
 */
function edd_rp_display_checkout() {
	global $post;

	if( edd_is_checkout() ) {
		// GitHub Issue: https://github.com/easydigitaldownloads/easy-digital-downloads/issues/1059
		add_filter( 'edd_straight_to_checkout', '__return_true' );
	}

	EDD()->session->set( 'edd_has_recommendations', $post->ID );

	edd_rp_get_template_part( 'checkout_recommendations' );
}
