=== Easy Digital Downloads - Recommended Products ===
Contributors: easydigitaldownloads, cklosows
Tags: Easy Digital Downloads, Recommendations
Requires at least: 3.0
Tested up to: 5.7
Stable tag: 1.2.13
License: GPLv2 or later

Show recommended products based on other customer purchases.

== Description ==

Recommended Products for Easy Digital Downloads allows you to show a cross sell of recommended products when viewing downloads or the checkout screen, with just a couple of checkboxes. These aren’t “related products” but specifically chosen products based off your stores previous sales. Every night, the recommendations are refreshed to include the day’s sales. You can manually run the update script as well via the Easy Digital Downloads Misc Settings

You can use the [recommended_products] shortcode to display recommendations for a download or downloads. It accepts the following parameters:
ids: a comma separated list of Download IDs to provide suggestions for (default: current post ID)
user: "true" or "false", weather to hide already purchased items from displaying (default: false)
count: number of suggestions to show (default: 3)
title: A title to display (default: "Recommended Products")

== Changelog ==

= 1.2.13, March 31, 2021 =
* Improvement: Custom template files now check if Recommended Products functions exist before using them.
* Fix: Invalid use of `date_i18n()` when doing time comparisons.
* Fix: Default number of recommendations not selected on first install.
* Fix: List table counts are incorrect when filtering.
* Fix: Typo in download select field on logs table.
* Tweak: Update plugin author name to Sandhills Development, LLC.
* Dev: Refactor code for WPCS.
* Dev: The `EDD_License` class has been removed in favour of the one that ships with EDD core.
* Dev: Compatibility with EDD 3.0.

= 1.2.12 February 10, 2017 =
* Fix: Shortcode outputting above content.
* Fix: Possible fatal error due to activation load order.

= 1.2.11 November 21, 2016 =
* Fix: Recommendation sales were not being tracked in logs.

= 1.2.10 =
* New: Added hooks, filters, and classes to the markup used to show recommendations.

= 1.2.9 =
* Fix: Schema data showing when it shouldn't be
* Fix: Duplicated settings showing
* New: Support for EDD Hide Download extension

= 1.2.8 =
* FIX: Show free products option not being respected during generation of recommendations.

= 1.2.7 =
* FIX: Add .pot and rename translation files
* FIX: Fatal error on recommendations log with WordPress 4.4
* NEW: Use new EDD 2.5 subsections

= 1.2.6.1 =
* FIX: Added missing file

= 1.2.6 =
* NEW: Added conversion tracking logs for items purchased via a recommendation

= 1.2.5 =
* FIX: Corrected Repeating recommendations on checkout when recalcuating taxes

= 1.2.4 =
* FIX: Error on arguements for pagination on generating recommendations
* FIX: Settings for displyaing recommendations always defaulting to 'On'
* TWEAK: Move to plugins_loaded for consistency

= 1.2.3.3 =
* FIX: XSS vulnerability in query args

= 1.2.3.2 =
* FIX: Fixed the way that the plugin text-domain is loaded, so translations work, and allowed them to be globally located.

= 1.2.3 =
* TWEAK: Allow the recommendation functions to be filtered with ```edd_rp_multi_recommendation_results``` and ```edd_rp_single_recommendation_results```
* FIX: Issue with Shortcode registration working
* TWEAK: Improved i18n configuration

= 1.2.2 =
* NEW: Shortcode recommended_products for dislaying recommendations where desired.

= 1.2.1 =
* FIX: formatting prices, above buttons and forcing no prices on recommended products buttons
* FIX: Only add a breakspace between title and price if theme doesn't support featured images, or one isn't present
* FIX: Clean up the Template files to be more consistant with template code formatting

= 1.2 =
* FIX: Removing warnings and notices on activation
* FIX: Fixing fatal error when EDD isn't active
* FIX: Updating to use edd_get_option() instead of calling the settings directly.
* UPDATE: Moving to the Extensions tab, instead of Misc settings

= 1.1 =
* NEW: Added new EDD v1.7 licensing system.

= 1.0 =
* NEW: Initial release.
