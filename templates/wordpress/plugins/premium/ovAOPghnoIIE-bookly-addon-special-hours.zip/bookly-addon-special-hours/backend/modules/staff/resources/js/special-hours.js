(function ($) {
    $(document).on('special_hours.tab_init', 'body', {},
        // Init listeners on tab container for editing staff services.
        function (event, $container, options) {
            var staff_id = options.get_staff_services.staff_id,
                location_id = options.get_staff_services.location_id,
                booklyAlertFunc = options.booklyAlert;

            SpecialHours.initContentListeners($container);
            $container.off().on('click', '.bookly-js-save-period', function (e) {
                e.preventDefault();

                // Listener for saving range.

                let $button = $(this),
                    $period_form = $button.closest('.popover-body'),
                    period_id = $button.data('period_id'),
                    price = $period_form.find('#bookly-special-price').val(),
                    ladda = rangeTools.ladda(this),
                    days = [];
                $period_form.find('.bookly-js-special-hours-day').each(function () {
                    if ($(this).prop('checked')) {
                        days.push($(this).data('day'));
                    }
                });

                $.ajax({
                    method: 'POST',
                    url: ajaxurl,
                    data: {
                        action: 'bookly_special_hours_save_period',
                        csrf_token: BooklyL10nGlobal.csrf_token,
                        start_time: $period_form.find('.bookly-js-range-start > option:selected').val(),
                        end_time: $period_form.find('.bookly-js-range-end > option:selected').val(),
                        days: days,
                        price: price,
                        staff_id: staff_id,
                        location_id: location_id,
                        service_id: $button.data('service_id'),
                        period_id: period_id
                    },
                    dataType: 'json',
                    success: function (response) {
                        if (response.success) {
                            if (period_id) {
                                // Change text on button with new range value.
                                var $interval_button = $('button.bookly-js-special-hours-toggle-popover.special-period[data-period_id="' + period_id + '"]');
                                $interval_button.html(response.data.interval);
                                $interval_button.data('price', price);
                                $interval_button.data('days', days);
                            } else {
                                var $html = $.parseHTML(response.data.html);
                                $('button[aria-describedby="' + $button.parents('.bookly-popover').attr('id') + '"]').closest('[data-service-id]').find('.periods-list-content').append($html);
                                SpecialHours.initContentListeners($container);
                                $('.bookly-js-special-hours-toggle-popover').prop('disabled', false);
                            }
                            booklyAlertFunc({success: [SpecialHoursL10n.saved]});
                            $button.parents('.bookly-popover').booklyPopover('hide');
                        } else {
                            if (response.data && response.data.message) {
                                booklyAlertFunc({error: [response.data.message]});
                            }
                        }
                    }
                }).always(function () {
                    ladda.stop()
                });
            }).on('click', '.delete-period[data-period_id]', function (e) {
                // Delete period.
                e.preventDefault();
                if (confirm(SpecialHoursL10n.are_you_sure)) {
                    var $button = $(this),
                        ladda = rangeTools.ladda(this);
                    $.ajax({
                        method: 'POST',
                        url: ajaxurl,
                        data: {action: 'bookly_special_hours_delete_period', csrf_token: BooklyL10nGlobal.csrf_token, id: $button.data('period_id'), staff_id: staff_id},
                        dataType: 'json',
                        success: function (response) {
                            if (response.success) {
                                $button.closest('.bookly-js-intervals-wrapper').remove();
                            } else {
                                if (response.data && response.data.message) {
                                    booklyAlertFunc({error: [response.data.message]});
                                }
                            }
                        }
                    }).always(function () {
                        ladda.stop();
                    });
                }
            });
        }
    );

    var SpecialHours = {
        initContentListeners: function ($content) {
            let $popup_content = $('.bookly-js-special-hours-popup-content', $content).clone().removeClass('bookly-js-special-hours-popup-content');
            $('.bookly-js-special-hours-day', $popup_content).each(function() {
                let id = $(this).prop('id'),
                    id_alt = id + '-alt';
                $(this).prop('id', id_alt);
                $('[for="' + id + '"]', $popup_content).prop('for', id_alt);
            });
            // init 'add special period' functionality
            $('.bookly-js-special-hours-toggle-popover', $content).booklyPopover({
                html: true,
                placement: 'bottom',
                container: $content,
                template: '<div class="bookly-popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>',
                trigger: 'manual',
                content: $popup_content
            }).on('click', function () {
                var $button = $(this);
                $button.booklyPopover('show');
                var $popover = $($button.data('bs.popover').tip).booklyPopover(),
                    $form = $popover.find('.popover-body'),
                    $break_start = $form.find('.bookly-js-range-start'),
                    $break_end = $form.find('.bookly-js-range-end'),
                    $price = $form.find('#bookly-special-price');
                $('.bookly-popover').not($popover).booklyPopover('hide');
                if ($button.hasClass('special-period')) {
                    var interval_string = $button.html().trim().split(' = ');
                    var interval = interval_string[0].split(/ [-–] /);
                    var start_time = moment(interval[0], ['h:mm A']).format('HH:mm:ss');
                    var end_time = moment(interval[1], ['h:mm A']).format('HH:mm:ss');
                    if (moment(interval[0], ['h:mm A']).format('HH') > moment(interval[1], ['h:mm A']).format('HH')) {
                        var parts = end_time.split(':');
                        parts[0] = parseInt(parts[0]) + 24;
                        end_time = parts.join(':');
                    }
                    $break_start.val(start_time);
                    $break_end.val(end_time);
                    $price.val($button.data('price'));
                    $form.find('input.bookly-js-special-hours-day').prop('checked', false);
                    $button.data('days').toString().split(',').forEach(function (day) {
                        $form.find('input[data-day="' + day + '"]').prop('checked', true);
                    });
                    $form.find('.bookly-js-save-period').data('period_id', $button.data('period_id'));
                } else {
                    $price.val($content.find('[name="price[' + $button.data('service_id') + ']"]').val());
                    $form.find('.bookly-js-save-period').data('service_id', $button.data('service_id')).removeData('period_id');
                    $form.find('input.bookly-js-special-hours-day').prop('checked', true);
                }

                rangeTools.hideUp24Hours($break_start, $break_end);
                $popover.find('.bookly-popover-close').on('click', function () {
                    $popover.booklyPopover('hide');
                });
            });
        }
    };
})(jQuery);