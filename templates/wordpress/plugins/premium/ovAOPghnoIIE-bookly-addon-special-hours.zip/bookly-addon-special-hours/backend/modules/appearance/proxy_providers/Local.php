<?php
namespace BooklySpecialHours\Backend\Modules\Appearance\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Modules\Appearance\Proxy;

class Local extends Proxy\SpecialHours
{
    /**
     * @inheritDoc
     */
    public static function renderHighlightSpecialHours()
    {
        self::renderTemplate( 'highlight_special_hours' );
    }
}