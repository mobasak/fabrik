<?php
namespace BooklySpecialHours\Backend\Modules\Staff\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Modules\Staff\Proxy;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function enqueueStaffProfileScripts()
    {
        self::enqueueScripts( array(
            'module' => array( 'js/special-hours.js' => array( 'bookly-backend-globals' ), ),
        ) );

        wp_localize_script( 'bookly-special-hours.js', 'SpecialHoursL10n', array(
            'are_you_sure' => __( 'Are you sure?', 'bookly' ),
            'saved'        => __( 'Settings saved.', 'bookly' ),
        ) );
    }

    /**
     * @inheritDoc
     */
    public static function enqueueStaffProfileStyles()
    {
        self::enqueueStyles( array(
            'alias' => array( 'bookly-backend-globals', ),
        ) );
    }

}