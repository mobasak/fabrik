<?php
namespace BooklySpecialHours\Backend\Modules\Staff\Forms;

class StaffSpecialHour extends \Bookly\Lib\Base\Form
{
    protected static $entity_class = 'StaffSpecialHour';

    protected static $namespace = '\BooklySpecialHours\Lib\Entities';

    public function configure()
    {
        $this->setFields( array(
            'start_time',
            'end_time',
            'price',
            'service_id',
            'staff_id',
            'location_id',
            'days',
        ) );
    }

}