<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Controls\Inputs;
?>
<div class="col-md-3 my-2">
    <?php Inputs::renderCheckBox( __( 'Highlight special hours', 'bookly' ), null, get_option( 'bookly_app_highlight_special_hours' ), array( 'id' => 'bookly-highlight-special-hours' ) ) ?>
</div>