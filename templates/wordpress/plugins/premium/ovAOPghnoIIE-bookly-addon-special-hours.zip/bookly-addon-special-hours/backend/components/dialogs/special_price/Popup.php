<?php
namespace BooklySpecialHours\Backend\Components\Dialogs\SpecialPrice;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Modules\Staff\Forms\Widgets\TimeChoice;

class Popup extends BooklyLib\Base\Component
{
    public static function render( $staff_id )
    {
        if ( ! BooklyLib\Utils\Common::isCurrentUserAdmin() ) {
            do {
                if ( self::parameter( 'staff_cabinet' ) && BooklyLib\Config::staffCabinetActive() ) {
                    $allow = true;
                } else {
                    $allow = get_option( 'bookly_gen_allow_staff_edit_profile' );
                }
                if ( $allow ) {
                    $staff = new BooklyLib\Entities\Staff();
                    if ( $staff->load( $staff_id ) && $staff->getWpUserId() == get_current_user_id() ) {
                        break;
                    }
                }
                wp_send_json_success( array( 'html' => 'Bookly: ' . __( 'You do not have sufficient permissions to access this page.' ) ) );
            } while ( 0 );
        }

        // Find 'optimal' start_time & end_time for current employee.
        $working_time = BooklyLib\Entities\StaffScheduleItem::query( 'ss' )
            ->select( 'ss.start_time' )
            ->where( 'ss.staff_id', $staff_id )
            ->whereNot( 'ss.start_time', null )
            ->groupBy( 'ss.start_time' )
            ->sortBy( 'COUNT(*) DESC, start_time' )
            ->limit( 1 )
            ->fetchRow();
        $working_start_time = is_array( $working_time ) ? $working_time['start_time'] : '08:00:00';
        $working_time = BooklyLib\Entities\StaffScheduleItem::query( 'ss' )
            ->select( 'ss.end_time' )
            ->where( 'ss.staff_id', $staff_id )
            ->whereNot( 'ss.end_time', null )
            ->groupBy( 'ss.end_time' )
            ->sortBy( 'COUNT(*) DESC, end_time' )
            ->order( BooklyLib\Query::ORDER_DESCENDING )
            ->limit( 1 )
            ->fetchRow();
        $working_end_time = is_array( $working_time ) ? $working_time['end_time'] : '18:00:00';

        $choice_start = new TimeChoice( array( 'use_empty' => false, 'type' => 'break_from' ) );
        $choice_end   = new TimeChoice( array( 'use_empty' => false, 'type' => 'to' ) );
        self::renderTemplate( 'popover', compact( 'staff_id', 'working_start_time', 'working_end_time', 'choice_start', 'choice_end' ) );
    }
}