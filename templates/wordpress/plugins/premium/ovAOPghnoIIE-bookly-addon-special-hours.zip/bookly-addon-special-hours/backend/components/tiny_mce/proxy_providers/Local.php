<?php
namespace BooklySpecialHours\Backend\Components\TinyMce\ProxyProviders;

use Bookly\Backend\Components\TinyMce\Proxy;

class Local extends Proxy\SpecialHours
{
    /**
     * @inheritDoc
     */
    public static function renderStaffCabinetSettings()
    {
        self::renderTemplate( 'staff_cabinet' );
    }
}