<?php
namespace BooklySpecialHours\Backend\Components\Dialogs\SpecialPrice\ProxyProviders;

use Bookly\Backend\Components\Dialogs\SpecialPrice\Proxy;

abstract class Local extends Proxy\SpecialHours
{
    /**
     * @inheritDoc
     */
    public static function renderSpecialPricePopup( $staff_id )
    {
        \BooklySpecialHours\Backend\Components\Dialogs\SpecialPrice\Popup::render( $staff_id );
    }
}