<?php
namespace BooklySpecialHours\Backend\Components\Dialogs\Staff\Edit;

use Bookly\Lib as BooklyLib;
use BooklySpecialHours\Lib;

class Ajax extends BooklyLib\Base\Ajax
{
    /**
     * @inheritDoc
     */
    protected static function permissions()
    {
        return array( '_default' => 'staff' );
    }

    /**
     * Add special period to staff schedule
     */
    public static function savePeriod()
    {
        $period_id = self::parameter( 'period_id' );
        $end_time = self::parameter( 'end_time' );
        $start_time = self::parameter( 'start_time' );
        $price = self::parameter( 'price', 0 );
        $days = self::parameter( 'days', array() );
        $days_string = implode( ',', $days );

        $period = new Lib\Entities\StaffSpecialHour();
        if ( $period_id ) {
            $period->load( $period_id );
            $service_id = $period->getServiceId();
            $staff_id = $period->getStaffId();
            $location_id = $period->getLocationId();
        } else {
            $service_id = self::parameter( 'service_id' );
            $staff_id = self::parameter( 'staff_id' );
            $location_id = self::parameter( 'location_id' ) ?: null;
            // Create new period.
            $period
                ->setServiceId( $service_id )
                ->setStaffId( $staff_id )
                ->setLocationId( $location_id );
        }

        if ( Lib\Utils\Common::isSpecialPeriodAvailable( $start_time, $end_time, $service_id, $staff_id, $location_id, $period_id, $days ) ) {
            $period
                ->setPrice( $price )
                ->setStartTime( $start_time )
                ->setEndTime( $end_time )
                ->setDays( $days_string )
                ->save();
            if ( $period_id ) {
                $interval = self::renderTemplate( '_interval', array(
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'price' => $price,
                    'days' => $days_string,
                ), false );
                wp_send_json_success( compact( 'interval' ) );
            } else {
                $html = self::renderTemplate( '_period', array(
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'period_id' => $period->getId(),
                    'price' => $price,
                    'days' => $days_string,
                    'read_only' => false,
                ), false );
                wp_send_json_success( compact( 'html' ) );
            }
        } else {
            wp_send_json_error( array( 'message' => __( 'The requested interval is not available', 'bookly' ) ) );
        }
    }

    /**
     * Add special period to staff schedule
     */
    public static function deletePeriod()
    {
        Lib\Entities\StaffSpecialHour::query()->delete()
            ->where( 'id', self::parameter( 'id' ) )
            ->where( 'staff_id', self::parameter( 'staff_id' ) )->execute();

        wp_send_json_success();
    }

    /**
     * Check if the current user has access to the action.
     *
     * @param string $action
     * @return bool
     */
    protected static function hasAccess( $action )
    {
        if ( parent::hasAccess( $action ) ) {
            if ( ! BooklyLib\Utils\Common::isCurrentUserAdmin() ) {
                $staff = new BooklyLib\Entities\Staff();
                switch ( $action ) {
                    case 'savePeriod':
                    case 'deletePeriod':
                        $staff->load( self::parameter( 'staff_id' ) );
                        break;
                    default:
                        return false;
                }

                return $staff->getWpUserId() == get_current_user_id();
            }

            return true;
        }

        return false;
    }
}