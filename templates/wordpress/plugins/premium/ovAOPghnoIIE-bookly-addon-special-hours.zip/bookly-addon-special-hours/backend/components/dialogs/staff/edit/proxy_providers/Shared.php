<?php
namespace BooklySpecialHours\Backend\Components\Dialogs\Staff\Edit\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;
use BooklySpecialHours\Lib;

class Shared extends Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function renderStaffServiceTail( $staff_id, BooklyLib\Entities\Service $service, $location_id, $attributes = array() )
    {
        if ( $service->getType() == BooklyLib\Entities\Service::TYPE_SIMPLE ) {
            $read_only    = isset( $attributes['read-only']['special-hours'] );
            $location_id  = $location_id ?: null;
            $service_id   = $service->getId();
            $periods_list = Lib\Entities\StaffSpecialHour::query()
                ->where( 'service_id', $service_id )
                ->where( 'staff_id', $staff_id )
                ->where( 'location_id', $location_id )
                ->sortBy( 'start_time' )
                ->fetchArray();

            self::renderTemplate( 'list', compact( 'service_id', 'staff_id', 'periods_list', 'read_only' ) );
        }
    }
}