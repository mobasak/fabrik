<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Backend\Components\Controls\Buttons;

/** @global WP_Locale $wp_locale */
global $wp_locale;

$start_of_week = (int) get_option( 'start_of_week' );
$weekdays = array_values( $wp_locale->weekday_abbrev );
?>
<div class="bookly-js-special-hours-popup-content">
    <div>
        <div class="form-row mb-2">
            <div class="col">
                <?php echo $choice_start->render( '', $working_start_time, array( 'class' => 'bookly-js-range-start form-control' ) ) ?>
            </div>
            <div class="mt-2">
                <?php esc_html_e( 'to', 'bookly' ) ?>
            </div>
            <div class="col">
                <?php echo $choice_end->render( '', $working_end_time, array( 'class' => 'bookly-js-range-end form-control' ) ) ?>
            </div>
        </div>
        <div class="form-group">
            <div class="form-row text-center">
                <?php for ( $i = 1; $i <= 7; $i ++ ) : ?>
                    <?php $day_index = ( $start_of_week + $i ) < 8 ? $start_of_week + $i : $start_of_week + $i - 7; ?>
                    <div class="col">
                        <?php echo $weekdays[ $day_index - 1 ] ?><br/>
                        <div class="custom-control custom-checkbox mt-2">
                            <input
                                    class="custom-control-input bookly-js-special-hours-day"
                                    id="bookly-special-hours-day-<?php echo $day_index ?>"
                                    type="checkbox"
                                    data-day="<?php echo $day_index ?>"
                            />
                            <label class="custom-control-label w-100 bookly-toggle-label" for="bookly-special-hours-day-<?php echo $day_index ?>" style="margin-left:4px; margin-right: -4px"></label>
                        </div>
                    </div>
                <?php endfor ?>
            </div>
        </div>
        <div class="form-group">
            <label for="bookly-special-price"><?php esc_html_e( 'Price', 'bookly' ) ?></label>
            <input class="form-control" id="bookly-special-price" type="number" min="0"/>
        </div>
        <hr>
        <div class="form-row justify-content-end">
            <div class="col-auto">
                <?php Buttons::renderSubmit( null, 'bookly-js-save-period' ) ?>
            </div>
            <div class="col-auto">
                <?php Buttons::render( null, 'bookly-popover-close btn-default', __( 'Close', 'bookly' ) ) ?>
            </div>
        </div>
    </div>
</div>