<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div class="bookly-js-special-hour-wrapper mt-1">
    <div class="bookly-js-intervals-wrapper">
        <div class="btn-group btn-group-sm w-100">
            <button type="button" class="btn btn-info bookly-js-special-hours-toggle-popover special-period text-left"
                    data-period_id="<?php echo $period_id ?>"
                    data-price="<?php echo $price ?>"
                    data-days="<?php echo $days ?>"
                <?php disabled( $read_only ) ?>
            >
                <?php include '_interval.php' ?>
            </button>
            <?php if ( ! $read_only ) : ?>
                <button type="button" title="<?php esc_attr_e( 'Delete', 'bookly' ) ?>" class="btn btn-info delete-period" data-period_id="<?php echo $period_id ?>" data-style="zoom-in" data-spinner-size="20" style="max-width: 32px;"><span class="ladda-label">&times;</span></button>
            <?php endif ?>
        </div>
    </div>
</div>