<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div class="row">
    <div class="col-lg-7">
        <?php esc_html_e( 'Special prices for appointments which begin between:', 'bookly' ) ?>
    </div>
    <div class="col-lg-5">
        <div class="bookly-js-special-hour-wrapper bookly-js-special-hours-breaks-list">
            <div class="bookly-js-intervals-wrapper">
                <?php if ( ! $read_only ) : ?>
                    <button type="button"
                            class="bookly-js-special-hours-toggle-popover btn btn-link p-0"
                            data-service_id="<?php echo $service_id ?>">
                        <?php esc_html_e( 'add special period', 'bookly' ) ?>
                    </button>
                <?php endif ?>
            </div>
            <div class="periods-list-content">
                <?php foreach ( $periods_list as $period ) :
                    $self::renderTemplate( '_period', array(
                        'start_time' => $period['start_time'],
                        'end_time' => $period['end_time'],
                        'period_id' => $period['id'],
                        'price' => $period['price'],
                        'days' => $period['days'],
                        'read_only' => $read_only,
                    ) );
                endforeach ?>
            </div>
        </div>
    </div>
</div>