<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly
use Bookly\Lib\Utils\DateTime;
use Bookly\Lib\Utils\Price;

/** @var string $days */
/** @var string $start_time */
/** @var string $end_time */
/** @var string $price */

global $wp_locale;
$weekdays = array_values( $wp_locale->weekday_abbrev );
?>
<?php foreach ( explode( ',', $days ) as $day ) : ?>
    <?php echo $weekdays[ $day - 1 ] ?>
<?php endforeach ?><br/>
<?php echo DateTime::formatInterval( $start_time, $end_time ) ?> = <?php echo Price::format( $price ) ?>
