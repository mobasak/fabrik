<?php
namespace BooklySpecialHours\Lib\Utils;

use BooklySpecialHours\Lib;

abstract class Common
{
    /**
     * Check if period is available.
     *
     * @param string $start_time
     * @param string $end_time
     * @param int $service_id
     * @param int $staff_id
     * @param int $location_id
     * @param int $period_id
     * @param array $days
     * @return bool
     */
    public static function isSpecialPeriodAvailable( $start_time, $end_time, $service_id, $staff_id, $location_id, $period_id, $days )
    {
        if ( $start_time > $end_time || ( $days !== null && empty( $days ) ) ) {
            return false;
        }
        if ( $days === null ) {
            $days = array( date( 'w', strtotime( $start_time ) ) + 1 );
        }

        $query = Lib\Entities\StaffSpecialHour::query()
            ->where( 'service_id', $service_id )
            ->where( 'staff_id', $staff_id )
            ->where( 'location_id', $location_id )
            ->whereNot( 'id', $period_id )
            ->whereLt( 'start_time', $end_time )
            ->whereGt( 'end_time', $start_time );

        if ( ! empty( $days ) ) {
            $days_query = array();
            foreach ( $days as $day ) {
                $days_query[] = "days LIKE '%$day%'";
            }
            $query->whereRaw( implode( ' OR ', $days_query ), array() );
        }

        return $query->count() == 0;
    }

}