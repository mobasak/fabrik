<?php
namespace BooklySpecialHours\Lib\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Lib\Utils\DateTime;
use BooklySpecialHours\Lib;

class Local extends BooklyLib\Proxy\SpecialHours
{
    /**
     * @inheritDoc
     */
    public static function adjustPrice( $price, $staff_id, $service_id, $location_id, $start_time, $week_day )
    {
        $location_id = BooklyLib\Proxy\Locations::prepareStaffLocationId( $location_id, $staff_id ) ?: null;
        $start_time_next_day = DateTime::buildTimeString( DateTime::timeToSeconds( $start_time ) + 24 * HOUR_IN_SECONDS );
        $special_price = Lib\Entities\StaffSpecialHour::query()
            ->select( 'price' )
            ->whereRaw(
                'r.start_time <= %s AND r.end_time > %s OR r.start_time <= %s AND r.end_time > %s',
                array( $start_time, $start_time, $start_time_next_day, $start_time_next_day )
            )
            ->where( 'service_id', $service_id )
            ->where( 'staff_id', $staff_id )
            ->where( 'location_id', $location_id )
            ->whereLike( 'days', '%' . $week_day . '%' )
            ->fetchRow();

        return $special_price ? $special_price['price'] : $price;
    }

    /**
     * @inheritDoc
     */
    public static function isNotInSpecialHour( $start_time, $end_time, $service_id, $staff_id, $location_id, $days = null )
    {
        $location_id = BooklyLib\Proxy\Locations::prepareStaffLocationId( $location_id, $staff_id ) ?: null;

        return Lib\Utils\Common::isSpecialPeriodAvailable( $start_time, $end_time, $service_id, $staff_id, $location_id, null, $days );
    }
}