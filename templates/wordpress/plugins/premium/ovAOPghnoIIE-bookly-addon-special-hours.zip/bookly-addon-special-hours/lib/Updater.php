<?php
namespace BooklySpecialHours\Lib;

use Bookly\Lib as BooklyLib;

class Updater extends BooklyLib\Base\Updater
{
    public function update_2_8()
    {
        add_option( 'bookly_app_highlight_special_hours', 0 );
        $this->alterTables( array(
            'bookly_staff_special_hours' => array(
                'ALTER TABLE `%s` ADD COLUMN `days` VARCHAR(255) NOT NULL DEFAULT "1,2,3,4,5,6,7" AFTER `end_time`',
            ),
        ) );
    }

    public function update_2_2()
    {
        $this->upgradeCharsetCollate( array(
            'bookly_staff_special_hours',
        ) );
    }

    public function update_2_0()
    {
        /** @global \wpdb $wpdb */
        global $wpdb;

        // Rename tables.
        $tables = array(
            'staff_special_hours',
        );
        $query = 'RENAME TABLE ';
        foreach ( $tables as $table ) {
            $query .= sprintf( '`%s` TO `%s`, ', $this->getTableName( 'ab_' . $table ), $this->getTableName( 'bookly_' . $table ) );
        }
        $query = substr( $query, 0, -2 );
        $wpdb->query( $query );

        delete_option( 'bookly_special_hours_enabled' );
    }

    function update_1_9()
    {
        $this->alterTables( array(
            'ab_staff_special_hours' => array(
                'ALTER TABLE `%s` ADD COLUMN `location_id` INT UNSIGNED DEFAULT NULL AFTER `service_id`',
            ),
        ) );
    }
}