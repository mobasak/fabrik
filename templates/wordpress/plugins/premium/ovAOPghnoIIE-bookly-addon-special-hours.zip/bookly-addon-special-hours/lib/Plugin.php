<?php
namespace BooklySpecialHours\Lib;

use BooklySpecialHours\Backend\Components;
use BooklySpecialHours\Backend;
use BooklySpecialHours\Frontend;

abstract class Plugin extends \Bookly\Lib\Base\Plugin
{
    protected static $prefix;
    protected static $title;
    protected static $version;
    protected static $slug;
    protected static $directory;
    protected static $main_file;
    protected static $basename;
    protected static $text_domain;
    protected static $root_namespace;
    protected static $embedded;

    /**
     * @inheritDoc
     */
    protected static function init()
    {
        // Init ajax.
        Components\Dialogs\Staff\Edit\Ajax::init();

        // Init proxy.
        Frontend\Modules\Booking\ProxyProviders\Shared::init();
        Backend\Modules\Staff\ProxyProviders\Shared::init();
        Backend\Modules\Appearance\ProxyProviders\Local::init();
        Backend\Modules\Appearance\ProxyProviders\Shared::init();
        Components\Dialogs\SpecialPrice\ProxyProviders\Local::init();
        Components\Dialogs\Staff\Edit\ProxyProviders\Shared::init();
        Components\TinyMce\ProxyProviders\Local::init();
        ProxyProviders\Local::init();
    }
}