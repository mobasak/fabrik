<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div class="bookly-form-group bookly-js-chain-appointments bookly-chain-actions"<?php if ( ! get_option( 'bookly_chain_appointments_enabled' ) ) : ?> style="display: none;"<?php endif ?>>
    <label></label>
    <div></div>
</div>