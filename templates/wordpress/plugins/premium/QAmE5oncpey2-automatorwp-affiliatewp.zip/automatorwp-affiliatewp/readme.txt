=== AutomatorWP - AffiliateWP ===
Contributors: automatorwp, rubengc, eneribs
Tags: affiliatewp, automatorwp, affiliate, referral, program
Requires at least: 4.4
Tested up to: 6.1
Stable tag: 1.0.4
License: GNU AGPLv3
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Connect AutomatorWP with AffiliateWP

== Description ==

[AffiliateWP](https://affiliatewp.com/?ref=1252 "AffiliateWP") is an easy-to-use, reliable WordPress plugin that gives you the affiliate marketing tools you need to grow your business and make more money.

= Triggers =

* User becomes an affiliate.
* User earns a referral of any/specific type.
* User gets a referral of any/specific type paid or rejected.

= Actions =

* Add referral to the user.
* Add referral to user's affiliate.

= Tags =

* Referral tags to use the referral information (amount, currency, campaign, etc).

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.0.4 =

* **Improvements**
* Updated "User becomes an affiliate" trigger to adapt to AffiliateWP new version.

= 1.0.3 =

* **Improvements**
* Correctly apply the referral if user is an affiliate in "Add referral to user" action.

= 1.0.2 =

* **New Features**
* Added referral tags to use the referral information (amount, currency, campaign, etc).
* **Improvements**
* Improved functions to get the affiliate ID.

= 1.0.1 =

* **New Features**
* New action: Add referral to user's affiliate.

= 1.0.0 =

* Initial release.
