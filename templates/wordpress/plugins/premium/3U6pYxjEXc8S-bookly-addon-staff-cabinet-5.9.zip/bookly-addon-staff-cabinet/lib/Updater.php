<?php
namespace BooklyStaffCabinet\Lib;

class Updater extends \Bookly\Lib\Base\Updater
{
    public function update_5_9()
    {
        $new_pc_key = 'bookly_staff_cabinet_purchase_code';
        $old_pc_key = 'bookly_staff_cabinet_envato_purchase_code';
        $current_pc = get_option( $old_pc_key, 'missing' );
        if ( $current_pc === 'missing' ) {
            add_option( $new_pc_key, '' );
        } else {
            if ( $current_pc ) {
                add_option( $new_pc_key, $current_pc );
            }
            delete_option( $old_pc_key );
        }
    }

    public function update_1_8()
    {
        delete_option( 'bookly_staff_cabinet_enabled' );
    }
}