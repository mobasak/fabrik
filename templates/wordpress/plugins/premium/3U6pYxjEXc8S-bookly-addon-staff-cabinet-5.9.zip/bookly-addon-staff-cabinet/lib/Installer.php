<?php
namespace BooklyStaffCabinet\Lib;

use Bookly\Lib as BooklyLib;

class Installer extends Base\Installer
{
}