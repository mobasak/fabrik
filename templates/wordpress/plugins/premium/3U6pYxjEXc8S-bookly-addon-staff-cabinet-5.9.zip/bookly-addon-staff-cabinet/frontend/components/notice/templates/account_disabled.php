<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div id="bookly-tbs">
    <div>
        <?php esc_html_e( 'Your account has been disabled. Contact your website administrator to continue.', 'bookly' ) ?>
    </div>
</div>