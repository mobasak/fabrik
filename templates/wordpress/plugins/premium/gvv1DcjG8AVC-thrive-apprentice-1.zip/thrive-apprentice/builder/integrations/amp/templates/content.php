<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}

?>

<div id="content">
	<div class="main-container thrv_wrapper">
		<?php echo $attr['content']; ?>
	</div>
	<div class="main-content-background thrv_wrapper"></div>
</div>
