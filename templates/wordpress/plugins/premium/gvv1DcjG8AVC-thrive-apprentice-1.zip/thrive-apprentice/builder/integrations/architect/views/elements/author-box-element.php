<div class="thrv_wrapper thrive_author_box tcb-elem-placeholder tcb-ct-placeholder" data-ct="thrive_author_box">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'add', false, 'editor' ); ?>
		<?php echo __( 'Insert About the Author', 'thrive-theme' ); ?>
	</span>
</div>
