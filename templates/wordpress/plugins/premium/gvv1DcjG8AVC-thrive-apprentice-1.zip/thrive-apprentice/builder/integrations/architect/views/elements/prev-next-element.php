<div class="thrv_wrapper thrive_prev_next tcb-elem-placeholder tcb-ct-placeholder" data-ct="thrive_prev_next">
	<span class="tcb-inline-placeholder-action with-icon">
		<?php tcb_icon( 'add', false, 'editor' ); ?>
		<?php echo __( 'Insert Prev/Next', 'thrive-theme' ); ?>
	</span>
</div>
