<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}

echo '[' . Thrive\Theme\Integrations\WooCommerce\Shortcodes\Account_Template::SHORTCODE . ']';
