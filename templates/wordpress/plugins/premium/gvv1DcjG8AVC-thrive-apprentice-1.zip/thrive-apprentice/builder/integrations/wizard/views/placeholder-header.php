<header class="ttb-placeholder p-header">
	<div class="ttb-width flex-mid" style="padding: 12px 0">
		<div class="p-box w-150" style="height: 36px"></div>
		<div class="dashes ml-30" style="width: 300px;"></div>
		<div class="flex-self-end flex-mid">
			<div class="p-box square"></div>
			<div class="p-box ml-10" style="height: 15px; width: 150px"></div>
			<div class="p-box square ml-25"></div>
			<div class="p-box ml-10" style="height: 15px; width: 150px"></div>
		</div>
	</div>
</header>
