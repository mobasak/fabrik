<div class="thrv_wrapper main-no-results thrv_contentbox_shortcode thrv-content-box tve-elem-default-pad">
	<div class="tve-content-box-background"></div>
	<div class="tve-cb">
		<div class="thrv_wrapper thrv_text_element"><p><?php echo __( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'thrive-theme' ); ?></p></div>
	</div>
</div>
