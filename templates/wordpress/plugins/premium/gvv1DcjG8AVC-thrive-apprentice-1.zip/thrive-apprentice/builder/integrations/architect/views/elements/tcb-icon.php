<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
} ?>

<span class="tcb-button-icon">
	<span class="thrv_icon thrv_wrapper tcb-icon-inherit-style tve_no_drag tve_no_icons tcb-icon-display">
		<?php echo $attr['icon']; ?>
	</span>
</span>
