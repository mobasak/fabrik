<?php

echo Thrive_Shortcodes::comments_section();
