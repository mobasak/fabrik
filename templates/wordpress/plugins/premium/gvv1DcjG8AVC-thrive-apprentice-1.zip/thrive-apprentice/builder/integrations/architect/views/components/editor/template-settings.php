<div id="tve-template-settings-component" class="tve-component default-visible" data-view="TemplateSettings">
	<div class="action-group">
		<div class="dropdown-header" data-prop="docked">
			<div class="group-description">
				<?php echo __( 'Template Settings', 'thrive-theme' ); ?>
			</div>
			<i></i>
		</div>
		<div class="dropdown-content">
			<?php echo Thrive_Utils::return_part( '/integrations/architect/views/backbone/theme-main/template-editor-notice.php' ); ?>
		</div>
	</div>
</div>
