<footer class="ttb-placeholder p-footer thrv_footer">
	<div class="ttb-width pt-30 pb-30 flex-mid" style="justify-content: space-between">
		<?php foreach ( range( 1, 3 ) as $col ) : ?>
			<div class="p-widget" style="width: 20%">
				<div class="p-box mb-10" style="height: 15px;"></div>
				<div class="p-box" style="height: 5px; width: 65%"></div>
				<div class="p-box" style="height: 5px; margin-top: 2px; width: 80%"></div>
				<div class="p-box" style="height: 5px; margin-top: 2px;"></div>
				<div class="p-box" style="height: 5px; margin-top: 2px;"></div>
				<div class="p-box" style="height: 5px; margin-top: 2px; width: 85%"></div>
				<div class="p-box" style="height: 5px; margin-top: 2px; width: 75%"></div>
				<div class="p-box" style="height: 5px; margin-top: 2px; width: 78%"></div>
			</div>
		<?php endforeach ?>
		<div class="p-widget" style="width: 15%">
			<div class="p-box ml-15" style="height: 10px;"></div>
			<div class="flex-mid mt-20" style="justify-content: space-between">
				<div class="square p-box"></div>
				<div class="square p-box"></div>
				<div class="square p-box"></div>
				<div class="square p-box"></div>
			</div>
			<div class="p-box mt-25" style="height: 5px;margin-left: 50px;"></div>
		</div>
	</div>
</footer>
