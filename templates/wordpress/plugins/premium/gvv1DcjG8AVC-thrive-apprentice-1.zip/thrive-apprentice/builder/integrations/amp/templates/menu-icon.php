<svg class="tcb-icon" viewBox="0 0 24 24" data-name="align-justify">
	<g>
		<g>
			<path class="st0" d="M23,13H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h22c0.6,0,1,0.4,1,1S23.6,13,23,13z"></path>
		</g>
		<g>
			<path class="st0" d="M23,6.7H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h22c0.6,0,1,0.4,1,1S23.6,6.7,23,6.7z"></path>
		</g>
		<g>
			<path class="st0" d="M23,19.3H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h22c0.6,0,1,0.4,1,1S23.6,19.3,23,19.3z">
			</path>
		</g>
	</g>
</svg>
