<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
} ?>

<span class="tcb-button-texts">
	<span class="tcb-button-text thrv-inline-text">
		<?php echo $attr['label']; ?>
	</span>
</span>
