<?php
/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-theme
 */

echo Thrive\Theme\Integrations\WooCommerce\Shortcodes\Account_Template::render();
