<div class="tcb-no-taxonomy">
	<span>
		<?php tcb_icon( 'exclamation-circle', false, 'iframe', '' ); ?>
		<?php echo __( 'Taxonomy Description Field not Found', 'thrive-theme' ); ?></span>
	<p><?php echo __( "The taxonomy description field doesn't exist for the current taxonomy so no content will be displayed", 'thrive-theme' ); ?></p>
</div>
