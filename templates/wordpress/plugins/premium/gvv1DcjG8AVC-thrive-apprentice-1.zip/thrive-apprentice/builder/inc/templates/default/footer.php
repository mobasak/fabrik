<?php

/**
 * Thrive Themes - https://thrivethemes.com
 *
 * @package thrive-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}

?>

<div class="symbol-section-out"></div>
<div class="symbol-section-in">
	<div class="thrv_wrapper thrv_text_element" style="">
		<p style="text-align: center;">Copyright <?php echo date( 'Y' ); ?> ACME Inc - <a href="#">Privacy Policy</a>
		</p>
	</div>
</div>
