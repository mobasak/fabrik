<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Silence is golden!
}
?>
<div id="c-s-p-content" class="scrollbar">
	<div class="c-s-p-section" data-section="vars"></div>
</div>

