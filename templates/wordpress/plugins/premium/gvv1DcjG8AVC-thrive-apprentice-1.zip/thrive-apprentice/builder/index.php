<?php
/**
 * Thrive Themes Builder
 */

thrive_template()->render();
