<?php
/**
 * The template for displaying woocommerce
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package thrive-theme
 */

thrive_template()->render();
