<div id="tva-app">
	<div class="tva-menu"></div>
	<div class="tva-submenu"></div>
	<div id="tva-content"></div>
	<div class="tvd-card-preloader tva-element-loader" style="position:fixed;left:36px;top:32px;background: #eaefef">
		<div style="width: 140px; height: 140px" class="tvd-preloader-wrapper tvd-active">
			<div class="tvd-spinner-layer tvd-spinner-blue-only">
				<div class="tvd-circle-clipper tvd-left">
					<div class="tvd-circle"></div>
				</div>
				<div class="tvd-gap-patch">
					<div class="tvd-circle"></div>
				</div>
				<div class="tvd-circle-clipper tvd-right">
					<div class="tvd-circle"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<div style="display: none;">
	<?php wp_editor( '', 'tve_tinymce_tpl' ); ?>
</div>
