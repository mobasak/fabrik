<div class="tvd-modal-content tva-no-after"></div>
<div class="tva-modal-footer-outer">
	<button type="button" class="tva-modal-btn tvd-modal-close"><?php echo esc_html__( 'Close', 'thrive-apprentice' ); ?></button>
	<button type="button" class="tva-modal-btn tva-modal-btn-green click tvd-modal-save" data-fn="save"><?php echo esc_html__( 'Save', 'thrive-apprentice' ); ?></button>
</div>
