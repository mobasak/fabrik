<?php
/**
 * Outputs the customer notification section for custom deliverables.
 *
 * @since 1.1
 *
 * @var string $description The explanation for the customer notification area.
 * @var int    $payment_id  The payment ID.
 * @var string $action      The ajax action to be performed.
 */
if ( empty( $description ) ) {
	if ( class_exists( '\\EDD\\Emails\\Email' ) ) {
		$args        = array(
			'page'  => 'edd-emails',
			'email' => 'custom_deliverable',
		);
		$description = sprintf(
			/* Translators: %1$s opening anchor tag; %2$s closing anchor tag */
			__( 'If you\'d like to send an email to the customer to let them know their files are ready to download, you can do so below. The email content can be edited in the %1$sEmails%2$s section.', 'edd-custom-deliverables' ),
			'<a href="' . esc_url( add_query_arg( $args, edd_get_admin_url() ) ) . '">',
			'</a>'
		);
	} else {
		$args        = array(
			'page'    => 'edd-settings',
			'tab'     => 'emails',
			'section' => 'edd-custom-deliverables-emails',
		);
		$description = sprintf(
		/* Translators: %1$s opening anchor tag; %2$s closing anchor tag */
			__( 'If you\'d like to send an email to the customer to let them know their files are ready to download, you can do so below. Note that you can edit that email in the %1$sEmail Settings%2$s area.', 'edd-custom-deliverables' ),
			'<a href="' . esc_url( add_query_arg( $args, edd_get_admin_url() ) ) . '">',
			'</a>'
		);
	}
}
?>
<div class="edd-custom-deliverables-send-email-wrapper">
	<h3><?php esc_html_e( 'Notify Customer', 'edd-customized-deliverables' ); ?></h3>
	<p>
		<?php echo wp_kses_post( $description ); ?>
	</p>
	<p>
		<button
			type="button"
			class="button button-secondary"
			id="edd-custom-deliverables-email-customer"
			data-payment="<?php echo esc_attr( $payment_id ); ?>"
			data-action="<?php echo esc_attr( $action ); ?>"
		>
			<?php esc_html_e( 'Notify Customer', 'edd-custom-deliverables' ); ?>
		</button>
	</p>
	<div id="edd-custom-deliverables-email-response"></div>
	<?php wp_nonce_field( 'edd-custom-deliverables-send-email', 'edd-custom-deliverables-send-email', false ); ?>
	<input type="hidden" id="edd-custom-deliverables-payment-id" name="edd-custom-deliverables-payment-id" value="<?php echo esc_attr( $payment_id ); ?>">
</div>
