<?php
/**
 * Outputs the selector for what groups of files the customer should have access to.
 *
 * @since 1.1
 * @var EDD_Payment $payment The EDD Payment object.
 */

// Get which files we should show, just custom files? Just default files? Both?
$available_files = edd_custom_deliverables_get_available_files_meta( $payment );
?>

<div id="eddcd_custom_deliverables_file_chooser_wrapper">
	<p>
		<?php esc_html_e( 'Here, you can provide custom files to this customer.', 'edd-custom-deliverables' ); ?>
	</p>
	<div class="edd-form-group">
		<label for="eddcd_custom_deliverables_available_files" class="edd-form-group__label label">
			<?php esc_html_e( 'Which group(s) of files should the customer have access to?', 'edd-custom-deliverables' ); ?>
		</label>
		<div class="edd-form-group__control">
			<select id="eddcd_custom_deliverables_available_files" name="eddcd_custom_deliverables_available_files">
				<?php
				$options = array(
					''             => __( 'Both custom files (below) and default product files', 'edd-custom-deliverables' ),
					'custom_only'  => __( 'Only custom files', 'edd-custom-deliverables' ),
					'default_only' => __( 'Only default files', 'edd-custom-deliverables' ),
				);
				foreach ( $options as $value => $label ) {
					printf(
						'<option value="%1$s" %2$s>%3$s</option>',
						esc_attr( $value ),
						selected( $available_files, $value, false ),
						esc_html( $label )
					);
				}
				?>
			</select>
		</div>
	</div>
</div>
