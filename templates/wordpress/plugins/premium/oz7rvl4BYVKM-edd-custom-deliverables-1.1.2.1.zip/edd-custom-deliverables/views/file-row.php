<?php
/**
 * Outputs an individual "row" for custom deliverables for a product.
 *
 * @since 1.1
 * @var string $key      Array key
 * @var array  $args     Array of all the arguments passed to the function
 * @var int    $post_id  Download (Post) ID
 * @var int    $price_id The price ID for the file
 * @var int    $index    The index of the current row
 */
$defaults = array(
	'name'           => null,
	'file'           => null,
	'condition'      => null,
	'attachment_id'  => null,
	'thumbnail_size' => null,
);

$args = wp_parse_args( $args, $defaults );

$prices = edd_get_variable_prices( $post_id );

$variable_pricing = edd_has_variable_prices( $post_id );
$variable_display = $variable_pricing ? '' : ' style="display:none;"';
$variable_class   = $variable_pricing ? ' has-variable-pricing' : '';
?>

<div class="eddcd-repeatable-row-header eddcd-draghandle-anchor">
	<span class="eddcd-repeatable-row-title" title="<?php esc_html_e( 'Click and drag to re-order files', 'edd-custom-deliverables' ); ?>">
		<?php printf( __( '%1$s file: %2$s', 'edd-custom-deliverables' ), esc_html( edd_get_label_singular() ), '<span class="eddcd_file_id">' . esc_attr( $key ) . '</span>' ); ?>
		<input type="hidden" name="eddcd_custom_deliverables_custom_files[<?php echo esc_attr( $post_id ); ?>][<?php echo esc_attr( $price_id ); ?>][<?php echo esc_attr( $key ); ?>][index]" class="eddcd_repeatable_index" value="<?php echo esc_attr( $index ); ?>" />
	</span>
	<span class="eddcd-repeatable-row-actions">
		<button class="eddcd-remove-row edd-delete button-link" data-type="file" download-id="<?php echo esc_attr( $post_id ); ?>" price-id="<?php echo esc_attr( $price_id ); ?>">
			<?php esc_html_e( 'Remove', 'edd-custom-deliverables' ); ?>
			<span class="screen-reader-text"> <?php printf( __( 'file %s', 'edd-custom-deliverables' ), esc_attr( $key ) ); ?></span>
		</button>
	</span>
</div>

<div class="eddcd-repeatable-row-standard-fields<?php echo esc_attr( $variable_class ); ?>">

	<div class="edd-form-group eddcd-file-name">
		<label for="eddcd_custom_deliverables_custom_files-<?php echo esc_attr( $post_id ); ?>-<?php echo esc_attr( $price_id ); ?>-<?php echo esc_attr( $key ); ?>-name" class="eddcd-repeatable-row-setting-label edd-form-group__label">
			<?php esc_html_e( 'File Name', 'edd-custom-deliverables' ); ?>
		</label>
		<div class="edd-form-group__control">
			<?php
			if ( ! empty( $submission_form_id ) ) {
				?>
				<input type="hidden" data-formid="<?php echo esc_attr( $submission_form_id ); ?>" data-fieldname="<?php echo 'custom_deliverables'; ?>" name="eddcd_custom_deliverables_custom_files[<?php echo esc_attr( $post_id ); ?>][<?php echo esc_attr( $price_id ); ?>][<?php echo absint( $key ); ?>][attachment_id]" class="eddcd_repeatable_attachment_id_field" value="<?php echo esc_attr( absint( $args['attachment_id'] ) ); ?>"/>
				<?php
			}
			?>
			<input type="hidden" name="eddcd_custom_deliverables_custom_files[<?php echo esc_attr( $post_id ); ?>][<?php echo esc_attr( $price_id ); ?>][<?php echo absint( $key ); ?>][attachment_id]" class="eddcd_repeatable_attachment_id_field" value="<?php echo esc_attr( absint( $args['attachment_id'] ) ); ?>"/>
			<input type="hidden" name="eddcd_custom_deliverables_custom_files[<?php echo esc_attr( $post_id ); ?>][<?php echo esc_attr( $price_id ); ?>][<?php echo absint( $key ); ?>][thumbnail_size]" class="eddcd_repeatable_thumbnail_size_field" value="<?php echo esc_attr( $args['thumbnail_size'] ); ?>"/>
			<?php echo EDD()->html->text(
				array(
					'name'        => 'eddcd_custom_deliverables_custom_files[' . esc_attr( $post_id ) . '][' . esc_attr( $price_id ) . '][' . esc_attr( $key ) . '][name]',
					'id'          => 'eddcd_custom_deliverables_custom_files-' . esc_attr( $post_id ) . '-' . esc_attr( $price_id ) . '-' . esc_attr( $key ) . '-name',
					'value'       => esc_attr( $args['name'] ),
					'placeholder' => __( 'File Name', 'edd-custom-deliverables' ),
					'class'       => 'edd-form-group__input eddcd_repeatable_name_field large-text',
				)
			); ?>
		</div>
	</div>

	<div class="edd-form-group eddcd-file-url">
		<label for="eddcd_custom_deliverables_custom_files-<?php echo esc_attr( $post_id ); ?>-<?php echo esc_attr( $price_id ); ?>-<?php echo esc_attr( $key ); ?>-file" class="edd-form-group__label eddcd-repeatable-row-setting-label"><?php esc_html_e( 'File URL', 'edd-custom-deliverables' ); ?></label>
		<div class="edd-form-group__control eddcd_repeatable_upload_field_container">
			<?php echo EDD()->html->text(
				array(
					'name'        => 'eddcd_custom_deliverables_custom_files[' . esc_attr( $post_id ) . '][' . esc_attr( $price_id ) . '][' . esc_attr( $key ) . '][file]',
					'id'          => 'eddcd_custom_deliverables_custom_files-' . esc_attr( $post_id ) . '-' . esc_attr( $price_id ) . '-' . esc_attr( $key ) . '-file',
					'value'       => esc_attr( $args['file'] ),
					'placeholder' => __( 'Upload or enter the file URL', 'edd-custom-deliverables' ),
					'class'       => 'edd-form-group__input eddcd_repeatable_upload_field eddcd_upload_field large-text',
				)
			); ?>

			<span class="eddcd_upload_file">
				<button class="eddcd_upload_file_button">
					<span class="dashicons dashicons-admin-links"></span>
					<span class="screen-reader-text"><?php esc_html_e( 'Upload a File', 'edd-custom-deliverables' ); ?></span>
				</button>
			</span>
		</div>
	</div>

	<?php do_action( 'edd_custom_deliverables_download_file_table_row', $post_id, $price_id, $key, $args ); ?>

</div>
