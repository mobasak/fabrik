<div class="edd-custom-deliverables-email-logs-wrapper">
	<h3><?php esc_html_e( 'Email Logs', 'edd-custom-deliverables' ); ?></h3>
	<?php
	$logs   = new EDD\Database\Queries\LogEmail();
	$emails = $logs->query(
		array(
			'object_id'   => $order_id,
			'object_type' => 'order',
			'email_id'    => 'custom_deliverable',
		)
	);
	if ( empty( $emails ) ) {
		esc_html_e( 'No emails have been sent for this order.', 'edd-custom-deliverables' );
	} else {
		?>
		<table class="widefat">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Email', 'edd-custom-deliverables' ); ?></th>
					<th><?php esc_html_e( 'Subject', 'edd-custom-deliverables' ); ?></th>
					<th><?php esc_html_e( 'Sent', 'edd-custom-deliverables' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $emails as $email ) {
					?>
					<tr class="edd-custom-deliverables-email-log">
						<td>
							<?php echo esc_html( $email->email ); ?>
						</td>
						<td>
							<?php echo esc_html( $email->subject ); ?>
						</td>
						<td>
							<?php
							echo esc_html( edd_date_i18n( strtotime( $email->date_created ), get_option( 'date_format' ) ) );
							echo '<br />';
							echo esc_html( edd_date_i18n( strtotime( $email->date_created ), get_option( 'time_format' ) ) );
							?>
						</td>
					</tr>
					<?php
				}
				?>
			</tbody>
		</table>
		<?php
	}
	?>
</div>
