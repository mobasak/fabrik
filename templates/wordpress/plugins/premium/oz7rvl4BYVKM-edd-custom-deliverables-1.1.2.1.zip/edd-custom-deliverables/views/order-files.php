<?php
/**
 * @var int         $payment_id          ID of the payment.
 * @var EDD_Payment $payment             Payment object.
 * @var array       $custom_deliverables Customized deliverable files for this payment.
 * @var array       $fulfilled_jobs      Fulfilled jobs in this payment.
 * @var int         $user_id             Current user (defined only by FES).
 * @var FES_Vendor  $vendor              The FES Vendor (defined only by FES).
 */

// If there are cart details and purchased items
if ( empty( $payment->cart_details ) ) {
	return;
}

// Loop through those purchased items
foreach ( $payment->cart_details as $cart_key => $cart_item ) {
	if ( ! isset( $cart_item['id'] ) || edd_is_bundled_product( $cart_item['id'] ) ) {
		continue;
	}

	// Get the download if of this purchased product
	$download_id = $cart_item['id'];

	// For FES, check if the current user can add files to this product.
	if ( ! empty( $vendor ) && ! edd_custom_deliverables_current_user_can_upload_deliverables( $download_id ) ) {
		continue;
	}
	$download        = new EDD_Download( $download_id );
	$variable_prices = $download->prices;
	$price_id        = 0;
	if ( isset( $cart_item['item_number']['options']['price_id'] ) && is_numeric( $cart_item['item_number']['options']['price_id'] ) ) {
		$price_id = $cart_item['item_number']['options']['price_id'];
	}
	?>
	<div id="edd-custom-deliverables-files-<?php echo intval( $download_id ); ?>-<?php echo intval( $price_id ); ?>">
		<h3 class="eddcd-purchased-download-title">
			<?php
			$product_name = isset( $variable_prices[ $price_id ]['name'] ) ? $cart_item['name'] . ' - ' . $variable_prices[ $price_id ]['name'] : $cart_item['name'];
			/* translators: the product name. */
			printf( esc_html__( 'Customized files for "%s"', 'edd-custom-deliverables' ), esc_html( $product_name ) );
			?>
		</h3>

		<div class="eddcd-file-fields eddcd-repeatables-wrap">
			<?php

			// Get the custom files attached to this payment for this product
			$custom_download_files = isset( $custom_deliverables[ $download_id ][ $price_id ] ) ? $custom_deliverables[ $download_id ][ $price_id ] : array();

			if ( ! empty( $custom_download_files ) && is_array( $custom_download_files ) ) {
				// Loop through the default files
				foreach ( $custom_download_files as $key => $value ) {

					// Remove our prefix of eddcd_ just for these fields while showing them
					$key = str_replace( 'eddcd_', '', $key );

					$index          = isset( $value['index'] ) ? $value['index'] : $key;
					$name           = isset( $value['name'] ) ? $value['name'] : '';
					$file           = isset( $value['file'] ) ? $value['file'] : '';
					$condition      = isset( $value['condition'] ) ? $value['condition'] : false;
					$attachment_id  = isset( $value['attachment_id'] ) ? absint( $value['attachment_id'] ) : false;
					$thumbnail_size = isset( $value['thumbnail_size'] ) ? $value['thumbnail_size'] : '';

					$args = apply_filters( 'edd_file_row_args', compact( 'name', 'file', 'condition', 'attachment_id', 'thumbnail_size' ), $value );
					?>
					<div class="eddcd_repeatable_upload_wrapper eddcd_repeatable_row" data-key="<?php echo esc_attr( $key ); ?>">
						<?php $this->edd_render_file_row( $key, $args, $download_id, $price_id, $index ); ?>
					</div>

					<?php
				}
			} else {
				?>
				<div class="eddcd_repeatable_upload_wrapper eddcd_repeatable_row">
					<?php $this->edd_render_file_row( 1, array(), $download_id, $price_id, 0 ); ?>
				</div>
				<?php
			}
			?>
			<div class="eddcd-action-buttons">
				<div class="eddcd-add-repeatable-row">
					<button
						class="button button-secondary eddcd_add_repeatable"
						data-download-id="<?php echo esc_attr( $download_id ); ?>"
						data-price-id="<?php echo esc_attr( $price_id ); ?>"
					>
					<?php esc_html_e( 'Add New File', 'edd-custom-deliverables' ); ?>
					</button>
				</div>
				<?php
				// If this job has not been fulfilled, output the button to fulfill it
				if ( ! isset( $fulfilled_jobs[ $download_id ][ $price_id ] ) ) {
					EDD_Custom_Deliverables::$edd_custom_deliverables_metabox->render_unfulfilled_job( $download_id, $price_id );
				} else {
					EDD_Custom_Deliverables::$edd_custom_deliverables_metabox->render_fulfilled_job( $download_id, $price_id );
				}
				?>
			</div>
		</div>
	</div>
	<?php
}
