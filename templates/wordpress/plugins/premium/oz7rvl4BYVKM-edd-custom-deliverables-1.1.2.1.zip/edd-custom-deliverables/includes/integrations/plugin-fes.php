<?php
/**
 * Integration functions to make Custom Deliverables compatible with EDD Frontend Submissions
 *
 * @package     EDD\EDDCustomDeliverables\Functions
 * @since       1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Integrates EDD Custom Deliverables with the EDD Frontend Submissions extension
 *
 * @since 1.0.0
 */
class EDD_Custom_Deliverables_Fes {

	/**
	 * Get things started
	 *
	 * @since  1.0.0
	 * @return void
	 */
	public function __construct() {

		if ( ! class_exists( 'EDD_Front_End_Submissions' ) ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_enqueue_scripts' ) );
		add_action( 'fes_below_vendor_receipt', array( $this, 'add_custom_deliverables_fields_to_order_edit_screen' ) );
		add_action( 'edd_add_email_tags', array( $this, 'add_email_tag' ), 100 );
		add_action( 'wp_ajax_edd_custom_deliverables_send_fes_email_ajax', array( $this, 'send_fes_email_ajax' ) );
		add_filter( 'edd_registered_settings', array( $this, 'email_settings' ), 99 );
	}

	/**
	 * Enqueue front-end assets.
	 *
	 * @return void
	 */
	public function frontend_enqueue_scripts() {
		// If we aren't on the "Edit Order" screen, don't enqueue these
		if ( ! isset( $_GET['task'] ) || 'edit-order' !== $_GET['task'] ) {
			return;
		}

		wp_enqueue_script( 'edd_custom_deliverables_fes_js', EDD_CUSTOM_DELIVERABLES_URL . 'assets/build/js/eddcd-fes-integration.js', array( 'jquery', 'jquery-ui-sortable' ), EDD_CUSTOM_DELIVERABLES_VER, true );

		wp_localize_script(
			'edd_custom_deliverables_fes_js',
			'edd_custom_deliverables_fes_vars',
			array(
				'save_payment_text' => '<h3>' . __( 'Notify Customer', 'edd-custom-deliverables' ) . '</h3><p>' . __( 'Since you have just modified the files, save the payment before notifying the customer. After saving, a notification tool will appear here.', 'edd-custom-deliverables' ) . '</p>',
			)
		);

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'edd_custom_deliverables_fes_css', EDD_CUSTOM_DELIVERABLES_URL . 'assets/build/css/eddcd-fes-integration.css', array( 'dashicons' ), EDD_CUSTOM_DELIVERABLES_VER );
	}

	public function add_custom_deliverables_fields_to_order_edit_screen() {

		// If we are looking at the order_id screen in FES, get out o here.
		if ( ! isset( $_GET['order_id'] ) ) {
			return;
		}

		// Get the product ID from the $_GET['order_id']
		$payment_id = absint( $_GET['order_id'] );
		$payment    = new EDD_Payment( $payment_id );

		if ( ! edd_custom_deliverables_payment_has_eligible_items( $payment ) ) {
			return;
		}

		// Get our array of customized deliverable files for this payment
		$custom_deliverables = edd_custom_deliverables_get_custom_files_meta( $payment );

		// Get the array of fulfilled jobs in this payment
		$fulfilled_jobs = edd_custom_deliverables_get_fulfilled_jobs_meta( $payment );

		// Check if Custom Deliverables form data was just updated. If so, run the save function
		if ( isset( $_POST['eddcd_fes_save_field'] ) ) {
			if ( wp_verify_nonce( $_POST['eddcd_fes_save_field'], 'eddcd_fes_save' ) ) {

				// Check if this user has permissions to update payments/orders
				if ( current_user_can( 'edit_shop_payments' ) || ( function_exists( 'EDD_FES' ) && EDD_FES()->vendors->vendor_is_vendor() ) ) {

					$custom_deliverables = $this->save_edited_fes_order( $payment, $custom_deliverables );
				}
			}
		}

		// Set up the Vendor Object
		$user_id = get_current_user_id();
		$vendor  = new FES_Vendor( $user_id, true );

		//Output the title for the Custom Deliverables section
		?>
		<h3><?php echo esc_html( apply_filters( 'edd_custom_deliverables_fes_payment_receipt_title', __( 'Custom Deliverables', 'edd-custom-deliverables' ) ) ); ?></h3>

		<form id="edd-custom-deliverables-fes-order-form" method="POST" class="fes-fields">
		<?php

		include EDD_CUSTOM_DELIVERABLES_DIR . 'views/order-files.php';

		if ( current_user_can( 'edit_shop_payments' ) || ( function_exists( 'EDD_FES' ) && EDD_FES()->vendors->vendor_is_vendor() ) ) {

			wp_nonce_field( 'eddcd_fes_save', 'eddcd_fes_save_field' );

			?>
			<input type="submit" id="eddcd_fes_submit" value="<?php esc_html_e( 'Save Custom Deliverables', 'edd-custom-deliverables' ); ?>">
			<?php
		}
		?>
		</form>

		<?php
		EDD_Custom_Deliverables::$edd_custom_deliverables_metabox->render_notify_customer(
			$payment_id,
			__( 'If you\'d like to send an email to the customer to let them know their customized files are ready to download, you can do so below. ', 'edd-custom-deliverables' ),
			'edd_custom_deliverables_send_fes_email_ajax'
		);
	}

	/**
	 * Individual file row.
	 *
	 * Used to output a table row for each file associated with a download.
	 *
	 * @since 1.0.0
	 * @since 1.1 updated to use the file-row view.
	 * @param string $key      Array key
	 * @param array  $args     Array of all the arguments passed to the function
	 * @param int    $post_id  Download (Post) ID
	 * @param int    $price_id The price ID for the file
	 * @param int    $index    The index of the current row
	 * @return void
	 */
	public function edd_render_file_row( $key, $args, $post_id, $price_id, $index ) {
		$fes_helpers        = new FES_Helpers();
		$submission_form_id = $fes_helpers->get_form_id_by_name( 'submission' );
		include EDD_CUSTOM_DELIVERABLES_DIR . 'views/file-row.php';
	}

	/**
	 * Save the post meta payment when saving/updating an FES order
	 *
	 * @since 1.0.0
	 * @param $payment_id
	 *
	 * @return void
	 */
	public function save_edited_fes_order( $payment, $custom_deliverables ) {

		// Check if Custom Deliverables form data was just updated. If so, run the save function
		if ( ! wp_verify_nonce( $_POST['eddcd_fes_save_field'], 'eddcd_fes_save' ) ) {
			return $custom_deliverables;
		}

		if ( ! EDD_FES()->vendors->vendor_is_vendor() ) {
			return $custom_deliverables;
		}

		if ( ! isset( $_POST['eddcd_custom_deliverables_custom_files'] ) ) {
			return;
		}

		if ( empty( $custom_deliverables ) ) {
			$custom_deliverables = array();
		}

		// Get the files being saved as custom deliverables for this payment
		$products = $_POST['eddcd_custom_deliverables_custom_files'];

		$sanitized_values = array();

		// Loop through each product whose files are being saved
		foreach ( $products as $product_id => $custom_download_files ) {

			// If this product is not one from this Vendor, skip it. We won't allow vendors to upload custom deliverables for products they didn't create.
			if ( ! edd_custom_deliverables_current_user_can_upload_deliverables( $product_id ) ) {
				continue;
			}

			// Loop through each file within this product being saved
			foreach ( $custom_download_files as $price_id => $files ) {

				// Loop through each piece of file data so we can sanitize it
				foreach ( $files as $file_key => $file_data ) {

					$single_file = edd_cd_sanitize_single_file( $file_data );
					if ( empty( $single_file ) ) {
						unset( $custom_deliverables[ $product_id ][ $price_id ][ $file_key ] );
						continue;
					}

					//Append eddcd_ to the file key if needed
					$file_key = strpos( $file_key, 'eddcd_' ) !== false ? $file_key : 'eddcd_' . $file_key;

					$sanitized_values[ $product_id ][ $price_id ][ $file_key ] = $single_file;
				}
			}

			if ( empty( $sanitized_values[ $product_id ] ) ) {
				unset( $custom_deliverables[ $product_id ] );
			}
		}

		// Now that we have sanitized all of the custom deliverables for this Vendor,
		// add in any other customer deliverables for products that belong to other vendors as well.
		if ( ! empty( $payment->cart_details ) ) {

			// Loop through those purchased items
			foreach ( $payment->cart_details as $cart_key => $cart_item ) {

				// Get the download if of this purchased product
				$product_id = $cart_item['id'];

				// Loop through each sanitized value
				foreach ( $sanitized_values as $sanitized_product_id => $sanitized_custom_deliverables_data ) {

					// If the product id matches the one we sanitized from this vendor, replace the old value with the new one. Otherwise we don't touch them.
					// This is how we prevent Vendors from uploading customized deliverables for products they didn't create.
					if ( $product_id == $sanitized_product_id ) {
						$custom_deliverables[ $product_id ] = $sanitized_custom_deliverables_data;
					}
				}
			}
		} else {
			$custom_deliverables = $sanitized_values;
		}

		$sanitized_values = apply_filters( 'edd_custom_deliverables_pre_files_save', $custom_deliverables, $payment->ID );

		$payment->update_meta( '_eddcd_custom_deliverables_custom_files', $sanitized_values );

		return $sanitized_values;
	}

	/**
	 * Register the {custom_download_list} email tag
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function add_email_tag() {

		edd_add_email_tag( 'custom_download_list', __( 'Show custom files added for the customer.', 'edd-custom-deliverables' ), array( $this, 'custom_download_list_tag' ) );
	}

	/**
	 * Output a UL of the custom files provided by the Vendor
	 *
	 * @since 1.0.0
	 * @since 1.1 Updated to use `edd_custom_deliverables_email_tag_download_list`.
	 * @param int    $payment_id The payment ID.
	 * @param string $tag        The email tag.
	 *
	 * @return string
	 */
	public function custom_download_list_tag( $payment_id, $tag ) {
		return edd_custom_deliverables_email_tag_download_list( $payment_id, 'custom_download_list' );
	}

	/**
	 * Send the default email for FES and Custom Deliverables letting the customer know their files are ready.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function send_fes_email_ajax() {
		$result = edd_custom_deliverables_email_customer(
			$_POST,
			edd_get_option( 'custom_deliverables_fes_subject', __( 'Your files are ready!', 'edd-custom-deliverables' ) ),
			edd_get_option( 'custom_deliverables_fes_email', $this->default_email_message() )
		);

		if ( is_wp_error( $result ) ) {
			/** @var WP_Error $result */
			wp_send_json_error(
				array(
					'failure_code'    => $result->get_error_code(),
					'failure_message' => $result->get_error_message(),
				)
			);
		}

		wp_send_json_success(
			array(
				'success_code'    => 'email_successfully_sent',
				'success_message' => __( 'Email successfully sent.', 'edd-custom-deliverables' ),
			)
		);
	}

	/**
	 * Set up the default message for the global FES custom deliverables email.
	 *
	 * @since      1.0
	 * @see        edd_custom_deliverables_default_email_message()
	 *
	 * @return string
	 */
	public function default_email_message() {
		return __(
			'Dear {name},

	Your files are ready to download for your order {payment_id}.
	You can download them here: {custom_download_list}',
			'edd-custom-deliverables'
		);
	}

	/**
	 * Display the FES email settings for Custom Deliverables under the FES > Emails tab.
	 *
	 * @since 1.0
	 * @param $settings
	 *
	 * @return array
	 */
	public function email_settings( $settings ) {

		if ( ! isset( $settings['fes'] ) ) {
			return $settings;
		}

		$settings['fes']['emails']['edd_custom_deliverables_fes_emails_header'] = array(
			'id'   => 'edd_custom_deliverables_emails_header',
			'name' => '<strong>' . __( 'Custom Deliverables Emails', 'edd-custom-deliverables' ) . '</strong>',
			'desc' => '',
			'type' => 'header',
			'size' => 'regular',
		);
		$settings['fes']['emails']['custom_deliverables_fes_subject']           = array(
			'id'          => 'custom_deliverables_fes_subject',
			'name'        => __( 'Email Subject Line', 'edd-custom-deliverables' ),
			'desc'        => __( 'The subject line used when sending a notification to customers that their customized files are ready to download.', 'edd-custom-deliverables' ),
			'type'        => 'text',
			'allow_blank' => false,
			'std'         => __( 'Your files are ready!', 'edd-custom-deliverables' ),
		);
		$settings['fes']['emails']['custom_deliverables_fes_email']             = array(
			'id'          => 'custom_deliverables_fes_email',
			'name'        => __( 'Email', 'edd-custom-deliverables' ),
			'desc'        => __( 'Enter the text that is used when sending a notification to customers that their files are ready. HTML is accepted. Available template tags:', 'edd-custom-deliverables' ) . '<br/>' . edd_get_emails_tags_list(),
			'type'        => 'rich_editor',
			'allow_blank' => false,
			'std'         => $this->default_email_message(),
		);

		return $settings;
	}
}
