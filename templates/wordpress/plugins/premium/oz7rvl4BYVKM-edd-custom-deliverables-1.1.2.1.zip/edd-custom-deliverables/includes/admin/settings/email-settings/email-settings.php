<?php
/**
* Helper Functions
*
* @package     EDD\EDDAllAccess\Functions
* @since       1.0.0
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( '\\EDD\\Emails\\Email' ) ) {
	add_filter( 'edd_settings_sections_emails', 'edd_custom_deliverables_settings_sections_emails' );
	add_filter( 'edd_settings_emails', 'edd_custom_deliverables_email_settings' );
}

/**
 * Add Custom Deliverables settings tab to EDD email settings page
 *
 * @since 1.0
 * @param $sections
 * @return void
 */
function edd_custom_deliverables_settings_sections_emails( $sections ) {
	$sections['edd-custom-deliverables-emails'] = __( 'Custom Deliverables', 'edd-custom-deliverables' );
	return $sections;
}

/**
 * Display the email settings for Custom Deliverables
 *
 * @since 1.0
 * @param $settings
 *
 * @return array
 */
function edd_custom_deliverables_email_settings( $settings ) {
	$rich_text_description = __( 'Enter the text that is used when sending a notification to customers that their files are ready. HTML is accepted.', 'edd-custom-deliverables' );
	if ( ! function_exists( 'edd_get_orders' ) ) {
		$rich_text_description .= ' ' . __( 'Available template tags:', 'edd-custom-deliverables' ) . '<br/>' . edd_get_emails_tags_list();
	}
	$custom_deliverables_email_settings = array(
		array(
			'id'          => 'custom_deliverables_email_subject',
			'name'        => __( 'Email Subject Line', 'edd-custom-deliverables' ),
			'desc'        => __( 'The subject line used when sending a notification to customers that their customized files are ready to download.', 'edd-custom-deliverables' ),
			'type'        => 'text',
			'allow_blank' => false,
			'std'         => __( 'Your files are ready!', 'edd-custom-deliverables' ),
		),
		array(
			'id'          => 'custom_deliverables_email_body',
			'name'        => __( 'Email', 'edd-custom-deliverables' ),
			'desc'        => $rich_text_description,
			'type'        => 'rich_editor',
			'allow_blank' => false,
			'std'         => edd_custom_deliverables_default_email_message(),
		),
	);

	return array_merge( $settings, array( 'edd-custom-deliverables-emails' => $custom_deliverables_email_settings ) );
}

/**
 * Set up the default message for the global custom deliverables email.
 *
 * @since 1.0
 *
 * @return string
 */
function edd_custom_deliverables_default_email_message() {

	return __(
		'Dear {name},

Your files are ready to download for your order {payment_id}.
You can download them here: {download_list}',
		'edd-custom-deliverables'
	);
}
