<?php
/**
 * upgrades.php
 *
 * @package   edd-custom-deliverables
 * @copyright Copyright (c) 2021, Sandhills Development, LLC
 * @license   GPL2+
 * @since     1.0.4
 */

/**
 * During the EDD 3.0 migration we need to move our custom file ID string to
 * file download meta.
 *
 * @since 1.0.4
 *
 * @param int    $log_id   ID of the newly inserted log.
 * @param object $log_data Log data from the wp_posts table.
 * @param array  $log_meta All log meta from 2.x.
 */
add_action( 'edd_30_migrate_file_download_log', function ( $log_id, $log_data, $log_meta ) {
	if ( empty( $log_meta['_edd_log_file_id'] ) || false === strpos( $log_meta['_edd_log_file_id'], 'eddcd_' ) ) {
		return;
	}

	edd_add_file_download_log_meta( $log_id, 'custom_deliverable', sanitize_text_field( $log_meta['_edd_log_file_id'] ) );
}, 10, 3 );
