<?php

/**
 * Class EDD_Custom_Deliverables_MetaBox
 * @since 1.0.0
 * Hooks, filters, and methods for the data required for Custom Deliverables
 */
class EDD_Custom_Deliverables_MetaBox {

	/**
	 * Load up all the hooks
	 *
	 * @since 1.0.0
	 *
	 * @return false;
	 */
	public function __construct() {
		add_action( 'edd_view_order_details_billing_after', array( $this, 'custom_files_in_payment' ) );
		add_action( 'edd_updated_edited_purchase',          array( $this, 'save_edited_payment' ), 10, 1 );
	}

	/**
	 * Renders the button to mark a job as fulfilled.
	 *
	 * @internal
	 * @since 1.1
	 *
	 * @param int $download_id
	 * @param int $price_id
	 *
	 * @return void
	 */
	public function render_unfulfilled_job( $download_id, $price_id ) {
		?>
		<div class="eddcd_unfulfilled_message_box eddcd_fulfillment_status">
			<button
				class="button button-secondary eddcd-fulfillment-button eddcd-fulfill-order-btn"
				data-download-id="<?php echo esc_attr( intval( $download_id ) ); ?>"
				data-price-id="<?php echo esc_attr( intval( $price_id ) ); ?>"
				data-nonce-id="edd-custom-deliverables-mark-as-fulfilled"
				data-action="edd_custom_deliverables_mark_as_fulfilled"
			>
				<?php esc_html_e( 'Mark job as fulfilled', 'edd-custom-deliverables' ); ?>
			</button>
			<?php wp_nonce_field( 'edd-custom-deliverables-mark-as-fulfilled', 'edd-custom-deliverables-mark-as-fulfilled', false ); ?>
		</div>
		<?php
	}

	/**
	 * Renders the markup for a fulfilled job.
	 *
	 * @internal
	 * @since 1.1
	 *
	 * @param int $download_id
	 * @param int $price_id
	 *
	 * @return void
	 */
	public function render_fulfilled_job( $download_id, $price_id ) {
		$user = wp_get_current_user();
		?>
		<div class="eddcd_fulfilled_message_box eddcd_fulfillment_status">
			<button
				class="button button-secondary eddcd-fulfillment-button eddcd-mark-not-fulfilled"
				data-download-id="<?php echo esc_attr( intval( $download_id ) ); ?>"
				data-price-id="<?php echo esc_attr( intval( $price_id ) ); ?>"
				data-nonce-id="edd-custom-deliverables-mark-as-not-fulfilled"
				data-action="edd_custom_deliverables_mark_as_not_fulfilled"
			>
				<?php esc_html_e( 'Mark as not fulfilled', 'edd-custom-deliverables' ); ?>
			</button>
			<?php wp_nonce_field( 'edd-custom-deliverables-mark-as-not-fulfilled', 'edd-custom-deliverables-mark-as-not-fulfilled', false ); ?>
		</div>
		<div class="eddcd-fulfilled-message">
			<p>
				<?php
				printf(
				/* Translators: %1$s date; %2$s user's display name */
					esc_html__( 'Fulfilled on %1$s by %2$s', 'edd_custom_deliverables' ),
					date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) ),
					esc_html( $user->display_name )
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Renders the HTML to email the customer that their files are ready.
	 *
	 * @since 1.1
	 *
	 * @param int         $payment_id  ID of the payment.
	 * @param string|null $description Description to override the default.
	 * @param string      $action      Ajax callback action.
	 *
	 * @return void
	 */
	public function render_notify_customer( $payment_id, $description = null, $action = 'edd_custom_deliverables_send_email_ajax' ) {
		include EDD_CUSTOM_DELIVERABLES_DIR . 'views/order-notification.php';
	}

	/**
	 * Show the Custom Deliverables metabox on the view order details
	 *
	 * @since 1.0.0
	 * @param $payment_id
	 *
	 * @return void
	 */
	public function custom_files_in_payment( $payment_id ) {

		$payment = new EDD_Payment( $payment_id );
		if ( ! edd_custom_deliverables_payment_has_eligible_items( $payment ) ) {
			return;
		}

		// Get our array of customized deliverable files for this payment
		$custom_deliverables = edd_custom_deliverables_get_custom_files_meta( $payment );

		// Get the array of fulfilled jobs in this payment
		$fulfilled_jobs = edd_custom_deliverables_get_fulfilled_jobs_meta( $payment );

		?>
		<div id="edd-custom-deliverables" class="postbox">
			<h2 class="hndle"><?php esc_html_e( 'Custom Deliverables', 'edd-custom-deliverables' ); ?></h2>
			<div class="inside">
				<div class="edd-admin-box">
					<div class="edd-custom-deliverables-files-area-wrapper edd-admin-box-inside">
						<?php
						include EDD_CUSTOM_DELIVERABLES_DIR . 'views/order-chooser.php';
						?>
						<div id="eddcd_custom_deliverables_custom_files_wrapper">
							<div id="eddcd_file_fields" class="eddcd_meta_table_wrap">
								<div class="widefat eddcd_repeatable_table">
									<div class="eddcd-custom-deliverables-products eddcd-repeatables-wrap">
										<?php
										include EDD_CUSTOM_DELIVERABLES_DIR . 'views/order-files.php';
										do_action( 'edd_custom_deliverables_after_files_area', $payment );
										?>
									</div>
								</div>
							</div>
						</div>
						<?php
						$this->render_notify_customer( $payment_id );
						$this->render_logs( $payment_id );
						?>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Individual file row.
	 *
	 * Used to output a table row for each file associated with a download.
	 *
	 * @since 1.0.0
	 * @param string $key Array key
	 * @param array $args Array of all the arguments passed to the function
	 * @param int $post_id Download (Post) ID
	 * @return void
	 */
	public function edd_render_file_row( $key, $args, $post_id, $price_id, $index ) {
		include EDD_CUSTOM_DELIVERABLES_DIR . 'views/file-row.php';
	}

	/**
	 * Save the post meta for the order details when modifying the attached files
	 *
	 * @since 1.0.0
	 * @param $payment_id
	 *
	 * @return void
	 */
	public function save_edited_payment( $payment_id ) {

		// Get the setting for which files should be shown to the customer
		$available_files = isset( $_POST['eddcd_custom_deliverables_available_files'] ) ? sanitize_text_field( $_POST['eddcd_custom_deliverables_available_files'] ) : null;

		if ( null === $available_files ) {
			return;
		}

		// Save the setting
		if ( ! empty( $available_files ) ) {
			edd_update_payment_meta( $payment_id, '_eddcd_custom_deliverables_available_files', $available_files );
		} else {
			$payment = edd_get_payment( $payment_id );
			if ( $payment ) {
				$payment->delete_meta( '_eddcd_custom_deliverables_available_files' );
			}
		}

		// Get the files being saved as custom deliverables for this payment
		$products = $_POST['eddcd_custom_deliverables_custom_files'];

		$sanitized_values = array();

		// Loop through each product whose files are being saved
		foreach ( $products as $product_id => $custom_download_files ) {

			// Loop through each file within this product being saved
			foreach( $custom_download_files as $price_id => $files ){

				// Loop through each piece of file data so we can sanitize it
				foreach ( $files as $file_key => $file_data ) {

					$single_file = edd_cd_sanitize_single_file( $file_data );
					if ( empty( $single_file ) ) {
						continue;
					}

					//Append eddcd_ to the file key if needed
					$file_key = strpos( $file_key, 'eddcd_' ) !== false ? $file_key : 'eddcd_' . $file_key;

					$sanitized_values[ $product_id ][ $price_id ][ $file_key ] = $single_file;
				}
			}
		}

		edd_update_payment_meta( $payment_id, '_eddcd_custom_deliverables_custom_files', $sanitized_values );
	}

	/**
	 * Render the logs for the order in EDD 3.3.0.
	 *
	 * @since 1.1.1
	 * @param $order_id The order ID.
	 */
	private function render_logs( $order_id ) {
		if ( ! class_exists( '\\EDD\\Emails\\Email' ) ) {
			return;
		}
		include EDD_CUSTOM_DELIVERABLES_DIR . 'views/order-logs.php';
	}
}
