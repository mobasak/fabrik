<?php
/**
 * Helper Functions
 *
 * @package     EDD\EDDCustomDeliverables\Functions
 * @since       1.0.0
 */


// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

/**
 * When the customer is viewing the custom deliverables, this is the function which makes sure they see the correct files.
 *
 * @since 1.0.0
 * @param EDD_Payment $payment         The payment object.
 * @param int         $download_id     The current download ID.
 * @param bool|int    $price_id        The current price ID.
 * @param array       $download_files  The original download files.
 *
 * @return array
 */
function edd_custom_deliverables_get_download_files( $payment, $download_id, $price_id, $download_files ) {

	// Get which files we should show, just custom files? Just default files? Both?
	$available_files = edd_custom_deliverables_get_available_files_meta( $payment );

	// If returning only default files, just return them.
	if ( 'default_only' === $available_files ) {
		return $download_files;
	}

	// Get our array of customized deliverable files for this payment
	$custom_deliverables = edd_custom_deliverables_get_custom_files_meta( $payment );

	// If this is a single price product, use 0 as the key
	if ( empty( $price_id ) ) {
		$price_id = 0;
	}

	// If returning only custom files, return them (or an empty array).
	if ( 'custom_only' === $available_files ) {
		return isset( $custom_deliverables[ $download_id ][ $price_id ] ) ? $custom_deliverables[ $download_id ][ $price_id ] : array();
	}

	// If no custom deliverables exist, return the original files.
	if ( empty( $custom_deliverables ) ) {
		return $download_files;
	}

	if ( ! is_array( $download_files ) ) {
		$download_files = (array) $download_files;
	}

	// Look through the custom deliverables and combine with the original files if possible.
	if ( isset( $custom_deliverables[ $download_id ][ $price_id ] ) && is_array( $custom_deliverables[ $download_id ][ $price_id ] ) ) {
		foreach ( $custom_deliverables[ $download_id ][ $price_id ] as $file_key => $custom_file_data ) {
			if ( ! empty( $custom_file_data['file'] ) ) {
				$download_files[ $file_key ] = $custom_file_data;
			}
		}
	}

	return $download_files;
}

/**
 * This function retrieves the custom deliverables from the payment and runs them through a filter.
 * Anywhere you retrieve custom deliverables payment meta, you should do it using this function.
 *
 * @since 1.0.0
 * @param $payment
 *
 * @return array
 */
function edd_custom_deliverables_get_custom_files_meta( $payment ) {

	$custom_deliverables = array();
	if ( $payment instanceof EDD_Payment ) {
		// Get the custom files meta from the database
		$custom_deliverables = $payment->get_meta( '_eddcd_custom_deliverables_custom_files', true );
	}

	// Filter those
	return apply_filters( 'eddcd_custom_deliverables_custom_files', $custom_deliverables, $payment );

}

/**
 * This function retrieves the available files setting from the payment and runs them through a filter.
 * Anywhere you retrieve available files payment meta, you should do it using this function.
 *
 * @since 1.0.0
 * @param $payment
 *
 * @return string
 */
function edd_custom_deliverables_get_available_files_meta( $payment ){

	// Get the available files meta from the database
	$available_files = $payment->get_meta( '_eddcd_custom_deliverables_available_files', true );

	// Filter it
	return apply_filters( 'eddcd_custom_deliverables_available_files', $available_files, $payment );

}

/**
 * This function retrieves the fulfilles jobs setting from the payment and runs them through a filter.
 * Anywhere you retrieve fulfilled jobs payment meta, you should do it using this function.
 *
 * @since 1.0.0
 * @param $payment
 *
 * @return array
 */
function edd_custom_deliverables_get_fulfilled_jobs_meta( $payment ){

	// Get the custom files meta from the database
	$fulfilled_jobs = $payment->get_meta( '_eddcd_custom_deliverables_fulfilled_jobs', true );

	// Filter those
	return apply_filters( 'eddcd_custom_deliverables_fulfilled_jobs', $fulfilled_jobs, $payment );

}

/**
 * This function will delete all uploaded custom deliverables which are attached to a payment.
 * Note that it deletes the actual files, and the references to them.
 *
 * @since 1.0.2
 * @param EDD_Payment|int $payment
 *
 * @return void
 */
function edd_custom_deliverables_delete_all_custom_deliverables_for_payment( $payment_id_or_payment_object ){

	$payment = is_numeric( $payment_id_or_payment_object ) ? edd_get_payment( $payment_id_or_payment_object ) : $payment_id_or_payment_object;

	if ( ! $payment ) {
		return;
	}

	// Get our array of customized deliverable files for this payment
	$custom_deliverables = edd_custom_deliverables_get_custom_files_meta( $payment );

	if ( empty( $custom_deliverables ) ) {
		return;
	}

	foreach ( $custom_deliverables as $download_id => $price_ids_and_files ) {
		foreach ( $price_ids_and_files as $price_id => $files ) {
			foreach ( $files as $file_key => $custom_file_data ){

				$wp_attachment_metadata = get_post_meta( $custom_file_data['attachment_id'], '_wp_attachment_metadata', true );

				// Delete each variation of this attachment, which are stored in the attachment meta
				if ( is_array( $wp_attachment_metadata ) ) {
					foreach ( $wp_attachment_metadata as $attachment_variations ) {
						if ( is_array( $attachment_variations ) ) {
							foreach ( $attachment_variations as $attachment_variation ) {
								if ( isset( $attachment_variation['file'] ) ) {
									wp_delete_file( $attachment_variation['file'] );
								}
							}
						}
					}
				}

				// Now we can delete the attachment itself
				wp_delete_attachment( $custom_file_data['attachment_id'], true );

				// Remove this file from the custom deliverables array as well
				unset( $custom_deliverables[ $download_id ][ $price_id ][ $file_key ] );
			}
		}
	}

	// Save the updated files array
	edd_update_payment_meta( $payment->ID, '_eddcd_custom_deliverables_custom_files', $custom_deliverables );
}

/**
 * Determines whether the current user can update the fulfillment status on the provided order.
 *
 * @since 1.1
 *
 * @param int $order_id ID of the order to check.
 *
 * @return bool
 */
function edd_custom_deliverables_current_user_can_update_fulfillment( $order_id ) {
	if ( current_user_can( 'edit_shop_payments' ) ) {
		return true;
	}

	if ( ! class_exists( 'EDD_Front_End_Submissions' ) ) {
		return false;
	}

	/**
	 * FES integration below.
	 *
	 * @see FES_Vendors::vendor_can_view_order()
	 * We can't use the above method directly because at one point it looks for the order ID
	 * in `$_GET`, which is annoying. So we're mostly just rebuilding that logic here.
	 */

	// If Vendors aren't allowed to view orders, then bail.
	if ( ! EDD_FES()->helper->get_option( 'fes-allow-vendors-to-view-orders' ) ) {
		return false;
	}

	// If the current user isn't even a vendor at all, bail.
	if ( ! EDD_FES()->vendors->user_is_vendor( get_current_user_id() ) ) {
		return false;
	}

	// Check if the current vendor is the "author" of at least one of the products in the cart.
	$cart = edd_get_payment_meta_cart_details( $order_id );

	foreach ( $cart as $product ) {
		if ( empty( $product['id'] ) ) {
			continue;
		}

		if ( edd_custom_deliverables_current_user_can_upload_deliverables( $product['id'] ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Whether a payment has items which can have custom files assigned.
 *
 * @since 1.1
 * @param \EDD_Payment $payment
 * @return bool Returns false if there are no items, or if all items were bundled.
 */
function edd_custom_deliverables_payment_has_eligible_items( \EDD_Payment $payment ) {
	if ( empty( $payment->cart_details ) ) {
		return false;
	}
	$ids = wp_list_pluck( $payment->cart_details, 'id' );
	foreach ( $ids as $key => $item_id ) {
		if ( edd_is_bundled_product( $item_id ) ) {
			unset( $ids[ $key ] );
		}
	}
	if ( empty( $ids ) ) {
		return false;
	}

	return true;
}

/**
 * Sanitizes the data for a single custom deliverable file.
 *
 * @since 1.1
 * @param array $file_data
 * @return false|array
 */
function edd_cd_sanitize_single_file( $file_data ) {

	// If there is no file entered, skip saving this file as it's likely blank.
	if ( empty( $file_data['file'] ) ) {
		return false;
	}

	$sanitized_data = array();

	// Loop through each piece of file data so we can sanitize it
	foreach ( $file_data as $meta_key => $meta_value ) {

		switch ( $meta_key ) {
			case 'file':
			case 'thumbnail_size':
			case 'name':
				$sanitized_data[ $meta_key ] = sanitize_text_field( $meta_value );

				break;
			case 'index':
				if ( is_numeric( $meta_value ) ) {
					$sanitized_data['index'] = $meta_value;
				}

				break;
			case 'attachment_id':
				if ( ! is_numeric( $meta_value ) ) {
					$sanitized_data['attachment_id'] = false;
				} else {
					$sanitized_data['attachment_id'] = $meta_value;
				}

				break;
		}
	}

	return $sanitized_data;
}

/**
 * Whether the current user can upload files to a specific product.
 *
 * @since 1.1
 * @param int $product_id The current product ID.
 * @return bool
 */
function edd_custom_deliverables_current_user_can_upload_deliverables( $product_id ) {
	$product = get_post( $product_id );

	return $product instanceof WP_Post && get_current_user_id() == $product->post_author;
}
