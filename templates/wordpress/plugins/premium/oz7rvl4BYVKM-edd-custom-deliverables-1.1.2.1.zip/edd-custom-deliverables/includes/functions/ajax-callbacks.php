<?php
/**
 * Ajax callback functions
 *
 * @package     EDD\EDDCustomDeliverables\Functions
 * @since       1.0.0
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Updates the fulfillment status.
 *
 * @internal
 * @since 1.1
 *
 * @param array $data           $_POST data.
 * @param bool  $mark_fulfilled `true` to mark as fulfilled, `false` to mark as unfulfilled.
 *
 * @return bool|WP_Error
 */
function edd_custom_deliverables_update_fulfillment( $data, $mark_fulfilled = true ) {
	if ( empty( $data['payment_id'] ) || empty( $data['download_id'] ) || ! isset( $data['price_id'] ) || empty( $data['nonce'] ) ) {
		return new WP_Error(
			'data_missing',
			__( 'There was data missing so the job could not be updated. Please re-save the payment and try again.', 'edd-custom-deliverables' )
		);
	}

	$nonce_action = $mark_fulfilled ? 'edd-custom-deliverables-mark-as-fulfilled' : 'edd-custom-deliverables-mark-as-not-fulfilled';
	if ( ! wp_verify_nonce( $data['nonce'], $nonce_action ) ) {
		return new WP_Error(
			'security_failure',
			__( 'There was a problem with the security check.', 'edd-custom-deliverables' )
		);
	}

	$payment     = edd_get_payment( intval( $data['payment_id'] ) );
	$download_id = intval( $data['download_id'] );
	$price_id    = intval( $data['price_id'] );

	if ( ! edd_custom_deliverables_current_user_can_update_fulfillment( $payment->ID ) ) {
		return new WP_Error(
			'security_failure',
			__( 'You do not have permission to perform this action.', 'edd-custom-deliverables' )
		);
	}

	// Get the array of fulfilled jobs in this payment.
	$fulfilled_jobs = edd_custom_deliverables_get_fulfilled_jobs_meta( $payment );

	// Make sure it's an array if this is a brand new save.
	if ( empty( $fulfilled_jobs ) || ! is_array( $fulfilled_jobs ) ) {
		$fulfilled_jobs = array();
	}

	if ( $mark_fulfilled ) {
		// Mark this job as complete by saving the timestamp.
		$fulfilled_jobs[ $download_id ][ $price_id ] = time();
	} else {
		// Mark this job as not complete by removing the variable key for it.
		unset( $fulfilled_jobs[ $download_id ][ $price_id ] );
	}

	// Update the fulfilled jobs meta.
	$payment->update_meta( '_eddcd_custom_deliverables_fulfilled_jobs', $fulfilled_jobs );

	if ( $mark_fulfilled ) {
		do_action( 'edd_custom_deliverables_mark_as_fulfilled', $payment, $download_id, $price_id, $fulfilled_jobs );
	} else {
		do_action( 'edd_custom_deliverables_mark_as_not_fulfilled', $payment, $download_id, $price_id, $fulfilled_jobs );
	}

	edd_custom_deliverables_check_for_full_fulfillment( $payment, $fulfilled_jobs );

	return true;
}

/**
 * Mark an order as "fulfilled" via ajax
 *
 * @since 1.0
 * @return void
 */
function edd_custom_deliverables_mark_as_fulfilled() {
	$result = edd_custom_deliverables_update_fulfillment( $_POST );
	if ( is_wp_error( $result ) ) {
		/** @var WP_Error $result */
		wp_send_json_error(
			array(
				'failure_code'    => $result->get_error_code(),
				'failure_message' => $result->get_error_message(),
			)
		);
	}

	ob_start();

	EDD_Custom_Deliverables::$edd_custom_deliverables_metabox->render_fulfilled_job( $_POST['download_id'], $_POST['price_id'] );

	// Return the HTML.
	wp_send_json_success(
		array(
			'success_message' => ob_get_clean(),
		)
	);
}
add_action( 'wp_ajax_edd_custom_deliverables_mark_as_fulfilled', 'edd_custom_deliverables_mark_as_fulfilled' );

/**
 * Mark an order as "fulfilled" via ajax
 *
 * @since 1.0
 * @return void
 */
function edd_custom_deliverables_mark_as_not_fulfilled() {
	$result = edd_custom_deliverables_update_fulfillment( $_POST, false );
	if ( is_wp_error( $result ) ) {
		/** @var WP_Error $result */
		wp_send_json_error(
			array(
				'failure_code'    => $result->get_error_code(),
				'failure_message' => $result->get_error_message(),
			)
		);
	}

	ob_start();

	EDD_Custom_Deliverables::$edd_custom_deliverables_metabox->render_unfulfilled_job( $_POST['download_id'], $_POST['price_id'] );

	// Return the HTML to mark as fulfilled.
	wp_send_json_success(
		array(
			'success_message' => ob_get_clean(),
		)
	);
}
add_action( 'wp_ajax_edd_custom_deliverables_mark_as_not_fulfilled', 'edd_custom_deliverables_mark_as_not_fulfilled' );

/**
 * Emails the customer that their Custom Deliverable files are ready.
 *
 * @since 1.1
 *
 * @param array  $data          POST data.
 * @param string $email_subject Email subject. Optional as of 1.1.1; not needed with EDD 3.3.0.
 * @param string $email_message Email message. Optional as of 1.1.1; not needed with EDD 3.3.0.
 *
 * @return true|WP_Error
 */
function edd_custom_deliverables_email_customer( $data, $email_subject = '', $email_message = '' ) {
	global $edd_custom_deliverable_ajax_email_payment_id;

	if ( empty( $data['payment_id'] ) || empty( $data['nonce'] ) ) {
		return new WP_Error(
			'data_missing',
			__( 'There was data missing so the email could not be sent.', 'edd-custom-deliverables' )
		);
	}

	if ( ! wp_verify_nonce( $data['nonce'], 'edd-custom-deliverables-send-email' ) ) {
		return new WP_Error(
			'security_failure',
			__( 'There was a problem with the security check.', 'edd-custom-deliverables' )
		);
	}

	$payment_id = intval( $data['payment_id'] );

	// Globalize the payment_id so that we can use it in other functions that we'll run during this ajax function.
	$edd_custom_deliverable_ajax_email_payment_id = $payment_id;

	if ( ! edd_custom_deliverables_current_user_can_update_fulfillment( $payment_id ) ) {
		return new WP_Error(
			'security_failure',
			__( 'You do not have permission to perform this action.', 'edd-custom-deliverables' )
		);
	}

	if ( class_exists( '\\EDD\\Emails\\Email' ) ) {
		$email      = new \EDD\CustomDeliverables\Emails\Type( $payment_id );
		$email_sent = $email->send();
	} else {
		if ( empty( $email_subject ) ) {
			$email_subject = edd_get_option( 'custom_deliverables_email_subject', __( 'Your files are ready!', 'edd-custom-deliverables' ) );
		}
		if ( empty( $email_message ) ) {
			$email_message = edd_get_option( 'custom_deliverables_email_body', edd_custom_deliverables_default_email_message() );
		}
		// Set up the message for the email.
		$body = stripslashes( edd_sanitize_text_field( $email_message ) );
		$body = edd_do_email_tags( $body, $payment_id );

		// Set up data for the email.
		$from_name  = edd_get_option( 'from_name', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );
		$from_email = edd_get_option( 'from_email', get_bloginfo( 'admin_email' ) );
		$to_email   = edd_get_payment_user_email( $payment_id );

		// Build the email header.
		$headers  = 'From: ' . stripslashes_deep( html_entity_decode( $from_name, ENT_COMPAT, 'UTF-8' ) ) . " <$from_email>\r\n";
		$headers .= 'Reply-To: ' . $from_email . "\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=utf-8\r\n";

		$emails = EDD()->emails;

		$emails->__set( 'from_name', $from_name );
		$emails->__set( 'from_email', $from_email );
		$emails->__set( 'heading', $email_subject );
		$emails->__set( 'headers', $headers );

		$email_sent = $emails->send( $to_email, $email_subject, $body );
	}

	if ( ! $email_sent ) {
		return new WP_Error(
			'sending_failure',
			__( 'The email failed to send.', 'edd-custom-deliverables' )
		);
	}

	// Add a note to the payment indicating that the email was sent.
	$user = wp_get_current_user();
	edd_insert_payment_note(
		$payment_id,
		sprintf(
		/* %s - username of the current user */
			__( '%s sent the customer an email to notify them of custom deliverables being available.', 'edd-custom-deliverables' ),
			$user instanceof WP_User ? $user->user_login : __( '(unknown user)', 'edd-custom-deliverables' )
		)
	);

	return true;
}

/**
 * Send the custom deliverables email via ajax
 *
 * @since 1.0
 * @return void
 */
function edd_custom_deliverables_send_email_ajax() {
	$result = edd_custom_deliverables_email_customer( $_POST );

	if ( is_wp_error( $result ) ) {
		/** @var WP_Error $result */
		wp_send_json_error(
			array(
				'failure_code'    => $result->get_error_code(),
				'failure_message' => $result->get_error_message(),
			)
		);
	}

	wp_send_json_success(
		array(
			'success_code'    => 'email_successfully_sent',
			'success_message' => __( 'Email successfully sent.', 'edd-custom-deliverables' ),
		)
	);
}
add_action( 'wp_ajax_edd_custom_deliverables_send_email_ajax', 'edd_custom_deliverables_send_email_ajax' );

/**
 * Turn on the file upload filter which tells files to upload to the edd directory
 *
 * @since 1.0
 * @deprecated 1.1
 * @return void
 */
function edd_cd_turn_on_file_filter() {
	$_SESSION['eddcd_upload_filter_enabled'] = true;
}

/**
 * Turn off the file upload filter which tells files to upload to the edd directory
 *
 * @since 1.0
 * @deprecated 1.1
 * @return void
 */
function edd_cd_turn_off_file_filter() {
	$_SESSION['eddcd_upload_filter_enabled'] = false;
}

/**
 * Check if an entire payment has been fulfilled and save it accordingly (true or false)
 *
 * @since 1.0
 * @param object $payment
 * @return void
 */
function edd_custom_deliverables_check_for_full_fulfillment( $payment, $fulfilled_jobs ) {

	// Set default to true
	$all_jobs_fulfilled = true;

	// Check if all jobs have been fulfilled - Loop through the purchased items
	foreach ( $payment->cart_details as $cart_key => $cart_item ) {

		// Get the download if of this purchased product
		$purchased_download_id = $cart_item['id'];

		// Get the purchased price ID
		$purchased_price_id = isset( $cart_item['item_number']['options']['price_id'] ) ? $cart_item['item_number']['options']['price_id'] : 0;

		// Check if this product has not been fulfilled
		if ( ! isset( $fulfilled_jobs[ $purchased_download_id ][ $purchased_price_id ] ) ) {
			$all_jobs_fulfilled = false;
		}
	}

	// If all jobs have been fulfilled, set the status of the fulfillment to true
	if ( $all_jobs_fulfilled ) {
		$payment->update_meta( '_eddcd_fulfillment_status', 2 );
	} else {
		$payment->update_meta( '_eddcd_fulfillment_status', 1 );
	}

	do_action( 'edd_custom_deliverables_check_for_full_fulfillment', $all_jobs_fulfilled, $payment, $fulfilled_jobs );
}
