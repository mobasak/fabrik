<?php
/**
 * Scripts
 *
 * @package     EDD\PluginName\Scripts
 * @since       1.0.0
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Load admin scripts
 *
 * @since       1.0.0
 * @global      array  $edd_settings_page The slug for the EDD settings page
 * @global      string $post_type         The type of post that we are editing
 * @return      void
 */
function edd_custom_deliverables_admin_post_meta_scripts( $hook ) {

	if ( ! edd_is_admin_page( 'payments', 'edit' ) ) {
		return;
	}

	wp_enqueue_script( 'edd_custom_deliverables_admin_js', EDD_CUSTOM_DELIVERABLES_URL . 'assets/build/js/admin-eddcd-scripts.js', array( 'jquery' ), EDD_CUSTOM_DELIVERABLES_VER, true );

	wp_localize_script( 'edd_custom_deliverables_admin_js', 'edd_custom_deliverables_vars',
		array(
			'save_payment_text' => '<h3>' . __( 'Notify Customer', 'edd-custom-deliverables' ) . '</h3><p>' . __( 'Since you have just modified the files, save the payment before notifying the customer. After saving, a notification tool will appear here.', 'edd-custom-deliverables' ) . '</p>',
		)
	);

	wp_enqueue_style( 'edd_custom_deliverables_admin_css', EDD_CUSTOM_DELIVERABLES_URL . 'assets/build/css/eddcd-admin.css', array(), EDD_CUSTOM_DELIVERABLES_VER );
}
add_action( 'admin_enqueue_scripts', 'edd_custom_deliverables_admin_post_meta_scripts', 100 );
