<?php
/**
 * Do not put custom translations here. They will be deleted on EDD Custom Deliverables updates.
 *
 * Keep custom EDD translations in /wp-content/languages/edd-custom-deliverables/
 */
