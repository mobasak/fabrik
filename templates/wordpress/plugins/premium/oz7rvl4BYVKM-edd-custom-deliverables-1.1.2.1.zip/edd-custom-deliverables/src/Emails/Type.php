<?php

namespace EDD\CustomDeliverables\Emails;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Types\Email;

class Type extends Email {

	/**
	 * Email ID.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	public $id = 'custom_deliverable';

	/**
	 * The email context.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	protected $context = 'order';

	/**
	 * The email recipient type.
	 *
	 * @var string
	 * @since 1.1.1
	 */
	protected $recipient_type = 'customer';

	/**
	 * The order object.
	 *
	 * @var \EDD\Orders\Order
	 * @since 1.1.1
	 */
	protected $order;

	/**
	 * Type constructor.
	 *
	 * @param int $order_id The order ID.
	 */
	public function __construct( $order_id ) {
		$this->order           = edd_get_order( $order_id );
		$this->email_object_id = $order_id;
	}

	/**
	 * Set the email to address.
	 *
	 * @since 1.1.1
	 *
	 * @return void
	 */
	protected function set_to_email() {
		$this->send_to = $this->order->email;
	}

	/**
	 * Set the email subject.
	 *
	 * @since 1.1.1
	 * @return void
	 */
	protected function set_subject() {
		$subject = $this->get_email()->subject;
		$subject = edd_do_email_tags( $subject, $this->order->id, $this->order, 'order' );

		$this->subject = $subject;
	}

	/**
	 * Set the email message.
	 *
	 * @since 1.1.1
	 * @return void
	 */
	protected function set_message() {
		$message = $this->maybe_apply_autop( $this->get_raw_body_content() );
		$message = edd_do_email_tags( $message, $this->order->id, $this->order, 'order' );

		$this->message = $message;
	}
}
