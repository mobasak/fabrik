<?php

namespace EDD\CustomDeliverables\Emails;

defined( 'ABSPATH' ) || exit;

class Registry {

	/**
	 * Registry constructor.
	 */
	public function __construct() {
		add_filter( 'edd_email_registered_templates', array( $this, 'register_templates' ) );
		add_filter( 'edd_email_registered_types', array( $this, 'register_types' ) );
		add_filter( 'edd_email_senders', array( $this, 'register_sender' ) );
	}

	/**
	 * Registers the preapproved order emails.
	 *
	 * @since 1.1.1
	 * @param array $emails
	 * @return array
	 */
	public function register_templates( $emails ) {
		$emails['custom_deliverable'] = Template::class;

		return $emails;
	}

	/**
	 * Registers the preapproved order emails.
	 *
	 * @since 1.1.1
	 * @param array $types
	 * @return array
	 */
	public function register_types( $types ) {
		$types['custom_deliverable'] = Type::class;

		return $types;
	}

	/**
	 * Registers Stripe as an email sender.
	 *
	 * @since 1.1.1
	 * @param array $senders
	 * @return array
	 */
	public function register_sender( $senders ) {
		$senders['custom_deliverables'] = __( 'Custom Deliverables', 'edd-custom-deliverables' );

		return $senders;
	}
}
