<?php

namespace EDD\CustomDeliverables\Emails;

defined( 'ABSPATH' ) || exit;

use EDD\Emails\Templates\EmailTemplate;

/**
 * Class Template
 *
 * @package EDD\CustomDeliverables\Emails
 */
class Template extends EmailTemplate {

	/**
	 * Whether this email can be previewed.
	 *
	 * @since 1.1.1
	 * @var bool
	 */
	protected $can_preview = true;

	/**
	 * Whether this email can be tested.
	 *
	 * @since 1.1.1
	 * @var bool
	 */
	protected $can_test = true;

	/**
	 * Unique identifier for this template.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	protected $email_id = 'custom_deliverable';

	/**
	 * The email recipient.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	protected $recipient = 'customer';

	/**
	 * The email context.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	protected $context = 'order';

	/**
	 * Retrieves the email sender.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	protected $sender = 'custom_deliverables';

	/**
	 * Name of the template.
	 *
	 * @since 1.1.1
	 * @return string
	 */
	public function get_name() {
		return __( 'Custom File Delivery', 'edd-custom-deliverables' );
	}

	/**
	 * Description of the email.
	 *
	 * @since 1.1.1
	 * @return string
	 */
	public function get_description() {
		return __( 'Enter the text that is used when sending a notification to customers that their files are ready. HTML is accepted.', 'edd-custom-deliverables' );
	}

	/**
	 * Gets the email defaults.
	 *
	 * @since 1.1.1
	 * @return string
	 */
	public function defaults(): array {
		return array(
			'subject' => __( 'Your files are ready!', 'edd-custom-deliverables' ),
			'content' => edd_custom_deliverables_default_email_message(),
			'status'  => 1,
		);
	}

	/**
	 * Gets the email preview data.
	 *
	 * @since 1.1.1
	 * @return array
	 */
	protected function get_preview_data() {
		$orders = edd_get_orders(
			array(
				'number'     => 10,
				'type'       => 'sale',
				'status__in' => edd_get_complete_order_statuses(),
				'fields'     => 'ids',
				'meta_query' => array(
					array(
						'key'     => '_eddcd_custom_deliverables_custom_files',
						'compare' => 'EXISTS',
					),
				),
			)
		);
		if ( empty( $orders ) ) {
			return false;
		}

		return array(
			array_rand( array_flip( $orders ) ),
		);
	}

	/**
	 * Determines whether the email is enabled.
	 *
	 * @since 1.1.1
	 * @return bool
	 */
	protected function is_enabled(): bool {
		return true;
	}

	/**
	 * Gets the editable properties for this email.
	 *
	 * @since 1.1.1
	 * @return array
	 */
	protected function get_editable_properties(): array {
		return array(
			'subject',
			'content',
		);
	}

	/**
	 * Legacy
	 */
	protected function get_options(): array {
		return array(
			'subject' => 'custom_deliverables_email_subject',
			'content' => 'custom_deliverables_email_body',
		);
	}
}
