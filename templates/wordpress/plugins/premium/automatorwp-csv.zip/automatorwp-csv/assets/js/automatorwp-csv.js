(function( $ ) {

    // On change source selection
    $('body').on('change', '.automatorwp-trigger-csv-import-file .cmb2-id-data-source select', function(e) {
        var row = $(this).closest('.cmb-row');
        var csv_file_field = row.siblings('.cmb2-id-csv');
        var csv_text_field = row.siblings('.cmb2-id-csv-text');
        var data_source = $(this).val();
        var first_change = row.hasClass('is-option-change');

        var show_func = first_change ? 'show' : 'slideDown';
        var hide_func = first_change ? 'hide' : 'slideUp';

        // Show selected element
        if (data_source === 'upload' || data_source === '') {
            csv_file_field[show_func]('fast');
            csv_text_field[hide_func]('fast');
        } else if (data_source === 'paste') {
            csv_file_field[hide_func]('fast');
            csv_text_field[show_func]('fast');
        }

        row.removeClass('is-option-change');
    });

    // On click on an option, check if form contains the data source inputs
    $('body').on('click', '.automatorwp-automation-item-label > .automatorwp-option', function(e) {
        var item = $(this).closest('.automatorwp-automation-item');
        var option = $(this).data('option');
        var option_form = item.find('.automatorwp-option-form-container[data-option="' + option + '"]');

        var data_source_field = option_form.find('.cmb2-id-data-source');

        if (data_source_field.length > 0) {
            data_source_field.addClass('is-option-change');
            data_source_field.find('select').trigger('change');
        }

    });

})( jQuery );
