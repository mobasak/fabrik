<script>
jQuery(function(){
	let wp_ab_esg = jQuery('#wp-admin-bar-esg');
	if( !wp_ab_esg.length ) return;

	let aliases = [];
	jQuery('.esg-grid-wrap-container').each(function(){
		let alias = jQuery(this).data('alias');
		if ( alias ) aliases.push( alias );
	});
	if( !aliases.length ) {
		jQuery('#wp-admin-bar-esg').remove();
		return;
	}

	wp_ab_esg.append( '<div class="ab-sub-wrapper"><ul role="menu" id="wp-admin-bar-esg-default" class="ab-submenu">' );
	
	let wp_ab_esg_submenu = jQuery('#wp-admin-bar-esg-default');
	let href = ESG.E.site_url + '/wp-admin/admin.php?page=essential-grid&view=grid-create&alias=';
	jQuery.each( aliases, function( index, alias ) {
		wp_ab_esg_submenu.append( '<li role="group" id="wp-admin-bar-esg-'+alias+'"><a role="menuitem" class="ab-item" href="'+href+alias+'" target="_blank"><span class="esg-label" data-alias="'+alias+'">'+alias+'</span></a></li>' );
	});
});
</script>
