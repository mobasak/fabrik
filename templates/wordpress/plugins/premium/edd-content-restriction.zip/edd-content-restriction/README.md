EDD Content Restriction
=======================
[![Build status](https://badge.buildkite.com/cd3ab4e7ea78d836dd620e6ec646a398dc980534f938a60af4.svg)](https://buildkite.com/sandhills-development-llc/edd-content-restriction)

EDD Content Restriction is a commercial plugin available from [http://easydigitaldownloads.com/extensions/content-restriction](http://easydigitaldownloads.com/extensions/content-restriction). The plugin is hosted here on a public Github repository in order to better faciliate commuity contributions from developers and users alike. If you have a suggestion, a bug report, or a patch for an issue, feel free to submit it here. We do ask, however, that if you are using the plugin on a live site that you please purchase a valid license from the [website](http://easydigitaldownloads.com). We cannot provide support to anyone that does not hold a valid license key.
