<?php

namespace ContentEgg\application\components;

defined('\ABSPATH') || exit;

/**
 * Content class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link https://www.keywordrush.com
 * @copyright Copyright &copy; 2025 keywordrush.com
 */
class Content
{
	public $unique_id;
	public $module_id;
	public $title;
	public $description;
	public $img;
	public $url;
	public $domain;
	public $last_update;
	public $extra;
}
