<?php

defined('\ABSPATH') || exit;

/*
  Name: Product card
 */



$this->renderPartial('item');
