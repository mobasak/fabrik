<?php

defined( '\ABSPATH' ) || exit;

/*
  Name: Description only
 */

$this->renderPartial( 'description' );
