<?php

/*
  Name: List
 */


$this->renderPartial('list');
