<?php

defined('\ABSPATH') || exit;
/*
  Name: Grid
 */

$this->renderPartial('grid');
