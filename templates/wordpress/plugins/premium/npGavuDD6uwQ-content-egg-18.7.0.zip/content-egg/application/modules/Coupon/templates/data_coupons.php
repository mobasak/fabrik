<?php

defined('\ABSPATH') || exit;

/*
  Name: Coupons
 */



$this->renderPartial('coupon');
