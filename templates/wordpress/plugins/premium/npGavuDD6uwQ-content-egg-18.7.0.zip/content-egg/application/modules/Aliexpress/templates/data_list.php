<?php

defined('\ABSPATH') || exit;

/*
  Name: List
 */


$this->renderPartial('list');
