<?php

defined('\ABSPATH') || exit;
/*
  Name: Price tracker & alert
 */

$this->renderPartial('price_tracker_alert');
