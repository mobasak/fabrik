<?php

namespace ContentEgg\application\modules\Coupang;

defined('\ABSPATH') || exit;

use ContentEgg\application\components\ExtraData;

/**
 * ExtraDataCoupang class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link https://www.keywordrush.com
 * @copyright Copyright &copy; 2025 keywordrush.com
 *
 */
class ExtraDataCoupang extends ExtraData
{
	public $isRocket;
	public $rank;
	public $keyword;
}
