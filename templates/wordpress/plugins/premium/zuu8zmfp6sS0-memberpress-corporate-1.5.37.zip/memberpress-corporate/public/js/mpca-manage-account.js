// IIFE
(function($, window, document) {

  // $ is now locally scoped and available

  $(function() {

    // DOM is now ready

    'use strict';

    //Init all the suggest autocomplete fields
    $(document).ready(function() {
      mpca_setup_clipboardjs();

      $('.mepr_suggest_user').suggest(
        mpcaAjax.ajaxurl + '?action=mepr_user_search', {
          delay: 500,
          minchars: 2
        }
      );
    });

    $('#mpca_import_sub_accounts form').on('submit', function(e) {
      $('.mpca-loading-gif').show();
      $('#mpca_import_sub_accounts form input[type=submit]').attr('disabled',true);
    });

    function search() {
      var href = window.location.href.replace(/([\?&])search=[^\?&]*/gi,'');
      href = href.replace(/([\?&])currpage=[^\?&]*/gi,'');
      var delim = href.match(/\?/) ? '&' : '?',
          term  = $('#mpca_sub_account_search').val();

      if(term) {
        window.location.href = href + delim + 'search=' + term;
      }
      else {
        window.location.href = href;
      }
    }

    $('#mpca_sub_account_search').on('keyup',function(e) {
      if(e.which == 13) {
        e.preventDefault();
        search();
      }
    });

    $('#mpca_sub_account_search_btn').click(function() {
      search();
    });

    $('.mpca-remove-sub-account').on('click', function(e) {
      e.preventDefault();

      if(confirm(mpcaAjax.confirmMsg)) {
        var args = {
          'action': 'mpca_remove_sub_account',
          'ca': $(this).data('ca'),
          'sa': $(this).data('sa')
        };

        $.post(mpcaAjax.ajaxurl,args,function() {
          //$('#mpca-sub-accounts-row-'+args.sa).remove();
          // Fixes reload problem with Chrome
          window.location.replace(location.href);
        });
      }
    });

    $('#mpca-add-sub-user-btn').click(function() {
      jQuery('#mpca-add-sub-user-form').slideToggle();
    });

    $('.mpca-make-parent').on('click', function(e) {
      e.preventDefault();

      if(confirm(mpcaAjax.changeConfirmMsg)) {
        var args = {
          'action': 'mpca_switch_corporate_account_holder',
          'ca': $(this).data('ca'),
          'sa': $(this).data('sa')
        };

        $.post(mpcaAjax.ajaxurl, args)
        .done(function (response) {
          if (response && typeof response.success === 'boolean') {
              if (response.success) {
                // Fixes reload problem with Chrome
                window.location.replace(window.location.href);
              } else {
                alert(response.data);
              }
          }
          else {
            alert('Invalid response');
          }
        })
        .fail(function () {
          alert('Request failed');
        });
      }
    });
  });
}(jQuery, window, document));
