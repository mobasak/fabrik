<?php
/**
 * Functions
 *
 * @package EDD_Custom_Prices
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check if product has custom pricing enabled
 *
 * @param int $post_id The download ID.
 *
 * @return bool
 */
function edd_cp_has_custom_pricing( $post_id ) {
	return (bool) get_post_meta( $post_id, '_edd_cp_custom_pricing', true );
}
