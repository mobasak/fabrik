<?php if ( ! empty( $settings->logo ) ) { ?>
	<img id="cspio-logo" src="<?php echo $settings->logo; ?>">
<?php } ?>
