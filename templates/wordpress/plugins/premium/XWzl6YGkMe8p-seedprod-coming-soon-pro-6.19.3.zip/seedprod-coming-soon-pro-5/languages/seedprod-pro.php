<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '1', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '2', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '3', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '4', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '5', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '6', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '7', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '8', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '9', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( '10', 'seedprod-pro' ),

	// Reference: src/App.vue
	// Reference: src/views/Setup.vue
	__( 'Changes not saved, are you sure you want to leave?', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( '&larr; Go Back', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( '&larr; Go to Dashboard', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Choose a New Page Template', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'All Templates', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Favorite Templates', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Saved Templates', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'No Favorited Templates Found', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'No Saved Templates Found', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Filter:', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'All', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/views/SectionTemplateOptions-Pro.vue
	// Reference: src/views/SectionTemplateOptions-Lite.vue
	__( 'No Templates Found', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Choose This Template', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Enter your new page details', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'You can always change it later in Page Settings.', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Page Name:', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/views/SettingsGeneral.vue
	__( 'Page URL:', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Save and Start Editing the Page', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'First Page', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Prev', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Next', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Last Page', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Search templates...', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'My Landing Page name goes here', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'You can favorite any template by clicking the heart icon under the page template.', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'You can save pages as templates in the builder. Any saved pages will be shown here.', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/BuilderView.vue
	__( 'Your license key is invalid', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/BuilderView.vue
	__( 'Click Here to Enter Your License Key', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	__( 'Template Dev Mode - Select the Blank Template to Create a New Template or Select an Existing Template to Edit', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/views/SectionTemplateOptions-Pro.vue
	// Reference: src/views/SectionTemplateOptions-Lite.vue
	// Reference: src/mixins/helpers.js
	__( 'Are you sure you want to delete?', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/views/SectionTemplateOptions-Pro.vue
	// Reference: src/views/SectionTemplateOptions-Lite.vue
	// Reference: src/mixins/helpers.js
	__( 'Yes, delete it!', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/views/Setup.vue
	// Reference: src/views/SectionTemplateOptions-Pro.vue
	// Reference: src/views/SectionTemplateOptions-Lite.vue
	// Reference: src/views/Layoutnav.vue
	// Reference: src/mixins/helpers.js
	// Reference: src/components/Section.vue
	// Reference: src/components/Row.vue
	// Reference: src/components/OpenAIImageControl.vue
	// Reference: src/components/OpenAIControl.vue
	// Reference: src/components/DynamicTextControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Cancel', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	// Reference: src/views/SectionTemplateOptions-Pro.vue
	// Reference: src/views/SectionTemplateOptions-Lite.vue
	__( 'Deleted!', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Blank Template', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'This page url already exisits. Please choose a unique page url.', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Pro.vue
	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Could not be saved. Please contact Support if you continue to experience this issue.', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Send Us Your Email and Get 10 Free Templates', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'Get <strong>FREE</strong> Templates', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'PRO', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'SUBSCRIBE ABOVE TO UNLOCK', 'seedprod-pro' ),

	// Reference: src/views/TemplateChooser-Lite.vue
	__( 'You now have access to 10 FREE templates.', 'seedprod-pro' ),

	// Reference: src/views/SetupSettings.vue
	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Access Control', 'seedprod-pro' ),

	// Reference: src/views/SetupSettings.vue
	// Reference: src/views/SettingsSEO.vue
	__( 'SEO', 'seedprod-pro' ),

	// Reference: src/views/SetupSettings.vue
	// Reference: src/views/SettingsAnalytics.vue
	// Reference: src/components/PushNotificationOptions.vue
	__( 'Analytics', 'seedprod-pro' ),

	// Reference: src/views/SetupSettings.vue
	// Reference: src/views/SettingsScripts.vue
	__( 'Scripts', 'seedprod-pro' ),

	// Reference: src/views/SetupSettings.vue
	// Reference: src/views/SettingsDomain.vue
	__( 'Custom Domain', 'seedprod-pro' ),

	// Reference: src/views/SetupSettings.vue
	// Reference: src/views/SettingsGeneral.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'General', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Editing:', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/Setup.vue
	__( 'Global Settings', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Header Font', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Body Text Font', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Dim Background', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Use Video Background', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	__( 'YouTube URL', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'The video background will not be displayed on mobile devices or in the editor preview.', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Play on auto-loop', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Enter your custom css below', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Edit Custom CSS', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/Setup.vue
	// Reference: src/views/InlineHelpView.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/TypographyControl.vue
	// Reference: src/components/CustomHTMLOptions.vue
	// Reference: src/components/ColorPicker.vue
	__( 'Close', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Color Palettes', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Font Themes Library', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Search colors...', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Search fonts...', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Headers', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Text', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Buttons', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Links', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostcommentsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Background', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Font Themes', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/CustomHTMLOptions.vue
	__( 'Expand Editor', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Fonts', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/LoginOptions.vue
	__( 'Colors', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Custom CSS', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'All Palettes', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'All Themes', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Serif', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Sans Serif', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Background Slideshow', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Slideshow Images', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Add New Slide', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/views/SetupDesign-Lite.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'The background slideshow will not be shown in the editor preview. The slides will only be displayed in the live preview.', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Pro.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Overlay Color', 'seedprod-pro' ),

	// Reference: src/views/SetupDesign-Lite.vue
	__( 'Video Background', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	// Reference: src/views/SectionTemplates-Pro.vue
	// Reference: src/views/SectionTemplates-Lite.vue
	__( 'Blocks', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	// Reference: src/views/SectionTemplates-Pro.vue
	// Reference: src/views/SectionTemplates-Lite.vue
	__( 'Sections', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	__( 'Standard', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TemplatetagOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShortcodeOptions.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductPriceOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostnavigationOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/PostcommentsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/MenuCartOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/FormOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EnviraGalleryOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadPriceOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CustomHTMLOptions.vue
	// Reference: src/components/CounterOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AdditionalInformationOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Advanced', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	__( 'Saved Blocks', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	__( 'Search blocks...', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	__( 'WooCommerce', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	__( 'Widgets', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	__( 'Template Tags', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	__( 'WooCommerce Template Tags', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	__( 'Easy Digital Downloads', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	__( 'EDD Template Tags', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/SetupBlockOptions-Lite.vue
	__( 'Square Payments', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/Layoutnav.vue
	__( 'Section', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Row', 'seedprod-pro' ),

	// Reference: src/views/SetupBlockOptions-Pro.vue
	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Column', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Design', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Connect', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/FacebookSettings.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Page Settings', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'You have unsaved changes. Are you sure you want to lose these changes?', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Exit Without Saving', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'template has been saved!', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'You can find it in your template library when you create a new landing page.', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Enter a new template name:', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Your page has been published!', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	// Reference: src/views/SettingsGeneral.vue
	__( 'Publish', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Unpublish', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Schedule', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Save as Template', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Return to Page Editor', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Section.vue
	// Reference: src/components/Row.vue
	__( 'Save Template', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'See Live Page', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Save and Exit', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Help', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Save', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	// Reference: src/views/Setup.vue
	__( 'Saved!', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	// Reference: src/views/Preview.vue
	__( 'Preview', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'You are about to leave this page and go to the Global CSS page. Continue?', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'This page is not active. Would you like to activate it now?', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Yes, Activate', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'No, Close', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Coming Soon Mode is not active. Would you like to activate it now and show this page to visitors?', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Maintenance Mode is not active. Would you like to activate it now and show this page to visitors?', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Note: This page will only be shown to users who are logged out. If you logged out and and do not see the correct page you may need to clear your site cache.', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'This page is not published. Would you like to publish it now?', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Yes, Publish', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	// Reference: src/views/GlobalCSS.vue
	__( 'Global CSS Settings', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Layout Navigation', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Revision History', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Undo', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Redo', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Hide Sidebar', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Show Sidebar', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Desktop Preview', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Tablet Preview', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Mobile Preview', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Please make sure to perform a Save before saving as a global template. Click OK to proceed. NOTE: You are about to update a live template, updating this template will deactivate it until it is reviewed and made live again.', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Please make sure to perform a Save before saving as a global template. Click OK to proceed.', 'seedprod-pro' ),

	// Reference: src/views/Setup.vue
	__( 'Something has prevented the page from being saved. Please make sure you are at least an Editor and have the unfiltered_html capability.', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'Header Scripts:', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'This code will be rendered before the closing &lt;/head&gt; tag.', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'Footer Scripts:', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'The code will be rendered before the closing &lt;/body&gt; tag.', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'Body Scripts:', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'The code will be rendered after the &lt;body&gt; tag.', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'You do not have the proper WordPress permissions to add scripts.', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'Pro Tip:', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'Need to add tracking scripts or comply with privacy laws?', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'WPCode', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'lets you safely manage code snippets site-wide without editing theme files, while', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'WPConsent', 'seedprod-pro' ),

	// Reference: src/views/SettingsScripts.vue
	__( 'keeps you GDPR/CCPA compliant with customizable cookie consent banners. Get both free!', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	// Reference: src/views/SettingsAnalytics.vue
	__( 'Your SEO settings are being managed by:', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	// Reference: src/views/SettingsSEO.vue
	__( 'Yoast SEO', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	// Reference: src/views/SettingsSEO.vue
	__( 'Install SEO plugin:', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'Install All in One SEO', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'Activate All in One SEO', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'SEO Title', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'SEO Description', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'Favicon', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'Social Media Thumbnail', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'Enable No Index', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'Rank Math', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'The SEO Framework', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'All in One SEO', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	__( 'All in One SEO Pro', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	// Reference: src/views/SettingsAnalytics.vue
	__( 'Install', 'seedprod-pro' ),

	// Reference: src/views/SettingsSEO.vue
	// Reference: src/views/SettingsAnalytics.vue
	__( 'Activate', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Page Title:', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Page Status:', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Draft', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Link', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/EnviraGalleryOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Show', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Choose New Template:', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Redirect Mode', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Redirect URL: A temporary redirect (302 status) will be created to the url entered.', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Enable', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Redirect URL: A permanent redirect (301 status) will be created to the url entered.', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'SeedProd Link', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Enter Your Affiliate URL and Make Money with SeedProd', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Join our affiliate program', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'and get a 20% commission on all sales generated from your powered by link.', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Isolation Mode', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Redirect the Default Login Page', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Facebook App ID:', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Isolation Mode prevents two WordPress hooks from running called wp_head and wp_footer. This will prevent conflicts with your theme or other plugins. While it prevents conflicts, it also means other plugins would not run on the page such as SEO and analytics plugins. You can manually set these under the SEO and Scripts menus on the left.', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'The Redirect the Default Login Page option should redirect all calls to the default login page which is located at', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'however it does not prevent it from being accessed as that default login page will still be used for password resets, login errors, and registration if that is enabled.', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'Choose Template', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Warning', 'seedprod-pro' ),

	// Reference: src/views/SettingsGeneral.vue
	__( 'This will delete the current template and content.', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'Custom Domain:', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'OFF', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'ON', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'Domain Name:', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'Please enter your domain.', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'Click here to learn more', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'how to map your custom domain.', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'Force HTTPS', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'Only enable this if you have an SSL certificate installed and you wish to redirect users to https://', 'seedprod-pro' ),

	// Reference: src/views/SettingsDomain.vue
	__( 'Please enter a valid URL that will be pointed to this landing page, such as', 'seedprod-pro' ),

	// Reference: src/views/SettingsAnalytics.vue
	__( 'Your Analytics settings are being managed by:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAnalytics.vue
	__( 'Edit Analytics Settings', 'seedprod-pro' ),

	// Reference: src/views/SettingsAnalytics.vue
	__( 'Install Google Analytics plugin:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAnalytics.vue
	__( 'Install MonsterInsights', 'seedprod-pro' ),

	// Reference: src/views/SettingsAnalytics.vue
	__( 'Activate MonsterInsights', 'seedprod-pro' ),

	// Reference: src/views/SettingsAnalytics.vue
	__( 'Pro', 'seedprod-pro' ),

	// Reference: src/views/SettingsAnalytics.vue
	__( 'Installing', 'seedprod-pro' ),

	// Reference: src/views/SettingsAnalytics.vue
	__( 'Install Analytics plugin:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Exclude Default:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ContentToggle-Pro.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Yes', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ContentToggle-Pro.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'No', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'By default we exclude urls with the terms: login, admin, dashboard and account to prevent lockouts.', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Bypass Cookie:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	__( 'Use cookies instead of creating a WordPress user for the bypass. Note: this may not work on sites that are cached. Learn More', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Bypass URL:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Bypass URL Expires:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Access by IP:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Access by Role:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'By default anyone logged in will see the regular website and not the coming soon page. To override this select Roles that will be given access to see the regular website.', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Include/Exclude URLs:', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Show on the Entire Website', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Show on the Entire Website except for the Blog', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Show on the Home Page Only', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Include URLs', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Exclude URLs', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Enter a phrase above and give your visitors a secret url that will allow them to bypass the Coming Soon page.', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'After the bypass url expires the user will need to revisit the bypass url to regain access.', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'One IP Address per line', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Add Role', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Include certain urls to display the Coming Soon or Maintenance Page.', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'One per line. You may also enter a page or post id.', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Exclude certain urls to display the Coming Soon or Maintenance Page.', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Pro.vue
	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Example: /about-us/', 'seedprod-pro' ),

	// Reference: src/views/SettingsAccess-Lite.vue
	__( 'Use cookies instead of creating a WordPress user for the bypass. Note: this may not work on sites that are cached. Learn More.', 'seedprod-pro' ),

	// Reference: src/views/SectionTemplates-Pro.vue
	// Reference: src/views/SectionTemplates-Lite.vue
	__( 'All Sections', 'seedprod-pro' ),

	// Reference: src/views/SectionTemplates-Pro.vue
	// Reference: src/views/SectionTemplates-Lite.vue
	__( 'Favorites', 'seedprod-pro' ),

	// Reference: src/views/SectionTemplates-Pro.vue
	// Reference: src/views/SectionTemplates-Lite.vue
	__( 'Categories:', 'seedprod-pro' ),

	// Reference: src/views/SectionTemplateOptions-Pro.vue
	// Reference: src/views/SectionTemplateOptions-Lite.vue
	__( 'Choose This Section', 'seedprod-pro' ),

	// Reference: src/views/Revisions.vue
	__( 'Loading Revisions', 'seedprod-pro' ),

	// Reference: src/views/Revisions.vue
	__( 'Click to preview version:', 'seedprod-pro' ),

	// Reference: src/views/Revisions.vue
	__( 'Current Version', 'seedprod-pro' ),

	// Reference: src/views/Revisions.vue
	__( 'by', 'seedprod-pro' ),

	// Reference: src/views/Revisions.vue
	__( 'There are no revisions to show.', 'seedprod-pro' ),

	// Reference: src/views/Revisions.vue
	__( 'ago', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Expand All', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Collapse All', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Section.vue
	__( 'Enter a new section template name:', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/views/BuilderView.vue
	// Reference: src/components/Section.vue
	// Reference: src/components/Row.vue
	__( 'Choose your layout:', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/views/BuilderView.vue
	// Reference: src/components/Section.vue
	__( 'Add Section', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Section.vue
	__( 'Duplicate Section', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Section.vue
	__( 'Save Section', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TemplatetagOptions.vue
	// Reference: src/components/ShortcodeOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/FormOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/CustomHTMLOptions.vue
	// Reference: src/components/CounterOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Settings', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Section.vue
	__( 'Delete Section', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Copy Section', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Paste Section', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Row.vue
	__( 'Add Row', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Row.vue
	__( 'Duplicate Row', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Row.vue
	__( 'Delete Row', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Copy Row', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Paste Row', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Add Column', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Duplicate Column', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Delete Column', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Copy Column', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Paste Column', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Row.vue
	__( 'Duplicate Block', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	// Reference: src/components/Row.vue
	__( 'Delete Block', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Copy Block', 'seedprod-pro' ),

	// Reference: src/views/Layoutnav.vue
	__( 'Paste Block', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'SeedProd Logo', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'Ask a question or search the docs...', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	// Reference: src/components/ColorPicker.vue
	__( 'Clear', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'No docs found', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'View Documentation', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'Browse documentation, reference material, and tutorials for SeedProd.', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'View All Documentation', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'Get Support', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'Submit a ticket and our world class support team will be in touch soon.', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'Submit a Support Ticket', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'Upgrade to SeedProd Pro to access our world class customer support', 'seedprod-pro' ),

	// Reference: src/views/InlineHelpView.vue
	__( 'Upgrade to SeedProd Pro', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Add Custom Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Body Text Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Show H1 - H6 Settings', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/AdditionalInformationOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Header Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H1 ', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H1 Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H2 ', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H2 Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H3 ', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H3 Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H4 ', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H4 Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H5 ', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H5 Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H6 ', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H6 Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Body Text', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Desktop BG', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Mobile BG', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/TypographyControl.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Normal', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Hover', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Layout', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Row Default Max Width', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Forms', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/HotspotOptions.vue
	__( 'Label', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Label Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Field', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Field Text Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Field Background Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Field Border Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Field Border Style', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BorderSectionControl.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Solid', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BorderSectionControl.vue
	__( 'Dotted', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BorderSectionControl.vue
	__( 'Dashed', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Field Border Width', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Field Padding', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Header Default Bottom Margin', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Paragraph Default Bottom Margin', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Label Default Bottom Margin', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Button', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Button Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Button Text Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/LoginOptions.vue
	__( 'Button Font', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	__( 'Button Border Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Gradient', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Button Background Style', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H1 Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H2 Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H3 Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H4 Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H5 Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'H6 Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Body Text Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Link Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Label Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	__( 'Field Typography', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Gradient Type', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Radial', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Linear', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Angle', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/PositionControl.vue
	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Position', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Top Center', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Top Left', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Top Right', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Center Center', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Center Left', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Center Right', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Bottom Center', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Bottom Left', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Bottom Right', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'First Color Location', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Second Color Location', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'First Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Second Color', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/LoginOptions.vue
	__( 'Button Border Radius', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/LoginOptions.vue
	__( 'Field Border Radius', 'seedprod-pro' ),

	// Reference: src/views/GlobalCSS.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ButtonOptions.vue
	__( 'Button Border Width', 'seedprod-pro' ),

	// Reference: src/views/BuilderView.vue
	// Reference: src/components/Section.vue
	// Reference: src/components/Row.vue
	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'or', 'seedprod-pro' ),

	// Reference: src/views/BuilderView.vue
	// Reference: src/components/Section.vue
	// Reference: src/components/Row.vue
	__( 'Drag a new block here', 'seedprod-pro' ),

	// Reference: src/views/BuilderView.vue
	// Reference: src/components/Section.vue
	// Reference: src/components/Row.vue
	__( 'Add Columns', 'seedprod-pro' ),

	// Reference: src/views/BuilderView.vue
	__( 'Header Template', 'seedprod-pro' ),

	// Reference: src/views/BuilderView.vue
	__( 'Footer Template', 'seedprod-pro' ),

	// Reference: src/views/BuilderView.vue
	__( 'Drag New Block Here', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( 'There is no content available to paste. Please try copy section first!', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	__( 'Image uploading will take some time.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	__( 'Section Uploaded successfully.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	__( 'There is no content available to paste. Please try copy row first!', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	__( 'Block Uploaded successfully.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	__( 'Column Uploaded successfully.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	__( 'Row Uploaded successfully.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( 'Block Copied.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( 'Column Copied.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( 'Row Copied.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( 'Section Copied.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	__( 'Upgrade to PRO', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	// Reference: src/mixins/helpers.js
	__( 'Increase traffic, engagement, and get more email subscribers. Click below to learn more about all our awesome features.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( ' is a PRO Feature', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( ' feature is not available on your plan. Please upgrade to the PRO plan to unlock all these awesome features.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( 'UPGRADE TO PRO', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( '<strong>Bonus:</strong>&nbsp;SeedProd Lite users get a discount off the regular price, automatically applied at checkout.', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( 'Upgrade to Unlock ', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( ' feature is not available on your plan. Please upgrade your plan to unlock this feature and more!', 'seedprod-pro' ),

	// Reference: src/mixins/helpers.js
	__( 'Upgrade with just a click of a button!', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Heading Color', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/EnviraGalleryOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AdditionalInformationOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Text Color', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/ListTable.vue
	__( 'Apply', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TemplatetagOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShortcodeOptions.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductPriceOptions.vue
	// Reference: src/components/ProductPrice-Pro.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostnavigationOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/PostcommentsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/MenuCartOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/FormOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EnviraGalleryOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadPriceOptions.vue
	// Reference: src/components/EDDDownloadPrice-Pro.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CustomHTMLOptions.vue
	// Reference: src/components/CounterOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AdditionalInformationOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Content', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	__( 'Widget Settings', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/MenuCartOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CounterOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Styles', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	__( 'Heading Bottom Margin', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Heading', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	__( 'Heading Typography', 'seedprod-pro' ),

	// Reference: src/components/WpWidgetBlockOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Text Typography', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Fields', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Alerts', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Cart', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Payment Section', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Choose Your Style', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Light Input Field', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'No Border Input Field', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Wide Border Input Field', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Inner Shadow Input Field', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Grey Input Field', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Dark Input Field', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Bottom Border Field', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Transparent Input Field', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'One Column', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Two Column', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Label Font', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Row Spacing', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Button Style', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BorderSectionControl.vue
	// Reference: src/components/BorderRadiusControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Border Radius', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Flat', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( '2D', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Vintage', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Ghost', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Info Highlight Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Error Highlight Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Success Highlight Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Cart Border Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Cart Border Width', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Background Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/TypographyControl.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Font Family', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Header Background Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Header Font Family', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Query', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SpacingSectionControl.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Spacing', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Columns', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'All Products', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Pagination', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Show Order By', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Show Items Count', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Type', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Featured Products', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Sale Products', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Best Selling Products', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Recent Products', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Top Rated Products', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Include', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Exclude', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Include By', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Exclude By', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Term', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Order By', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Order', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Date', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/CounterOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Title', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Price', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Popularity', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Rating', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Random', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Menu Order', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'ASC', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'DESC', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TypographyControl.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Alignment', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Description', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Price Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Button Size', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Small', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Medium', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Large', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'X Large', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( '2X Large', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Image', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Shadow', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/BorderSectionControl.vue
	__( 'Border Style', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'None', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Hairline', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	__( 'Bottom Drop Shadow', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Image Border Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Image Border Width', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/PaddingControl.vue
	// Reference: src/components/MarginControl.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BorderWidthControl.vue
	// Reference: src/components/BorderRadiusControl.vue
	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Top', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/PaddingControl.vue
	// Reference: src/components/MarginControl.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BorderWidthControl.vue
	// Reference: src/components/BorderRadiusControl.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Right', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/PaddingControl.vue
	// Reference: src/components/MarginControl.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BorderWidthControl.vue
	// Reference: src/components/BorderRadiusControl.vue
	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Bottom', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/PaddingControl.vue
	// Reference: src/components/MarginControl.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BorderWidthControl.vue
	// Reference: src/components/BorderRadiusControl.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Left', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	__( 'Image Whitespace Padding', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( 'Limit', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( '- Select Options -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'ID', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( 'Select By SKU', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( '- Select SKU(s) -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Select By Category', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( '- Select Categories -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Select By Tags', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( '- Select Tags -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Select By Group', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( '- Select Group -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( 'On Sale', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( 'Best Selling', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( 'Top Rated', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( 'Query By Attribute', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( '- Select Attribute -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( '- Select Attribute Terms -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Include Selected Terms', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Exclude Selected Terms', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Include Selected Tags', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Exclude Selected Tags', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Include Selected Categories', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Exclude Selected Categories', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( 'Select By Visibility', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	__( '- Select Product Visibility -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/DisplaySectionControl.vue
	__( 'Visible', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Catalog', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Search', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/DisplaySectionControl.vue
	__( 'Hidden', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Featured', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Custom Query', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Select By ID', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( '- Select ID(s) -', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	__( 'Sale Badge Color', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Archive Products', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Description Typography', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Price Typography', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGridOptions.vue
	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Button Typography', 'seedprod-pro' ),

	// Reference: src/components/WCCustomProductsGrid-Pro.vue
	__( 'Products Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/CounterOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Templates', 'seedprod-pro' ),

	// Reference: src/components/WCCheckoutOptions.vue
	// Reference: src/components/WCCartOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/FontControl.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	// Reference: src/components/CounterOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Default', 'seedprod-pro' ),

	// Reference: src/components/WCCart-Pro.vue
	__( 'PLACEHOLDER', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Button Text', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/ButtonOptions.vue
	__( 'Button Sub Text', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	__( 'Open In New Window', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Size', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Vertical Padding', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Horizontal Padding', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Icons', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Before Text Icon', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'After Text Icon', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Tiny', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Pill Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Flat Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Blue Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Light Green Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Green Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Orange Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Red Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Yellow Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'White Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Grey Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Black Button', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Text Shadow', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	__( 'Product ID', 'seedprod-pro' ),

	// Reference: src/components/WCAddToCartOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Direct To Checkout', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Video', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Source', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'YouTube', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/StripepaymentOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/ButtonOptions.vue
	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/AddToCartOptions.vue
	__( 'Custom', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	__( 'Custom Video Code', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/VideoOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Width', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Vimeo URL', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Vimeo', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Start Time', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Specify a start time (in seconds)', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/CountdownOptions.vue
	__( 'End Time', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Specify an end time (in seconds)', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'External URL', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Custom Video URL', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Select Custom Video', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Video Options', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Autoplay', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Mute', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Loop', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Show Player Controls', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Show Download Button', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Preload', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Metadata', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Auto', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Preload attribute lets you specify how the video should be loaded when the page loads.', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Learn more here.', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Poster', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Image Overlay', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Choose Image', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Image Size', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SpacerOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeightControl.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/DividerOptions.vue
	__( 'Height', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	__( 'PX', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Show Play Icon', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Enable Lightbox', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Enable Sticky Video', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Enable Image Overlay', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Play on Mobile', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Modest Branding', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Privacy Mode', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Lazy Load', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Suggested Videos', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Current Video Channel', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Any Video', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Intro Title', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Intro Portrait', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Intro Byline', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Controls Color', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Play video inline on mobile devices instead of automatically going into fullscreen mode.', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Icon Font Size', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Icon Opacity', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	__( 'Icon Color', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Click on Preview and scroll past the video on the page to see this in action.', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Aspect Ratio', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( '1:1', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( '3:2', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( '4:3', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( '9:16', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( '16:9', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( '21:9', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Teaser Video', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Enable Teaser Video', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Show Banner', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Disabled because Teaser Video feature has been enabled.', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Disabled because Image Overlay feature has been enabled.', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Banner Text', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Banner Background Color', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Banner Text Color', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Banner Text Typography', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Banner Text Icon', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Teaser Video Play Icon', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Video must be hosted by a Starter, Standard, Advanced, Plus, Pro, Business, Premium, or Enterprise account.', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Image Src', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUpOptions.vue
	__( 'Poster Image Src', 'seedprod-pro' ),

	// Reference: src/components/VideoPopUp-Pro.vue
	__( 'Select a Video or Add Video URL', 'seedprod-pro' ),

	// Reference: src/components/VideoControl.vue
	__( 'Choose New Video', 'seedprod-pro' ),

	// Reference: src/components/VideoControl.vue
	__( 'Select Video', 'seedprod-pro' ),

	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/CounterOptions.vue
	__( 'Title Typography', 'seedprod-pro' ),

	// Reference: src/components/UpsellsOptions.vue
	// Reference: src/components/ProductRelatedOptions.vue
	__( 'Posts Per Page', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Dismiss this message', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Get SeedProd Pro and Unlock all the Powerful Features', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Thanks for being a loyal SeedProd Lite user. Upgrade to
SeedProd Pro to unlock all the awesome features and
experience why SeedProd is the best WordPress landing
page plugin.', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Pro Features:', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Drag & Drop Page Builder', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( '80+ PRO Page Blocks', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'PRO Email Marketing Integrations', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Custom 404 Pages', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Page Access Controls', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( '200+ PRO Page Templates', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'PRO Smart Sections', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Email Subscriber Management', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Plus much more...', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Bonus:', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'SeedProd Lite users get', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'a discount off the regular price', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'automatically applied at checkout.', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTAUpgrade.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Get SeedProd Pro Today and Unlock all the Powerful Features »', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	__( 'is not available, upgrade to unlock', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	__( 'is not available on your plan. Please upgrade to a higher plan to access this feature.', 'seedprod-pro' ),

	// Reference: src/components/UpgradeCTABuilder.vue
	__( 'Upgrade Your License', 'seedprod-pro' ),

	// Reference: src/components/TypographyControl.vue
	__( 'Typography', 'seedprod-pro' ),

	// Reference: src/components/TypographyControl.vue
	__( 'Edit', 'seedprod-pro' ),

	// Reference: src/components/TypographyControl.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/FontSizeControl.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Font Size', 'seedprod-pro' ),

	// Reference: src/components/TypographyControl.vue
	__( 'Line Height', 'seedprod-pro' ),

	// Reference: src/components/TypographyControl.vue
	__( 'Letter Spacing', 'seedprod-pro' ),

	// Reference: src/components/TypographyControl.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Style', 'seedprod-pro' ),

	// Reference: src/components/TypographyControl.vue
	__( 'Letter Case', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Hide Header', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Hide Footer', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Hide Borders', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Transparent', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Hide Scrollbar', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Show Replies', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Target Url', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Current Page', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'X (Twitter) Handle', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Url Format', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Plain Permalink', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Pretty Permalink', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'X (Twitter) Setting', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Facebook App Id:', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Like', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Recommend', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	__( 'Url', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	__( 'Hashtags', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	__( 'Via', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	__( 'Related', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Color Scheme', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Light', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Dark', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Language', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TextOptions.vue
	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/ProgressBarOptions.vue
	// Reference: src/components/ProductPriceOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostnavigationOptions.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/MenuCartOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/EDDDownloadPriceOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Color', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/BorderSectionControl.vue
	__( 'Border Color', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Automatic', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'English (default)', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Arabic', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Bengali', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Czech', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Danish', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'German', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Greek', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Spanish', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Persian', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Finnish', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Filipino', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'French', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Hebrew', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Hindi', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Hungarian', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Indonesian', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Italian', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Japanese', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Korean', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Malay', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Dutch', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Norwegian', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Polish', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Portuguese', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Romanian', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Russian', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Swedish', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Thai', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Turkish', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Ukrainian', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Urdu', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Vietnamese', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Chinese (Simplified)', 'seedprod-pro' ),

	// Reference: src/components/TwitterTweetButtonOptions.vue
	// Reference: src/components/TwitterFollowButtonOptions.vue
	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Chinese (Traditional)', 'seedprod-pro' ),

	// Reference: src/components/TwitterFollowButtonOptions.vue
	__( 'X (Twitter) Screen Name', 'seedprod-pro' ),

	// Reference: src/components/TwitterFollowButtonOptions.vue
	__( 'Show Screen Name', 'seedprod-pro' ),

	// Reference: src/components/TwitterFollowButtonOptions.vue
	__( 'Show Count', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTweetOptions.vue
	__( 'Hide Conversation', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTweetOptions.vue
	__( 'Hide Photos/Videos/Cards', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTweetOptions.vue
	__( 'Tweet ID', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	__( 'Button Count', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Box Count', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/FacebookSettings.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Set your Facebook App ID in the ', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/FacebookSettings.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'You are connected to Facebook App', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTweetOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Change App', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	__( 'Deprecation Notice', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTimelineOptions.vue
	// Reference: src/components/TwitterEmbedTimeline-Pro.vue
	__( 'X(Twitter) has silently deprecated the Timeline feature. This block will be deprecated in a future update.', 'seedprod-pro' ),

	// Reference: src/components/TwitterEmbedTimeline-Pro.vue
	__( 'Deprecated Block', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/LiteCTASubscribers.vue
	__( 'Filter by Page', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/LiteCTASubscribers.vue
	__( 'Export to a CSV File', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/LiteCTASubscribers.vue
	__( 'Premium Email Marketing Integrations', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/LiteCTASubscribers.vue
	__( 'Subscribers Over Time', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/LiteCTASubscribers.vue
	__( 'See Names and Emails', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	__( 'This Feature Is Not Available in Your Current Plan', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	__( 'Use SeedProd to Build Your Entire Website and Create Your Theme', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	__( 'Create Headers &amp; Footers', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	__( 'Create Global Parts', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	__( 'Includes Starter Theme', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	// Reference: src/components/ThemeBuilderUpsell.vue
	__( 'Create Pages and Posts', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsellPro.vue
	__( 'View Available Upgrades', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Upgrade to SeedProd PRO Now', 'seedprod-pro' ),

	// Reference: src/components/ThemeBuilderUpsell.vue
	// Reference: src/components/SettingsLiteCTA.vue
	// Reference: src/components/LiteCTATemplates.vue
	// Reference: src/components/LiteCTASubscribers.vue
	// Reference: src/components/LiteCTABuilder.vue
	__( 'Special Upgrade Offer - Save 50% Off', 'seedprod-pro' ),

	// Reference: src/components/TextOptions.vue
	// Reference: src/components/PostcommentsOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/DynamicTextControl.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Insert Dynamic Text', 'seedprod-pro' ),

	// Reference: src/components/TextOptions.vue
	__( 'Visual Editor', 'seedprod-pro' ),

	// Reference: src/components/TextOptions.vue
	__( 'Edit HTML', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SearchFormOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Icon', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	__( 'Name Color', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Add Testimonial', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/AnchorOptions.vue
	__( 'Name', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Navigation Color Mode', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'AutoPlay', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Pause On Hover', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Autoplay Speed', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	__( 'Testimonial to Show', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'seconds', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Enable Comment Bubble', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Bubble Color', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	__( 'Testimonials', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Carousel Settings', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	__( 'Name Typography', 'seedprod-pro' ),

	// Reference: src/components/TestimonialOptions.vue
	__( 'Show Image', 'seedprod-pro' ),

	// Reference: src/components/TemplatetagOptions.vue
	// Reference: src/components/Templatetag-Pro.vue
	__( 'Template Tag', 'seedprod-pro' ),

	// Reference: src/components/TemplatetagOptions.vue
	__( 'Show Template Tag Preview', 'seedprod-pro' ),

	// Reference: src/components/TemplatetagOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Select Type', 'seedprod-pro' ),

	// Reference: src/components/Templatetag-Pro.vue
	__( 'Enter Your Template Tag', 'seedprod-pro' ),

	// Reference: src/components/Templatetag-Pro.vue
	__( '(This template tag will be rendered on the live preview.)', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Striped Effect Template', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Divider Template', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Background Template', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Show Designation', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	__( 'Designation', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Show Description', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( '%', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/CounterOptions.vue
	__( 'Separator', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Below Name', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Below Designation', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Below Description', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Thickness', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Social Icons', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/FormOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Add New Item', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Shape', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	__( 'Rounded', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Circle', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Icon Padding', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/SpaceBetweenControl.vue
	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ProductPriceOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/CountdownOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/AddToCartOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Space Between', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Date Align', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Time Align', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'List Layout', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Vertical', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/ColOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Horizontal', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SpacingSectionControl.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Top Margin', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Style Day/Time', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Designation Color', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Description Color', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Day Color', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Time Color', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Divider', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Divider Color', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Weight', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Day and Time', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Striped Effect', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Striped Odd Rows Color', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Striped Even Rows Color', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Image Position', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TeamMemberOptions.vue
	__( 'Separator Align', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Social Icon Align', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Separator Margin Bottom', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Designation Align', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Designation Margin Bottom', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Description Align', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Name Align', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Name Margin Bottom', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Description Margin Bottom', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PriceListOptions.vue
	__( 'Image Area', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Title Tag', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/DividerOptions.vue
	__( 'H1', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/DividerOptions.vue
	__( 'H2', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/DividerOptions.vue
	__( 'H3', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/DividerOptions.vue
	__( 'H4', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'H5', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'H6', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	__( 'div', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/DividerOptions.vue
	__( 'span', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostauthorboxOptions.vue
	__( 'p', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	__( 'Alt Text', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Designation Typography', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Image Margin Bottom', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PaddingControl.vue
	// Reference: src/components/BusinessHoursOptions.vue
	// Reference: src/components/BulletListOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Padding', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/PriceListOptions.vue
	__( 'Image Border Radius', 'seedprod-pro' ),

	// Reference: src/components/TeamMemberOptions.vue
	__( 'Social Icon Border Radius', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/FacebookPageOptions.vue
	__( 'Tabs', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Tab Layout', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Tab Name', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Tab Color', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Hide Tab Icon', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Tab Background Color', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Tab Border Radius', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Content Border Radius', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Content Border Style', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Content Border Color', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Content Border Width', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	// Reference: src/components/BorderWidthControl.vue
	// Reference: src/components/BorderSectionControl.vue
	__( 'Border Width', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Tab', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Active Tab Color', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Active Tab Background', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Content Background', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Delete', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Duplicate', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Tab Typography', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Content Typography', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Tab ', 'seedprod-pro' ),

	// Reference: src/components/TabbedLayoutOptions.vue
	__( 'Tab Content', 'seedprod-pro' ),

	// Reference: src/components/SuperScriptControl.vue
	__( 'SuperScript Top', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Connect with Stripe', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Connect with', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Reconnect', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Connect or Create your Stripe account to start collecting payments.', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Pay as you go pricing: 3% fee per-transaction + Stripe fees', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Payment Setup', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Amount', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Payment Description', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Payment Currency', 'seedprod-pro' ),

	// Reference: src/components/StripepaymentOptions.vue
	__( 'Success URL', 'seedprod-pro' ),

	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Star Rating', 'seedprod-pro' ),

	// Reference: src/components/StarRatingOptions.vue
	// Reference: src/components/AnimationEffectControl.vue
	__( 'Scale', 'seedprod-pro' ),

	// Reference: src/components/StarRatingOptions.vue
	__( 'Star Color', 'seedprod-pro' ),

	// Reference: src/components/StarRatingOptions.vue
	__( 'Empty Star Color', 'seedprod-pro' ),

	// Reference: src/components/SpacerOptions.vue
	__( 'Spacer', 'seedprod-pro' ),

	// Reference: src/components/SocialSharingOptions.vue
	__( 'Social Sharing', 'seedprod-pro' ),

	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Add New Share', 'seedprod-pro' ),

	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Select a Type', 'seedprod-pro' ),

	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Facebook', 'seedprod-pro' ),

	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'X (Twitter)', 'seedprod-pro' ),

	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'LinkedIn', 'seedprod-pro' ),

	// Reference: src/components/SocialSharingOptions.vue
	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Pinterest', 'seedprod-pro' ),

	// Reference: src/components/SocialSharingOptions.vue
	__( 'Tweet Text', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Instagram', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Snapchat', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'WordPress', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Github', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'SoundCloud', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'RSS', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/Form-Pro.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Email', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'URL (Include https:// for web links)', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/ProductPriceOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	__( 'Stacked', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Icon Size', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Phone', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Discord', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Telegram', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Facebook Messenger', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Slack', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'Weibo', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'WhatsApp', 'seedprod-pro' ),

	// Reference: src/components/SocialProfilesOptions.vue
	__( 'TikTok', 'seedprod-pro' ),

	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/ImageBorderControl.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	__( 'Image Border', 'seedprod-pro' ),

	// Reference: src/components/SiteLogoOptions.vue
	// Reference: src/components/ProductFeaturedImageOptions.vue
	// Reference: src/components/PostfeaturedimageOptions.vue
	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/IconOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/EDDDownloadFeaturedImageOptions.vue
	__( 'No Follow', 'seedprod-pro' ),

	// Reference: src/components/SiteLogoOptions.vue
	__( 'Edit Site Identity', 'seedprod-pro' ),

	// Reference: src/components/ShortcodeOptions.vue
	// Reference: src/components/Shortcode-Pro.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Shortcode', 'seedprod-pro' ),

	// Reference: src/components/ShortcodeOptions.vue
	__( 'Show Shortcode Preview', 'seedprod-pro' ),

	// Reference: src/components/Shortcode-Pro.vue
	__( 'Enter Your Shortcode', 'seedprod-pro' ),

	// Reference: src/components/Shortcode-Pro.vue
	// Reference: src/components/Mypaykit.vue
	// Reference: src/components/Giveaway.vue
	// Reference: src/components/EnviraGallery.vue
	// Reference: src/components/ContactForm.vue
	__( '(This shortcode will be rendered on the live preview.)', 'seedprod-pro' ),

	// Reference: src/components/ShortDescription-Pro.vue
	__( 'Short Description Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Shape Divider', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Mountains', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Drops', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Clouds', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Zigzag', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Pyramids', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Triangle', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Triangle Asymmetrical', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Tilt', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Tilt Opacity', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Fan Opacity', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Curve', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Curve Asymmetrical', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Waves', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Waves Brush', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Waves Pattern', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Arrow', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Split', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Book', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Flip', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Invert', 'seedprod-pro' ),

	// Reference: src/components/ShapeDividerControl.vue
	__( 'Bring to Front', 'seedprod-pro' ),

	// Reference: src/components/ShadowControl.vue
	// Reference: src/components/AnimationEffectControl.vue
	__( 'Blur', 'seedprod-pro' ),

	// Reference: src/components/ShadowControl.vue
	__( 'Spread', 'seedprod-pro' ),

	// Reference: src/components/ShadowControl.vue
	__( 'Outline', 'seedprod-pro' ),

	// Reference: src/components/ShadowControl.vue
	__( 'Inset', 'seedprod-pro' ),

	// Reference: src/components/SettingsLiteCTA.vue
	__( 'Powerful Page Editor', 'seedprod-pro' ),

	// Reference: src/components/SettingsLiteCTA.vue
	__( 'Email Marketing Integrations', 'seedprod-pro' ),

	// Reference: src/components/SettingsLiteCTA.vue
	__( 'Access Controls', 'seedprod-pro' ),

	// Reference: src/components/SettingsLiteCTA.vue
	__( 'Subscriber Management', 'seedprod-pro' ),

	// Reference: src/components/SettingsLiteCTA.vue
	__( 'Upgrade to SeedProd Pro<br />Today and Save', 'seedprod-pro' ),

	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	__( 'Template Part', 'seedprod-pro' ),

	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	__( 'Select Part', 'seedprod-pro' ),

	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	__( 'No template parts available in SeedProd', 'seedprod-pro' ),

	// Reference: src/components/SeedProdTemplatePartsOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	__( 'Edit This Template Part', 'seedprod-pro' ),

	// Reference: src/components/SeedProdTemplateParts-Pro.vue
	// Reference: src/components/ContentToggle-Pro.vue
	__( 'No template parts available.', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Caption Align', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/AdditionalInformationOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Header Typography', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Caption Color', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Add Galleries', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Gallery Images', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Background Overlay', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Slider Image Styles', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/HotspotOptions.vue
	__( 'Image Shadow', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Media File', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Custom URL', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/ImageOptions.vue
	__( 'Custom Link', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Grid', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Justified', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Row Height', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Single', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Multiple', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Upload Images', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Thumbnail', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Caption', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Alt', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Overlay', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Tab Styles', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Hover Color', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Hover Background Color', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Left Margin', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Active Color', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGalleryOptions.vue
	__( 'Active Background Color', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGallery-Pro.vue
	// Reference: src/components/SeedProdBasicGallery-Pro.vue
	__( 'Gallery Not Available', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGallery-Pro.vue
	// Reference: src/components/SeedProdBasicGallery-Pro.vue
	__( 'Please add gallery images.', 'seedprod-pro' ),

	// Reference: src/components/SeedProdGallery-Pro.vue
	// Reference: src/components/SeedProdBasicGallery-Pro.vue
	__( 'Loading Gallery Preview', 'seedprod-pro' ),

	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Attachment', 'seedprod-pro' ),

	// Reference: src/components/SeedProdBasicGalleryOptions.vue
	__( 'Lightbox', 'seedprod-pro' ),

	// Reference: src/components/SectionOptions.vue
	__( 'Section Width', 'seedprod-pro' ),

	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/RowOptions.vue
	__( 'Full Screen', 'seedprod-pro' ),

	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/RowOptions.vue
	__( 'Fixed Width', 'seedprod-pro' ),

	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/RowOptions.vue
	__( 'Content Width', 'seedprod-pro' ),

	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/EnviraGalleryOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Advanced Styles', 'seedprod-pro' ),

	// Reference: src/components/SectionOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/BorderSectionControl.vue
	__( 'Border', 'seedprod-pro' ),

	// Reference: src/components/Section.vue
	__( 'Move Section', 'seedprod-pro' ),

	// Reference: src/components/Section.vue
	__( 'Section Settings', 'seedprod-pro' ),

	// Reference: src/components/Section.vue
	__( 'Save Global Section', 'seedprod-pro' ),

	// Reference: src/components/SearchFormOptions.vue
	__( 'Search Form Setting', 'seedprod-pro' ),

	// Reference: src/components/SearchFormOptions.vue
	__( 'Placeholder', 'seedprod-pro' ),

	// Reference: src/components/SearchFormOptions.vue
	__( 'Button Type', 'seedprod-pro' ),

	// Reference: src/components/SearchFormOptions.vue
	__( 'Search Background', 'seedprod-pro' ),

	// Reference: src/components/SearchFormOptions.vue
	__( 'Search Text Color', 'seedprod-pro' ),

	// Reference: src/components/SearchFormOptions.vue
	__( 'Button Background', 'seedprod-pro' ),

	// Reference: src/components/SearchForm-Pro.vue
	// Reference: src/components/AnchorOptions.vue
	// Reference: src/components/Anchor-Pro.vue
	__( 'Anchor', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	__( 'Column Gutter', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Content Alignment', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/NavOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Simple', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Display', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Flex Direction', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Justify Content', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Align Items', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Flex Start', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Center', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Flex End', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Space Around', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Space Evenly', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Baseline', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	// Reference: src/components/ColOptions.vue
	__( 'Stretch', 'seedprod-pro' ),

	// Reference: src/components/RowOptions.vue
	__( 'Row Width', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Enter a new block template name:', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Row Settings', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Move Row', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Resize Columns', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Column Settings', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Move Block', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Block Settings', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Save Block', 'seedprod-pro' ),

	// Reference: src/components/Row.vue
	__( 'Add Block', 'seedprod-pro' ),

	// Reference: src/components/PushNotificationOptions.vue
	__( 'PushEngage', 'seedprod-pro' ),

	// Reference: src/components/PushNotificationOptions.vue
	__( 'PushEngage allows you to send personalized campaigns to your website visitors and gives you an easy way to collect subscribers. It’s a marketing plugin that helps you get more web push notification subscribers, increase sales, and grow your business.', 'seedprod-pro' ),

	// Reference: src/components/PushNotificationOptions.vue
	__( 'Visit Dashboard', 'seedprod-pro' ),

	// Reference: src/components/PushNotificationOptions.vue
	__( 'Push Broadcasts', 'seedprod-pro' ),

	// Reference: src/components/PushNotificationOptions.vue
	__( 'Drip Autoresponders', 'seedprod-pro' ),

	// Reference: src/components/PushNotificationOptions.vue
	__( 'Audience', 'seedprod-pro' ),

	// Reference: src/components/PushNotificationOptions.vue
	__( 'Documentation', 'seedprod-pro' ),

	// Reference: src/components/PushNotification-Pro.vue
	__( 'Install Push Notifications Plugin:', 'seedprod-pro' ),

	// Reference: src/components/PushNotification-Pro.vue
	__( 'PushEngage Installed and Activated', 'seedprod-pro' ),

	// Reference: src/components/PushNotification-Pro.vue
	__( 'Install PushEngage', 'seedprod-pro' ),

	// Reference: src/components/PushNotification-Pro.vue
	__( 'Activate PushEngage', 'seedprod-pro' ),

	// Reference: src/components/PushNotification-Pro.vue
	// Reference: src/components/ContactForm.vue
	__( 'Contact Form', 'seedprod-pro' ),

	// Reference: src/components/ProgressBarOptions.vue
	__( 'Progress Bar', 'seedprod-pro' ),

	// Reference: src/components/ProgressBarOptions.vue
	__( 'Bar Text', 'seedprod-pro' ),

	// Reference: src/components/ProgressBarOptions.vue
	__( 'Percent', 'seedprod-pro' ),

	// Reference: src/components/ProgressBarOptions.vue
	__( 'My Text', 'seedprod-pro' ),

	// Reference: src/components/ProductTitle-Pro.vue
	__( 'Product Title Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductStock-Pro.vue
	__( 'Product Stock Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductRelated-Pro.vue
	__( 'Product Related Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductRating-Pro.vue
	__( 'Product Rating Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductPriceOptions.vue
	__( 'Sale Price', 'seedprod-pro' ),

	// Reference: src/components/ProductPriceOptions.vue
	__( 'Sale Price Typography', 'seedprod-pro' ),

	// Reference: src/components/ProductPrice-Pro.vue
	__( 'Product Price Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductMetaOptions.vue
	__( 'View', 'seedprod-pro' ),

	// Reference: src/components/ProductMetaOptions.vue
	__( 'Table', 'seedprod-pro' ),

	// Reference: src/components/ProductMetaOptions.vue
	__( 'Inline', 'seedprod-pro' ),

	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	__( 'Add Item', 'seedprod-pro' ),

	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	__( 'Layout Settings', 'seedprod-pro' ),

	// Reference: src/components/ProductMetaOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Link Color', 'seedprod-pro' ),

	// Reference: src/components/ProductMetaOptions.vue
	__( 'Divider Typography', 'seedprod-pro' ),

	// Reference: src/components/ProductMeta-Pro.vue
	__( 'Product Meta Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Panel', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Active', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Panel Padding', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	__( 'Zoom Button', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	__( 'Position Right', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	__( 'Position Top', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	__( 'Thumbnails Border', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	__( 'Thumbnails Border Radius', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImagesOptions.vue
	__( 'Thumbnails Border Width', 'seedprod-pro' ),

	// Reference: src/components/ProductGalleryImages-Pro.vue
	__( 'Product Gallery Images Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductFeaturedImage-Pro.vue
	__( 'Product Featured Image Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Panel Typography', 'seedprod-pro' ),

	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Panel Header Typography', 'seedprod-pro' ),

	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Panel Shadow', 'seedprod-pro' ),

	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Panel Border Radius', 'seedprod-pro' ),

	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Panel Border Width', 'seedprod-pro' ),

	// Reference: src/components/ProductDataTabsOptions.vue
	__( 'Panel Border', 'seedprod-pro' ),

	// Reference: src/components/ProductDataTabs-Pro.vue
	__( 'Product Data Tabs Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/ProductContent-Pro.vue
	__( 'Product Content Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Features List', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Plan Name', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Currency Symbol', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/AdditionalInformationOptions.vue
	__( 'Header', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	__( 'Regular Price', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/PricingTableOptions.vue
	__( 'Plan Name Typography', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Plan Name Color', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Button Size', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Button', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Bottom Button', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Size', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Button Before Text Icon', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Button After Text Icon', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Regular Price Color', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/AccordionOptions.vue
	__( 'Header Open Color', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Button Border Radius', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Bottom Button Border Radius', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '$ Dollar', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '€ Euro', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '฿ Baht', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₣ Franc', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'ƒ Guilder', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'kr Krona', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₤ Lira', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₧ Peseta', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₱ Peso', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '£ Pound Sterling', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'R$ Real', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₽ Ruble', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₨ Rupee', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₹ Rupee (Indian)', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₪ Shekel', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '¥ Yen/Yuan', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( '₩ Won', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Custom Symbol', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Period', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Show Regular Price', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Regular Price Label', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Show Top Button', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Button Text', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Button Link', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Show Bottom Button', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Bottom Button Text', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Bottom Button Link', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Top Button Color', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Features List Color', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Bottom Button Color', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Bottom Button Size', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Bottom Button Before Text Icon', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Bottom Button After Text Icon', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Price Superscript', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Price Superscript Top', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Block', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Currency Symbol Position', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Before', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'After', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Regular Price Typography', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Price Superscript Typography', 'seedprod-pro' ),

	// Reference: src/components/PricingTableOptions.vue
	__( 'Features List Typography', 'seedprod-pro' ),

	// Reference: src/components/PricingTable-Pro.vue
	__( 'Normally', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Left Layout Template', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Right Layout Template', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'No Image Template', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Price List Items', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Date Font Size', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Time Font Size', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Overall Alignment', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/FeatureOptions.vue
	__( 'Vertical Alignment', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Title Color', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Enter Title', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Enter Description', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Actual Price', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Offering Discount?', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Title Price Separator', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Link Complete Box', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Price Position', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Below Heading and Description', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Right of Heading', 'seedprod-pro' ),

	// Reference: src/components/PriceListOptions.vue
	__( 'Discount Color', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Posts Query', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Query Type', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Manual', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Query By Post Type', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Include Selected Post Type(s)', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( '- Select Post Type(s) -', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Query By Category', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Query By Tag(s)', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Include Selected Tag(s)', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( '- Select Tag(s) -', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Query By Author(s)', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Include Selected Author(s)', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( '- Select Author(s) -', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Date Last Modified', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Comment Count', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Slides to Show', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Query Params', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Number Per Page', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Featured Image', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Title', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Meta', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Date Modified', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Author', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Date', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Time', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Comment Count', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Show Excerpt', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Excerpt Length', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Show Read More', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Read More Text', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Meta Text', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Meta Text Color', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Excerpt', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Excerpt Color', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Read More Text Color', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Pagination Color', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Space Bottom', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Meta Text Typography', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Excerpt Typography', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Read More Text Typography', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Pagination Typography', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Taxonomy Typography', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Post Shadow', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Content Shadow', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Post Padding', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Image Margin', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Skin', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Classic', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Card', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Full Content', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Badge', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Badge Taxonomy', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	__( 'Category', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Tags', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	__( 'Avatar', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Carousel', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Masonry', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Creative', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Minimal', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Business News', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Bottom Spacing', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Taxonomy', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Navigation Color', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Navigation Position', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Navigation', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Arrows and Dots', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Arrows', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Dots', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Image Height', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/PostsOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Post Background Color', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Divider Border Color', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Content Area', 'seedprod-pro' ),

	// Reference: src/components/PostsOptions.vue
	__( 'Content Area Border', 'seedprod-pro' ),

	// Reference: src/components/Posts-Pro.vue
	// Reference: src/components/Posts-Pro.vue
	__( 'Loading Posts Preview', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'Author', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Time', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'Comments', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/PostinfoOptions.vue
	__( 'Terms', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'Link to Author', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Date Format', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'May 14, 2021 (F j, Y)', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( '2021-05-14 (Y-m-d)', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( '05/14/2021 (m/d/Y)', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( '14/05/2021 (d/m/Y)', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Custom Date Format', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'Use the letters: l D d j S F m M n Y y', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/IconPicker.vue
	__( 'Choose Icon', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'Modified Date', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'Modified Time', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Time Format', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( '9:15 am (g:i a)', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( '9:15 AM (g:i A)', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( '09:15 (H:i)', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Custom Time Format', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'Use the letters: g G H i a A', 'seedprod-pro' ),

	// Reference: src/components/PostinfoOptions.vue
	__( 'Show Icons', 'seedprod-pro' ),

	// Reference: src/components/PostcommentsOptions.vue
	__( 'Content Policy', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	__( 'Profile Picture', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Display Name', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	__( 'Biography', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/DividerOptions.vue
	__( 'HTML Tag', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Website', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	__( 'Archive Posts', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	__( 'Biography Color', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	__( 'Biography Typography', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	// Reference: src/components/NavOptions.vue
	__( 'Go to the', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	__( 'Profile Screen', 'seedprod-pro' ),

	// Reference: src/components/PostauthorboxOptions.vue
	__( 'to manage your profile.', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Enable Particle Background', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Particle Background', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Polygon', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/CounterOptions.vue
	__( 'Space', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Snow', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Snowflakes', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Christmas', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Halloween', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Opacity', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Flow Direction', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	// Reference: src/components/HotspotOptions.vue
	__( 'Advanced Settings', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Number of Particles', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Particle Size', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Move Speed', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Enable Hover Effect', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Add custom JSON for the Particle Background. Please follow below steps:', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( '- Please visit this link ', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'here', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( ' and choose required attributes for particle', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( '- Copy JSON code and paste below.', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Particle hover effect will not work in the following scenarios:', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( '- In the builder area.', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( '- Content added in the section occupies the entire space and leaves it inaccessible.', 'seedprod-pro' ),

	// Reference: src/components/ParticlesBackgroundControl.vue
	__( 'Note: Increasing the number of particles can slow down your page.', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	__( 'Submit Button', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	__( 'Success Action', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	__( 'Form', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	__( 'Required', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	__( 'Input Sizes', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	__( 'Action To Take', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/CountdownOptions.vue
	__( 'Show Message', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/CountdownOptions.vue
	__( 'Redirect', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/CountdownOptions.vue
	__( 'Message', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/CountdownOptions.vue
	__( 'Redirect URL', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	__( 'Remove Inline Padding', 'seedprod-pro' ),

	// Reference: src/components/OptinFormOptions.vue
	__( 'Button text', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Edit with AI', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Add with AI', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Please wait for image to upload.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate Image', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate new image', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Your AI Result', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	// Reference: src/components/OpenAIControl.vue
	// Reference: src/components/DynamicTextControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Insert', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate image with AI', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Edit image with AI', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate variations of your image', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Remove the background of your image', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Describe your image prompt.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Input your prompt for image generation.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Describe your full image prompt, not just the erased area.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Provide a detailed prompt for the entire image, including specific instructions for the erased area.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate with a prompt', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Remove Background', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Back', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	// Reference: src/components/OpenAIControl.vue
	__( '---', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Variations', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate Variations', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Edit Image', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Toggle Eraser Mode', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate New Image', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Erase an area on the canvas and enhance it with a prompt. Simply move the mouse and click to begin erasing.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Prompt cannot be blank.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Edit prompt cannot be blank.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Suggested prompts:', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate a futuristic cityscape with flying cars.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate an abstract art piece with vibrant colors and geometric shapes.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Visualize a peaceful beach scene with palm trees and a sunset.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Generate a retro-futuristic scene reminiscent of the 1980s sci-fi movies.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Create a dreamy celestial scene with stars, galaxies, and nebulae.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	__( 'Your patience is appreciated! Expected wait: 45 seconds', 'seedprod-pro' ),

	// Reference: src/components/OpenAIImageControl.vue
	// Reference: src/components/OpenAIControl.vue
	__( 'Credits:', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Generate AI Text', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Generate Text', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write with AI', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Describe your text.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'New Prompt', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Simple Language', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Make it longer', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Make it shorter', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Change text tone', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Translate text to', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Choose Tone', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Choose Language', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write a catchy slogan for ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write a page title for ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Suggest a 5 word headline for ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write an interesting title for ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write a section header for', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( ' ... ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Create a list for ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write about us section for ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write a product description for', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write a short content for ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Write 50 words content for ', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'English', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Chinese', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Swahili', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Bulgarian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Croatian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Serbian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Slovak', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Slovenian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Estonian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Latvian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Lithuanian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Tamil', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Punjabi', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Gujarati', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Telugu', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Marathi', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Kannada', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Malayalam', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Nepali', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Georgian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Armenian', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Azerbaijani', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Kazakh', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Uzbek', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Turkmen', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Kyrgyz', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Tajik', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Professional', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Friendly', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Funny', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Serious', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Excited', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Casual', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Formal', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Analytical', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Instructional', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Sympathetic', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Enthusiastic', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Persuasive', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Optimistic', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Respectful', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Polite', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Sincere', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Encouraging', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Calm', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	// Reference: src/components/AnimationEffectControl.vue
	__( 'Direct', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Confident', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Helpful', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Informative', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Patient', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Conversational', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Empathetic', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Concise', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Courteous', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Thoughtful', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Inspirational', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'An Internal Server error occurred. Please try again later.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'An unexpected error occurred. Please try again later.', 'seedprod-pro' ),

	// Reference: src/components/OpenAIControl.vue
	__( 'Your Patience is Appreciated! Expected wait: 45 seconds', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Active Text Color', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'URL Link', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Mobile Menu', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'On', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Off', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Hover Text Color', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Menu Type', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'WordPress Menu', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu Background Color', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu Border Radius', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu Line Height', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu Border Width', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu Border Color', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu Text Color', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu Hover Color', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Sub Menu Shadow', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Menus', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'Menus Screen', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'to manage your menus', 'seedprod-pro' ),

	// Reference: src/components/NavOptions.vue
	__( 'There are no menus in your site.', 'seedprod-pro' ),

	// Reference: src/components/Nav-Pro.vue
	__( 'There are no navigation menus in your site.', 'seedprod-pro' ),

	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/Mypaykit.vue
	__( 'Select a MyPayKit Form', 'seedprod-pro' ),

	// Reference: src/components/MypaykitOptions.vue
	__( 'Need to make changes?', 'seedprod-pro' ),

	// Reference: src/components/MypaykitOptions.vue
	__( 'Click here to edit the selected payment form.', 'seedprod-pro' ),

	// Reference: src/components/MypaykitOptions.vue
	__( '+ New Payment Form', 'seedprod-pro' ),

	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/EnviraGalleryOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Hide', 'seedprod-pro' ),

	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	__( 'Form Name', 'seedprod-pro' ),

	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	__( 'Form Description', 'seedprod-pro' ),

	// Reference: src/components/MypaykitOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	__( 'Display Options', 'seedprod-pro' ),

	// Reference: src/components/Mypaykit.vue
	__( 'Install MyPayKit Plugin:', 'seedprod-pro' ),

	// Reference: src/components/Mypaykit.vue
	__( 'Install MyPayKit', 'seedprod-pro' ),

	// Reference: src/components/Mypaykit.vue
	__( 'Activate MyPayKit', 'seedprod-pro' ),

	// Reference: src/components/Mypaykit.vue
	__( 'MyPayKit', 'seedprod-pro' ),

	// Reference: src/components/Mypaykit.vue
	__( 'You can use MyPayKit to build payment forms in minutes and collect payments.', 'seedprod-pro' ),

	// Reference: src/components/Modal.vue
	__( 'default header', 'seedprod-pro' ),

	// Reference: src/components/Modal.vue
	__( 'default body', 'seedprod-pro' ),

	// Reference: src/components/MenuCartOptions.vue
	__( 'Hide on Empty', 'seedprod-pro' ),

	// Reference: src/components/MenuCartOptions.vue
	__( 'Show Subtotal', 'seedprod-pro' ),

	// Reference: src/components/MenuCartOptions.vue
	__( 'Badge Color', 'seedprod-pro' ),

	// Reference: src/components/MenuCartOptions.vue
	__( 'Badge Text Color', 'seedprod-pro' ),

	// Reference: src/components/MenuCart-Pro.vue
	__( 'Menu Cart Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/MarginControl.vue
	__( 'Margin', 'seedprod-pro' ),

	// Reference: src/components/MarginControl.vue
	__( 'auto', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Label for User field', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Placeholder for User field', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Label for Password field', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Placeholder for Password field', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Link Hover Color', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Label Text Color', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Button Background Color', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Field Size', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Label Spacing', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Additional Options', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Remember User Label', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Lost Password Link Text', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Label Font Weight', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Field Font', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Field Font Weight', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Button Font Weight', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Logged In Text', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Field Width', 'seedprod-pro' ),

	// Reference: src/components/LoginOptions.vue
	__( 'Label Text Size', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'Username or Email Address', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'Get New Password', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'New password', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'Hide password', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'Strength indicator', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'Confirm use of weak password', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'Confirm new password', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'Reset Password', 'seedprod-pro' ),

	// Reference: src/components/Login-Pro.vue
	__( 'Back to Log In', 'seedprod-pro' ),

	// Reference: src/components/LiteCTAUpgrade.vue
	__( 'Upgrade to get the', 'seedprod-pro' ),

	// Reference: src/components/LiteCTAUpgrade.vue
	__( 'is not available on your plan.<br>Please upgrade your license to unlock this feature.', 'seedprod-pro' ),

	// Reference: src/components/LiteCTAUpgrade.vue
	__( 'Upgrade Your SeedProd License', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'More Premium Blocks', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'Capture Emails and Leads', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'Marketing & CRM Integrations', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'Maintenance Access Controls', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'Growing Library of Templates', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'Smart Sections', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'More Design Controls', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'Coming Soon Access Controls', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'Templates are a PRO Feature', 'seedprod-pro' ),

	// Reference: src/components/LiteCTATemplates.vue
	__( 'Not all Templates are not available on your plan. Please upgrade to the PRO version to unlock all these awesome features.', 'seedprod-pro' ),

	// Reference: src/components/LiteCTASubscribers.vue
	__( 'Start Collecting Emails with SeedProd Pro', 'seedprod-pro' ),

	// Reference: src/components/LiteCTASubscribers.vue
	__( 'Use our Optin Form Block to start collecting emails from your visitors. All collected emails will show up on this page. Integrate with any of the Email Service Providers below.', 'seedprod-pro' ),

	// Reference: src/components/LiteCTABuilder.vue
	__( 'is a PRO Feature', 'seedprod-pro' ),

	// Reference: src/components/LiteCTABuilder.vue
	__( 'is not available on your plan. Please upgrade to the PRO version to unlock all these awesome features.', 'seedprod-pro' ),

	// Reference: src/components/ListTable.vue
	__( 'Loading', 'seedprod-pro' ),

	// Reference: src/components/ListTable.vue
	// Reference: src/components/ListTable.vue
	// Reference: src/components/ListTable.vue
	__( 'Select bulk action', 'seedprod-pro' ),

	// Reference: src/components/ListTable.vue
	__( 'Bulk Actions', 'seedprod-pro' ),

	// Reference: src/components/ListTable.vue
	__( 'items', 'seedprod-pro' ),

	// Reference: src/components/ListTable.vue
	__( 'No items found.', 'seedprod-pro' ),

	// Reference: src/components/ImageOptions.vue
	__( 'Link Type', 'seedprod-pro' ),

	// Reference: src/components/ImageOptions.vue
	__( 'Media - Lightbox', 'seedprod-pro' ),

	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/HotspotOptions.vue
	__( 'Object Fit', 'seedprod-pro' ),

	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/HotspotOptions.vue
	__( 'Fill', 'seedprod-pro' ),

	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Cover', 'seedprod-pro' ),

	// Reference: src/components/ImageOptions.vue
	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Contain', 'seedprod-pro' ),

	// Reference: src/components/ImageOptions.vue
	__( 'Border Radius Unit', 'seedprod-pro' ),

	// Reference: src/components/ImageOptions.vue
	__( 'Rotate Image', 'seedprod-pro' ),

	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Choose New Image', 'seedprod-pro' ),

	// Reference: src/components/ImageMultipleControl.vue
	__( 'Add Gallery Images', 'seedprod-pro' ),

	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Own Image', 'seedprod-pro' ),

	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Stock Images Library', 'seedprod-pro' ),

	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Use a', 'seedprod-pro' ),

	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Stock Image', 'seedprod-pro' ),

	// Reference: src/components/ImageMultipleControl.vue
	// Reference: src/components/ImageControl.vue
	__( 'Search images...', 'seedprod-pro' ),

	// Reference: src/components/ImageMultipleControl.vue
	__( 'Insert Media', 'seedprod-pro' ),

	// Reference: src/components/ImageControl.vue
	__( 'Use Your', 'seedprod-pro' ),

	// Reference: src/components/ImageControl.vue
	__( 'Select Image', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Banner Header Color', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Banner Subheader Color', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Add Images', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Carousel Images', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Show Caption', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Show Slider Navigation', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Caption Typography', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Banner Header Typography', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Banner Subheader Typography', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Banner Button Typography', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Show Button', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Sub Header', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Button Link', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Show Header Text', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Header Tag', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'h1', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'h2', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'h3', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'h4', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'h5', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'h6', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Carousel Banner Settings', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Vertical Position', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Horizontal Position', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Banner Button Radius', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Banner Button Color', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Header Text Align', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Subheader Text Align', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Carousel Button Align', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Header Animation Effects', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Sub Header Animation Effects', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Button Animation Effects', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Image Overlay Color', 'seedprod-pro' ),

	// Reference: src/components/ImageCarouselOptions.vue
	__( 'Image Overlay Opacity', 'seedprod-pro' ),

	// Reference: src/components/IconPicker.vue
	__( 'All Icons', 'seedprod-pro' ),

	// Reference: src/components/IconPicker.vue
	__( 'Font Awesome', 'seedprod-pro' ),

	// Reference: src/components/IconPicker.vue
	__( 'Search icons...', 'seedprod-pro' ),

	// Reference: src/components/IconPicker.vue
	__( 'Icon Library', 'seedprod-pro' ),

	// Reference: src/components/IconFeatureOptions.vue
	__( 'Icon Gap', 'seedprod-pro' ),

	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Header Text', 'seedprod-pro' ),

	// Reference: src/components/IconFeatureOptions.vue
	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/FeatureOptions.vue
	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Level', 'seedprod-pro' ),

	// Reference: src/components/Icon-Pro.vue
	__( 'Select an Icon', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Tooltip Content', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Add Hotspot', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Hotspot', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Max Width', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Custom Icon Size', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Min Width', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Horizontal Orientation', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Vertical Orientation', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Text Wrap', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Tooltip', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Trigger', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Click', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Animation', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Fade', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Grow', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/AnimationEffectControl.vue
	__( 'Swing', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Slide', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Duration', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Fall', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Icon Position', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Soft Beat', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Expand', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Hotspot Animation', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	__( 'Show Arrow', 'seedprod-pro' ),

	// Reference: src/components/HotspotOptions.vue
	// Reference: src/components/HotspotOptions.vue
	__( 'Add Your Tooltip Text Here', 'seedprod-pro' ),

	// Reference: src/components/HeaderOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Headline', 'seedprod-pro' ),

	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/GoogleMaps-Pro.vue
	__( 'Google Maps', 'seedprod-pro' ),

	// Reference: src/components/GoogleMapsOptions.vue
	__( 'Location', 'seedprod-pro' ),

	// Reference: src/components/GoogleMapsOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Zoom', 'seedprod-pro' ),

	// Reference: src/components/GoogleMapsOptions.vue
	__( 'Height (px)', 'seedprod-pro' ),

	// Reference: src/components/GoogleMapsOptions.vue
	__( 'Width (%)', 'seedprod-pro' ),

	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/GiveawayOptions.vue
	// Reference: src/components/Giveaway.vue
	__( 'Select a Giveaway', 'seedprod-pro' ),

	// Reference: src/components/GiveawayOptions.vue
	__( 'Need to make changes? Edit the selected giveaway.', 'seedprod-pro' ),

	// Reference: src/components/GiveawayOptions.vue
	__( '+ New Giveaway', 'seedprod-pro' ),

	// Reference: src/components/Giveaway.vue
	__( 'Install Giveaway plugin:', 'seedprod-pro' ),

	// Reference: src/components/Giveaway.vue
	__( 'Install RafflePress', 'seedprod-pro' ),

	// Reference: src/components/Giveaway.vue
	__( 'Activate RafflePress', 'seedprod-pro' ),

	// Reference: src/components/Giveaway.vue
	__( 'Giveaway', 'seedprod-pro' ),

	// Reference: src/components/Giveaway.vue
	__( 'You can use RafflePress to build viral giveaways in minutes and explode your email list.', 'seedprod-pro' ),

	// Reference: src/components/Form-Pro.vue
	__( 'Submit', 'seedprod-pro' ),

	// Reference: src/components/FontVariantControl.vue
	__( 'Select a Font Weight', 'seedprod-pro' ),

	// Reference: src/components/FontVariantControl.vue
	__( 'Normal 400', 'seedprod-pro' ),

	// Reference: src/components/FontVariantControl.vue
	__( 'Bold 700', 'seedprod-pro' ),

	// Reference: src/components/FontControl.vue
	__( 'Standard Fonts', 'seedprod-pro' ),

	// Reference: src/components/FontControl.vue
	__( 'Google Fonts', 'seedprod-pro' ),

	// Reference: src/components/FontAwesomePicker.vue
	__( 'Click to select an icon', 'seedprod-pro' ),

	// Reference: src/components/FontAwesomePicker.vue
	__( 'Search icons', 'seedprod-pro' ),

	// Reference: src/components/FacebookSettings.vue
	__( 'Change App Id', 'seedprod-pro' ),

	// Reference: src/components/FacebookPageOptions.vue
	__( 'Small Header', 'seedprod-pro' ),

	// Reference: src/components/FacebookPageOptions.vue
	__( 'Hide Cover Photo', 'seedprod-pro' ),

	// Reference: src/components/FacebookPageOptions.vue
	__( 'Profile Photos', 'seedprod-pro' ),

	// Reference: src/components/FacebookPageOptions.vue
	__( 'Hide CTA button', 'seedprod-pro' ),

	// Reference: src/components/FacebookPageOptions.vue
	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookEmbedOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Facebook Setting', 'seedprod-pro' ),

	// Reference: src/components/FacebookPageOptions.vue
	__( 'Timeline', 'seedprod-pro' ),

	// Reference: src/components/FacebookPageOptions.vue
	__( 'Events', 'seedprod-pro' ),

	// Reference: src/components/FacebookPageOptions.vue
	__( 'Messages', 'seedprod-pro' ),

	// Reference: src/components/FacebookLikeOptions.vue
	__( 'Share Button', 'seedprod-pro' ),

	// Reference: src/components/FacebookLikeOptions.vue
	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Faces', 'seedprod-pro' ),

	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Include full post', 'seedprod-pro' ),

	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Allow Full Screen', 'seedprod-pro' ),

	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Captions', 'seedprod-pro' ),

	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Parent Comment', 'seedprod-pro' ),

	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Post Link', 'seedprod-pro' ),

	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Video Link', 'seedprod-pro' ),

	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Comment Link', 'seedprod-pro' ),

	// Reference: src/components/FacebookEmbedOptions.vue
	__( 'Comment', 'seedprod-pro' ),

	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Lazy Loading', 'seedprod-pro' ),

	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Social', 'seedprod-pro' ),

	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Reverse Time', 'seedprod-pro' ),

	// Reference: src/components/FacebookCommentsOptions.vue
	__( 'Number of Comments', 'seedprod-pro' ),

	// Reference: src/components/EnviraGalleryOptions.vue
	__( 'Select Gallery', 'seedprod-pro' ),

	// Reference: src/components/EnviraGalleryOptions.vue
	// Reference: src/components/ContactFormOptions.vue
	__( 'Select', 'seedprod-pro' ),

	// Reference: src/components/EnviraGalleryOptions.vue
	__( '+ New Gallery', 'seedprod-pro' ),

	// Reference: src/components/EnviraGalleryOptions.vue
	__( 'Image Limit', 'seedprod-pro' ),

	// Reference: src/components/EnviraGalleryOptions.vue
	__( 'Gallery', 'seedprod-pro' ),

	// Reference: src/components/EnviraGalleryOptions.vue
	__( 'Image Options', 'seedprod-pro' ),

	// Reference: src/components/EnviraGallery.vue
	__( 'Install Envira Gallery plugin:', 'seedprod-pro' ),

	// Reference: src/components/EnviraGallery.vue
	__( 'Install Envira', 'seedprod-pro' ),

	// Reference: src/components/EnviraGallery.vue
	__( 'Activate Envira', 'seedprod-pro' ),

	// Reference: src/components/EnviraGallery.vue
	__( 'Select a gallery', 'seedprod-pro' ),

	// Reference: src/components/EnviraGallery.vue
	__( 'You can use your Envira gallery from this block.', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'If orderby is set to random, pagination will be disabled to prevent subsequent pages from showing already-displayed products.', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Number', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Post Date(Default)', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Current Page Color', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Relation', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( '- Select Relation -', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'OR', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'AND', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Specify whether the downloads displayed have to be in ALL the categories/tags provided, or just in at least one.', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( 'Show Price', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Show Full Content', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Show Buy Button', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGridOptions.vue
	__( 'Show Thumbnails', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadsGrid-Pro.vue
	__( 'Downloads Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadTitle-Pro.vue
	__( 'EDD Download Title Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadPrice-Pro.vue
	__( 'Download Price Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadInstructions-Pro.vue
	__( 'Download Instructions Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadFeaturedImage-Pro.vue
	__( 'EDD Download Featured Image Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadExcerpt-Pro.vue
	__( 'Download Excerpt Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDDownloadContent-Pro.vue
	__( 'Download Content Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Total Color', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Cart Item Color', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Cart Links Color', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Payments Border Color', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Payments Border Radius', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Item Typography', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckoutOptions.vue
	// Reference: src/components/EDDCartOptions.vue
	__( 'Total Typography', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckoutOptions.vue
	__( 'Payments Border Width', 'seedprod-pro' ),

	// Reference: src/components/EDDCheckout-Pro.vue
	__( 'Download Checkout Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDCartOptions.vue
	__( 'Product Text Color', 'seedprod-pro' ),

	// Reference: src/components/EDDCartOptions.vue
	__( 'Price Text Color', 'seedprod-pro' ),

	// Reference: src/components/EDDCartOptions.vue
	__( 'Total Text Color', 'seedprod-pro' ),

	// Reference: src/components/EDDCartOptions.vue
	__( 'Links Color', 'seedprod-pro' ),

	// Reference: src/components/EDDCartOptions.vue
	__( 'Product Typography', 'seedprod-pro' ),

	// Reference: src/components/EDDCart-Pro.vue
	__( 'Download Cart Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/EDDBuyNowButtonOptions.vue
	// Reference: src/components/EDDAddToCartOptions.vue
	__( '- Select ID -', 'seedprod-pro' ),

	// Reference: src/components/EDDBuyNowButton-Pro.vue
	__( 'Buy Now Button Preview Not Available. Please Select Product.', 'seedprod-pro' ),

	// Reference: src/components/EDDAddToCart-Pro.vue
	__( 'Download Add To Cart Preview Not Available. Please Select Product.', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	// Reference: src/components/DynamicTextControl.vue
	__( 'Please enter parameter name', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Please enter date/time format', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Please select date/time format', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Dynamic Text Replacement', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'DateTime', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Query Parameter', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Today', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Tomorrow', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Today Date', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Tomorrow Date', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Month', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Next Month', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Year', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Select Date Time Format', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Query Parameters', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'Parameter Name', 'seedprod-pro' ),

	// Reference: src/components/DynamicTextControl.vue
	__( 'Default Value', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Insert Dynamic Tags', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Add Dynamic Tags', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Select Tag', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Select Key', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Custom Key', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( '- Select -', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Please select a tag', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/Archivetitle-Pro.vue
	__( 'Archive Title', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'ACF Field', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Archive', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Categories', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Select Taxonomy', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'e.g. ,', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Show Advanced Settings', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Fallback', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post Published', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post Modified', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Format', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'F j, Y', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Y-m-d', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'm/d/Y', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'd/m/Y', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'e.g. Y-m-d', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Meta Key', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Include Context', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Show Home Title', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'g:i a', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'g:i A', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	// Reference: src/components/DynamicTagsControl.vue
	__( 'H:i', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Custom Format', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'e.g. Y-m-d g:i a', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Get', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Query Var', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Username', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'First Name', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Last Name', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Bio', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'User Meta', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Data', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'File URL', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Attachment URL', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'No Comments Format', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'One Comment Format', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Many Comments Format', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Comments Link', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'e.g. g:i a', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post ID', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post Date', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post Time', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post Title', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post Excerpt', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post Terms', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Post Custom Field', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Archive Meta', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Archive Description', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Page Title', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Site Tagline', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Site Title', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Site Logo', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Current Date Time', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Request Parameter', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'User Info', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Featured Image Data', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Author Info', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Author Meta', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Author Name', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Author Profile Picture', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'User Profile Picture', 'seedprod-pro' ),

	// Reference: src/components/DynamicTagsControl.vue
	__( 'Comments Number', 'seedprod-pro' ),

	// Reference: src/components/DividerOptions.vue
	__( 'Solid Line', 'seedprod-pro' ),

	// Reference: src/components/DividerOptions.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Double', 'seedprod-pro' ),

	// Reference: src/components/DividerOptions.vue
	__( 'Add Element', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	__( 'Z-Index', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	__( 'Static', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Relative', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Fixed', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	__( 'Absolute', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	__( 'Sticky', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	__( 'Offset', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	__( 'Overflow', 'seedprod-pro' ),

	// Reference: src/components/DisplaySectionControl.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Scroll', 'seedprod-pro' ),

	// Reference: src/components/DeviceVisibilityControl.vue
	__( 'Device Visibility', 'seedprod-pro' ),

	// Reference: src/components/DeviceVisibilityControl.vue
	__( 'Hide on Desktop', 'seedprod-pro' ),

	// Reference: src/components/DeviceVisibilityControl.vue
	__( 'Hide on Mobile', 'seedprod-pro' ),

	// Reference: src/components/DeviceVisibilityControl.vue
	__( 'Hide on Tablet', 'seedprod-pro' ),

	// Reference: src/components/CustomHTMLOptions.vue
	__( 'Custom Code', 'seedprod-pro' ),

	// Reference: src/components/CustomHTMLOptions.vue
	__( 'Edit Custom HTML', 'seedprod-pro' ),

	// Reference: src/components/CustomHTML.vue
	__( 'Enter Your HTML', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Starting Number', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Ending Number', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Number Prefix', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Number Suffix', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Animation Duration', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Thousands Separator', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Dot', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Title Text Color', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Number Text Color', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Number Align', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	// Reference: src/components/AlertBoxOptions.vue
	__( 'Title Align', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Number Shadow', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Title Shadow', 'seedprod-pro' ),

	// Reference: src/components/CounterOptions.vue
	__( 'Number Typography', 'seedprod-pro' ),

	// Reference: src/components/Counter-Pro.vue
	__( 'Counter Block', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Countdown Type', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Visitor Timer (Evergreen)', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'DateTime Countdown', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Set Timer For', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'End Date', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Timezone', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Action To Take On Expires', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Customize Labels', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Day Label', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Hour Label', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Minute Label', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Second Label', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Hours', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Minutes', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Seconds', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Highlight Color', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Restart', 'seedprod-pro' ),

	// Reference: src/components/CountdownOptions.vue
	__( 'Select Date', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Heading 1', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Heading 2', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Content Area 1', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Content Area 2', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Toggle', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Content 1', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Content 2', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Before Label', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'After Label', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Templates Parts', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Section Content', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	// Reference: src/components/AlignControl.vue
	__( 'Align', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'First Background Color', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Second Background Color', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Switcher Color', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Heading 1 Color', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Heading 2 Color', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Content 1 Color', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Content 2 Color', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Orientation', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Slider Orientation', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Move on Hover', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Comparison Handle', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Handle Initial Offset', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Handle Color', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Handle Thickness', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Circle Width', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Circle Radius', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Triangle Size', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Heading / Content', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Switcher', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Switch Style', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Round', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Square', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Label Box', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Switch Size', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Mini', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Loading Template Parts...', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Header 1 Typography', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Header 2 Typography', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Content 1 Typography', 'seedprod-pro' ),

	// Reference: src/components/ContentToggleOptions.vue
	__( 'Content 2 Typography', 'seedprod-pro' ),

	// Reference: src/components/ContactFormOptions.vue
	// Reference: src/components/ContactForm.vue
	__( 'Select a Form', 'seedprod-pro' ),

	// Reference: src/components/ContactFormOptions.vue
	__( 'Need to make changes? Edit the selected form.', 'seedprod-pro' ),

	// Reference: src/components/ContactFormOptions.vue
	__( '+ New Form', 'seedprod-pro' ),

	// Reference: src/components/ContactForm.vue
	__( 'Install Contact Form plugin:', 'seedprod-pro' ),

	// Reference: src/components/ContactForm.vue
	__( 'Install WPForms', 'seedprod-pro' ),

	// Reference: src/components/ContactForm.vue
	__( 'Activate WPForms', 'seedprod-pro' ),

	// Reference: src/components/ContactForm.vue
	__( 'You can use WPForms to build contact forms, surveys, payment forms, and more with just a few clicks.', 'seedprod-pro' ),

	// Reference: src/components/ColorPicker.vue
	__( 'Global Colors', 'seedprod-pro' ),

	// Reference: src/components/ColorPicker.vue
	__( 'Common Colors', 'seedprod-pro' ),

	// Reference: src/components/ColorPicker.vue
	__( 'Recently Used', 'seedprod-pro' ),

	// Reference: src/components/ColorPicker.vue
	__( 'Global Theme Colors', 'seedprod-pro' ),

	// Reference: src/components/ColOptions.vue
	__( 'Column Width', 'seedprod-pro' ),

	// Reference: src/components/ButtonOptions.vue
	__( 'The border color is required for the border width to take effect.', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Review Source', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Google Places', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Yelp', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Google & Yelp', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Google Place ID', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Yelp Business ID', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Language Code', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Reload Reviews', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Hour', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Day', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Week', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Filters', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Filter By', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'No Filter', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Review Date', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Minimum Rating', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( '2 star', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( '3 star', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( '4 star', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( '5 star', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'No Minimum Rating', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Reviewer Info', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Reviewer Image', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Above Name', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Left of Name', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Left of all content', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Reviewer Name', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Link Name', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Review Date Color', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Numeric', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Reviewer Name Color', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Unmasked Icon Color', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Review Text', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Text Length', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Read More Color', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Date Color', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Content Color', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'No of Reviews', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Select Layout', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Please add Google Places API Key ', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'You are connected to Google Places API Key', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Please add Yelp API Key ', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( ' here ', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'You are connected to Yelp API Key', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Google allows maximum 5 reviews.', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Yelp allows maximum 3 reviews.', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Google + Yelp allows maximum 8 reviews total.', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Click here', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( ' to find your Google Place ID.', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( ' to check your Language code.', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( ' to find your Yelp Business ID.', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Reviewer Name Typography', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Review Date Typography', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviewsOptions.vue
	__( 'Loading Business Review.', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviews-Pro.vue
	__( 'Review Not Available', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviews-Pro.vue
	// Reference: src/components/BusinessReviews-Pro.vue
	__( 'Loading Reviews...', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviews-Pro.vue
	__( ' Please add Google Places API Key. ', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviews-Pro.vue
	__( ' Please add Google Places Id. ', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviews-Pro.vue
	__( ' Please add Yelp API Key. ', 'seedprod-pro' ),

	// Reference: src/components/BusinessReviews-Pro.vue
	__( ' Please add Yelp Business Id. ', 'seedprod-pro' ),

	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Business Days and Timing', 'seedprod-pro' ),

	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Enter Day', 'seedprod-pro' ),

	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Enter Time', 'seedprod-pro' ),

	// Reference: src/components/BusinessHoursOptions.vue
	__( 'Time Typography', 'seedprod-pro' ),

	// Reference: src/components/BulletListOptions.vue
	__( 'List', 'seedprod-pro' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Before Image', 'seedprod-pro' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'After Image', 'seedprod-pro' ),

	// Reference: src/components/BeforeAfterToggleOptions.vue
	__( 'Before / After Label Styles', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Background Style', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Background Position', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Full Screen Cover - Fixed', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( '100% Width Top', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	// Reference: src/components/BackgroundControl.vue
	__( 'Repeat', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Repeat Horizontal Top', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Repeat Horizontal Bottom', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Repeat Vertical Center', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( '100% Width Bottom', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Custom Position', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Background Image', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Full Screen Contain - Fixed', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Full Screen Cover', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Full Screen Contain', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'X Position', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Y Position', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'No-repeat', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Repeat-x', 'seedprod-pro' ),

	// Reference: src/components/BackgroundControl.vue
	__( 'Repeat-y', 'seedprod-pro' ),

	// Reference: src/components/AttributeSectionControl.vue
	__( 'Attributes', 'seedprod-pro' ),

	// Reference: src/components/AttributeSectionControl.vue
	__( 'Custom Class', 'seedprod-pro' ),

	// Reference: src/components/AttributeSectionControl.vue
	__( 'CSS ID', 'seedprod-pro' ),

	// Reference: src/components/AttributeSectionControl.vue
	__( 'Custom Attributes', 'seedprod-pro' ),

	// Reference: src/components/AttributeSectionControl.vue
	__( 'Add custom attributes to the wrapper element. Enter each attribute on a new line. Use the | character to separate the attribute key and value.', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Animation Effects', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Scrolling Effect', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Mouse Effect', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Vertical Scroll', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AnimationEffectControl.vue
	__( 'Direction', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Speed', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Viewport', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Viewport Top %', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Up', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Down', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Horizontal Scroll', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'To Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'To Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Transparency', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade Out', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Rotate', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Scale Up', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Scale Down', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Mouse Track', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Opposite', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( '3D Tilt', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Entrance Animation', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Select Animation', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fading', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Down', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Up', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Zooming', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Zoom In', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Zoom In Down', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Zoom In Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Zoom In Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Zoom In Up', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Rotating', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Rotate In', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Rotate In Down Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Rotate In Down Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Rotate In Up Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Rotate In Up Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Attention Seekers', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Bounce', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Flash', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Pulse', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Rubber Band', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Shake X', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Shake Y', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Head Shake', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Tada', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Wobble', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Jello', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Heart Beat', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Back In Down', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Back In Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Back In Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Back In Up', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	// Reference: src/components/AnimationEffectControl.vue
	__( 'Bounce In', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Bounce In Down', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Bounce In Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Bounce In Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Bounce In Up', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Down Big', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Left Big', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Right Big', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Up Big', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Top Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Top Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Bottom Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Fade In Bottom Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Flip In X', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Flip In Y', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Light Speed In Left', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Light Speed In Right', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Roll In', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Back In', 'seedprod-pro' ),

	// Reference: src/components/AnimationEffectControl.vue
	__( 'Note: In the preview the animation is applied when you select it. On the live page the animation will be applied when the element is scrolled into view.', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Before Headline', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'After Headline', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Highlighted', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Curly', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Underline', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Double Underline', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Underline Zigzag', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Diagonal', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Strikethrough', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'X', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Typing', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Clip', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Roll', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Light Speed', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Slide Down', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Infinite Loop', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Duration (ms)', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Delay (ms)', 'seedprod-pro' ),

	// Reference: src/components/AnimatedHeadlineOptions.vue
	__( 'Stroke Color', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Alert', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Title Font Size', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Description Font Size', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Title Background', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Dismiss Color', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Show Icon', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Info', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Success', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Danger', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Dismiss Button', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Style 1', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Style 2', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Style 3', 'seedprod-pro' ),

	// Reference: src/components/AlertBoxOptions.vue
	__( 'Style 4', 'seedprod-pro' ),

	// Reference: src/components/AdditionalInformation-Pro.vue
	__( 'Additional Information Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/AddToCartOptions.vue
	__( 'Quantity Typography', 'seedprod-pro' ),

	// Reference: src/components/AddToCart-Pro.vue
	__( 'Add To Cart Preview Not Available', 'seedprod-pro' ),

	// Reference: src/components/AccordionOptions.vue
	__( 'Accordion', 'seedprod-pro' ),

	// Reference: src/components/AccordionOptions.vue
	__( 'Closed Icon Color', 'seedprod-pro' ),

	// Reference: src/components/AccordionOptions.vue
	__( 'Closed Icon', 'seedprod-pro' ),

	// Reference: src/components/AccordionOptions.vue
	__( 'Open Icon Color', 'seedprod-pro' ),

	// Reference: src/components/AccordionOptions.vue
	__( 'Open Icon', 'seedprod-pro' ),

	// Reference: src/components/AccordionOptions.vue
	__( 'Accordion ', 'seedprod-pro' )
);
/* THIS IS THE END OF THE GENERATED FILE */
