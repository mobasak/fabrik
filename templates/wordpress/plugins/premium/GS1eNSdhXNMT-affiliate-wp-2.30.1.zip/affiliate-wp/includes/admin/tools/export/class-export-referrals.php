<?php
/**
 * Tools: Referrals Export Class
 *
 * This class handles exporting referral data.
 *
 * @package     AffiliateWP
 * @subpackage  Tools/Export
 * @copyright   Copyright (c) 2014, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 */

use AffWP\Utils\Exporter;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

#[\AllowDynamicProperties]

/**
 * Affiliate_WP_Export Class
 *
 * @since 1.0
 */
class Affiliate_WP_Referral_Export extends Affiliate_WP_Export implements Exporter\CSV {

	/**
	 * Our export type. Used for export-type specific filters/actions
	 * @var string
	 * @since 1.0
	 */
	public $export_type = 'referrals';

	/**
	 * Date
	 * @var array
	 * @since 1.0
	 */
	public $date;

	/**
	 * Status
	 * @var string
	 * @since 1.0
	 */
	public $status;

	/**
	 * Affiliate ID
	 * @var int
	 * @since 1.0
	 */
	public $affiliate = null;

	/**
	 * Sets the CSV columns.
	 *
	 * @since 1.0
	 * @since 2.6.4 Added the 'type' column.
	 * @since 2.27.9 - Removed translation functions from column headers for consistent export formatting
	 *
	 * @return array All the referrals columns to export.
	 */
	public function csv_cols() {
		$cols = array(
			'affiliate_id'  => 'Affiliate ID',
			'email'         => 'Email',
			'name'          => 'Name',
			'payment_email' => 'Payment Email',
			'username'      => 'Username',
			'amount'        => 'Amount',
			'currency'      => 'Currency',
			'description'   => 'Description',
			'campaign'      => 'Campaign',
			'reference'     => 'Reference',
			'context'       => 'Context',
			'status'        => 'Status',
			'type'          => 'Type',
			'flag'          => 'Flag',
			'date'          => 'Date',
		);
		return $cols;
	}

	/**
	 * Retrieves the data being exported.
	 *
	 * @access public
	 * @since  1.0
	 *
	 * @return array $data Data for Export
	 */
	public function get_data() {

		$args = array(
			'status'       => $this->status,
			'date'         => ! empty( $this->date ) ? $this->date : '',
			'affiliate_id' => $this->affiliate,
			'number'       => -1
		);

		$data         = array();
		$affiliates   = array();
		$referral_ids = array();
		$referrals    = affiliate_wp()->referrals->get_referrals( $args );

		if( $referrals ) {

			foreach( $referrals as $referral ) {

				/**
				 * Filters an individual line of referral data to be exported.
				 *
				 * @since 1.9.5
				 * @since 2.6.4 Added support for exporting the referral type.
				 *
				 * @param array           $referral_data {
				 *     Single line of exported referral data
				 *
				 *     @type int    $affiliate_id  Affiliate ID.
				 *     @type string $email         Affiliate email.
				 *     @type string $payment_email Affiliate payment email.
				 *     @type float  $amount        Referral amount.
				 *     @type string $currency      Referral currency.
				 *     @type string $description   Referral description.
				 *     @type string $campaign      Campaign.
				 *     @type string $reference     Referral reference.
				 *     @type string $context       Context the referral was created under, e.g. 'woocommerce'.
				 *     @type string $status        Referral status.
				 *     @type string $type          Referral type.
				 *     @type string $flag          Referral flag.
				 *     @type string $date          Referral date.
				 * }
				 * @param \AffWP\Referral $referral Referral object.
				 */
				$referral_data = apply_filters( 'affwp_referral_export_get_data_line', array(
					'affiliate_id'  => $referral->affiliate_id,
					'email'         => affwp_get_affiliate_email( $referral->affiliate_id ),
					'name'          => affwp_get_affiliate_name( $referral->affiliate_id ),
					'payment_email' => affwp_get_affiliate_payment_email( $referral->affiliate_id ),
					'username'      => affwp_get_affiliate_login( $referral->affiliate_id ),
					'amount'        => $referral->amount,
					'currency'      => $referral->currency,
					'description'   => $referral->description,
					'campaign'      => $referral->campaign,
					'reference'     => $referral->reference,
					'context'       => $referral->context,
					'status'        => $referral->status,
					'type'          => ! empty( $referral->type ) ? $referral->type : 'sale',
					'flag'          => $referral->flag,
					'date'          => $referral->date_i18n( 'datetime' ),
				), $referral );

				// Add slashing.
				$data[] = array_map( function( $column ) {
					return addslashes( preg_replace( "/\"/","'", $column ) );
				}, $referral_data );

				unset( $referral_data );
			}

		}

		/** This filter is documented in includes/admin/tools/export/class-export.php */
		$data = apply_filters( 'affwp_export_get_data', $data );

		/** This filter is documented in includes/admin/tools/export/class-export.php */
		$data = apply_filters( 'affwp_export_get_data_' . $this->export_type, $data );

		return $data;
	}

}
