<?php
namespace BooklyRatings\Lib\ProxyProviders;

use Bookly\Lib as BooklyLib;

class Shared extends BooklyLib\Proxy\Shared
{
    /**
     * @inheritDoc
     */
    public static function prepareTableColumns( $columns, $table )
    {
        if ( $table == BooklyLib\Utils\Tables::APPOINTMENTS ) {
            $columns['rating'] = __( 'Rating', 'bookly' );
        }

        return $columns;
    }
}