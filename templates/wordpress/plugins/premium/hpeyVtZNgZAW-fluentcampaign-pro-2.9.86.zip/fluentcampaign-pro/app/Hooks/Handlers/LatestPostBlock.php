<?php

namespace FluentCampaign\App\Hooks\Handlers;

class LatestPostBlock
{
    public function register()
    {

    }
}
