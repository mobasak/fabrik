# Languages

## Generating POT

The generated POT template file is not included in this repository. It gets generated when building the project:

```
npm run build
```

After the build completes, you'll find a `woocommerce-subscriptions.pot` strings file in this directory. 