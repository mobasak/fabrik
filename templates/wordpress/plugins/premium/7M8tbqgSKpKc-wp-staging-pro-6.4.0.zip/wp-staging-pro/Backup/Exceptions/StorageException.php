<?php

namespace WPStaging\Backup\Exceptions;

use WPStaging\Framework\Exceptions\WPStagingException;

class StorageException extends WPStagingException
{
}
