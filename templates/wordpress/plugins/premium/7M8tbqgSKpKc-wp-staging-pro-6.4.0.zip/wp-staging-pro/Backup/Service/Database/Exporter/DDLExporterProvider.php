<?php
namespace WPStaging\Backup\Service\Database\Exporter;
use WPStaging\Framework\Database\Exporter\AbstractExporterProvider;
class DDLExporterProvider extends AbstractExporterProvider
{
}
