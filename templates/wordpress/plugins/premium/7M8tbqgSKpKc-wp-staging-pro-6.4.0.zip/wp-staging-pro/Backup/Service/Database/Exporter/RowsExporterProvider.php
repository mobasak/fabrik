<?php
namespace WPStaging\Backup\Service\Database\Exporter;
use WPStaging\Framework\Database\Exporter\AbstractExporterProvider;
class RowsExporterProvider extends AbstractExporterProvider
{
}
