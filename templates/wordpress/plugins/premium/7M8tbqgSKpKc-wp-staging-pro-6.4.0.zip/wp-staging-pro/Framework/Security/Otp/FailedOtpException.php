<?php

namespace WPStaging\Framework\Security\Otp;

/**
 * Class FailedOtpException
 *
 * @package WPStaging\Framework\Security\Otp
 */
class FailedOtpException extends OtpException
{
}
