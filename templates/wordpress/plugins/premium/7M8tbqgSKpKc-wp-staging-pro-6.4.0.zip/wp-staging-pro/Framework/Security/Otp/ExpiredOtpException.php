<?php

namespace WPStaging\Framework\Security\Otp;

/**
 * Class ExpiredOtpException
 *
 * @package WPStaging\Framework\Security\Otp
 */
class ExpiredOtpException extends OtpException
{
}
