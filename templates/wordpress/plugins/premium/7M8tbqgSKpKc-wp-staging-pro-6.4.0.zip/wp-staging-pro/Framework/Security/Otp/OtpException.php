<?php

namespace WPStaging\Framework\Security\Otp;

/**
 * Class OtpException
 *
 * @package WPStaging\Framework\Security\Otp
 */
class OtpException extends \RuntimeException
{
}
