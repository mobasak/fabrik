<?php

namespace WPStaging\Framework\Queue;

use RuntimeException;

class FinishedQueueException extends RuntimeException
{
}
