<?php

namespace WPStaging\Framework\Exceptions;

class RetryException extends WPStagingException
{

}
