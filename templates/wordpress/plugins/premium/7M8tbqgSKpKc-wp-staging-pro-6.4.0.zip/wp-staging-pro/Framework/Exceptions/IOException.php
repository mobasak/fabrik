<?php

namespace WPStaging\Framework\Exceptions;

class IOException extends \Exception
{

}
