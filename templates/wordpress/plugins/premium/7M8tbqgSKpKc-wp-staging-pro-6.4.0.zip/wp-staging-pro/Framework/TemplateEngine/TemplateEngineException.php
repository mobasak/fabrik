<?php

// TODO PHP7.x; declare(strict_types=1);

namespace WPStaging\Framework\TemplateEngine;

use RuntimeException;

class TemplateEngineException extends RuntimeException
{

}
