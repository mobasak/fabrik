<?php

namespace WPStaging\Backend\Modules\Jobs\Exceptions;

class FatalException extends \RuntimeException
{

}
