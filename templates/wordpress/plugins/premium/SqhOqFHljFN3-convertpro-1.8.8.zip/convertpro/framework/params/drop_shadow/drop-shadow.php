<?php
/**
 * Fields.
 *
 * @package ConvertPro
 */

$text_attributes = array(
	'id'      => 'cp_drop_shadow_par',
	'type'    => 'drop_shadow',
	'scripts' => '',
	'styles'  => '',
);

echo wp_json_encode( $text_attributes );
