<?php
/**
 * This file contains the implementation of the specified functionality.
 * 
 * @package ConvertPro
 * @version 1.7.7
 */

return array(
	'packages' => array(
		'wordpress' => array(
			'source' => 'https://github.com/WordPress/WordPress.git',
			'tags'   => array( 'v6.4.3' ),
			'output' => __DIR__ . '/stubs/wordpress',
		),
	),
);
