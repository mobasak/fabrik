<?php
/**
 * Privacy Functions
 *
 * @package     EDD/Message
 * @subpackage  Functions
 * @copyright   Copyright (c) 2018, Easy Digital Downloads, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register any of our Privacy Data Exporters
 *
 * @since 2.9.2
 *
 * @param $exporters
 *
 * @return array
 */
function edd_message_register_privacy_exporters( $exporters ) {

	$exporters[] = array(
		'exporter_friendly_name' => __( 'Customer Messages', 'edd-message' ),
		'callback'               => 'edd_message_privacy_customer_exporter',
	);

	return $exporters;
}
add_filter( 'wp_privacy_personal_data_exporters', 'edd_message_register_privacy_exporters' );

/**
 * Retrieves the Customer messages
 *
 * @param string $email_address
 * @param int    $page
 *
 * @return array
 */
function edd_message_privacy_customer_exporter( $email_address = '', $page = 1 ) {
	$email_addresses = array( $email_address );
	$customer        = new EDD_Customer( $email_address );

	// Only get more customer email addresses if we find an email address for this customer.
	if ( ! empty( $customer->id ) ) {
		$email_addresses = array_merge( $email_addresses, $customer->emails );
	}

	$email_addresses = array_unique( $email_addresses );
	$meta_query      = array( 'relation' => 'OR' );

	foreach ( $email_addresses as $email_address ) {
		$meta_query[] = array(
			'key'     => 'to',
			'value'   =>  $email_address,
			'compare' => 'LIKE',
		);
	}

	$log_query = array(
		'type'       => 'email',
		'offset'     => 30 * ( $page - 1 ), // 30 is default number value in edd_get_logs
		'orderby'    => 'id',
		'meta_query' => $meta_query,
	);

	$logs = edd_get_logs( $log_query );

	if ( empty( $logs ) ) {
		return array(
			'data' => array(),
			'done' => true,
		);
	}

	$export_data = array();
	foreach ( $logs as $log ) {
		$log_data      = edd_message_get_log_data( $log );
		$export_data[] = array(
			'group_id'    => 'edd-message-records',
			'group_label' => __( 'Customer Messages', 'edd-message' ),
			'item_id'     => "edd-message-records-{$log_data['id']}",
			'data'        => array(
				array(
					'name'  => __( 'Customer ID', 'edd-message' ),
					'value' => $log_data['customer_id'],
				),
				array(
					'name'  => __( 'Sent To', 'edd-message' ),
					'value' => implode( ', ', maybe_unserialize( $log_data['to'] ) ),
				),
				array(
					'name'  => __( 'Date Sent', 'edd-message' ),
					'value' => $log_data['date'],
				),
				array(
					'name'  => __( 'Message Subject', 'edd-message' ),
					'value' => $log_data['title'],
				),
				array(
					'name'  => __( 'Message Body', 'edd-message' ),
					'value' => $log_data['content'],
				),
			),
		);
	}

	return array(
		'data' => $export_data,
		'done' => false,
	);
}
