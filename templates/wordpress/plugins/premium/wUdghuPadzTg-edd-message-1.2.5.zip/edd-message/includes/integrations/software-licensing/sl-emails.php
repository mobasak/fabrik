<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds SL related emails to the EDD Message settings for logging
 *
 * @param $options
 * @since 1.2
 * @return mixed
 */
function edd_message_add_sl_logging( $options ) {
	$options['license_renewal_notice'] = __( 'License renewal notices', 'edd-message' );
	return $options;
}
add_filter( 'edd_message_logging_options', 'edd_message_add_sl_logging' );

/**
 * Runs when SL adds the meta for a renewal notice log and stores a full log of the message
 *
 * @todo Deprecate this function when the minimum EDD is 3.3.0.
 * @since 1.2
 * @param $mid
 * @param $object_id
 * @param $meta_key
 */
function edd_message_log_sl_renewal_notices( $mid, $object_id, $meta_key ) {
	if ( 'edd_sl_renewal_notice_id' !== $meta_key ) {
		return;
	}

	if ( class_exists( '\\EDD\\Emails\\Email' ) ) {
		return;
	}

	if ( ! edd_message_maybe_log( 'license_renewal_notice' ) ) {
		return;
	}

	$admin = get_user_by( 'email', get_bloginfo( 'admin_email' ) );
	// License and customer info
	$license        = get_post_meta( $object_id, '_edd_sl_log_license_id', true );
	$license        = new EDD_SL_License( $license );
	$customer_id    = $license->customer_id;
	$customer       = new EDD_Customer( $customer_id );
	$customer_email = $customer->email;
	// Get the renewal notice that was sent.
	$notice_id = get_post_meta( $object_id, '_edd_sl_renewal_notice_id', true );
	$notice    = edd_sl_get_renewal_notice( $notice_id );
	$message   = ! empty( $notice['message'] ) ? $notice['message'] : '';
	$subject   = ! empty( $notice['subject'] ) ? $notice['subject'] : '';

	$args = array(
		'type'        => 'email',
		'message'     => $message,
		'subject'     => $subject,
		'post_author' => $admin->ID,
		'customer_id' => $customer_id,
		'to'          => array( $customer_email ),
		'from_name'   => edd_get_option( 'from_name' ),
		'from_email'  => edd_get_option( 'from_email' ),
	);
	edd_message_log( $args );
}
add_action( 'added_post_meta', 'edd_message_log_sl_renewal_notices', 10, 3 );

/**
 * Logs the renewal notices for the software licensing integration in EDD Message plugin.
 *
 * @param bool   $should_send  Whether the renewal notice should be sent or not.
 * @param int    $license_id   The ID of the license.
 * @param int    $notice_id    The ID of the renewal notice.
 * @return bool  Whether the renewal notice should be sent or not.
 */
function edd_message_maybe_log_sl_renewal_notices( $should_send, $license_id, $notice_id ) {
	if ( ! $should_send ) {
		return $should_send;
	}

	if ( ! class_exists( '\\EDD\\Emails\\Email' ) ) {
		return $should_send;
	}

	if ( edd_message_maybe_log( 'license_renewal_notice' ) ) {
		add_action( "edd_email_sent_{$notice_id}", 'edd_message_log_renewal_notice', 10, 2 );
	}

	return $should_send;
}
add_filter( 'edd_sl_send_renewal_reminder', 'edd_message_maybe_log_sl_renewal_notices', 10, 3 );

/**
 * Logs the renewal notice email sent for a specific license.
 *
 * @param EDD\SoftwareLicensing\Emails\Types\Notices $email The email class.
 * @param bool                                       $sent  Whether the renewal notice email was successfully sent or not.
 */
function edd_message_log_renewal_notice( $email, $sent ) {
	if ( ! $sent || ! class_exists( '\\EDD\\Emails\\Email' ) ) {
		return;
	}

	$admin = get_user_by( 'email', get_bloginfo( 'admin_email' ) );

	edd_message_log(
		array(
			'type'        => 'email',
			'message'     => $email->message,
			'subject'     => $email->subject,
			'post_author' => $admin->ID,
			'customer_id' => $email->license->customer_id,
			'to'          => $email->send_to,
			'from_name'   => $email->from_name,
			'from_email'  => $email->from_email,
		)
	);
}
