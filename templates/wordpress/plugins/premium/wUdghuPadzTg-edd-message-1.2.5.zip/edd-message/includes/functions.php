<?php
/**
 * Helper Functions
 *
 * @package     EDD\Message\Functions
 * @since       0.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gets message fields and filters them.
 *
 * @since 1.1
 * @return array
 * @param array $data Possible defaults.
 */
function edd_message_get_message_field_values( $data = array() ) {

	$available_fields = array(
		'emails',
		'from-name',
		'from-email',
		'reply',
		'cc',
		'bcc',
		'subject',
		'message',
	);

	$fields = array_fill_keys( $available_fields, '' );

	foreach ( $available_fields as $field ) {

		if ( isset( $data[ "edd-message-$field" ] ) ) {

			$fields[ $field ] = $data[ "edd-message-$field" ];
		}
	}

	$fields = wp_unslash( $fields );
	/**
	 * Filters the fields before being used in a message.
	 *
	 * @since 1.1
	 */
	$fields = apply_filters( 'edd_message_fields', $fields );

	return $fields;
}

/**
 * Outputs the message from a log.
 *
 * @since 1.1
 * @param mixed $log Log ID or post object.
 */
function edd_message_show_message( $log ) {

	$log_data    = edd_message_get_log_data( $log );
	$log_id      = $log['id'];
	$to          = $log['to'];
	$from        = $log['from'];
	$reply       = $log['reply'];
	$cc          = $log['cc'];
	$bcc         = $log['bcc'];
	$attachments = $log['attachments'];

	if ( ! empty( $to ) ) : ?>
		<div class="edd-message-log-to">
			<strong><?php _e( 'To:', 'edd-message' ); ?></strong>

			<ul>
				<?php foreach ( $to[0] as $recipient ) : ?>
					<li><?php echo esc_attr( $recipient ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $from ) ) : ?>
		<div class="edd-message-log-from">
			<strong><?php _e( 'From:', 'edd-message' ); ?></strong>
			<?php echo esc_attr( $from ); ?>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $reply ) ) : ?>
		<div class="edd-message-log-reply">
			<strong><?php _e( 'Reply to:', 'edd-message' ); ?></strong>
			<?php echo esc_attr( $reply ); ?>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $cc ) ) : ?>
		<div class="edd-message-log-cc">
			<strong><?php _e( 'CC:', 'edd-message' ); ?></strong>
			<?php echo esc_attr( $cc ); ?>
		</div>
	<?php endif; ?>

	<?php if ( ! empty( $bcc ) ) : ?>
		<div class="edd-message-log-bcc">
			<strong><?php _e( 'BCC:', 'edd-message' ); ?></strong>
			<?php echo esc_attr( $bcc ); ?>
		</div>
	<?php endif; ?>

	<div class="edd-message-log-body">
		<strong><?php _e( 'Message body:', 'edd-message' ); ?></strong>

		<?php echo apply_filters( 'the_content', $log->post_content ); ?>
	</div>

	<?php if ( ! empty( $attachments ) ) : ?>
		<div class="edd-message-log-attachments">
			<strong><?php _e( 'Attachments:', 'edd-message' ); ?></strong>
			<ul>
				<?php foreach ( $attachments[0] as $attachment ) : ?>
					<li><?php echo basename( $attachment ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	endif;
}

/**
 * Send a customer message
 *
 * @since  0.1.0
 * @param  array $args The $_POST array being passed
 * @return void
 */
function edd_message_send_message( $args ) {

	if ( empty( $args ) ) {
		return;
	}
	$nonce = $args['add_customer_message_nonce'];

	// All the reasons we might bail because someone messed up...
	if ( ! wp_verify_nonce( $nonce, 'add-customer-message' ) ) {
		wp_die( __( 'Cheatin\' eh?!', 'edd-message' ) );
	}

	if ( ! isset( $args['edd-message-selected-emails'] ) ) {
		edd_set_error( 'empty-customer-recipient', __( 'A recipient is required', 'edd-message' ) );
	}

	if ( empty( $args['edd-message-message'] ) ) {
		edd_set_error( 'empty-customer-message', __( 'A message is required', 'edd-message' ) );
	}

	if ( empty( $args['edd-message-subject'] ) ) {
		edd_set_error( 'empty-customer-subject', __( 'A subject is required', 'edd-message' ) );
	}

	if ( edd_get_errors() ) {
		return;
	}

	// The email select field seems to only want to pass indexes so...
	$addresses = explode( ',', $args['edd-message-emails'] );
	$selected  = $args['edd-message-selected-emails'];
	// Let's get all the addresses and remove the ones that weren't selected
	foreach ( $addresses as $index => $address ) {
		if ( ! in_array( $index, $selected ) ) {
			unset( $addresses[ $index ] );
		}
	}

	$to          = $addresses;
	$message     = stripslashes( do_shortcode( $args['edd-message-message'] ) );
	$subject     = trim( sanitize_text_field( $args['edd-message-subject'] ) );
	$from_name   = trim( sanitize_text_field( $args['edd-message-from-name'] ) );
	$from_email  = sanitize_email( $args['edd-message-from-email'] );
	$reply_to    = sanitize_email( $args['edd-message-reply'] );
	$cc          = trim( sanitize_text_field( $args['edd-message-cc'] ) );
	$bcc         = trim( sanitize_text_field( $args['edd-message-bcc'] ) );
	$customer_id = ! empty( $args['edd-message-customer-id'] ) ? trim( sanitize_text_field( $args['edd-message-customer-id'] ) ) : false;
	$vendor_id   = ! empty( $args['edd-message-vendor-id'] ) ? trim( sanitize_text_field( $args['edd-message-vendor-id'] ) ) : false;
	$attachments = array();

	if ( ! empty( $args['edd_download_files'][1]['file'] ) ) {

		$attachments = wp_list_pluck( $args['edd_download_files'], 'attachment_id' );
		$attachments = array_map( 'get_attached_file', $attachments );
		/**
		 * Allows attachments to be modified before sending. S3 integration is an example.
		 *
		 * @since 1.1
		 */
		$attachments = (array) apply_filters( 'edd_message_attachments', $attachments, $args['edd_download_files'] );
	}

	$email = EDD()->emails;
	$email->__set( 'heading', $subject );
	// Send the message
	$email->send( $to, $subject, $message, $attachments );

	if ( edd_message_maybe_log( 'admin' ) ) {
		// Log the message in edd_logs
		$log_args = array(
			'message'     => $message,
			'subject'     => $subject,
			'to'          => $to,
			'customer_id' => $customer_id,
			'type'        => 'admin',
			'vendor_id'   => $vendor_id,
			'from_email'  => $from_email,
			'from_name'   => $from_name
		);
		if ( ! empty( $reply_to ) ) {
			$log_args['reply_to'] = $reply_to;
		}
		if ( ! empty( $cc ) ) {
			$log_args['cc'] = $cc;
		}
		if ( ! empty( $bcc ) ) {
			$log_args['bcc'] = $bcc;
		}
		if ( ! empty( $attachments ) ) {
			$log_args['attachments'] = $attachments;
		}

		edd_message_log( $log_args );
	}

	do_action( 'edd_message_after', $to, $subject, $message, $attachments );

	if ( ! empty( $vendor_id ) ) {
		$base_url = 'admin.php';
		$args     = array(
			'page'        => 'fes-vendors',
			'view'        => 'message',
			'id'          => urlencode( $vendor_id ),
			'edd_message' => 'success',
		);
		// FES Vendor pages have moved in FES 2.7.
		if ( version_compare( fes_plugin_version, '2.7', '>=' ) ) {
			$args['post_type'] = 'download';
			$base_url          = 'edit.php';
		}
		$redirect = add_query_arg( $args, admin_url( $base_url ) );
	} else {
		$redirect = add_query_arg(
			array(
				'post_type'   => 'download',
				'page'        => 'edd-customers',
				'view'        => 'messages',
				'id'          => urlencode( $customer_id ),
				'edd_message' => 'success',
			),
			admin_url( 'edit.php' )
		);
	}
	wp_safe_redirect( esc_url_raw( $redirect ) );
	exit;
}
add_action( 'edd_add-customer-message', 'edd_message_send_message', 10, 1 );

/**
 * Define "From" name on email
 *
 * @param $name
 * @since 1.0
 * @return string|void
 */
function edd_message_from_name( $name ) {

	if ( empty( $_POST['edd-message-from-name'] ) ) {
		return $name;
	}

	$from = wp_unslash( trim( sanitize_text_field( $_POST['edd-message-from-name'] ) ) );

	return $from;
}

add_filter( 'edd_email_from_name', 'edd_message_from_name' );

/**
 * Define "From" email address on message
 *
 * @param $email
 * @since 1.0
 * @return string|void
 */
function edd_message_from_email( $email ) {

	if ( empty( $_POST['edd-message-from-email'] ) || ! is_email( $_POST['edd-message-from-email'] ) ) {
		return $email;
	}

	$email = $_POST['edd-message-from-email'];

	return $email;
}

add_filter( 'edd_email_from_address', 'edd_message_from_email' );

/**
 * Set reply to header on email
 *
 * @param $headers
 * @since 1.0
 * @return string|void
 */
function edd_message_reply_to( $headers ) {

	if ( empty( $_POST['edd-message-reply'] ) || ! is_email( $_POST['edd-message-from-email'] ) ) {
		return $headers;
	}

	$reply_to = trim( sanitize_text_field( $_POST['edd-message-reply'] ) );
	$headers  = $headers . "Reply-To: $reply_to\r\n";

	return $headers;
}

add_filter( 'edd_email_headers', 'edd_message_reply_to' );

/**
 * Add CC to message
 *
 * @param $headers
 * @since 1.0
 * @return string|void
 */
function edd_message_cc( $headers ) {

	if ( empty( $_POST['edd-message-cc'] ) ) {
		return $headers;
	}

	$cc      = trim( sanitize_text_field( $_POST['edd-message-cc'] ) );
	$headers = $headers . "Cc: $cc\r\n";

	return $headers;
}

add_filter( 'edd_email_headers', 'edd_message_cc' );

/**
 * Add BCC to message
 *
 * @param $headers
 * @since 1.0
 * @return string|void
 */
function edd_message_bcc( $headers ) {

	if ( empty( $_POST['edd-message-bcc'] ) ) {
		return $headers;
	}

	$bcc     = trim( sanitize_text_field( $_POST['edd-message-bcc'] ) );
	$headers = $headers . "Bcc: $bcc\r\n";

	return $headers;
}

add_filter( 'edd_email_headers', 'edd_message_bcc' );

/**
 * Gets the message log data from a log or post object and returns what's necessary as an array.
 *
 * @since 1.2.2
 * @param EDD\Logs\Log $log Log object.
 * @return array
 */
function edd_message_get_log_data( $log ) {
	$id = $log->id;
	return array(
		'id'          => $id,
		'title'       => $log->title,
		'date'        => edd_date_i18n( $log->date_created, 'datetime' ),
		'content'     => $log->content,
		'to'          => edd_get_log_meta( $id, 'to', true ),
		'sent_by'     => ! empty( $log->user_id ) ? $log->user_id : edd_get_log_meta( $id, 'sent_by', true ),
		'customer_id' => edd_get_log_meta( $id, 'customer_id', true ),
		'from'        => edd_get_log_meta( $id, 'from', true ),
		'reply'       => edd_get_log_meta( $id, 'reply_to', true ),
		'cc'          => edd_get_log_meta( $id, 'cc', true ),
		'bcc'         => edd_get_log_meta( $id, 'bcc', true ),
		'attachments' => edd_get_log_meta( $id, 'attachments' ),
	);
}