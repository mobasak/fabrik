<?php

/**
 * Add Messages to the EDD Customer Interface
 *
 * @since       0.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add the messages tab to the customer interface
 *
 * @since  0.1.0
 * @param  array $tabs The tabs currently added to the customer view
 * @return array       Updated tabs array
 */
function edd_message_customer_tab( $tabs ) {

	$tabs['messages'] = array(
		'dashicon' => 'dashicons-email-alt',
		'title'    => __( 'Messages', 'edd-message' ),
	);

	return $tabs;
}

add_filter( 'edd_customer_tabs', 'edd_message_customer_tab', 10, 1 );

/**
 * Register the messages view for the customer interface
 *
 * @since  0.1.0
 * @param  array $views The tabs currently added to the customer views
 * @return array       Updated tabs array
 */
function edd_message_customer_view( $views ) {
	$views['messages'] = 'edd_message_customer_messages_view';

	return $views;
}

add_filter( 'edd_customer_views', 'edd_message_customer_view', 10, 1 );

/**
 * Display the messages area for the customer view
 *
 * @since  0.1.0
 * @param  object $customer The Customer being displayed
 * @return void
 */
function edd_message_customer_messages_view( $customer ) {

	$message = ! empty( $_GET['edd_message'] ) ? sanitize_text_field( $_GET['edd_message'] ) : '';
	if ( empty( $_POST['edd-message-customer-id'] ) && 'success' === $message ) {
		?>
		<div class="notice updated is-dismissible">
			<p><?php esc_html_e( 'Message sent successfully.', 'edd-message' ); ?></p>
		</div>
		<?php
	}

	$customer_emails = ( isset( $customer->emails ) ) ? $customer->emails : array( $customer->email );
	$customer_id     = $customer->id;

	$field_values = edd_message_get_message_field_values( $_POST );
	?>
	<div class="edd-message">
		<?php
		if ( $customer instanceof EDD_Customer ) {
			edd_render_customer_details_header( $customer );
		} else {
			?>
			<div class="edd-item-header-small edd-item-message-header">
				<?php echo get_avatar( $customer->email, 30 ); ?> <span><?php echo esc_html( $customer->name ); ?></span>
			</div>
		<?php } ?>
		<h3><?php esc_html_e( 'Messages', 'edd-message' ); ?></h3>

		<div id="post-body" class="metabox-holder columns-1" style="display: block; margin-bottom: 35px;">
			<form id="edd-add-customer-message" method="post">
				<div class="edd-message-fields">
					<label class="edd-label" for="edd-message-selected-emails[]"><?php esc_html_e( 'To', 'edd-message' ) ?></label>
					<?php
					echo EDD()->html->select(
						array(
							'id'               => 'edd-message-selected-emails',
							'name'             => 'edd-message-selected-emails[]',
							'options'          => $customer_emails,
							'multiple'         => true,
							'selected'         => $field_values['emails'],
							'chosen'           => true,
							'show_option_none' => false,
							'show_option_all'  => false,
							'placeholder'      => __( 'Choose one or more email addresses', 'edd-message' ),
							'data'             => array(
								'search-placeholder' => __( 'Type to search all email addresses', 'edd-message' ),
							),
						)
					);
					?>
					<input type="hidden" name="edd-message-emails" value="<?php echo implode( ',', $customer_emails ); ?>"/>
					<label for="edd_message_show_more_fields" class="alignright">
						<?php esc_html_e( 'More fields', 'edd-message' ); ?>
						<input type="checkbox" name="_edd_message_show_more_fields" id="edd_message_show_more_fields" value="1">
					</label>
				</div>
				<div class="edd-message-fields edd-message-more-field">
					<label class="edd-label" for="edd-message-from-name"><?php esc_html_e( 'From name', 'edd-message' ); ?></label>
					<?php
					echo EDD()->html->text(
						array(
							'id'    => 'edd-message-from-name',
							'name'  => 'edd-message-from-name',
							'label' => '',
							'value' => esc_attr( $field_values['from-name'] ),
						)
					);
					?>
				</div>
				<div class="edd-message-fields edd-message-more-field">
					<label class="edd-label" for="edd-message-from-email"><?php esc_html_e( 'From email', 'edd-message' ); ?></label>
					<?php
					echo EDD()->html->text(
						array(
							'id'    => 'edd-message-from-email',
							'name'  => 'edd-message-from-email',
							'label' => '',
							'value' => esc_attr( $field_values['from-email'] ),
						)
					);
					?>
				</div>
				<div class="edd-message-fields edd-message-more-field">
					<label class="edd-label" for="edd-message-reply"><?php esc_html_e( 'Reply to', 'edd-message' ); ?></label>
					<?php
					echo EDD()->html->text(
						array(
							'id'    => 'edd-message-reply',
							'name'  => 'edd-message-reply',
							'label' => '',
							'value' => esc_attr( $field_values['reply'] ),
						)
					);
					?>
				</div>
				<div class="edd-message-fields edd-message-more-field">
					<label class="edd-label" for="edd-message-cc"><?php esc_html_e( 'CC', 'edd-message' ); ?></label>
					<?php
					echo EDD()->html->text(
						array(
							'id'    => 'edd-message-cc',
							'name'  => 'edd-message-cc',
							'label' => '',
							'value' => esc_attr( $field_values['cc'] ),
						)
					);
					?>
				</div>
				<div class="edd-message-fields edd-message-more-field">
					<label class="edd-label" for="edd-message-bcc"><?php esc_html_e( 'BCC', 'edd-message' ); ?></label>
					<?php
					echo EDD()->html->text(
						array(
							'id'    => 'edd-message-bcc',
							'name'  => 'edd-message-bcc',
							'label' => '',
							'value' => esc_attr( $field_values['bcc'] ),
						)
					);
					?>
				</div>
				<div class="edd-message-fields">
					<label class="edd-label" for="edd-message-subject"><?php esc_html_e( 'Subject', 'edd-message' ); ?></label>
					<?php
					echo EDD()->html->text(
						array(
							'id'    => 'edd-message-subject',
							'name'  => 'edd-message-subject',
							'label' => '',
							'value' => esc_attr( $field_values['subject'] ),
						)
					);
					?>
				</div>
				<div class="edd-message-fields">
					<label class="edd-label" for="edd-message-message"><?php esc_html_e( 'Message', 'edd-message' ); ?></label>
					<?php
					wp_editor(
						$field_values['message'],
						'edd-message-message',
						array(
							'teeny'         => true,
							'editor_height' => 140,
						)
					);
					?>
				</div>
				<div class="edd-message-fields">
					<label class="edd-label" for="edd-message-message"><?php esc_html_e( 'Attachments', 'edd-message' ); ?></label>
					<table class="edd_repeatable_table">
						<tbody class="ui-sortable">
						<tr class="edd_repeatable_upload_wrapper edd_repeatable_row">

							<td>
								<input type="hidden" name="edd_download_files[1][index]" class="edd_repeatable_index"
										value="1">
							</td>
							<td>
								<input type="hidden" name="edd_download_files[1][attachment_id]"
										class="edd_repeatable_attachment_id_field" value="1">
							<span id="edd-edd_download_files1file-wrap"><label class="edd-label" for=""></label>
								<input type="text" name="edd_download_files[1][file]" id="" autocomplete="" value=""
										placeholder="File Name" class="edd_repeatable_name_field large-text">
							</span>
							</td>
							<td>
								<div class="edd_repeatable_upload_field_container">
									<?php
									echo EDD()->html->text(
										array(
											'name'        => 'edd_download_files[1][file]',
											'value'       => '',
											'placeholder' => __( 'Upload or enter the file URL', 'edd-message' ),
											'class'       => 'edd_repeatable_upload_field edd_upload_field large-text',
										)
									);
									?>
								</div>
							</td>

							<td>
								<div class="edd-message-attachment-actions">
									<button
										class="button edd_upload_file_button"
										data-type="file"
										data-uploader-title="<?php esc_html_e( 'Insert File', 'edd-message' ); ?>"
										data-uploader-button-text="<?php esc_html_e( 'Insert', 'edd-message' ); ?>"
									>
										<span class="screen-reader-text"><?php esc_html_e( 'Upload a File', 'edd-message' ); ?></span>
										<span class="dashicons dashicons-upload"></span>
									</button>
									<button class="button edd_remove_repeatable" data-type="file">
										<span class="screen-reader-text"><?php esc_html_e( 'Remove file', 'edd-message' ); ?></span>
										<span class="dashicons dashicons-no-alt"></span>
									</button>
								</div>
							</td>
						</tr>
						<tr>
							<td class="submit" colspan="4" style="float: none; clear:both; background: #fff;">
								<button class="button-secondary edd_add_repeatable" style="margin: 6px 0 10px;">
									<?php esc_html_e( 'Add New File', 'edd-message' ); ?>
								</button>
							</td>
						</tr>
						</tbody>
					</table>

					<?php
					$is_vendor = $customer instanceof FES_Vendor;
					if ( $is_vendor ) {
						?>
						<input type="hidden" id="vendor-id" name="edd-message-vendor-id" value="<?php echo esc_attr( $customer->id ); ?>"/>
						<?php
					} else {
						?>
						<input type="hidden" id="customer-id" name="edd-message-customer-id" value="<?php echo esc_attr( $customer->id ); ?>"/>
						<?php
					}
					?>
					<input type="hidden" name="edd_action" value="add-customer-message"/>
					<?php wp_nonce_field( 'add-customer-message', 'add_customer_message_nonce', true, true ); ?>
					<input id="add-customer-message" class="right button-primary" type="submit" value="<?php esc_html_e( 'Send message', 'edd-message' ); ?>"/>
				</div>
			</form>
		</div>
		<?php edd_message_get_logged_emails( $customer_id, $is_vendor ); ?>
	</div>

	<?php
	edd_message_email_logs_modal();
}
