<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determines whether a message type should be logged
 *
 * @param $log
 *
 * @since 1.1
 * @return bool
 */
function edd_message_maybe_log( $log ) {
	global $edd_options;

	$output = ( isset( $edd_options['edd-message-logging'][ $log ] ) ) ? true : false;

	return $output;
}

/**
 * Records the log if the message type is set to log in the settings
 *
 * @param $args
 *
 * @since 1.1
 */
function edd_message_log( $args ) {

	$log_data = array(
		'object_type' => 'email',
		'type'        => 'email',
		'content'     => $args['message'],
		'title'       => $args['subject'],
		'object_id'   => $args['post_parent'] ?? 0,
		'user_id'     => $args['post_author'] ?? get_current_user_id(),
	);
	$log_meta = array(
		'to'           => $args['to'],
		'message_type' => $args['type'],
	);
	if ( ! empty( $args['customer_id'] ) ) {
		$log_meta['customer_id'] = $args['customer_id'];
	}
	if ( ! empty( $args['vendor_id'] ) ) {
		$log_meta['vendor_id'] = $args['vendor_id'];
	}
	if ( ! empty( $args['from_email'] ) ) {
		$from_name        = $args['from_name'] ?? '';
		$log_meta['from'] = sprintf( '%1$s <%2$s>', $from_name, $args['from_email'] );

		if ( empty( $log_data['user_id'] ) ) {
			$user = get_user_by( 'email', $args['from_email'] );
			if ( $user ) {
				$log_data['user_id'] = $user->ID;
			}
		}
	}
	if ( ! empty( $args['reply_to'] ) ) {
		$log_meta['reply_to'] = $args['reply_to'];
	}
	if ( ! empty( $args['cc'] ) ) {
		$log_meta['cc'] = $args['cc'];
	}
	if ( ! empty( $args['bcc'] ) ) {
		$log_meta['bcc'] = $args['bcc'];
	}
	if ( isset( $args['attachments'] ) && $args['attachments'] !== null ) {
		$log_meta['attachments'] = $args['attachments'];
	}

	$log_id = edd_add_log( $log_data );

	if ( $log_id ) {
		foreach ( $log_meta as $key => $value ) {
			edd_add_log_meta( $log_id, $key, $value );
		}
	}
}

/**
 * Sets up the email logs view output
 */
function edd_message_email_logs_view() {

	if ( ! current_user_can( 'view_shop_reports' ) ) {
		return;
	}

	include __DIR__ . '/admin/class-email-logs-list-table.php';

	$logs_table = new EDD_Message_Log_Table();
	$logs_table->prepare_items();
	$logs_table->display();
	edd_message_email_logs_modal();
}

add_action( 'edd_logs_view_email', 'edd_message_email_logs_view' );

function edd_message_email_logs_modal() {
	?>
	<div id="edd-message-log-message-modal" style="display: none;">
		<div class="edd-message-log-message-modal-container">
			<a href="#" class="edd-message-log-message-modal-close" data-log-modal-close
				title="<?php _e( 'Close Message Window', 'edd-message' ); ?>">
				<span class="screen-reader-text">
					<?php _e( 'Close Message Window', 'edd-message' ); ?>
				</span>

				<span class="dashicons dashicons-no"></span>
			</a>

			<div class="edd-message-log-message-modal-loading">
				<span class="spinner is-active"></span>
			</div>

			<div class="edd-message-log-message-modal-content"></div>
		</div>
	</div>
	<?php
}
/**
 * Includes the email log view in view selector
 *
 * @param $views
 *
 * @return mixed
 */
function edd_message_add_email_log_view( $views ) {
	$views['email'] = __( 'Messages', 'edd-message' );

	return $views;
}

add_filter( 'edd_log_views', 'edd_message_add_email_log_view' );

/**
 * Registers the email log view
 *
 * @param $terms
 *
 * @return array
 */
function edd_message_add_email_logging( $terms ) {
	$terms[] = 'email';

	return $terms;
}

add_filter( 'edd_log_types', 'edd_message_add_email_logging' );

/**
 * Gets a list of all logged messages to a customer
 *
 * @param $id
 */
function edd_message_get_logged_emails( $id, $is_vendor = false ) {
	$meta_key = $is_vendor ? 'vendor_id' : 'customer_id';

	$args = array(
		'type'       => 'email',
		'number'     => 10,
		'meta_query' => array(
			array(
				'key'   => $meta_key,
				'value' => (int) $id,
			),
		),
	);

	$logs = edd_get_logs( $args );

	if ( ! empty( $logs ) && ! is_wp_error( $logs ) ) :
		?>
		<div class="edd-message-logs">

			<h3><?php esc_html_e( 'Message history', 'edd-message' ); ?></h3>

			<table class="wp-list-table widefat striped">

				<thead>
					<tr>
						<th scope="col" id="message-subject" class="manage-column column-subject column-primary">
							<?php esc_html_e( 'Subject', 'edd-message' ); ?>
						</th>
						<th scope="col" id="message-date" class="manage-column column-date column-primary">
							<?php esc_html_e( 'Date', 'edd-message' ); ?>
						</th>
						<th scope="col" id="message-actions" class="manage-column column-actions column-primary">
							<?php esc_html_e( 'Actions', 'edd-message' ); ?>
						</th>
					</tr>
				</thead>
				<?php
				$date_format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
				foreach ( $logs as $log ) :
					$log_data = edd_message_get_log_data( $log );
					?>

					<tr id="edd-message-log-<?php echo esc_attr( $log_data['id'] ); ?>">
						<td>
							<span class="row-title"><?php echo esc_html( $log_data['title'] ); ?></span>
						</td>
						<td>
							<em><?php echo esc_html( $log_data['date'] ); ?></em>
						</td>
						<td>
							<button type="button" class="button" data-log-view-message data-log-id="<?php echo esc_attr( $log_data['id'] ); ?>">
								<?php esc_html_e( 'View', 'edd-message' ); ?>
							</button>
							<button type="button" class="edd-message-delete-log button" data-log-delete data-log-id="<?php echo esc_attr( $log_data['id'] ); ?>">
							<?php esc_html_e( 'Delete', 'edd-message' ); ?>
							</button>
						</td>
					</tr>

				<?php endforeach; ?>

			</table>
		</div>
		<?php
	endif;
}

/**
 * Log EDD purchase receipts
 *
 * @param $check
 * @param $to
 * @param $subject
 * @param $message
 *
 * @deprecated  1.2.5 Use the edd_message_log_order_receipt function instead.
 * 
 * @since 1.1
 * @return mixed
 */
function edd_message_log_purchase_receipts( $check, $to, $subject, $message ) {

	$option = edd_get_option( 'purchase_subject', __( 'Purchase Receipt', 'edd-message' ) );
	if ( edd_message_maybe_log( 'purchase_receipt' ) && $subject === $option ) {

		$customer = edd_get_customer_by( 'email', $to );

		$args = array(
			'to'          => array( $to ),
			'subject'     => $subject,
			'message'     => $message,
			'from_email'  => edd_get_option( 'from_email' ),
			'from_name'   => get_bloginfo( 'name' ),
			'type'        => 'purchase_receipt',
			'customer_id' => $customer->id,
		);

		edd_message_log( $args );
	}

	return $check;
}

/**
 * Retrieves a log message via AJAX.
 *
 * @since {{VERSION}}
 * @access private
 */
function edd_message_log_get_message_ajax() {

	$log_id   = ! empty( $_POST['log_ID'] ) ? (int) $_POST['log_ID'] : false;
	$log      = edd_get_log( $log_id );

	if ( ! $log ) {
		wp_send_json_error(
			array(
				'error' => __( 'Could not get message.', 'edd-message' ),
			)
		);
	}

	wp_send_json_success(
		array(
			'message' => apply_filters( 'the_content', $log->content ),
		)
	);
}
add_action( 'wp_ajax_edd_message_log_get_message', 'edd_message_log_get_message_ajax' );

/**
 * Deletes a log via AJAX.
 *
 * @since {{VERSION}}
 * @access private
 */
function edd_message_log_delete_ajax() {

	$log_id = ! empty( $_POST['log_ID'] ) ? (int) $_POST['log_ID'] : false;
	$delete = edd_delete_log( $log_id );

	if ( ! $delete ) {
		wp_send_json_error(
			array(
				'error' => __( 'Could not delete message log.', 'edd-message' ),
			)
		);
	}

	wp_send_json_success();
}
add_action( 'wp_ajax_edd_message_delete_message', 'edd_message_log_delete_ajax' );

/**
 * Log EDD order receipts
 * 
 * @since 1.2.5
 *
 * @param OrderReceipt $order_receipt_email Order receipt Email instance
 * @param bool         $sent
 */
function edd_message_log_order_receipt( $order_receipt_email, $sent ) {
	
	if ( ! edd_message_maybe_log( 'purchase_receipt' ) ) {
		return;
	}

	$customer = edd_get_customer_by( 'email', $order_receipt_email->send_to );
	$args     = array(
		'to'          => array( $order_receipt_email->send_to ),
		'subject'     => $order_receipt_email->subject,
		'message'     => $order_receipt_email->message,
		'from_email'  => $order_receipt_email->from_email,
		'from_name'   => get_bloginfo( 'name' ),
		'type'        => 'purchase_receipt',
		'customer_id' => $customer->id,
	);

	edd_message_log( $args );
}
add_action( 'edd_email_sent_order_receipt', 'edd_message_log_order_receipt', 10, 2 );
