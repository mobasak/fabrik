<?php
/**
 * Mark Module
 *
 * @package     AutomatorWP\Integrations\Thrive_Apprentice\Actions\Mark_Module
 * @author      AutomatorWP <contact@automatorwp.com>, Ruben Garcia <rubengcdev@gmail.com>
 * @since       1.0.0
 */
// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

class AutomatorWP_Thrive_Apprentice_Mark_Module extends AutomatorWP_Integration_Action {

    public $integration = 'thrive_apprentice';
    public $action = 'thrive_apprentice_mark_module';

    /**
     * Register the trigger
     *
     * @since 1.0.0
     */
    public function register() {

        automatorwp_register_action( $this->action, array(
            'integration'       => $this->integration,
            'label'             => __( 'Mark module as completed for the user', 'automatorwp-thrive-apprentice' ),
            'select_option'     => __( 'Mark <strong>module as completed</strong> for the user', 'automatorwp-thrive-apprentice' ),
            /* translators: %1$s: Module title. */
            'edit_label'        => sprintf( __( 'Mark %1$s as completed for the user', 'automatorwp-thrive-apprentice' ), '{post}' ),
            /* translators: %1$s: Module title. */
            'log_label'         => sprintf( __( 'Mark %1$s as completed for the user', 'automatorwp-thrive-apprentice' ), '{post}' ),
            'options'           => array(
                'post' => array(
                    'from' => 'module',
                    'default' => __( 'module', 'automatorwp-thrive-apprentice' ),
                    'fields' => array(
                        'course' => automatorwp_utilities_term_field( array(
                            'name'              => __( 'Course:', 'automatorwp-thrive-apprentice' ),
                            'placeholder'       => __( 'Select a course', 'automatorwp-thrive-apprentice' ),
                            'option_none'       => false,
                            'option_custom_desc'    => __( 'Course ID', 'automatorwp-thrive-apprentice' ),
                            'taxonomy' => 'tva_courses',
                        ) ),
                        'module' => automatorwp_utilities_ajax_selector_field( array(
                            'option_none' => false,
                            'option_custom' => false,
                            'placeholder'       => __( 'Select a module', 'automatorwp-thrive-apprentice' ),
                            'name' => __( 'Modules:', 'automatorwp-thrive-apprentice' ),
                            'action_cb' => 'automatorwp_thrive_apprentice_get_modules',
                            'options_cb' => 'automatorwp_thrive_apprentice_options_cb_modules',
                            'default' => ''
                        ) ),
                    )
                ),
            ),
        ) );

    }


    /**
     * Action execution function
     *
     * @since 1.0.0
     *
     * @param stdClass  $action             The action object
     * @param int       $user_id            The user ID
     * @param array     $action_options     The action's stored options (with tags already passed)
     * @param stdClass  $automation         The action's automation object
     */
    public function execute( $action, $user_id, $action_options, $automation ) {

        // Shorthand
        $module_id = absint( $action_options['module'] );
        $course_id = absint( $action_options['course'] );
        
        // Bail if not module provided
        if( $module_id === 0 ) {
            return;
        }

        // Bail if not course provided
        if( $course_id === 0 ) {
            return;
        }

        $post_module = get_post( $module_id );

        $lessons_module = TVA_Manager::get_module_lessons( $post_module );

        // Complete all lessons from the module
        foreach ( $lessons_module as $lesson ){

            $learned = get_user_meta( $user_id, 'tva_learned_lessons', true );
        
            // Value for completed lesson
            $learned[ $course_id ][ $lesson->ID ] = 1;
            update_user_meta( $user_id, 'tva_learned_lessons', $learned );

        }

    }

}

new AutomatorWP_Thrive_Apprentice_Mark_Module();