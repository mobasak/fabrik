=== AutomatorWP - Thrive Apprentice ===
Contributors: automatorwp, rubengc, eneribs, dioni00
Tags: thrive, apprentice, automatorwp, course, module, lesson, lms
Requires at least: 4.4
Tested up to: 6.8
Stable tag: 1.0.3
License: GNU AGPLv3
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Connect AutomatorWP with Thrive Apprentice

== Description ==

[Thrive Apprentice](https://thrivethemes.com/apprentice/ "Thrive Apprentice") is a LMS plugin that gives you the most flexible drag and drop WordPress course building solution on the market.

= Triggers =

* User completes a course.
* User completes a lesson.
* User completes a module.

= Actions =

* Enroll user to a product.
* Unroll user from a product.
* Mark lesson as completed for the user.
* Mark module as completed for the user.
* Mark course as completed for the user.

== Installation ==

= From WordPress backend =

1. Navigate to Plugins -> Add new.
2. Click the button "Upload Plugin" next to "Add plugins" title.
3. Upload the downloaded zip file and activate it.

= Direct upload =

1. Upload the downloaded zip file into your `wp-content/plugins/` folder.
2. Unzip the uploaded zip file.
3. Navigate to Plugins menu on your WordPress admin area.
4. Activate this plugin.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 1.0.3 =

* **Improvements**
* Added tags to get IDs and titles from modules and courses.

= 1.0.2 =

* **Bug Fixes**
* Fixed bug related to option "any" in lessons.

= 1.0.1 =

* **Bug Fixes**
* Fixed product selection.

= 1.0.0 =

* Initial release.
