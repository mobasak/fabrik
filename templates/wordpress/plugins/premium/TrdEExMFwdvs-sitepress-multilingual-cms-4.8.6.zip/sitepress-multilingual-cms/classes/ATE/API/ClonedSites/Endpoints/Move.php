<?php

namespace WPML\TM\ATE\ClonedSites\Endpoints;

use WPML\FP\Either;
use WPML\Ajax\IHandler;
use WPML\Collect\Support\Collection;
use WPML\TM\ATE\ClonedSites\Report;
use function WPML\Container\make;

class Move implements IHandler {

	public function run( Collection $data ) {
		/** @var Report $report */
		$report = make( Report::class );

		$result = $report->move();

		if ( ! is_wp_error( $result ) ) {
			do_action( 'wpml_tm_cloned_site_reported', $result );
			return Either::of( true );
		}

		return Either::left( 'Failed to report' );
	}
}
