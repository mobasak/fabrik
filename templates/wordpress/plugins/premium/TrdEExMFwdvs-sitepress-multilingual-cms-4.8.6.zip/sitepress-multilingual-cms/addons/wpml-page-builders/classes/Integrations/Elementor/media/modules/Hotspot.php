<?php

namespace WPML\PB\Elementor\Media\Modules;

class Hotspot extends \WPML_Elementor_Media_Node_With_Image_Property {

	protected function get_property_name() {
		return 'image';
	}
}
