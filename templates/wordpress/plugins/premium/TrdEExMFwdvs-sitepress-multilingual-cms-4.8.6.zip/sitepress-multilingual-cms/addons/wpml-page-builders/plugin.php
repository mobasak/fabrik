<?php
/**
 * Plugin Name: WPML Page Builders
 * Description: Add full WPML support for most popular page builders.
 * Author: OnTheGoSystems
 * Author URI: http://www.onthegosystems.com
 * Version: 2.4.0.1
 * Plugin Slug: wpml-page-builders
 */

require_once __DIR__ . '/loader.php';
