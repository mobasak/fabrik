=== Order Notifications on WhatsApp for WooCommerce ===
Contributors: Procom
Donate link: https://www.procomsoftsol.com
Tags: WhatsApp, Message, Order messages, Whatsapp Messages
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 6.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Send WhatsApp notifications using the official WhatsApp Cloud APIs for WooCommerce orders.

== Description ==

Send WhatsApp notifications using the official WhatsApp Cloud APIs for WooCommerce orders.

== Installation ==

1. Upload `order-notifications-on-whatsapp-for-woocommerce` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

2025-01-21 - version 1.0.1
* Fixed Invalid parameter issue
* Fixed Template formatting issue

2024-07-01 - version 1.0.0
* Initial Release