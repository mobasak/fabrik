<?php
/**
 * Admin dashboard.
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/admin/partials
 */

?>
<div class="wrap onww-help">
	
	<div class="onww-help-wrapper" id="dashboard-widgets-wrap">
		<div id="dashboard-widgets" class=" metabox-holder">
			<div id="postbox-container-1" >
				<div class="postbox ">
					<div class="postbox-header">
						<h2 class="hndle"><?php echo esc_html__( 'Help? ', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></h2>
					</div>
					<div class="inside">
						<p>Follow the instructions below to setup your Order Notifications on WhatsApp for WooCommerce plugin.</p>



						<h3>Step 1: Create a Facebook Developer Account</h3>
						<ul>
													<li><b>Sign Up:</b> If you don't have a Facebook Developer account, <a href="https://developers.facebook.com/" target="_blank"> <b>sign up</b></a> at Facebook for Developers.</li>
							<li><b>Create an App:</b> Once logged in, go to the "My Apps" section and click on "Create App". Choose "Business" as the app type.</li>
						</ul>
						<ul>
							<h3>Step 2: Setup WhatsApp Business API</h3>
							<ul>
								<li><b>Add WhatsApp:</b> After creating the app, navigate to the "Add a Product" section, find "WhatsApp", and click "Set Up".</li>
								<li><b>Get Started:</b> Follow the instructions to set up the WhatsApp Business API, including selecting a business account and verifying your phone number.</li>
							</ul>
							<h3>Step 3: Access the WhatsApp Cloud API</h3>
							<ul>
								<li><b>API Setup:</b> Go to the "WhatsApp" section in your app’s dashboard and click on "API Setup". Here, you will configure your API settings.</li>
								<li><b>Generate API Key:</b> You will need to generate an API key that you will use to authenticate your API requests.</li>
							</ul>



					</div>
				</div>

			</div>

		</div>
	</div>
</div>

