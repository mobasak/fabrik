/**
 * All of the js for your admin-specific functionality should be
 * included in this file.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 */

jQuery( document ).ready(
	function ($) {
		$( document ).on(
			'change keyup paste',
			'.whatsapp_template_name',
			function (event) {
				var start = event.target.selectionStart;
				$( this ).val( $( this ).val().toLowerCase().replace( / /g, '_' ) );
				event.target.selectionStart = event.target.selectionEnd = start;
			}
		);

		$( document ).on(
			'click',
			'#onww-fetch-templates',
			function (event) {
				event.preventDefault();
				$( '.wrap' ).block(
					{
						message: null,
						overlayCSS: {
							background: '#fff',
							opacity: 0.6
						}
						}
				);

				$.post(
					onww_admin_params.ajax_url,
					{'action': 'onww_fetch_templates', 'security': onww_admin_params.fetch_templates_nonce},
					function (data) {
						console.log( data );

						var current = $.featherlight.current();
						if (current) {
							current.close();
						}
						if (data.data.popup_html != '') {
							$.featherlight( data.data.popup_html );
						} else {
							location.reload();
						}

						$( '.wrap' ).unblock();
					}
				);

			}
		);

		$( document ).on(
			'submit',
			'form.onww-edit-template-form',
			function (event) {
				event.preventDefault();
				$( 'form.onww-edit-template-form' ).block(
					{
						message: null,
						overlayCSS: {
							background: '#fff',
							opacity: 0.6
						}
						}
				);
				var $form_data = $( this ).serializeArray();
				$.post(
					onww_admin_params.ajax_url,
					$form_data,
					function (data) {
						$( 'form.onww-edit-template-form' ).unblock();
						$( '.whatsapp-template-update-message' ).show();
						$( '#onww-fetch-templates' ).click();
					}
				);
			}
		);

		$( document ).on(
			'click',
			'.onww_order_message_buttons_load_message',
			function () {
				$( '#onww_order_meta_box' ).block( {message: null, overlayCSS: {background: '#fff', opacity: 0.6}} );
				var $order_id = $( this ).data( 'order-id' );
				$.post(
					onww_admin_params.ajax_url,
					{'action': "onww_order_message_load_message", 'order_id': $order_id, 'security': onww_admin_params.load_mesage_nonce},
					function ($data) {
						$( '#onww_order_message' ).val( $data.data.message.replace( '\n', ' ' ) );
						$( '#onww_order_message' ).attr( 'readonly', true );
						$( '#onww_order_message' ).after( '<input type="hidden" id="onww_template_id" value="' + $data.data.template_id + '">' );
						$( '#onww_order_meta_box' ).unblock();
					},
					"JSON"
				);
			}
		);

		$( document ).on(
			'click',
			'.onww_order_message_buttons_send_message',
			function () {
				$( '#onww_order_meta_box' ).block( {message: null, overlayCSS: {background: '#fff', opacity: 0.6}} );
				var $order_id    = $( this ).data( 'order-id' );
				var $message     = $( '#onww_order_message' ).val();
				var $template_id = '';
				if ($( '#onww_template_id' ).length > 0) {
					$template_id = $( '#onww_template_id' ).val();
				}
				$.post(
					onww_admin_params.ajax_url,
					{'action': "onww_order_message_send_message", 'order_id': $order_id, 'message': $message, 'template_id': $template_id, 'security': onww_admin_params.send_message_nonce},
					function ($data) {
						$( '#onww_order_message' ).val( '' );
						$( '#onww_order_message' ).attr( 'readonly', false );
						if ($data.data.message.status == 'success') {
							alert( 'Message Sent' );
						} else {
							alert( 'Message Failed' );
						}
						$( '#onww_order_meta_box' ).unblock();
					},
					"JSON"
				);
			}
		);

	}
);
