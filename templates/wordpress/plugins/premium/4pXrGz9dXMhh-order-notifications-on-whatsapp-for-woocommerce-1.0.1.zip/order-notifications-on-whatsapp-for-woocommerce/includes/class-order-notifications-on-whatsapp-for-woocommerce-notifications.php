<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/admin
 */
class Order_Notifications_On_Whatsapp_For_Woocommerce_Notifications {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Notifications settings.
	 *
	 * @since    1.0.0
	 * @var      array    $notification_settings    Notification settings.
	 */
	private $notification_settings;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string $plugin_name       The name of this plugin.
	 * @param      string $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

		$this->notification_settings = get_option( 'order_notifications_on_whatsapp_for_woocommerce_order_notification', array() );
		$settings                    = get_option( 'order_notifications_on_whatsapp_for_woocommerce', array() );
		$this->notification_settings = array_merge( $this->notification_settings, $settings );

		if ( ! empty( $this->notification_settings ) ) {
			if ( isset( $this->notification_settings['new_order_notification_enable'] ) && 'on' == $this->notification_settings['new_order_notification_enable'] ) {
				$sttus = array(
					'woocommerce_order_status_pending_to_processing_notification',
					'woocommerce_order_status_pending_to_completed_notification',
					'woocommerce_order_status_pending_to_on-hold_notification',
					'woocommerce_order_status_failed_to_processing_notification',
					'woocommerce_order_status_failed_to_completed_notification',
					'woocommerce_order_status_failed_to_on-hold_notification',
					'woocommerce_order_status_cancelled_to_processing_notification',
					'woocommerce_order_status_cancelled_to_completed_notification',
					'woocommerce_order_status_cancelled_to_on-hold_notification',
				);
				foreach ( $sttus as $st ) {
					add_action( $st, array( $this, 'new_order_notification' ), 10, 2 );
				}
			}

			add_action( 'woocommerce_order_status_changed', array( $this, 'notification_after_order' ), 10, 4 );

			add_filter( 'onww_custom_message', array( $this, 'custom_order_message' ), 10, 4 );
		}
	}

	/**
	 * New order notification to admin user.
	 *
	 * @since    1.0.0
	 * @param      string $order_id Order id.
	 * @param      mixed  $order Order.
	 */
	public function new_order_notification( $order_id, $order = false ) {
		if ( $order_id && ! is_a( $order, 'WC_Order' ) ) {
			$order = wc_get_order( $order_id );
		}

		$this->add_log( $order, 'called new_order_notification' );

		if ( isset( $this->notification_settings['new_order_notification_template'] ) && ! empty( $this->notification_settings['new_order_notification_template'] ) ) {
			$template_id = $this->notification_settings['new_order_notification_template'];
			$mobile      = $this->notification_settings['whatsapp_admin_mobile_number'];
			if ( '' != $template_id ) {
				$status = $this->send_template_message( $template_id, $order, $mobile );
			}
		}
	}

	/**
	 * Notification after order.
	 *
	 * @since    1.0.0
	 * @param int    $order_id Prder id.
	 * @param string $old_status Old Status.
	 * @param string $new_status New status.
	 * @param object $order Order.
	 */
	public function notification_after_order( $order_id, $old_status, $new_status, $order ) {
		if ( ! $order_id ) {
			return;
		}
		if ( empty( $new_status ) ) {
			return;
		}

		$this->add_log( $order, 'called notification_after_order' );

		$statuses = wc_get_order_statuses();
		$status   = 'wc-' === substr( $new_status, 0, 3 ) ? substr( $new_status, 3 ) : $new_status;
		$status   = isset( $statuses[ 'wc-' . $status ] ) ? $statuses[ 'wc-' . $status ] : $status;
		$status   = strtolower( $status );

		$this->add_log( $order, 'called notification_after_order : Status :' . $status );

		if ( 'on' == $this->notification_settings[ "enable_order_notification_admin_{$new_status}" ] ) {
			if ( isset( $this->notification_settings[ "order_notification_admin_template_{$new_status}" ] ) && ! empty( $this->notification_settings[ "order_notification_admin_template_{$new_status}" ] ) ) {
				$template_id = $this->notification_settings[ "order_notification_admin_template_{$new_status}" ];
				$mobile      = $this->notification_settings['whatsapp_admin_mobile_number'];
				if ( '' != $template_id ) {
					$status = $this->send_template_message( $template_id, $order, $mobile );
				}
			}
		}

		if ( 'on' == $this->notification_settings[ "enable_order_notification_customer_{$new_status}" ] ) {
			if ( isset( $this->notification_settings[ "order_notification_customer_template_{$new_status}" ] ) && ! empty( $this->notification_settings[ "order_notification_customer_template_{$new_status}" ] ) ) {
				$template_id = $this->notification_settings[ "order_notification_customer_template_{$new_status}" ];
				$mobile      = $this->get_customer_mobile( $order );

				if ( '' != $template_id ) {
					$status = $this->send_template_message( $template_id, $order, $mobile );
				}
			}
		}
	}

	/**
	 * Custom order message.
	 *
	 * @since    1.0.0
	 *
	 * @param string $status Status.
	 * @param int    $order_id Order id.
	 * @param int    $template_id Template id.
	 * @param string $message Message.
	 * @return array $status  Status.
	 */
	public function custom_order_message( $status, $order_id, $template_id, $message ) {
		$order  = wc_get_order( $order_id );
		$mobile = $this->get_customer_mobile( $order );
		if ( '' != $template_id ) {
			$status = $this->send_template_message( $template_id, $order, $mobile );
		} elseif ( '' != $message ) {
			$status = $this->send_custom_message( $message, $order, $mobile );
		}
		return $status;
	}

	/**
	 * Custom order message.
	 *
	 * @since    1.0.0
	 * @param type $message Message.
	 * @param type $order Order.
	 * @param type $mobile Mobile.
	 * @return string $status Status.
	 */
	public function send_custom_message( $message, $order, $mobile ) {
		if ( ! empty( $message ) && ! empty( $mobile ) ) {
			$template_cls     = new Order_Notifications_On_Whatsapp_For_Woocommerce_Template();
			$whatsapp_message = $template_cls->process_message( $message, $order );

			$api    = new Order_Notifications_On_Whatsapp_For_Woocommerce_Api();
			$mobile = explode( ',', $mobile );
			$mobile = array_map( 'trim', $mobile );
			foreach ( $mobile as $mobile_number ) {
				$status            = $api->send_message( $mobile_number, $whatsapp_message );
				$status['mobile']  = $mobile_number;
				$status['type']    = 'WhatsApp Message';
				$status['message'] = $whatsapp_message;
				$this->add_order_note( $order, $status );
			}
		}
		return $status;
	}

	/**
	 * Send template message.
	 *
	 * @since    1.0.0
	 * @param int    $template_id Template id.
	 * @param object $order Order.
	 * @param string $mobile Mobile.
	 * @return array $status Status.
	 */
	public function send_template_message( $template_id, $order, $mobile ) {
		$template_cls      = new Order_Notifications_On_Whatsapp_For_Woocommerce_Template();
		$whatsapp_template = $template_cls->process_template( $template_id, $order );
		if ( $whatsapp_template && ! empty( $mobile ) ) {
			$api    = new Order_Notifications_On_Whatsapp_For_Woocommerce_Api();
			$mobile = explode( ',', $mobile );
			$mobile = array_map( 'trim', $mobile );
			foreach ( $mobile as $mobile_number ) {
				$status             = $api->send_template_message( $mobile_number, $whatsapp_template );
				$whatsapp_message   = $template_cls->preview_template_message( $template_id, $order );
				$status['mobile']   = $mobile_number;
				$status['type']     = 'WhatsApp Template Message';
				$status['message']  = $whatsapp_message;
				$status['template'] = $whatsapp_template;

				$this->add_order_note( $order, $status );
			}
		}
		return $status;
	}

	/**
	 * Returns customer mobile number.
	 *
	 * @since    1.0.0
	 * @param      mixed $order Order.
	 * @return   string   $mobile Mobile.
	 */
	public function get_customer_mobile( $order ) {
		$mobile          = $order->get_billing_phone();
		$billing_country = $order->get_billing_country();

		$mobile = $this->get_formatted_phone_number( $mobile, $billing_country );

		$mobile = apply_filters( 'order_notifications_on_whatsapp_for_woocommerce_get_customer_mobile', $mobile, $order );
		return $mobile;
	}

	/**
	 * Returns formated mobile number.
	 *
	 * @since    1.0.0
	 * @param string $phone_number Phone number.
	 * @param string $country_code Country code.
	 * @return string $phone_number Phone number.
	 */
	public function get_formatted_phone_number( $phone_number, $country_code ) {
		$phone_number = preg_replace( '/[^\d+]/', '', $phone_number );
		$phone_number = ltrim( $phone_number, '0' );
		if ( in_array( $country_code, array( 'US', 'CA' ), true ) ) {
			$calling_code = '+1';
			$phone_number = ltrim( $phone_number, '+1' );
		} else {
			$calling_code = WC()->countries->get_country_calling_code( $country_code );
			$calling_code = is_array( $calling_code ) ? $calling_code[0] : $calling_code;
			if ( $calling_code ) {
				$phone_number = str_replace( $calling_code, '', preg_replace( '/^0/', '', $phone_number ) );
			}
		}
		$phone_number = ltrim( $phone_number, '0' );
		$phone_number = $calling_code . $phone_number;
		return $phone_number;
	}

	/**
	 * Add order note.
	 *
	 * @since    1.0.0
	 * @param mixed  $order Order.
	 * @param string $status Status.
	 */
	public function add_order_note( $order, $status ) {
		if ( is_array( $status ) && ! empty( $status ) ) {
			$note  = strtoupper( $status['type'] ) . ' <br>';
			$note .= esc_attr__( 'Mobile : ', 'order_notifications_on_whatsapp_for_woocommerce' );
			$note .= $status['mobile'] . '<br>';
			$note .= esc_attr__( 'Message : ', 'order_notifications_on_whatsapp_for_woocommerce' );
			$note .= $status['message'];

			if ( 'success' == $status['status'] ) {
				$note .= '<br>' . esc_attr__( 'Status : Success ', 'order_notifications_on_whatsapp_for_woocommerce' );
			} else {
				$note .= '<br>' . esc_attr__( 'Status : Failed ', 'order_notifications_on_whatsapp_for_woocommerce' );
				$note .= '<br>' . esc_attr__( 'Error Code :  ', 'order_notifications_on_whatsapp_for_woocommerce' );
				$note .= $status['error_code'];
				$note .= '<br>' . esc_attr__( 'Error Message :  ', 'order_notifications_on_whatsapp_for_woocommerce' );
				$note .= $status['error_message'];
			}

			$order->add_order_note( $note );
			$order->save();
			$this->add_log( $order, $status );
		}
	}

	/**
	 * Add logs.
	 *
	 * @since    1.0.0
	 * @param mixed $order Order.
	 * @param mixed $status Status.
	 */
	public function add_log( $order, $status ) {
		if ( isset( $this->notification_settings['enable_log'] ) && 'on' == $this->notification_settings['enable_log'] ) {
			$logger = wc_get_logger();
			ob_start();
			echo '<pre>';
			echo 'Order ID : ' . esc_html( $order->get_id() );
			echo '<br>';
			print_r( $status );
			echo '</pre>';
			$d = ob_get_clean();
			$logger->debug( $d, array( 'source' => 'order-notifications-on-whatsapp-for-woocommerce' ) );
		}
	}

}
