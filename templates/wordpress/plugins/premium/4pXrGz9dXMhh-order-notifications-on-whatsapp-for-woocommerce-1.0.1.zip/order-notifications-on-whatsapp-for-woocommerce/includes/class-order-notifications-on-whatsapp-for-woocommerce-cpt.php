<?php
/**
 * The cpt-specific functionality of the plugin.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */

/**
 * The cpt-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */
class Order_Notifications_On_Whatsapp_For_Woocommerce_Cpt {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string $plugin_name       The name of this plugin.
	 * @param      string $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

		$settings = get_option( 'order_notifications_on_whatsapp_for_woocommerce', array() );

		if ( empty( $settings ) ) {
			return;
		}
		if ( 'on' != $settings['enable'] ) {
			return;
		}

		add_action( 'init', array( $this, 'register_post_type' ), 90 );
		add_action( 'add_meta_boxes', array( $this, 'meta_boxes' ), 99, 2 );

		add_action( 'admin_menu', array( $this, 'admin_page' ) );

		add_filter( 'bulk_actions-whatsapp-templates', array( $this, 'remove_bulk_actions' ) );
		add_filter( 'post_row_actions', array( $this, 'remove_quick_edit' ), 10, 2 );

		add_action( 'current_screen', array( $this, 'current_screen' ) );

		add_action( 'cmb2_admin_init', array( $this, 'custom_fields' ) );

		add_action( 'wp_after_insert_post', array( $this, 'trigger_template_changes_whatsapp' ), 90, 4 );

		add_filter( 'wp_insert_post_data', array( $this, 'check_template_name' ), 10, 4 );

		add_action( 'admin_notices', array( $this, 'error_notice' ) );

		add_filter( 'manage_whatsapp-templates_posts_columns', array( $this, 'define_columns' ) );
		add_action( 'manage_whatsapp-templates_posts_custom_column', array( $this, 'render_columns' ), 10, 2 );

		add_action( 'admin_init', array( $this, 'check_template_status' ) );

		add_action( 'wp_ajax_onww_fetch_templates', array( $this, 'fetch_templates' ) );
		add_action( 'wp_ajax_onww_template_map_variables_update', array( $this, 'template_map_variables_update' ) );
	}

	/**
	 * Register new post type
	 *
	 * @since      1.0.0
	 */
	public function register_post_type() {

		$labels = array(
			'name'                  => esc_html_x( 'WhatsApp Templates', 'Post Type General Name', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'singular_name'         => esc_html_x( 'WhatsApp Templates', 'Post Type Singular Name', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'menu_name'             => esc_html__( 'WhatsApp Templates', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'name_admin_bar'        => esc_html__( 'WhatsApp Templates', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'archives'              => esc_html__( 'Template Archives', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'attributes'            => esc_html__( 'Template Attributes', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'parent_item_colon'     => esc_html__( 'Parent Template:', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'all_items'             => esc_html__( 'WhatsApp Templates', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'add_new_item'          => esc_html__( 'Add New Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'add_new'               => esc_html__( 'Add New Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'new_item'              => esc_html__( 'New Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'edit_item'             => esc_html__( 'Edit WhatsApp Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'update_item'           => esc_html__( 'Update WhatsApp Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'view_item'             => esc_html__( 'View WhatsApp Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'view_items'            => esc_html__( 'View WhatsApp Templates', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'search_items'          => esc_html__( 'Search WhatsApp Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'not_found'             => esc_html__( 'Not found', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'featured_image'        => esc_html__( 'Featured Image', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'set_featured_image'    => esc_html__( 'Set featured image', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'remove_featured_image' => esc_html__( 'Remove featured image', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'use_featured_image'    => esc_html__( 'Use as featured image', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'insert_into_item'      => esc_html__( 'Insert into WhatsApp Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to this WhatsApp Template', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'items_list'            => esc_html__( 'Cloud Prin Templates list', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'items_list_navigation' => esc_html__( 'WhatsApp Template list navigation', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'filter_items_list'     => esc_html__( 'Filter items list', 'order-notifications-on-whatsapp-for-woocommerce' ),
		);
		$args   = array(
			'label'               => esc_html__( 'WhatsApp Templates', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'description'         => esc_html__( 'WhatsApp Templates', 'order-notifications-on-whatsapp-for-woocommerce' ),
			'labels'              => $labels,
			'supports'            => array( 'title' ),
			'hierarchical'        => false,
			'false'               => true,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'menu_position'       => 90,
			'menu_icon'           => 'dashicons-printer',
			'show_in_admin_bar'   => false,
			'show_in_nav_menus'   => false,
			'can_export'          => false,
			'has_archive'         => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'capability_type'     => 'post',
		);
		register_post_type( 'whatsapp-templates', $args );
	}

	/**
	 * Remove inline edit from Bulk Edit
	 *
	 * @since      1.0.0
	 * @param      array $actions       Actions.
	 * @return      array $actions    Actions.
	 */
	public function remove_bulk_actions( $actions ) {
		unset( $actions['inline'] );
		return $actions;
	}

	/**
	 * Remove inline Quick Edit
	 *
	 * @since      1.0.0
	 * @param      array $actions       Actions.
	 * @param      array $post       Post.
	 * @return      array $actions    Actions.
	 */
	public static function remove_quick_edit( $actions, $post ) {
		if ( 'whatsapp-templates' == $post->post_type ) {
			unset( $actions['inline hide-if-no-js'] );
		}
		return $actions;
	}



	/**
	 * Add actions for templates screen
	 *
	 * @since      1.0.0
	 * @param      string $current_screen       Current Screen.
	 */
	public function current_screen( $current_screen ) {
		if ( 'whatsapp-templates' != $current_screen->post_type ) {
			return false;
		}

		wp_enqueue_script( 'jquery-blockui' );

		if ( 'edit' == $current_screen->base ) {
			add_action( 'admin_head', array( $this, 'current_screen_edit' ) );
		}

		if ( 'post' == $current_screen->base ) {
			add_action( 'admin_head', array( $this, 'current_screen_post' ) );
		}
	}

	/**
	 * Add script to templates screen
	 *
	 * @since      1.0.0
	 */
	public function current_screen_post() {
		?>
		<script type="text/javascript">
			/* <![CDATA[ */
			jQuery(window).ready(function ($) {
				if ($('#template_name').val() != "") {
					document.getElementById("template_name").setAttribute("readonly", "true");
										document.getElementById("template_language").setAttribute("disabled", "true");
				}
							   
							   $('#post').on('submit', function() {
									$('#template_language').prop('disabled', false);
								});
	
			});

		</script>
		<?php
	}

	/**
	 * Reformat the `edit` screen
	 *
	 * @since      1.0.0
	 */
	public function current_screen_edit() {
		?>
		<script type="text/javascript">
			/* <![CDATA[ */
			jQuery(window).ready(function ($) {
				var links = '';
				links += '<a href="javascript:void(0)" id="onww-fetch-templates" class="page-title-action"><?php echo esc_html__( 'Fetch Templates', 'order-notifications-on-whatsapp-for-woocommerce' ); ?></a>';

				$("#wpbody-content .page-title-action").after(links);
			});

		</script>
		<?php
	}

	/**
	 * Add admin sub page
	 *
	 * @since      1.0.0
	 */
	public function admin_page() {
		add_submenu_page( 'order_notifications_on_whatsapp_for_woocommerce', esc_html__( 'WhatsApp Templates', 'order-notifications-on-whatsapp-for-woocommerce' ), esc_html__( 'WhatsApp Templates', 'order-notifications-on-whatsapp-for-woocommerce' ), 'manage_options', 'edit.php?post_type=whatsapp-templates' );
	}

	/**
	 * Modify meta boxes
	 *
	 * @since      1.0.0
	 * @param      string $post_type       Post type.
	 * @param      array  $post       Post.
	 */
	public function meta_boxes( $post_type, $post ) {

		global $wp_meta_boxes;

		global $post;
		$current_post_type = get_post_type( $post );
		if ( 'whatsapp-templates' == $current_post_type ) {
			$exceptions = array( 'whatsapp_template_data' );
			if ( isset( $wp_meta_boxes[ $current_post_type ] ) ) {
				foreach ( $wp_meta_boxes[ $current_post_type ] as $context => $box_context ) {
					if ( ! empty( $box_context ) ) {
						foreach ( $box_context as $box_type ) {
							if ( ! empty( $box_type ) ) {
								foreach ( $box_type as $id => $box ) {
									if ( ! in_array( $id, $exceptions ) ) :

										remove_meta_box( $id, $current_post_type, $context );
									endif;
								}
							}
						}
					}
				}
			}
		}

		add_meta_box( 'submitdiv', esc_html__( 'Save Template', 'order-notifications-on-whatsapp-for-woocommerce' ), 'post_submit_meta_box', 'whatsapp-templates', 'side', 'high' );
	}

	/**
	 * Custom fields for post type.
	 *
	 * @since      1.0.0
	 */
	public function custom_fields() {
		$args     = array(
			'id'           => 'whatsapp_template_data',
			'title'        => esc_html__( 'Template Data', 'automatic-order-printing-for-woocommerce' ),
			'object_types' => array( 'whatsapp-templates' ),
		);
		$meta_box = new_cmb2_box( $args );

		$fields = $this->get_meta_fields();
		foreach ( $fields as $field ) {
			$meta_box->add_field( $field );
		}
	}

	/**
	 * Return meta fields
	 *
	 * @since      1.0.0
	 * @return     array     $fields
	 */
	public function get_meta_fields() {
		$fields = array();

		$template_placeholders = onww_get_template_placeholders();
		$template_variables    = array();
		foreach ( $template_placeholders as $placeholder => $name ) {
			$template_variables[] = "[{$placeholder}]";
		}
		$template_variables = implode( ', ', $template_variables );

				$languages = array(
					'af'        => 'Afrikaans',
					'sq'        => 'Albanian',
					'ar'        => 'Arabic',
					'az'        => 'Azerbaijani',
					'bn'        => 'Bengali',
					'bg'        => 'Bulgarian',
					'ca'        => 'Catalan',
					'zh_CN'     => 'Chinese (CHN)',
					'zh_HK'     => 'Chinese (HKG)',
					'zh_TW'     => 'Chinese (TAI)',
					'hr'        => 'Croatian',
					'cs'        => 'Czech',
					'da'        => 'Danish',
					'nl'        => 'Dutch',
					'en'        => 'English',
					'en_GB'     => 'English (UK)',
					'en_US'     => 'English (US)',
					'et'        => 'Estonian',
					'fil'       => 'Filipino',
					'fi'        => 'Finnish',
					'fr'        => 'French',
					'ka'        => 'Georgian',
					'de'        => 'German',
					'el'        => 'Greek',
					'gu'        => 'Gujarati',
					'ha'        => 'Hausa',
					'he'        => 'Hebrew',
					'hi'        => 'Hindi',
					'Hungarian' => 'hu',
					'id'        => 'Indonesian',
					'ga'        => 'Irish',
					'it'        => 'Italian',
					'ja'        => 'Japanese',
					'kn'        => 'Kannada',
					'kk'        => 'Kazakh',
					'rw_RW'     => 'Kinyarwanda',
					'ko'        => 'Korean',
					'ky_KG'     => 'Kyrgyz (Kyrgyzstan)',
					'lo'        => 'Lao',
					'lv'        => 'Latvian',
					'lt'        => 'Lithuanian',
					'mk'        => 'Macedonian',
					'ms'        => 'Malay',
					'ml'        => 'Malayalam',
					'mr'        => 'Marathi',
					'nb'        => 'Norwegian',
					'fa'        => 'Persian',
					'pl'        => 'Polish',
					'pt_BR'     => 'Portuguese (BR)',
					'pt_PT'     => 'Portuguese (POR)',
					'pa'        => 'Punjabi',
					'ro'        => 'Romanian',
					'ru'        => 'Russian',
					'sr'        => 'Serbian',
					'sk'        => 'Slovak',
					'sl'        => 'Slovenian',
					'es'        => 'Spanish',
					'es_AR'     => 'Spanish (ARG)',
					'es_ES'     => 'Spanish (SPA)',
					'es_MX'     => 'Spanish (MEX)',
					'sw'        => 'Swahili',
					'sv'        => 'Swedish',
					'ta'        => 'Tamil',
					'te'        => 'Telugu',
					'th'        => 'Thai',
					'tr'        => 'Turkish',
					'uk'        => 'Ukrainian',
					'ur'        => 'Urdu',
					'uz'        => 'Uzbek',
					'vi'        => 'Vietnamese',
					'zu'        => 'Zulu',
				);

				$fields['template_name'] = array(
					'name'       => esc_html__( 'Name', 'automatic-order-printing-for-woocommerce' ),
					'desc'       => esc_html__( 'Name your message template. Use only lowercase letters, numbers and underscore only. ', 'automatic-order-printing-for-woocommerce' ),
					'id'         => 'template_name',
					'type'       => 'text',
					'attributes' => array(
						'required' => 'required',
						'class'    => 'regular-text whatsapp_template_name',
					),
				);

				$fields['template_variables'] = array(
					'name' => esc_html__( 'Available variables ( use variables in Header and Body fields only )', 'automatic-order-printing-for-woocommerce' ),
					'desc' => $template_variables,
					'id'   => 'template_variables',
					'type' => 'title',
				);

				$fields['template_language'] = array(
					'name'    => esc_html__( 'Template language', 'automatic-order-printing-for-woocommerce' ),
					'desc'    => esc_html__( 'Select language', 'automatic-order-printing-for-woocommerce' ),
					'id'      => 'template_language',
					'type'    => 'select',
					'options' => $languages,
					'default' => 'en_US',
				);

				$fields['template_header'] = array(
					'name'    => esc_html__( 'Header', 'automatic-order-printing-for-woocommerce' ),
					'desc'    => esc_html__( 'Add text for the header. Allows only one variable.', 'automatic-order-printing-for-woocommerce' ),
					'id'      => 'template_header',
					'type'    => 'text',
					'default' => 'Dear [customer_full_name],',
				);
				$fields['template_body']   = array(
					'name'    => esc_html__( 'Body', 'automatic-order-printing-for-woocommerce' ),
					'desc'    => esc_html__( 'Enter the text for your message in the language you\'ve selected.', 'automatic-order-printing-for-woocommerce' ),
					'id'      => 'template_body',
					'type'    => 'textarea',
					'default' => 'Thank you for ordering.😍 Your order ID is: [order_id] Your ordered items are: [order_items] Your order total is: [order_total] Order details are sent to: [customer_email] If you have any query you can contact us at [admin_email] Keep ordering! Thank you.☺️☺️,',
				);
				$fields['template_footer'] = array(
					'name'    => esc_html__( 'Footer', 'automatic-order-printing-for-woocommerce' ),
					'desc'    => esc_html__( 'Add a short line of text to the bottom of your message template.', 'automatic-order-printing-for-woocommerce' ),
					'id'      => 'template_footer',
					'type'    => 'text',
					'default' => get_bloginfo( 'name' ),
				);
				$fields                    = apply_filters( 'order_notifications_on_whatsapp_for_woocommerce_template_get_meta_fields', $fields );

				return $fields;
	}

	/**
	 * Check template name
	 *
	 * @since      1.0.0
	 * @param string $data Data.
	 * @param type   $postarr Postattr.
	 * @param type   $unsanitized_postarr Unsanitized postarr.
	 * @param type   $update Update.
	 * @return string|array  $data Data.
	 */
	public function check_template_name( $data, $postarr, $unsanitized_postarr, $update ) {
		if ( 'whatsapp-templates' == $data['post_type'] && ( 'Auto Draft' == $data['post_title'] || '' == $data['post_title'] ) ) {
			$data['post_title'] = 'Whatsapp Template';
		}
		return $data;
	}

	/**
	 * Trigger template changes
	 *
	 * @since      1.0.0
	 * @param type $post_id Post Id.
	 * @param type $post Post.
	 * @param type $update Update.
	 * @param type $post_before Post Before.
	 */
	public function trigger_template_changes_whatsapp( $post_id, $post, $update, $post_before ) {
		if ( 'whatsapp-templates' !== $post->post_type ) {
			return;
		}

		$title            = get_post_meta( $post_id, 'template_name', true );
		$head             = get_post_meta( $post_id, 'template_header', true );
		$body             = get_post_meta( $post_id, 'template_body', true );
		$footer           = get_post_meta( $post_id, 'template_footer', true );
				$language = get_post_meta( $post_id, 'template_language', true );

		$whatsapp_template_name = get_post_meta( $post_id, 'whatsapp_template_name', true );

		$head_data = $this->replace_placeholders_with_numbers( $head );
		$body_data = $this->replace_placeholders_with_numbers( $body );

		if ( isset( $head_data[1] ) ) {
			$header_parms = array_column( $head_data[1], 0 );
			update_post_meta( $post_id, 'template_header_parms', $header_parms );
		}
		if ( isset( $body_data[1] ) ) {
			$body_parms = array_column( $body_data[1], 0 );
			update_post_meta( $post_id, 'template_body_parms', $body_parms );
		}

		$existing_id = get_post_meta( $post_id, '_whatsapp_message_id', true );

		if ( $existing_id ) {
			$template = array();

			$template['components'] = array();
			$header_component       = array(
				'type'   => 'HEADER',
				'format' => 'TEXT',
				'text'   => $head_data[0],
			);
			if ( ! empty( $head_data[1] ) ) {
				$header_component['example'] = array(
					'header_text' => $head_data[1][0][1],
				);
			}
			$body_component = array(
				'type' => 'BODY',
				'text' => $body_data[0],
			);
			if ( ! empty( $body_data[1] ) ) {
				$body_component['example'] = array(
					'body_text' => array( array_column( $body_data[1], 1 ) ),
				);
			}
			$footer_component = array(
				'type' => 'FOOTER',
				'text' => $footer,
			);

			$template['components'][] = $header_component;
			$template['components'][] = $body_component;
			$template['components'][] = $footer_component;

			$api      = new Order_Notifications_On_Whatsapp_For_Woocommerce_Api();
			$response = $api->update_whatsapp_template( $existing_id, $template );

			if ( 'success' == $response['status'] ) {
				$status = ( isset( $response['response']->success ) ) ? 'APPROVED' : 'PENDING';
				update_post_meta( $post_id, '_whatsapp_message_status', $status );

				delete_post_meta( $post_id, '_whatsapp_message_error' );
				delete_post_meta( $post_id, '_whatsapp_message_error_message' );
				delete_post_meta( $post_id, '_whatsapp_message_error_title' );
			} else {

				update_post_meta( $post_id, '_whatsapp_message_error', $response['response']->error );
				update_post_meta( $post_id, '_whatsapp_message_error_title', $response['response']->error->error_user_title );
				update_post_meta( $post_id, '_whatsapp_message_error_message', $response['response']->error->error_user_msg );
			}
		} else {

			if ( empty( $title ) ) {
				return;
			}

			$template = array(
				'name'     => $title,
				'language' => $language,
				'category' => 'UTILITY',
			);

			$template['components'] = array();
			$header_component       = array(
				'type'   => 'HEADER',
				'format' => 'TEXT',
				'text'   => $head_data[0],
			);
			if ( ! empty( $head_data[1] ) ) {
				$header_component['example'] = array(
					'header_text' => $head_data[1][0][1],
				);
			}
			$body_component = array(
				'type' => 'BODY',
				'text' => $body_data[0],
			);
			if ( ! empty( $body_data[1] ) ) {
				$body_component['example'] = array(
					'body_text' => array( array_column( $body_data[1], 1 ) ),
				);
			}
			$footer_component = array(
				'type' => 'FOOTER',
				'text' => $footer,
			);

			$template['components'][] = $header_component;
			$template['components'][] = $body_component;
			$template['components'][] = $footer_component;

			$api      = new Order_Notifications_On_Whatsapp_For_Woocommerce_Api();
			$response = $api->put_whatsapp_template( $template );

			if ( 'success' == $response['status'] ) {
				$id       = $response['response']->id;
				$status   = $response['response']->status;
				$category = $response['response']->category;

				update_post_meta( $post_id, '_whatsapp_message_id', $id );
				update_post_meta( $post_id, '_whatsapp_message_status', $status );
				update_post_meta( $post_id, '_whatsapp_message_category', $category );

				delete_post_meta( $post_id, '_whatsapp_message_error' );
				delete_post_meta( $post_id, '_whatsapp_message_error_title' );
				delete_post_meta( $post_id, '_whatsapp_message_error_message' );
			} else {
				delete_post_meta( $post_id, '_whatsapp_message_id' );
				delete_post_meta( $post_id, '_whatsapp_message_status' );
				delete_post_meta( $post_id, '_whatsapp_message_category' );

				update_post_meta( $post_id, '_whatsapp_message_error', $response['response']->error );
				update_post_meta( $post_id, '_whatsapp_message_error_title', $response['response']->error->error_user_title );
				update_post_meta( $post_id, '_whatsapp_message_error_message', $response['response']->error->error_user_msg );
			}
		}
	}

	/**
	 * Trigger template changes
	 *
	 * @since      1.0.0
	 * @param type $text Text.
	 * @return array $data Data.
	 */
	public function replace_placeholders_with_numbers( $text ) {
		preg_match_all( '@\[([^<>&/\[\]\x00-\x20=]++)@', $text, $matches );

		$found_tags            = array();
		$template_placeholders = onww_get_template_placeholders();

		if ( isset( $matches[1] ) && ! empty( $matches[1] ) ) {
			$i = 0;
			foreach ( $matches[1] as $tag ) {
				if ( isset( $template_placeholders[ $tag ] ) ) {
					$i++;
					$found_tags[] = array( $tag, $template_placeholders[ $tag ] );
					$text         = implode( '{{' . $i . '}}', explode( "[{$tag}]", $text, 2 ) );
				}
			}
		}
		$data = array( $text, $found_tags );
		return $data;
	}

	/**
	 * Display template error
	 *
	 * @since      1.0.0
	 * @global type $post Post.
	 * @global type $pagenow Pagenow.
	 * @global type $typenow Typenow.
	 */
	public function error_notice() {
		global $post;
		global $pagenow, $typenow;
		if ( $post ) {
			$current_post_type = get_post_type( $post );
			if ( 'whatsapp-templates' == $current_post_type && 'post.php' == $pagenow ) {
				$post_id          = $post->ID;
				$error            = get_post_meta( $post_id, '_whatsapp_message_error', true );
				$error_user_title = get_post_meta( $post_id, '_whatsapp_message_error_title', true );
				$error_user_msg   = get_post_meta( $post_id, '_whatsapp_message_error_message', true );
				if ( $error_user_msg ) {
					?>

					<div class="error notice">
						<p><b><?php echo esc_html( $error_user_title ); ?></b> <?php echo esc_html( $error_user_msg ); ?></p>
					</div>
					<?php
				} else {
					$message_id     = get_post_meta( $post_id, '_whatsapp_message_id', true );
					$message_status = get_post_meta( $post_id, '_whatsapp_message_status', true );
					if ( $message_id ) {
						if ( 'PENDING' == $message_status ) {
							?>
							<div class="notice-warning notice">
								<p><?php echo esc_html__( 'Your WhatsApp template is in Pendiing, Please don\'t edit.', 'automatic-order-printing-for-woocommerce' ); ?></p>
							</div>
							<?php
						} else {
							?>
							<div class="notice-warning notice">
								<p>
								<?php
									/* translators: %1$s message status */
									echo sprintf( esc_html__( 'Your WhatsApp template is in %s, Please don\'t edit.', 'automatic-order-printing-for-woocommerce' ), esc_html( $message_status ) );
								?>
									</p>
							</div>
							<?php
						}
					}
				}
			}
		}
	}

	/**
	 * Define which columns to show on this screen.
	 *
	 * @since      1.0.0
	 * @param array $columns Existing columns.
	 * @return array $new_columns New columns.
	 */
	public function define_columns( $columns ) {
		$new_columns = array();
		foreach ( $columns as $key => $val ) {
			$new_columns[ $key ] = $val;
			if ( 'title' == $key ) {
				$new_columns['status']        = esc_html__( 'Status', 'automatic-order-printing-for-woocommerce' );
				$new_columns['template_name'] = esc_html__( 'Template Name', 'automatic-order-printing-for-woocommerce' );
				$new_columns['template_id']   = esc_html__( 'Template ID', 'automatic-order-printing-for-woocommerce' );
			}
		}
		return $new_columns;
	}

	/**
	 * Render individual columns.
	 *
	 * @since      1.0.0
	 * @param string $column Column ID to render.
	 * @param int    $post_id Post ID being shown.
	 */
	public function render_columns( $column, $post_id ) {
		if ( 'status' == $column ) {
			$_whatsapp_message_status = get_post_meta( $post_id, '_whatsapp_message_status', true );
			echo esc_html( $_whatsapp_message_status );
		}
		if ( 'template_name' == $column ) {
			$template_name = get_post_meta( $post_id, 'template_name', true );
			echo esc_html( $template_name );
		}
		if ( 'template_id' == $column ) {
			$_whatsapp_message_id = get_post_meta( $post_id, '_whatsapp_message_id', true );
			echo esc_html( $_whatsapp_message_id );
		}

	}

	/**
	 * Check template status.
	 *
	 * @since      1.0.0
	 * @global string $pagenow Pagenow.
	 * @global string $typenow Typenow.
	 * @global object $wpdb Wpdb.
	 */
	public function check_template_status() {
		global $pagenow, $typenow;
		if ( empty( $typenow ) ) {
			if ( ! empty( $_GET['post'] ) ) {
				$post     = get_post( sanitize_text_field( wp_unslash( $_GET['post'] ) ) );
				$_typenow = $post->post_type;
			} else {
							$_typenow = $typenow;
			}
		} else {
			$_typenow = $typenow;
		}

		if ( is_admin() && ( ( ( 'post-new.php' == $pagenow ) || ( 'edit.php' == $pagenow ) ) && 'whatsapp-templates' == $_typenow ) ) {
			$api     = new Order_Notifications_On_Whatsapp_For_Woocommerce_Api();
			$results = $api->get_whatsapp_templates();
			global $wpdb;
			if ( $results ) {
				foreach ( $results as $template ) {
					$id      = $template->id;
					$status  = $template->status;
					$post_id = $wpdb->get_var( $wpdb->prepare( "select post_id from $wpdb->postmeta where meta_key = %s and meta_value = %s", array( '_whatsapp_message_id', $id ) ) );
					if ( $post_id ) {
						update_post_meta( $post_id, '_whatsapp_message_status', $status );
						update_post_meta( $post_id, '_whatsapp_template', $template );
						update_post_meta( $post_id, 'template_language', $template->language );
					}
				}
			}
		}
	}

	/**
	 * Get next template.
	 *
	 * @since      1.0.0
	 * @global object $wpdb
	 * @return boolean
	 */
	public function get_next_template_to_map() {
		$api     = new Order_Notifications_On_Whatsapp_For_Woocommerce_Api();
		$results = $api->get_whatsapp_templates( true );
		global $wpdb;
		if ( $results ) {
			foreach ( $results as $template ) {
				$id      = $template->id;
				$post_id = $wpdb->get_var( $wpdb->prepare( "select post_id from $wpdb->postmeta where meta_key = %s and meta_value = %s", array( '_whatsapp_message_id', $id ) ) );
				if ( ! $post_id ) {
					return $template;
				}
			}
		}
		return false;
	}

	/**
	 * Fetch templates.
	 *
	 * @since      1.0.0
	 */
	public function fetch_templates() {
		ob_start();
		check_ajax_referer( 'onww-fetch-templates-nonce', 'security' );
		$api      = new Order_Notifications_On_Whatsapp_For_Woocommerce_Api();
		$results  = $api->get_whatsapp_templates();
		$template = $this->get_next_template_to_map();

		if ( $template ) {
			$template_placeholders = onww_get_template_placeholders();
			require ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_DIR . '/admin/partials/order-notifications-on-whatsapp-for-woocommerce-edit-template.php';
		} else {
			esc_html__( 'No Templates Found.', 'automatic-order-printing-for-woocommerce' );
		}

		$data = ob_get_clean();

		wp_send_json_success( array( 'popup_html' => $data ) );
		die();
	}

	/**
	 * Update template  variables.
	 *
	 * @since      1.0.0
	 */
	public function template_map_variables_update() {
		check_ajax_referer( 'onww-update-template-nonce', '_wpnonce' );
		$template_id = isset( $_POST['template_id'] ) ? sanitize_text_field( wp_unslash( $_POST['template_id'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( ! empty( $template_id ) ) {
			$api      = new Order_Notifications_On_Whatsapp_For_Woocommerce_Api();
			$template = $api->get_whatsapp_template( $template_id );

			$header_parms = isset( $_POST['onww-template-header-parms'] ) ? wp_unslash( array_map( 'sanitize_text_field', $_POST['onww-template-header-parms'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$body_parms   = isset( $_POST['onww-template-body-parms'] ) ? wp_unslash( array_map( 'sanitize_text_field', $_POST['onww-template-body-parms'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

			$template_name   = '';
			$template_header = '';
			$template_body   = '';
			$template_footer = '';
			$language        = '';

			if ( $template ) {
				$status        = $template->status;
				$$category     = $template->category;
				$template_name = $template->name;
				$language      = $template->language;
				if ( isset( $template->components ) ) {
					foreach ( $template->components as $component ) {
						if ( 'HEADER' == $component->type ) {
							$template_header  = $component->text;
							$head_param_count = substr_count( $template_header, '{{' );
							if ( $head_param_count ) {
								$template_header = str_replace( '{{1}}', '[' . $header_parms[0] . ']', $template_header );
							}
						}

						if ( 'BODY' == $component->type ) {
							$template_body    = $component->text;
							$body_param_count = substr_count( $template_body, '{{' );
							$i                = 0;
							for ( $bpc = 1; $bpc <= $body_param_count; $bpc++ ) {
								$template_body = str_replace( '{{' . $bpc . '}}', '[' . $body_parms[ $i ] . ']', $template_body );
								$i++;
							}
						}

						if ( 'FOOTER' == $component->type ) {
							$template_footer = $component->text;
						}
					}
				}

				$post_title = ucfirst( str_replace( '_', ' ', $template_name ) );
				$my_post    = array(
					'post_title'   => $post_title,
					'post_content' => '',
					'post_type'    => 'whatsapp-templates',
					'post_status'  => 'publish',
				);

				$post_id = wp_insert_post( $my_post );

				update_post_meta( $post_id, 'template_name', $template_name );
				update_post_meta( $post_id, 'template_header', $template_header );
				update_post_meta( $post_id, 'template_body', $template_body );
				update_post_meta( $post_id, 'template_footer', $template_footer );
				update_post_meta( $post_id, '_whatsapp_template', $template );

				update_post_meta( $post_id, 'template_header_parms', $header_parms );
				update_post_meta( $post_id, 'template_body_parms', $body_parms );

				update_post_meta( $post_id, '_whatsapp_message_id', $template_id );
				update_post_meta( $post_id, '_whatsapp_message_status', $status );
				update_post_meta( $post_id, '_whatsapp_message_category', $category );
				update_post_meta( $post_id, 'template_language', $language );
			}
		}
		die();
	}

}
