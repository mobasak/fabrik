<?php
/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */
class Order_Notifications_On_Whatsapp_For_Woocommerce {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @var      Order_Notifications_On_Whatsapp_For_Woocommerce_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_VERSION' ) ) {
			$this->version = ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'order-notifications-on-whatsapp-for-woocommerce';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

		add_filter( 'plugin_action_links_' . ORDER_NOTIFICATIONS_ON_WHATSAPP_FOR_WOOCOMMERCE_BASENAME, array( $this, 'plugin_page_settings_link' ), 10, 1 );
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Order_Notifications_On_Whatsapp_For_Woocommerce_Loader. Orchestrates the hooks of the plugin.
	 * - Order_Notifications_On_Whatsapp_For_Woocommerce_i18n. Defines internationalization functionality.
	 * - Order_Notifications_On_Whatsapp_For_Woocommerce_Admin. Defines all hooks for the admin area.
	 * - Order_Notifications_On_Whatsapp_For_Woocommerce_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 */
	private function load_dependencies() {

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'vendor/cmb2/cmb2/init.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'vendor/cmb2-conditionals/cmb2-conditionals.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'vendor/cmb-field-select2/cmb-field-select2.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'vendor/cmb2-radio-image/cmb2-radio-image.php';

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce-i18n.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce-api.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce-notifications.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce-cpt.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-order-notifications-on-whatsapp-for-woocommerce-template.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-order-notifications-on-whatsapp-for-woocommerce-admin.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-order-notifications-on-whatsapp-for-woocommerce-settings.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-order-notifications-on-whatsapp-for-woocommerce-public.php';

		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/order-notifications-on-whatsapp-for-woocommerce-functions.php';

		$this->loader = new Order_Notifications_On_Whatsapp_For_Woocommerce_Loader();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Order_Notifications_On_Whatsapp_For_Woocommerce_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 */
	private function set_locale() {

		$plugin_i18n = new Order_Notifications_On_Whatsapp_For_Woocommerce_I18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Order_Notifications_On_Whatsapp_For_Woocommerce_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		$plugin_cpt = new Order_Notifications_On_Whatsapp_For_Woocommerce_Cpt( $this->get_plugin_name(), $this->get_version() );
		$GLOBALS['Order_Notifications_On_Whatsapp_For_Woocommerce_Cpt'] = $plugin_cpt;

		$plugin_settings = new Order_Notifications_On_Whatsapp_For_Woocommerce_Settings( $this->get_plugin_name(), $this->get_version() );

		$plugin_notifications = new Order_Notifications_On_Whatsapp_For_Woocommerce_Notifications( $this->get_plugin_name(), $this->get_version() );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 */
	private function define_public_hooks() {

		$plugin_public = new Order_Notifications_On_Whatsapp_For_Woocommerce_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Order_Notifications_On_Whatsapp_For_Woocommerce_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
				return time();
		return $this->version;
	}

	/**
	 * Plugin page settings.
	 *
	 * @since   1.0.0
	 * @param       Array $links  Plugin Settings page link.
	 * @return      Array $links       Plugin Settings page link.
	 */
	public function plugin_page_settings_link( $links ) {

		$action_links = array(
			'settings' => '<a href="' . admin_url( 'admin.php?page=order_notifications_on_whatsapp_for_woocommerce' ) . '" aria-label="' . esc_attr__( 'View settings', 'order-notifications-on-whatsapp-for-woocommerce' ) . '">' . esc_html__( 'Settings', 'order-notifications-on-whatsapp-for-woocommerce' ) . '</a>',
		);

		return array_merge( $action_links, $links );
	}

}
