<?php
/**
 * The api-specific functionality of the plugin.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */

/**
 * The api-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */
class Order_Notifications_On_Whatsapp_For_Woocommerce_Api {

	/**
	 * The settings of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $settings;

	/**
	 * The API url.
	 *
	 * @since    1.0.0
	 * @var      string    $url    The API Url.
	 */
	private $url = 'https://graph.facebook.com/v19.0/';

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		$this->settings = get_option( 'order_notifications_on_whatsapp_for_woocommerce' );
	}

	/**
	 * Update WhatsApp template.
	 *
	 * @since    1.0.0
	 * @param      string $template_id       The template id.
	 * @param      array  $template    The template.
	 * @return  array
	 */
	public function update_whatsapp_template( $template_id, $template ) {
		$business_account_id = $this->settings['whatsapp_business_account_id'];
		$token               = $this->settings['api_token'];
		$url                 = $this->url . "{$template_id}";

		$response = wp_safe_remote_post(
			$url,
			array(
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => "Bearer {$token}",
				),
				'body'    => wp_json_encode( $template ),
				'method'  => 'POST',
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$response_code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 == $response_code ) {
			$response = json_decode( wp_remote_retrieve_body( $response ) );
			return array(
				'status'   => 'success',
				'response' => $response,
			);
		}

		$response = json_decode( wp_remote_retrieve_body( $response ) );
		return array(
			'status'   => 'failed',
			'response' => $response,
		);
	}

	/**
	 * Put WhatsApp template.
	 *
	 * @since    1.0.0
	 * @param      array $template    The template.
	 * @return  array
	 */
	public function put_whatsapp_template( $template ) {
			add_filter(
				'http_request_timeout',
				function( $timeout ) {
					return 60;
				}
			);

		$business_account_id = $this->settings['whatsapp_business_account_id'];
		$token               = $this->settings['api_token'];
		$url                 = $this->url . "{$business_account_id}/message_templates";

		$response = wp_safe_remote_post(
			$url,
			array(
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => "Bearer {$token}",
				),
				'body'    => wp_json_encode( $template ),
				'method'  => 'POST',
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$response_code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 == $response_code ) {
			$response = json_decode( wp_remote_retrieve_body( $response ) );
			return array(
				'status'   => 'success',
				'response' => $response,
			);
		}

		$response = json_decode( wp_remote_retrieve_body( $response ) );
		return array(
			'status'   => 'failed',
			'response' => $response,
		);
	}

	/**
	 * Get WhatsApp templates.
	 *
	 * @since    1.0.0
	 * @param      bool $cache    Cache.
	 * @return  array|bool
	 */
	public function get_whatsapp_templates( $cache = false ) {

		if ( true == $cache ) {
			$message_templates = get_transient( 'onww_whatsapp_message_templates' );
			if ( $message_templates ) {
				return $message_templates;
			}
		}

		$business_account_id = $this->settings['whatsapp_business_account_id'];
		$token               = $this->settings['api_token'];
		$url                 = $this->url . "{$business_account_id}/message_templates";

		$response = wp_safe_remote_get(
			$url,
			array(
				'headers' => array(
					'Authorization' => "Bearer {$token}",
				),
				'method'  => 'GET',
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$response_code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 == $response_code ) {
			$response = json_decode( wp_remote_retrieve_body( $response ) );
			set_transient( 'onww_whatsapp_message_templates', $response->data, HOUR_IN_SECONDS );

			return $response->data;
		}

		return false;
	}

	/**
	 * Get WhatsApp template by id.
	 *
	 * @since    1.0.0
	 * @param      string $template_id    Template id.
	 * @return  array $selected_template Selected template.
	 */
	public function get_whatsapp_template( $template_id ) {
		$templates         = $this->get_whatsapp_templates();
		$selected_template = false;
		if ( $templates ) {
			foreach ( $templates as $template ) {
				if ( $template_id == $template->id ) {
					$selected_template = $template;
					break;
				}
			}
		}
		return $selected_template;
	}

	/**
	 * Send WhatsApp message.
	 *
	 * @since    1.0.0
	 * @param      string $mobile    Mobile.
	 * @param  string $message Message.
	 * @return  array|bool
	 */
	public function send_message( $mobile, $message ) {
		$phone_number_id = $this->settings['whatsapp_phone_number_id'];
		$token           = $this->settings['api_token'];
		$url             = $this->url . "{$phone_number_id}/messages";

		$token = 'Bearer ' . $token;

		$args = array(
			'messaging_product' => 'whatsapp',
			'recipient_type'    => 'individual',
			'to'                => $mobile,
			'type'              => 'text',
			'text'              => array( 'body' => $message ),
		);

		$args = wp_json_encode( $args );

		$response = wp_safe_remote_post(
			$url,
			array(
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => $token,
				),
				'body'    => $args,
				'method'  => 'POST',
			)
		);

		$response_code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 == $response_code ) {
			$response = json_decode( wp_remote_retrieve_body( $response ) );

			return array( 'status' => 'success' );
		} else {
			$response = json_decode( wp_remote_retrieve_body( $response ) );

			return array(
				'status'        => 'failed',
				'error_code'    => $response->error->code,
				'error_message' => $response->error->message,
			);
		}

		return false;
	}

	/**
	 * Send WhatsApp template message.
	 *
	 * @since    1.0.0
	 * @param      string $mobile    Mobile.
	 * @param  string $template Template Message.
	 * @return  array|bool
	 */
	public function send_template_message( $mobile, $template ) {
		$phone_number_id = $this->settings['whatsapp_phone_number_id'];
		$token           = $this->settings['api_token'];
		$url             = $this->url . "{$phone_number_id}/messages";

		$token = 'Bearer ' . $token;

		$args = array(
			'messaging_product' => 'whatsapp',
			'to'                => $mobile,
			'type'              => 'template',
			'template'          => $template,
		);

		$args = wp_json_encode( $args );

		$response = wp_safe_remote_post(
			$url,
			array(
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => $token,
				),
				'body'    => $args,
				'method'  => 'POST',
			)
		);

		$response_code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 == $response_code ) {
			$response = json_decode( wp_remote_retrieve_body( $response ) );

			return array( 'status' => 'success' );
		} else {
			$response = json_decode( wp_remote_retrieve_body( $response ) );

			return array(
				'status'        => 'failed',
				'error_code'    => $response->error->code,
				'error_message' => $response->error->message,
			);
		}

		return false;
	}

}
