<?php
/**
 * The template-specific functionality of the plugin.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */

/**
 * The api-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */
class Order_Notifications_On_Whatsapp_For_Woocommerce_Template {

	/**
	 * The settings of this plugin.
	 *
	 * @since    1.0.0
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $settings;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		$this->settings = get_option( 'order_notifications_on_whatsapp_for_woocommerce' );
	}

	/**
	 * Preview template message.
	 *
	 * @since    1.0.0
	 * @param int   $template_id Template id.
	 * @param mixed $order Order.
	 * @return string $template_message Template message.
	 */
	public function preview_template_message( $template_id, $order ) {
		$saved_template = $this->get_local_template( $template_id );
		if ( $saved_template ) {
			$_whatsapp_template = $saved_template['_whatsapp_template'];
			$process_template   = $this->process_template( $template_id, $order );

			$template_header = $saved_template['template_header'];
			$template_body   = $saved_template['template_body'];
			$template_footer = $saved_template['template_footer'];

			$template_message = $template_header . PHP_EOL . $template_body . PHP_EOL . $template_footer;

			$placeholders = onww_get_template_placeholders();
			foreach ( $placeholders as $placeholder => $name ) {
				if ( false != strpos( $template_message, $placeholder ) ) {
					$process_param    = $this->process_param( $placeholder, $order );
					$process_param    = str_replace( '\n', PHP_EOL, $process_param );
					$template_message = str_replace( '[' . $placeholder . ']', $process_param, $template_message );
				}
			}

			return $template_message;
		}
		return '';
	}

	/**
	 * Process message.
	 *
	 * @since    1.0.0
	 * @param string $message Message.
	 * @param mixed  $order Order.
	 * @return string $message Message.
	 */
	public function process_message( $message, $order ) {
		$placeholders = onww_get_template_placeholders();
		foreach ( $placeholders as $placeholder => $name ) {
			if ( false != strpos( $message, $placeholder ) ) {
				$process_param = $this->process_param( $placeholder, $order );
				$process_param = str_replace( '\n', PHP_EOL, $process_param );
				$message       = str_replace( '[' . $placeholder . ']', $process_param, $message );
			}
		}
		return $message;
	}

	/**
	 * Process template.
	 *
	 * @since    1.0.0
	 *
	 * @param int   $template_id Template id.
	 * @param mixed $order Order.
	 * @return string|array $whatsapp_template WhatsApp Template.
	 */
	public function process_template( $template_id, $order ) {

		$saved_template = $this->get_local_template( $template_id );

		if ( $saved_template ) {
			$template_name     = $saved_template['template_name'];
			$template_language = $saved_template['template_language'];
			$_header_params    = $saved_template['template_header_parms'];
			$_body_params      = $saved_template['template_body_parms'];

			$header_params = array();
			$body_params   = array();

			if ( ! empty( $_header_params ) ) {
				$_header_params = maybe_unserialize( $_header_params );
				foreach ( $_header_params as $param ) {
					$process_param   = $this->process_param( $param, $order );
					$header_params[] = array(
						'type' => 'text',
						'text' => "$process_param",
					);
				}
			}

			if ( ! empty( $_body_params ) ) {
				$_body_params = maybe_unserialize( $_body_params );
				foreach ( $_body_params as $param ) {
					$process_param = $this->process_param( $param, $order );
					$body_params[] = array(
						'type' => 'text',
						'text' => "$process_param",
					);
				}
			}

			$whatsapp_template = array(
				'name'       => $template_name,
				'language'   => array( 'code' => $template_language ),
				'components' => array(
					array(
						'type'       => 'header',
						'parameters' => $header_params,
					),
					array(
						'type'       => 'body',
						'parameters' => $body_params,
					),
				),
			);
			return $whatsapp_template;
		}
		return '';
	}

	/**
	 * Get local template.
	 *
	 * @since    1.0.0
	 * @param int $post_id Post ID.
	 * @return array $template Template.
	 */
	public function get_local_template( $post_id ) {
		$post = get_post( $post_id );
		if ( $post ) {
			$template = array( 'post_id' => $post_id );
			$keys     = array(
				'_whatsapp_message_id',
				'template_name',
				'template_header',
				'template_body',
				'template_footer',
				'template_language',
				'template_header_parms',
				'template_body_parms',
				'_whatsapp_template',
			);
			foreach ( $keys as $key ) {
				$template[ $key ] = get_post_meta( $post_id, $key, true );
			}
		}
		return $template;
	}

	/**
	 * Process params.
	 *
	 * @since    1.0.0
	 * @param string $param Param.
	 * @param mixed  $order Order.
	 * @return string $processed_parm Processed parm.
	 */
	public function process_param( $param, $order ) {
				$param  = ( is_array( $param ) && ! empty( $param[0] ) ) ? $param[0] : $param;
		$processed_parm = '';
		switch ( $param ) {
			case 'customer_first_name':
				$processed_parm = $order->get_billing_first_name();
				break;
			case 'customer_last_name':
				$processed_parm = $order->get_billing_last_name();
				break;
			case 'customer_full_name':
				$processed_parm = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
				break;
			case 'customer_email':
				$processed_parm = $order->get_billing_email();
				break;
			case 'customer_phone':
				$processed_parm = $order->get_billing_phone();
				break;
			case 'payment_method':
				$processed_parm = $order->get_payment_method_title();
				break;
			case 'customer_billing_address':
				// $processed_parm = $order->get_formatted_billing_address( esc_html__( 'N/A', 'order-notifications-on-whatsapp-for-woocommerce' ) );
								$raw_address    = apply_filters( 'woocommerce_order_formatted_billing_address', $order->get_address( 'billing' ), $order );
								$processed_parm = WC()->countries->get_formatted_address( $raw_address, ', ' );
				break;
			case 'customer_shipping_address':
				// $processed_parm = $order->get_formatted_shipping_address( esc_html__( 'N/A', 'order-notifications-on-whatsapp-for-woocommerce' ) );
								$raw_address    = apply_filters( 'woocommerce_order_formatted_billing_address', $order->get_address( 'shipping' ), $order );
								$processed_parm = WC()->countries->get_formatted_address( $raw_address, ', ' );
				break;
			case 'order_items':
				$order_item_data = array();
				foreach ( $order->get_items() as $item ) {
					$order_item        = $item->get_name() . ' x ' . $item->get_quantity() . ' (' . wc_price( $item->get_total() ) . ')';
					$order_item_data[] = sanitize_textarea_field( $order_item );
				}

				$processed_parm = implode( ', ', $order_item_data );
				break;
			case 'order_total':
				$processed_parm = strip_tags( wc_price( $order->get_total() ) );
				break;
			case 'order_id':
				$processed_parm = $order->get_id();
				break;
			case 'order_time':
				$processed_parm = wc_format_datetime( $order->get_date_created(), wc_time_format() );
				break;
			case 'order_date':
				$processed_parm = wc_format_datetime( $order->get_date_created() );
				break;
			case 'order_status':
				$processed_parm = wc_get_order_status_name( $order->get_status() );
				break;
			case 'site_name':
				$processed_parm = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
				break;
			case 'admin_email':
				$processed_parm = get_option( 'admin_email' );
				break;
		}

		$processed_parm = preg_replace( '#<br\s*/?>#i', ', ', $processed_parm );

		$processed_parm = html_entity_decode( $processed_parm, ENT_QUOTES, get_bloginfo( 'charset' ) );
		$processed_parm = apply_filters( 'order_notifications_on_whatsapp_for_woocommerce_whatsapp_processed_parm', $processed_parm, $param, $order );
		return $processed_parm;
	}

}


