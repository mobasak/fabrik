<?php
/**
 * The plugin functionality.
 *
 * @link       https://procomsoftsol.com
 * @since      1.0.0
 *
 * @package    Order_Notifications_On_Whatsapp_For_Woocommerce
 * @subpackage Order_Notifications_On_Whatsapp_For_Woocommerce/includes
 */

/**
 * Returns template placeholders.
 *
 * @since     1.0.0
 * @return arry $placeholders
 */
function onww_get_template_placeholders() {
	$placeholders = array(
		'customer_first_name'       => esc_html__( 'Customer First Name', 'automatic-order-printing-for-woocommerce' ),
		'customer_last_name'        => esc_html__( 'Customer Last Name', 'automatic-order-printing-for-woocommerce' ),
		'customer_full_name'        => esc_html__( 'Customer Full Name', 'automatic-order-printing-for-woocommerce' ),
		'customer_email'            => esc_html__( 'Customer Email', 'automatic-order-printing-for-woocommerce' ),
		'customer_phone'            => esc_html__( 'Customer Phone', 'automatic-order-printing-for-woocommerce' ),
		'payment_method'            => esc_html__( 'Payment Method Name', 'automatic-order-printing-for-woocommerce' ),
		'customer_billing_address'  => esc_html__( 'Customer Billing Address', 'automatic-order-printing-for-woocommerce' ),
		'customer_shipping_address' => esc_html__( 'Customer Shipping Address', 'automatic-order-printing-for-woocommerce' ),
		'order_items'               => esc_html__( 'Order Items', 'automatic-order-printing-for-woocommerce' ),
		'order_total'               => esc_html__( 'Order Total', 'automatic-order-printing-for-woocommerce' ),
		'order_id'                  => esc_html__( 'Order Id', 'automatic-order-printing-for-woocommerce' ),
		'order_time'                => esc_html__( 'Order Time', 'automatic-order-printing-for-woocommerce' ),
		'order_date'                => esc_html__( 'Order Date', 'automatic-order-printing-for-woocommerce' ),
		'order_status'              => esc_html__( 'Order Status', 'automatic-order-printing-for-woocommerce' ),
		'site_name'                 => esc_html__( 'Site Name', 'automatic-order-printing-for-woocommerce' ),
		'admin_email'               => esc_html__( 'Admin Email', 'automatic-order-printing-for-woocommerce' ),
	);
	$placeholders = apply_filters( 'order_notifications_on_whatsapp_for_woocommerce_get_template_placeholders', $placeholders );
	return $placeholders;
}
