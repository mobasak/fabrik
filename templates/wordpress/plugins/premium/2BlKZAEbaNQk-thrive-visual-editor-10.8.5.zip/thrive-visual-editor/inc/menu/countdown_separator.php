<div id="tve-countdown_separator-component" class="tve-component" data-view="CountdownSeparator">
	<div class="dropdown-header" data-prop="docked">
		<div class="group-description"><?php echo esc_html__( 'Main Options', 'thrive-cb' ); ?></div>
		<i></i>
	</div>
	<div class="dropdown-content">
		<div class="tve-control mb-10" data-view="Separator"></div>
	</div>
</div>
