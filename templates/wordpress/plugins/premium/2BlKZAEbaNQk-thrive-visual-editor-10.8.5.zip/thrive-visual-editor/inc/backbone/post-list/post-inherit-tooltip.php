<div class="control-grid full-width pb-0">
	<span>
		<?php echo esc_html__( 'Thrive Landing Pages can only inherit theme fonts if you have Thrive Theme Builder active on your site.', 'thrive-cb' ); ?>
	</span>
</div>