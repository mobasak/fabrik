const constants = {
	ITEMS_PER_PAGE: 10,
};

module.exports = constants;
