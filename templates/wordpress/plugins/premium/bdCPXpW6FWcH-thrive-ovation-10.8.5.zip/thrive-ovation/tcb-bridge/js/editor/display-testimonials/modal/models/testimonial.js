module.exports = Backbone.Model.extend( {
	idAttribute: 'ID',
	urlRoot: '',
	defaults: {
		order: 0,
	},
} );
