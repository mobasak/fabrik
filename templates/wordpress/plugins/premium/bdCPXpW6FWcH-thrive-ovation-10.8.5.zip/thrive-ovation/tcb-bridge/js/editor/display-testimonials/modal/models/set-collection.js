module.exports = Backbone.Collection.extend( {
	model: require( './set' ),
} );
