<div id="tvo-modal-edit-testimonial" class="tvd-modal" style="max-width: inherit;">
	<iframe width="100%" height="557px" data-source="<?php echo admin_url( 'admin-ajax.php?action=testimonial_iframe&comment_id=' ); ?>" src=""></iframe>
</div>
<a href="#tvo-modal-edit-testimonial" id="tvo-modal-edit-testimonial-trigger" class="modal-trigger" style="display: none"></a>

<div class="tvd-modal-preloader tvo-hide">
	<div class="tvd-preloader-wrapper tvd-big tvd-active">
		<div class="tvd-spinner-layer tvd-spinner-blue-only">
			<div class="tvd-circle-clipper tvd-left">
				<div class="tvd-circle"></div>
			</div>
			<div class="tvd-gap-patch">
				<div class="tvd-circle"></div>
			</div>
			<div class="tvd-circle-clipper tvd-right">
				<div class="tvd-circle"></div>
			</div>
		</div>
	</div>
</div>
<div class="tvd-lean-overlay"></div>
