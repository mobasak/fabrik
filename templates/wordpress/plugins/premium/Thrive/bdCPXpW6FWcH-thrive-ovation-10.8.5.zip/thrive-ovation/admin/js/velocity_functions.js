/**
 * Created by Ovidiu on 6/7/2016.
 */
// Required for Meteor package, the use of window prevents export by Meteor
(function ( window ) {
	if ( window.Package ) {
		Materialize = {};
	} else {
		window.Materialize = {};
	}
})( window );


// Unique ID
Materialize.guid = (function () {
	function s4() {
		return Math.floor( (1 + Math.random()) * 0x10000 )
		           .toString( 16 )
		           .substring( 1 );
	}

	return function () {
		return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
		       s4() + '-' + s4() + s4() + s4();
	};
})();

Materialize.elementOrParentIsFixed = function ( element ) {
	var $element = $( element );
	var $checkElements = $element.add( $element.parents() );
	var isFixed = false;
	$checkElements.each( function () {
		if ( $( this ).css( "position" ) === "fixed" ) {
			isFixed = true;
			return false;
		}
	} );
	return isFixed;
};

// Velocity has conflicts when loaded with jQuery, this will check for it
var Vel;
if ( jQuery ) {
	Vel = jQuery.Velocity;
} else {
	Vel = Velocity;
}
