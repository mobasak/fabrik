import { useBlockProps } from '@wordpress/block-editor';

export default function save() {
    return null; // Dynamic block, rendered by PHP
} 